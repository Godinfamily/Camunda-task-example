# language: pl
# Scenariusze profilu „flota” — własność zespołu floty. Świat testowy: specs/README.md.
# Procesy: rejestracja-samochodu (główny) i opiniowanie-rejestracji (podrzędny, zadanie wielokrotne „Opinia komórki”).
Funkcja: Opiniowanie rejestracji samochodu przez komórki banku
  Jako komórka banku (IT, HR, Prawny, Finanse, Ryzyko)
  Chcę wydać opinię o wniosku o samochód służbowy w swoim zakresie
  Aby decydent przydzielał samochody na podstawie opinii wszystkich komórek

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz sprawa "F-0012" procesu "rejestracja-samochodu" wnioskodawcy "tomasz" z modelem "Toyota Corolla Touring Sports 1.8 Hybrid" przeszła weryfikację wniosku
    Oraz proces "opiniowanie-rejestracji" utworzył w sprawie "F-0012" zadania "Opinia komórki" dla grup:
      | grupa                |
      | flota-opinia-it      |
      | flota-opinia-hr      |
      | flota-opinia-prawny  |
      | flota-opinia-finanse |
      | flota-opinia-ryzyko  |

  @FLO-FR-04
  Szablon scenariusza: Każda komórka widzi tylko swoje zadanie opinii
    Jeżeli "<osoba>" otwiera listę "Do przejęcia"
    Wtedy lista zawiera zadanie "Opinia komórki" grupy "<grupa>" w sprawie "F-0012"
    Ale lista nie zawiera zadań "Opinia komórki" pozostałych grup

    Przykłady:
      | osoba | grupa                |
      | igor  | flota-opinia-it      |
      | hanna | flota-opinia-hr      |
      | lena  | flota-opinia-prawny  |
      | filip | flota-opinia-finanse |
      | rafal | flota-opinia-ryzyko  |

  @FLO-FR-04
  Scenariusz: Komórka nie przejmie zadania innej komórki
    Jeżeli "igor" przejmuje zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Denied" i kodem "R2"

  @FLO-FR-04
  Scenariusz: Opinię zapisuje i kończy tylko assignee
    Zakładając "hanna" przejęła zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Jeżeli "wiktor" zapisuje szkic tego zadania
    Wtedy operacja jest odrzucona regułą "R1"

  @FLO-FR-04
  Scenariusz: Opinia trafia do dziennika z rolą projektową, a sprawa czeka na pozostałe komórki
    Zakładając "hanna" przejęła zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Jeżeli "hanna" kończy to zadanie z opinią "warunkowa" i warunkiem "samochód kategorii B zamiast A"
    Wtedy dziennik bezpieczeństwa zawiera "Task.Complete" z wynikiem "Succeeded", rolą "flota/opiniujacy" i profilem "flota"
    Oraz rejestr opinii profilu "flota" zawiera opinię komórki "hr" w sprawie "F-0012"
    Oraz sprawa "F-0012" pozostaje w etapie "Opiniowanie" z 4 otwartymi zadaniami "Opinia komórki"

  @FLO-FR-04
  Szablon scenariusza: Rekomendacja wynika z opinii wszystkich komórek
    Zakładając komórki wydały w sprawie "F-0012" opinie: <opinie>
    Jeżeli proces "opiniowanie-rejestracji" kończy się
    Wtedy rekomendacja w sprawie "F-0012" to "<rekomendacja>"
    Oraz sprawa "F-0012" przechodzi do etapu "Decyzja" z zadaniem "Decyzja o przydziale samochodu" dla grupy "flota-decydenci"

    Przykłady:
      | opinie                                                                            | rekomendacja |
      | IT pozytywna, HR pozytywna, Prawny pozytywna, Finanse pozytywna, Ryzyko pozytywna | pozytywna    |
      | IT pozytywna, HR warunkowa, Prawny pozytywna, Finanse pozytywna, Ryzyko pozytywna | warunkowa    |
      | IT pozytywna, HR warunkowa, Prawny pozytywna, Finanse negatywna, Ryzyko pozytywna | negatywna    |

  @FLO-FR-04
  Scenariusz: Brak opinii w terminie eskaluje sprawę
    Zakładając zadanie "Opinia komórki" grupy "flota-opinia-prawny" w sprawie "F-0012" jest otwarte
    Jeżeli uruchamia się zdarzenie "TerminOpiniiPrzekroczony" z poziomem eskalacji 1
    Wtedy lista eskalowanych osoby "wiktor" zawiera sprawę "F-0012" z etapem "Opiniowanie" i poziomem 1

  @FLO-FR-05
  Scenariusz: Decydent widzi zestawienie opinii, a odczyt wrażliwy trafia do dziennika
    Zakładając sprawa "F-0012" jest w etapie "Decyzja" z opiniami wszystkich komórek
    Oraz zadanie "Decyzja o przydziale samochodu" w sprawie "F-0012" jest przypisane do "jan"
    Jeżeli "jan" pobiera szczegóły tego zadania
    Wtedy widok zawiera sekcję "extensions.flota" z 5 opiniami komórek
    Oraz dziennik bezpieczeństwa zawiera "flota.OpinionsSummary" z wynikiem "Succeeded", rolą "flota/decydent-floty" i profilem "flota"
    Ale wpis dziennika nie zawiera treści uzasadnień opinii

  @FLO-FR-05
  Scenariusz: Opiniujący nie widzi opinii innych komórek
    Jeżeli "hanna" pobiera szczegóły zadania "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Wtedy widok nie zawiera sekcji "extensions.flota"

  @FLO-FR-05
  Scenariusz: Cenę i termin dostawy sprawdza tylko assignee zadania decyzji
    Zakładając zadanie "Decyzja o przydziale samochodu" w sprawie "F-0012" jest przypisane do "jan"
    Oraz system zakupowy zwraca dla modelu "Toyota Corolla Touring Sports 1.8 Hybrid" cenę netto 116900 i termin dostawy "2026-12-15"
    Jeżeli "jan" wykonuje operację "flota.CheckDeliveryTerms" na tym zadaniu
    Wtedy szkic zadania zawiera "cenaAktualna" równe 116900 i "terminDostawy" równe "2026-12-15"
    Ale "wiktor" pobierający szczegóły tego zadania nie widzi akcji "flota.CheckDeliveryTerms"
