# language: pl
# Scenariusze profilu „flota” — własność zespołu floty. Świat testowy: specs/README.md.
# Dedykowane elementy: sekcja nawigacji „Flota”, trasa /p/flota/katalog, zapytanie flota.CarCatalog,
# operacje na danych profilu flota.SaveCatalogItem i flota.WithdrawCatalogItem (profile-action, ADR-017),
# źródło danych formatki flota.CarModels.
Funkcja: Katalog samochodów widoczny i prowadzony wyłącznie w profilu „flota”
  Jako administrator katalogu samochodów
  Chcę prowadzić w aplikacji katalog modeli dostępnych do zakupu
  Aby wnioskodawcy wybierali tylko samochody zgodne z polityką floty, a inne projekty nie widziały katalogu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz katalog floty zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid" w kategorii "B" ze statusem "dostępny"
    Oraz katalog floty zawiera model "Skoda Octavia Combi 2.0 TDI" w kategorii "B" ze statusem "wycofany"
    Oraz limit emisji CO2 w polityce floty wynosi 130 g/km

  @FLO-FR-01
  Szablon scenariusza: Katalog i sekcję nawigacji „Flota” widzą tylko role profilu
    Jeżeli "<osoba>" otwiera trasę "/p/flota/katalog"
    Wtedy wynik to "<wynik>"
    Oraz sekcja nawigacji "Flota" jest <sekcja> dla "<osoba>"

    Przykłady:
      | osoba  | kto                                      | wynik                                 | sekcja      |
      | tomasz | wnioskodawca (flota)                     | Allowed: flota/wnioskodawca           | widoczna    |
      | hanna  | opiniująca komórki HR (flota)            | Allowed: flota/opiniujacy             | widoczna    |
      | karol  | administrator katalogu (flota)           | Allowed: flota/administrator-katalogu | widoczna    |
      | anna   | analityk kredytowy (kredyty)             | Denied: brak uprawnienia              | niewidoczna |
      | adam   | administrator procesów kredytowych       | Denied: brak uprawnienia              | niewidoczna |
      | olga   | audytor (rola globalna)                  | Denied: brak uprawnienia              | niewidoczna |

  @FLO-FR-01
  Scenariusz: Wejście na stronę katalogu spoza profilu jest odmową zapisaną w dzienniku
    Jeżeli "anna" otwiera trasę "/p/flota/katalog"
    Wtedy dziennik bezpieczeństwa zawiera "flota.CarCatalog" z wynikiem "Denied" i kodem "brak uprawnienia"
    Oraz kod profilu "flota" nie został wywołany

  @FLO-FR-01
  Scenariusz: Wnioskodawca przegląda katalog bez akcji zmiany
    Jeżeli "tomasz" pobiera zapytanie "flota.CarCatalog"
    Wtedy wynik zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid" ze statusem "dostępny"
    Oraz dozwolone akcje nie zawierają "flota.SaveCatalogItem" ani "flota.WithdrawCatalogItem"

  @FLO-FR-01
  Scenariusz: Administrator katalogu dostaje akcje katalogu razem z wynikiem zapytania
    Jeżeli "karol" pobiera zapytanie "flota.CarCatalog"
    Wtedy dozwolone akcje zawierają "flota.SaveCatalogItem" i "flota.WithdrawCatalogItem"

  @FLO-FR-01 @integration
  Scenariusz: Kod innego profilu nie czyta katalogu floty
    Zakładając kod profilu "kredyty" działa w kontekście bazy "prj_kredyty"
    Jeżeli kod profilu odczytuje tabelę "prj_flota.ModelSamochodu"
    Wtedy baza odmawia dostępu

  @FLO-FR-02
  Scenariusz: Administrator katalogu dodaje model
    Jeżeli "karol" wykonuje operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range", kategorią "A", emisją CO2 0 i ceną netto 215000
    Wtedy operacja kończy się sukcesem
    Oraz katalog floty zawiera model "Kia EV6 Long Range" ze statusem "dostępny"
    Oraz historia katalogu zawiera dodanie modelu "Kia EV6 Long Range" przez "karol"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Succeeded", rolą "flota/administrator-katalogu" i profilem "flota"

  @FLO-FR-02
  Szablon scenariusza: Katalogu nie zmienia nikt poza administratorem katalogu
    Jeżeli "<osoba>" wykonuje operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range", kategorią "A", emisją CO2 0 i ceną netto 215000
    Wtedy operacja jest odrzucona: "brak uprawnienia"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Denied"
    Oraz kod profilu "flota" nie został wywołany

    Przykłady:
      | osoba  | kto                                                        |
      | alicja | administrator procesów floty — Administrator procesu bez flota.Catalog.Manage |
      | wiktor | kierownik floty — Menadżer procesu                         |
      | tomasz | wnioskodawca                                               |
      | adam   | administrator procesów kredytowych — inny profil           |
      | zenon  | administrator platformy — rola globalna                    |

  @FLO-FR-02
  Scenariusz: Model niezgodny z polityką floty nie trafia do katalogu
    Jeżeli "karol" wykonuje operację "flota.SaveCatalogItem" z modelem "Ford Ranger 2.0 EcoBlue", kategorią "B", emisją CO2 220 i ceną netto 189000
    Wtedy operacja kończy się błędem walidacji "Emisja CO2 przekracza limit polityki floty (130 g/km)"
    Oraz katalog floty nie zawiera modelu "Ford Ranger 2.0 EcoBlue"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Failed"

  @FLO-FR-02
  Scenariusz: Ponowienie z tym samym identyfikatorem żądania nie dubluje modelu
    Zakładając "karol" wykonał operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range" i identyfikatorem żądania "k-1"
    Jeżeli "karol" ponawia operację z identyfikatorem żądania "k-1"
    Wtedy operacja kończy się sukcesem
    Oraz katalog floty zawiera dokładnie 1 model "Kia EV6 Long Range"

  @FLO-FR-02 @FLO-FR-03
  Scenariusz: Wycofany model znika z formatki, a wniosek w toku go zachowuje
    Zakładając sprawa "F-0012" procesu "rejestracja-samochodu" z modelem "Toyota Corolla Touring Sports 1.8 Hybrid" jest w etapie "Opiniowanie"
    Jeżeli "karol" wykonuje operację "flota.WithdrawCatalogItem" dla modelu "Toyota Corolla Touring Sports 1.8 Hybrid"
    Wtedy źródło danych "flota.CarModels" nie zwraca modelu "Toyota Corolla Touring Sports 1.8 Hybrid"
    Oraz sprawa "F-0012" nadal ma model "Toyota Corolla Touring Sports 1.8 Hybrid"

  @FLO-FR-03
  Scenariusz: Pole formatki startowej oferuje tylko dostępne modele z katalogu
    Jeżeli "tomasz" otwiera formatkę startową procesu "rejestracja-samochodu"
    Wtedy pole "Model samochodu z katalogu" zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid"
    Ale pole "Model samochodu z katalogu" nie zawiera modelu "Skoda Octavia Combi 2.0 TDI"

  @FLO-FR-03
  Scenariusz: Formatka innego procesu nie korzysta z katalogu floty
    Jeżeli formatka procesu "wniosek-kredytowy" wywołuje źródło danych "flota.CarModels" w imieniu "anna"
    Wtedy wywołanie jest odrzucone regułą "R9"
    Oraz dziennik bezpieczeństwa zawiera "flota.CarModels" z wynikiem "Denied" i kodem "R9"
