# Profil „flota” — rejestracja samochodu służbowego z opiniami komórek banku

Przykładowy profil projektu, który pokazuje komplet **dedykowanych elementów jednego projektu**: własną sekcję nawigacji „Flota” z katalogiem samochodów, który widzą wyłącznie role tego profilu, rolę administracyjną, która uzupełnia katalog, pole formatki korzystające z katalogu i panel z opiniami komórek w zadaniu decyzji. Żaden inny proces ani profil nie widzi katalogu i nie może z niego korzystać.

Kontrakt z platformą: `profile.yaml`, `authorization.yaml` · plan zespołu: `backlog.yaml` (FLO-01…FLO-05) · scenariusze: `specs/` · modele: `bpmn/` · przewodnik dla zespołów: `docs/guides/dedykowane-elementy-profilu.md` · klikalna makieta: `design/mockups/index.html` (persony Tomasz, Hanna, Karol).

## Procesy

| Proces | `bpmnProcessId` | Kto startuje | Etapy (mapa etapów) |
| --- | --- | --- | --- |
| Rejestracja samochodu służbowego | `rejestracja-samochodu` | Wnioskodawca, z formatki startowej z polem „Model samochodu z katalogu” | Wniosek → Opiniowanie → Decyzja → Zakup i rejestracja → Zakończenie |
| Opiniowanie rejestracji samochodu | `opiniowanie-rejestracji` | wyłącznie proces główny (call activity) | Opinie komórek → Podsumowanie |

```mermaid
flowchart LR
  S(("Wniosek złożony<br/>model z katalogu")) --> W["Weryfikacja wniosku<br/>Koordynator floty"]
  W --> K{"Wniosek<br/>kompletny?"}
  K -- nie --> Z(("Wniosek<br/>zwrócony"))
  K -- tak --> O
  subgraph O["Opiniowanie rejestracji samochodu — proces podrzędny"]
    direction TB
    OS(("start")) --> IT["Opinia: IT"] & HR["Opinia: HR"] & PR["Opinia: Prawny"] & FI["Opinia: Finanse"] & RY["Opinia: Ryzyko"]
    IT & HR & PR & FI & RY --> P["Podsumuj opinie<br/>rekomendacja"]
  end
  O --> D["Decyzja o przydziale<br/>Decydent floty<br/>panel „Opinie komórek”"]
  D --> G{"Decyzja?"}
  G -- odmowa --> R(("Wniosek<br/>odrzucony"))
  G -- przydział --> ZZ["Złóż zamówienie u dealera<br/>worker flota.zamowienie.zloz"]
  ZZ --> RP["Rejestracja pojazdu<br/>Koordynator floty"]
  RP --> E["Wpisz do ewidencji floty<br/>worker flota.ewidencja.dodaj"]
  E --> OK(("Samochód<br/>zarejestrowany"))
```

Model techniczny (Camunda 8.9): `bpmn/rejestracja-samochodu.bpmn` i `bpmn/opiniowanie-rejestracji.bpmn` — otwórz w Camunda Modeler. W modelu opinie to **jedno zadanie wielokrotne** „Opinia komórki” (`OpiniaKomorki`): Camunda tworzy tyle równoległych zadań, ile komórek jest na liście `routing.komorkiOpiniujace`, a każde dostaje grupę kandydującą swojej komórki (`candidateGroups="=[komorka.grupa]"`, praktyka C4).

### Opiniowanie przez komórki banku

| Komórka | Grupa kandydująca (BPMN) | Grupa AD | Co ocenia |
| --- | --- | --- | --- |
| IT | `flota-opinia-it` | `PH-FLOTA-OPINIA-IT` | telematyka, aplikacje mobilne i bezpieczeństwo urządzeń w samochodzie |
| HR | `flota-opinia-hr` | `PH-FLOTA-OPINIA-HR` | uprawnienie użytkownika do kategorii samochodu według regulaminu floty |
| Prawny | `flota-opinia-prawny` | `PH-FLOTA-OPINIA-PRAWNY` | forma nabycia (zakup, leasing, najem) i umowa z dealerem |
| Finanse | `flota-opinia-finanse` | `PH-FLOTA-OPINIA-FINANSE` | budżet centrum kosztów i sposób finansowania |
| Ryzyko | `flota-opinia-ryzyko` | `PH-FLOTA-OPINIA-RYZYKO` | ryzyko operacyjne, ubezpieczenie, zgodność z polityką emisji |

- Wszystkie komórki mają tę samą rolę projektową `flota/opiniujacy`; komórkę wyznacza grupa AD i grupa kandydująca. Każda komórka widzi i przejmuje wyłącznie swoje zadanie (R2, R3); opinię edytuje i kończy tylko assignee (R1).
- Opinia: **pozytywna**, **warunkowa** (z warunkami) albo **negatywna**. Skrypt „Podsumuj opinie” liczy rekomendację: negatywna, gdy choć jedna komórka jest przeciw; warunkowa, gdy któraś stawia warunki; inaczej pozytywna.
- Do procesu głównego wraca tylko lista `{komorka, opinia, warunki}` i rekomendacja (C8). Uzasadnienie opinii (może zawierać dane osobowe) zapisuje rejestr opinii profilu w `prj_flota` (`flota.OpinionRegister`); decydent widzi je w panelu „Opinie komórek” (odczyt wrażliwy, audytowany).
- Nowa komórka (np. Compliance) to konfiguracja, nie zmiana modelu: grupa AD i grupa kandydująca w `authorization.yaml` oraz wpis w `routing.komorkiOpiniujace`.

Zmienne startowe ustawia BFF z konfiguracji procesu (C4, C5):

```json
{
  "routing": {
    "koordynatorzy": ["flota-koordynatorzy"],
    "decydenci": ["flota-decydenci"],
    "komorkiOpiniujace": [
      { "kod": "it", "nazwa": "IT", "grupa": "flota-opinia-it" },
      { "kod": "hr", "nazwa": "HR", "grupa": "flota-opinia-hr" },
      { "kod": "prawny", "nazwa": "Prawny", "grupa": "flota-opinia-prawny" },
      { "kod": "finanse", "nazwa": "Finanse", "grupa": "flota-opinia-finanse" },
      { "kod": "ryzyko", "nazwa": "Ryzyko", "grupa": "flota-opinia-ryzyko" }
    ]
  },
  "sla": { "opinia": "P5D", "decyzja": "P2D" }
}
```

### Mapa etapów (zasiew `ph:stage`, ostateczną mapę ustala administrator procesu)

| Proces | Etap | Elementy BPMN | Cel SLA (propozycja) |
| --- | --- | --- | --- |
| rejestracja-samochodu | Wniosek | `WniosekZlozony`, `WeryfikacjaWniosku` | 1 dzień |
| | Opiniowanie | `OpiniowanieKomorek` (cały proces podrzędny) | 5 dni |
| | Decyzja | `DecyzjaOPrzydziale` (eskalacja `TerminDecyzjiPrzekroczony`) | 2 dni |
| | Zakup i rejestracja | `ZlozZamowienie`, `RejestracjaPojazdu`, `WpiszDoEwidencji` | 20 dni |
| | Zakończenie | `SamochodZarejestrowany` (success), `WniosekZwrocony` i `WniosekOdrzucony` (rejected) | — |
| opiniowanie-rejestracji | Opinie komórek | `OpiniowanieRozpoczete`, `OpiniaKomorki` (eskalacja `TerminOpiniiPrzekroczony`) | 5 dni |
| | Podsumowanie | `PodsumujOpinie`, `OpinieZebrane` (success) | — |

## Role projektowe

| Rola (`flota/<id>`) | Role platformy | Uprawnienia projektu | Procesy | Grupy AD | Co robi |
| --- | --- | --- | --- | --- | --- |
| `wnioskodawca` | Inicjator | `flota.Catalog.View` | rejestracja-samochodu | `PH-FLOTA-WNIOSKODAWCY` | przegląda katalog, składa wniosek, śledzi go w „Moich procesach” |
| `koordynator-floty` | Uczestnik | `flota.Catalog.View` | rejestracja-samochodu | `PH-FLOTA-KOORDYNATORZY` | weryfikuje wniosek, rejestruje pojazd |
| `opiniujacy` | Uczestnik | `flota.Catalog.View` | opiniowanie-rejestracji | `PH-FLOTA-OPINIA-IT`, `-HR`, `-PRAWNY`, `-FINANSE`, `-RYZYKO` | wydaje opinię swojej komórki |
| `decydent-floty` | Uczestnik | `flota.Catalog.View`, `flota.Opinion.ViewAll`, `flota.Delivery.Check` | rejestracja-samochodu | `PH-FLOTA-DECYDENCI` | decyduje o przydziale, sprawdza cenę i termin dostawy |
| `kierownik-floty` | Menadżer procesu | `flota.Catalog.View`, `flota.Opinion.ViewAll` | oba | `PH-FLOTA-MGR` | nadzór, przekazywanie, dashboard, eskalacje |
| `administrator-procesow-floty` | Administrator procesu | `flota.Catalog.View` | oba | `PH-FLOTA-ADM` | formatki, mapa etapów, widok techniczny — **bez** zmian katalogu |
| `administrator-katalogu` | — | `flota.Catalog.View`, `flota.Catalog.Manage` | dane profilu | `PH-FLOTA-KATALOG` | **uzupełnia katalog**: dodaje, zmienia i wycofuje modele |

Profil ma dwie role administracyjne. Konfigurację procesów prowadzi Administrator procesów floty (rola platformy Administrator procesu), a katalog — Administrator katalogu samochodów, który nie ma żadnej roli platformy, tylko uprawnienia projektu. Dzięki temu osoba prowadząca katalog nie zmienia formatek ani mapy etapów i odwrotnie (najmniejsze uprawnienia).

## Dedykowane elementy profilu

| Element | Punkt rozszerzenia (`profile.yaml`) | Uprawnienie | Gdzie w UI |
| --- | --- | --- | --- |
| Sekcja nawigacji „Flota” | `ui.slots: nav.section` → `FleetNavSectionComponent` | `flota.Catalog.View` | szuflada nawigacji, pod sekcjami platformy |
| Strona „Katalog samochodów” | `ui.routes: /p/flota/katalog` + zapytanie `flota.CarCatalog` (`query`) | `flota.Catalog.View` | `/p/flota/katalog` |
| Dodaj, zmień model | `flota.SaveCatalogItem` (`profile-action`, ADR-017) | `flota.Catalog.Manage` | przyciski na stronie katalogu z `allowedActions` |
| Wycofaj model | `flota.WithdrawCatalogItem` (`profile-action`) | `flota.Catalog.Manage` | jw., z oknem potwierdzenia |
| Widżet „Katalog samochodów” | `ui.slots: dashboard.widget` → `CatalogWidgetComponent` | `flota.Catalog.View` | pulpit |
| Pole „Model samochodu z katalogu” | `ui.slots: form.field` + źródło danych `flota.CarModels` (`form-data-source`) | `flota.Catalog.View` | formatka startowa procesu `rejestracja-samochodu` |
| Panel „Opinie komórek” | `ui.slots: task.panel` + `flota.OpinionsSummary` (`task-enricher`, `sensitive: true`) | `flota.Opinion.ViewAll` | zadanie „Decyzja o przydziale samochodu” |
| Sprawdź cenę i termin dostawy | `flota.CheckDeliveryTerms` (`task-action`, `requiresAssignee: true`) | `flota.Delivery.Check` | akcja zadania decyzji (tylko assignee, R1) |
| Rejestr opinii | `flota.OpinionRegister` (`event-handler`) | — (zdarzenia platformy z procesów profilu) | brak — dane dla panelu opinii |

### Kto co widzi

| Element | Role profilu `flota` | Administrator katalogu | Role innych profili (np. Anna — kredyty) | Audytor |
| --- | --- | --- | --- | --- |
| Sekcja „Flota”, strona i widżet katalogu | tak (podgląd) | tak (podgląd i edycja) | nie — brak sekcji; wejście z adresu = odmowa w dzienniku (R5) | nie (rola globalna bez uprawnień projektu) |
| Przyciski „Dodaj model”, „Zmień”, „Wycofaj” | nie | tak | nie | nie |
| Pole formatki z katalogu | tylko w formatkach procesów profilu | — | formatka innego procesu nie wywoła `flota.CarModels` (R9) | — |
| Zadanie opinii | komórka widzi tylko swoje zadanie | nie | nie | podgląd tylko do odczytu |
| Panel „Opinie komórek” | Decydent i Kierownik floty | nie | nie | nie |
| Wpisy dziennika (`flota.SaveCatalogItem`…) | — | — | — | tak, z rolą `flota/administrator-katalogu` |

### Uzupełnienie katalogu — przepływ

```mermaid
sequenceDiagram
  participant K as Administrator katalogu
  participant UI as Powłoka + profile-flota-ui
  participant API as Potok platformy
  participant AP as Access Policy
  participant AU as Audit
  participant EX as Extension Host
  participant OP as flota.SaveCatalogItem
  K->>UI: Flota → Katalog samochodów → „Dodaj model”
  Note over UI: przycisk istnieje, bo allowedActions wyniku flota.CarCatalog zawiera flota.SaveCatalogItem
  UI->>API: POST /p/flota/actions/flota.SaveCatalogItem (requestId)
  API->>AP: uprawnienie flota.Catalog.Manage
  AP-->>API: Allowed, GrantedBy flota/administrator-katalogu
  API->>AU: Intent
  API->>EX: wykonaj w kontekście profilu (użytkownik bazy prj_flota)
  EX->>OP: ExecuteAsync(ctx, model)
  OP-->>EX: Ok albo Invalid (np. emisja CO2 ponad limit polityki floty)
  EX-->>API: wynik
  API->>AU: Outcome
  API-->>UI: wynik i nowe allowedActions
```

## Dane profilu (`prj_flota`, klasa confidential, retencja 84 miesiące)

| Encja | Zawartość | Kto zapisuje |
| --- | --- | --- |
| `ModelSamochodu` | marka, model, wersja, napęd, kategoria floty, cena katalogowa netto, emisja CO2, umowa ramowa, status (dostępny, wycofany) | `flota.SaveCatalogItem`, `flota.WithdrawCatalogItem` |
| `ZmianaKatalogu` | historia zmian pozycji: kto, kiedy, co zmienił | jw. |
| `OpiniaKomorki` | sprawa, komórka, opinia, warunki, uzasadnienie, autor, czas | `flota.OpinionRegister` |

Liczbę wniosków w toku dla modelu zapytanie `flota.CarCatalog` liczy z widoków `platform_api` (tylko procesy profilu). Wnioski w toku zachowują wybrany model także po jego wycofaniu.

## Uwagi do modeli BPMN

- Modele przechodzą walidację projektową Zeebe 8.9 (`zeebe-bpmn-model`) i reguły zgodności Camunda 8.9 (`bpmnlint-plugin-camunda-compat`).
- Timery eskalacji (`TerminOpiniiPrzekroczony`, `TerminDecyzjiPrzekroczony`) nie mają przepływu wychodzącego — tak jak przykład C12 w `docs/architecture/06-camunda-integration.md`: zdarzenie służy tylko do oznaczenia eskalacji, zadanie zostaje u wykonawcy. Reguły `bpmnlint:recommended` `no-disconnected` i `no-implicit-end` zgłaszają takie zdarzenia — konfiguracja wtyczki `bpmnlint-plugin-ph` (S17) musi wyłączyć je dla zdarzeń z `ph:escalationLevel`.
- Formatkę startową „Wniosek o samochód” przypisuje do procesu Form Management: zdarzenie startowe w Zeebe 8.9 przyjmuje tylko `formId` albo `formKey`, nie `externalReference`. Kontrakt danych formatki startowej opisuje `ph:outputs` na zdarzeniu startowym.
