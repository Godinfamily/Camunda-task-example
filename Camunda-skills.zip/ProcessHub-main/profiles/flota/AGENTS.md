# AGENTS.md — profil „flota”

Pracujesz dla zespołu floty samochodowej. Część specyficzną profilu (katalog samochodów, opinie komórek banku, operacje dedykowane, rozszerzenia UI, workery) realizujesz wyłącznie w `profiles/flota/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości; poniżej to, co dodaje profil. Opis procesów i diagramy: `profiles/flota/README.md`; jak budować dedykowane elementy: `docs/guides/dedykowane-elementy-profilu.md`.

## Granice

- Zależysz tylko od SDK rozszerzeń w wersji `^1.1`: `ProcessHub.Extensibility` (backend) i `@process-hub/extension-sdk` (frontend). Nie odwołujesz się do modułów platformy ani do innych profili — testy architektury zatrzymają build.
- Działasz tylko na procesach profilu: `rejestracja-samochodu`, `opiniowanie-rejestracji` (reguła R9). Uprawnienia, operacje i typy zadań mają prefiks `flota.` (reguła R10).
- Katalog samochodów zmieniasz wyłącznie operacjami `flota.SaveCatalogItem` i `flota.WithdrawCatalogItem` (`profile-action`, ADR-017). Nie dodajesz endpointów poza potokiem platformy i nie sprawdzasz uprawnień w kodzie — robi to potok.
- Dane trzymasz w schemacie `prj_flota`; dane platformy (np. liczba wniosków w toku dla modelu) czytasz tylko przez widoki `platform_api`, filtrowane do procesów profilu.
- Opinie komórek mogą zawierać dane osobowe pracownika: w audycie i logach tylko identyfikatory, nigdy treść uzasadnienia (NFR-09).
- Komórki opiniujące to dane konfiguracyjne (grupy kandydujące w `authorization.yaml` i zmienna `routing.komorkiOpiniujace`), nie kod. Nowa komórka nie wymaga zmiany BPMN.
- Potrzebujesz nowego punktu rozszerzenia albo zmiany SDK → RFC w `docs/rfc/` do zespołu platformy (wzór: `RFC-FLO-03`). Nie obchodzisz braku przez kod platformy.

## Struktura

```
profiles/flota/
  profile.yaml · authorization.yaml     kontrakt z platformą (zmiany: zespół + architekt platformy)
  README.md                             procesy, diagramy, role, dedykowane elementy, widoczność
  backlog.yaml                          plan zespołu (kroki FLO-xx) — tools/agents/*.py --backlog
  specs/                                scenariusze profilu (# language: pl, tagi @FLO-FR-xx)
  bpmn/      rejestracja-samochodu.bpmn, opiniowanie-rejestracji.bpmn (typy zadań flota.*)
  backend/   Flota.Extension/  Flota.Extension.Tests/  Flota.Specs/
  frontend/  biblioteka Nx `profile-flota-ui` (sekcja „Flota”, strona /p/flota/katalog, widżet, pole formatki, panel opinii)
  db/        migracje schematu prj_flota (tożsamość migracji profilu)
  workers/   workery typów zadań flota.* (zamówienie u dealera, ewidencja floty)
```

## Komendy

```bash
dotnet build profiles/flota/backend -warnaserror
dotnet test profiles/flota/backend --filter "Category!=integration"
dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
npx nx run-many -t lint test build --projects=tag:scope:profile-flota
npx bpmnlint "profiles/flota/bpmn/**/*.bpmn"
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota
```

Skill do pracy z SDK: `profile-extension`.
