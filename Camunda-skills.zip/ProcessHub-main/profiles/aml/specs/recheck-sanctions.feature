# language: pl
# Scenariusze profilu „aml” — własność zespołu AML. Świat testowy: specs/README.md.
Funkcja: Ponowna weryfikacja sankcji
  Jako analityk AML
  Chcę ponownie sprawdzić listy sankcyjne w trakcie analizy
  Aby decyzja uwzględniała najnowsze wpisy

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T3" procesu "weryfikacja-aml" typu "AnalizaAml" przypisane do "darek"

  @AML-FR-01
  Scenariusz: Assignee zleca ponowną weryfikację przez usługę zespołu
    Jeżeli "darek" wykonuje operację "aml.RecheckSanctions" na zadaniu "T3"
    Wtedy platforma wywołuje usługę profilu "aml" z kontekstem zadania "T3" i aktora "darek"
    Oraz dziennik bezpieczeństwa zawiera "aml.RecheckSanctions" z wynikiem "Succeeded" i profilem "aml"

  @AML-FR-01
  Scenariusz: Niedostępna usługa profilu nie blokuje pracy na zadaniu
    Zakładając usługa profilu "aml" nie odpowiada
    Jeżeli "darek" wykonuje operację "aml.RecheckSanctions" na zadaniu "T3"
    Wtedy operacja kończy się błędem "ProfileServiceUnavailable"
    Oraz "darek" nadal może zapisać szkic i zakończyć zadanie "T3"
