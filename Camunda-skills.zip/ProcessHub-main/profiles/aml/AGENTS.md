# AGENTS.md — profil „aml”

Pracujesz dla zespołu AML. Część specyficzną realizujesz wyłącznie w `profiles/aml/**`. Profil działa w modelu **remote**: operacje profilu wykonuje usługa zespołu (`profiles/aml/remote/`), wywoływana przez platformę według kontraktu `profile-operations v1` (ADR-012). Zasady platformy z głównego `AGENTS.md` obowiązują w całości.

## Granice

- Dane profilu mają klasę **restricted** — każda zmiana przechodzi przegląd bezpieczeństwa (security-reviewer); jak cały rój, agenci pracują na modelu w infrastrukturze banku.
- Usługa zespołu nie łączy się z Camunda ani z bazą platformy. Dostaje od platformy kontekst operacji (zadanie, aktor, uprawnienie) w podpisanym żądaniu i zwraca wynik; audyt i autoryzację wykonuje platforma.
- Działasz tylko na procesie `weryfikacja-aml` (R9); uprawnienia i operacje mają prefiks `aml.` (R10).
- Dane trzymasz w schemacie `prj_aml` (albo w bazie usługi — decyzja zespołu, opisana w `profiles/aml/README.md`).

## Struktura

```
profiles/aml/
  profile.yaml · authorization.yaml     kontrakt z platformą
  backlog.yaml                          plan zespołu (kroki AML-xx)
  specs/                                scenariusze profilu (@AML-FR-xx)
  remote/    usługa operacji profilu (kontrakt profile-operations v1, mTLS + token platformy)
  frontend/  biblioteka Nx `profile-aml-ui`
  db/        migracje prj_aml
  bpmn/      proces weryfikacja-aml (typy zadań aml.*)
```

## Komendy

```bash
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile aml
npx nx run-many -t lint test build --projects=tag:scope:profile-aml
# testy usługi: według technologii zespołu + test kontraktowy profile-operations v1 dostarczany przez platformę
```
