# Profile projektów

Profil projektu to sposób, w jaki projekt biznesowy (np. kredyty, AML) korzysta z Process Hub: deklaruje swoje procesy, role projektowe, dane i operacje dedykowane, a resztę dostaje od platformy. Część platformowa działa tak samo dla każdego profilu; część specyficzna należy do zespołu projektu i jest od platformy oraz od innych profili oddzielona — w repozytorium, w kodzie, w bazie, w uprawnieniach i w pracy agentów AI.

Architektura: `docs/architecture/13-project-profiles.md` · decyzje: ADR-012 (profile i punkty rozszerzeń), ADR-013 (separacja kodu), ADR-014 (dane profilu), ADR-017 (operacje na danych profilu) · jak budować dedykowane menu, strony, dane i operacje: `docs/guides/dedykowane-elementy-profilu.md`.

## Profile w repozytorium

| Profil | Model | Co pokazuje |
| --- | --- | --- |
| `kredyty` | in-process | operacje na zadaniu („Przelicz scoring”), wzbogacenie zadania, źródło danych formatki, raport portfela na trasie `/p/kredyty/portfel` |
| `aml` | remote | usługa zespołu (kontrakt `profile-operations v1`), operacja na sprawie, dane klasy `restricted` |
| `flota` | in-process | **przykład dedykowanych elementów**: sekcja nawigacji „Flota” z katalogiem samochodów widocznym tylko dla ról profilu, operacje na danych profilu (`profile-action`) dla roli „Administrator katalogu samochodów”, pole formatki z katalogu, opinie pięciu komórek banku w procesie podrzędnym, modele BPMN (`profiles/flota/README.md`) |

## Platforma a profil

| Platforma — tak samo dla wszystkich | Profil — decyzja zespołu projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4) | Role projektowe złożone z ról platformy i uprawnień projektu |
| Start procesu, moje procesy, przekazywanie, zastępstwa | Operacje dedykowane na zadaniach, sprawach i danych profilu (np. „Przelicz scoring”, „Zapisz model w katalogu”) |
| Eskalacje, dashboard, mapa etapów, formatki | Dane projektu we własnym schemacie `prj_<id>` |
| Audyt każdej akcji, autoryzacje jako kod | Rozszerzenia UI w slotach: panel zadania, panel sprawy, widżet, pole formatki, sekcja nawigacji, trasy `/p/<id>/` |
| Integracja z Camunda (wyłącznie platforma) | Workery typów zadań `<id>.*` i integracje z systemami projektu |
| SDK rozszerzeń i jego zgodność wsteczna | Model integracji: `in-process` (moduł w hoście) albo `remote` (usługa zespołu) |

## Założenie nowego profilu

```bash
python3 tools/profiles/new_profile.py lizing --name "Lizing" --team "@bank/zespol-lizing" --process umowa-lizingowa
python3 tools/profiles/validate_profiles.py --write-codeowners   # sprawdza manifesty, aktualizuje CODEOWNERS
python3 tools/agents/render_agents.py                            # agenci lizing-* z zapisem tylko w profiles/lizing/**
# bez Pythona: ph profiles new …, ph profiles validate --write-codeowners, ph agents render
```

1. Zespół uzupełnia `profile.yaml` (procesy, uprawnienia, role, dane, operacje, UI) i `authorization.yaml` (grupy AD → role projektowe).
2. Pull request przeglądają zespół profilu i architekt platformy (`CODEOWNERS`); CI uruchamia walidację manifestów.
3. Po scaleniu reconciler nadaje autoryzacje w Camunda, a platforma rejestruje profil przy starcie.
4. Zespół prowadzi własny plan (`backlog.yaml`) tymi samymi narzędziami co platforma.

## Co wolno, a czego nie

| Wolno | Nie wolno |
| --- | --- |
| Zależeć od `ProcessHub.Extensibility` i `@process-hub/extension-sdk` | Odwoływać się do modułów platformy lub innych profili |
| Czytać dane platformy przez widoki `platform_api` | Czytać lub zapisywać tabele platformy i innych profili |
| Definiować uprawnienia, operacje i typy zadań z prefiksem `<id>.` | Używać cudzej przestrzeni nazw albo nadawać rolę audytora |
| Wywoływać systemy projektu z operacji lub workerów | Łączyć się z Camunda poza workerami typów zadań profilu |
| Wydawać profil w rytmie zespołu (remote) lub w pociągu wydań (in-process) | Omijać potok platformy: autoryzację, audyt, idempotencję |

## Praca z agentami

Generator tworzy agentów profilu (`kredyty-module-implementer`, `kredyty-frontend-developer`…), którzy mogą zapisywać wyłącznie w `profiles/<id>/**`; wszyscy agenci pracują na modelu GLM w infrastrukturze banku, a klasa danych profilu decyduje o przeglądzie bezpieczeństwa. W OpenCode: `/profil kredyty KRE-02`.

## Lista kontrolna przed pierwszym wydaniem profilu

- [ ] `validate_profiles.py --check` zielone; zespół w `CODEOWNERS`
- [ ] testy zgodności SDK i testy architektury profilu zielone
- [ ] każda operacja zapisu ma `requiresAssignee` i scenariusz odmowy
- [ ] odczyty wrażliwe oznaczone `sensitive: true`
- [ ] migracje schematu `prj_<id>` przechodzą tożsamością migracji profilu
- [ ] przegląd bezpieczeństwa dla klasy danych `restricted`
