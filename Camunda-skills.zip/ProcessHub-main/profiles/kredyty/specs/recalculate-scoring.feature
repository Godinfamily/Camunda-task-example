# language: pl
# Scenariusze profilu „kredyty” — własność zespołu kredytów. Świat testowy: specs/README.md.
Funkcja: Przeliczenie scoringu w zadaniu oceny wniosku
  Jako analityk kredytowy
  Chcę przeliczyć scoring w trakcie oceny
  Aby decyzja opierała się na aktualnych danych wnioskodawcy

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" typu "OcenaWniosku" przypisane do "anna"
    Oraz system scoringowy zwraca dla wniosku z zadania "T1" wynik 712

  @KRE-FR-01
  Scenariusz: Assignee przelicza scoring
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja kończy się sukcesem
    Oraz szkic zadania "T1" zawiera "scoring" równe 712
    Oraz dziennik bezpieczeństwa zawiera "kredyty.RecalculateScoring" z wynikiem "Succeeded", rolą "kredyty/analityk-kredytowy" i profilem "kredyty"

  @KRE-FR-01
  Scenariusz: Osoba z grupy, która nie jest assignee, nie przelicza scoringu
    Jeżeli "bartek" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja jest odrzucona regułą "R1"
    Oraz system scoringowy nie został wywołany

  @KRE-FR-01
  Scenariusz: Ponowienie z tym samym identyfikatorem żądania nie wywołuje systemu drugi raz
    Zakładając "anna" wykonała operację "kredyty.RecalculateScoring" na zadaniu "T1" z identyfikatorem żądania "r-1"
    Jeżeli "anna" ponawia operację z identyfikatorem żądania "r-1"
    Wtedy operacja kończy się sukcesem
    Oraz system scoringowy został wywołany dokładnie 1 raz
