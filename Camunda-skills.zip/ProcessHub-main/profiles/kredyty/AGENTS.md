# AGENTS.md — profil „kredyty”

Pracujesz dla zespołu kredytów. Część specyficzną profilu (dane, operacje dedykowane, rozszerzenia UI, workery) realizujesz wyłącznie w `profiles/kredyty/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości; poniżej to, co dodaje profil.

## Granice

- Zależysz tylko od SDK rozszerzeń: `ProcessHub.Extensibility` (backend) i `@process-hub/extension-sdk` (frontend). Nie odwołujesz się do modułów platformy ani do innych profili — testy architektury zatrzymają build.
- Działasz tylko na procesach profilu: `wniosek-kredytowy`, `aneks-kredytowy` (reguła R9). Platforma i tak odrzuci operację na zadaniu innego procesu.
- Uprawnienia, operacje i typy zadań mają prefiks `kredyty.` (reguła R10). Nowe uprawnienie lub rola = zmiana `profile.yaml`, którą zatwierdza architekt platformy.
- Dane trzymasz w schemacie `prj_kredyty`; dane platformy czytasz tylko przez widoki `platform_api` (filtrowane do procesów profilu).
- Potrzebujesz nowego punktu rozszerzenia albo zmiany SDK → RFC w `docs/rfc/` do zespołu platformy. Nie obchodzisz braku przez kod platformy.

## Struktura

```
profiles/kredyty/
  profile.yaml · authorization.yaml     kontrakt z platformą (zmiany: zespół + architekt platformy)
  backlog.yaml                          plan zespołu (kroki KRE-xx) — tools/agents/*.py --backlog
  specs/                                scenariusze profilu (# language: pl, tagi @KRE-FR-xx)
  backend/   Kredyty.Extension/  Kredyty.Extension.Tests/  Kredyty.Specs/
  frontend/  biblioteka Nx `profile-kredyty-ui` (komponenty slotów i trasy /p/kredyty/…)
  db/        migracje schematu prj_kredyty (tożsamość migracji profilu)
  bpmn/      procesy profilu (wdrożenie z pipeline'u z jawnym tenantem; typy zadań kredyty.*)
  workers/   workery typów zadań kredyty.* (np. rejestr kredytowy)
```

## Komendy

```bash
dotnet build profiles/kredyty/backend -warnaserror
dotnet test profiles/kredyty/backend --filter "Category!=integration"
dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
npx nx run-many -t lint test build --projects=tag:scope:profile-kredyty
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty
```

Skill do pracy z SDK: `profile-extension`.
