# AGENTS.md — profil „__ID__”

Pracujesz dla zespołu „__NAME__”. Część specyficzną profilu realizujesz wyłącznie w `profiles/__ID__/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości.

## Granice

- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`).
- Działasz tylko na procesach z `profile.yaml` (R9); uprawnienia, operacje i typy zadań mają prefiks `__ID__.` (R10).
- Dane: schemat `prj___ID__`; dane platformy tylko przez widoki `platform_api`.
- Zmiana kontraktu (`profile.yaml`, `authorization.yaml`) — zatwierdza też architekt platformy. Brak punktu rozszerzenia → RFC w `docs/rfc/`.

## Komendy

```bash
dotnet test profiles/__ID__/backend --filter "Category!=integration"
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile __ID__
```
