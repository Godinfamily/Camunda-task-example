# language: pl
Funkcja: Widoczność wynika z ról w zakresach i z reguł wierszowych

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" dla grupy "kre-analitycy" przypisane do "anna"
    Oraz zadanie "T2" procesu "wniosek-kredytowy" dla grupy "kre-underwriting" nieprzypisane
    Oraz zadanie "T3" procesu "weryfikacja-aml" dla grupy "aml-analitycy" przypisane do "darek"

  @FR-03 @FR-10 @FR-19
  Szablon scenariusza: Kto widzi które zadanie i z jakimi akcjami
    Jeżeli "<osoba>" pobiera listę zadań
    Wtedy zadanie "<zadanie>" jest "<widoczność>" z akcjami "<akcje>"

    Przykłady:
      | osoba  | zadanie | widoczność  | akcje                 |
      | anna   | T1      | widoczne    | edit,complete,unclaim |
      | bartek | T1      | widoczne    | —                     |
      | celina | T1      | niewidoczne | —                     |
      | celina | T2      | widoczne    | claim                 |
      | marta  | T1      | widoczne    | reassign              |
      | marta  | T3      | niewidoczne | —                     |
      | piotr  | T3      | widoczne    | reassign              |
      | olga   | T1      | widoczne    | —                     |
      | olga   | T3      | widoczne    | —                     |
      | adam   | T1      | niewidoczne | —                     |
      | zenon  | T1      | niewidoczne | —                     |

  @FR-09
  Scenariusz: Uprawnienia wielu ról sumują się, a audyt zapisuje rolę uzasadniającą
    Jeżeli "piotr" przekazuje zadanie "T3" osobie "darek" z powodem "obciążenie"
    Wtedy operacja kończy się sukcesem
    Oraz dziennik bezpieczeństwa zawiera "Task.Reassign" dla "piotr" z rolą uzasadniającą "aml/kierownik-aml" (rola platformy "process-manager", proces "weryfikacja-aml")

  @FR-09
  Scenariusz: Rola w jednym procesie nie daje uprawnień w innym
    Jeżeli "piotr" przekazuje zadanie "T1" osobie "bartek" z powodem "obciążenie"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-19
  Scenariusz: Audytor nie wykona żadnej akcji zapisu
    Jeżeli "olga" przejmuje zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-10
  Scenariusz: Menadżer procesu nie widzi technikaliów BPMN
    Jeżeli "marta" otwiera szczegóły instancji zadania "T1"
    Wtedy widzi mapę etapów z bieżącym etapem "Ocena"
    Ale nie widzi identyfikatorów elementów ani zmiennych spoza formatki

  @multi-tenant
  Scenariusz: Zadania drugiego tenanta są niewidoczne nawet dla audytora pierwszego
    Zakładając tenant "drugi" z zadaniem "X1" procesu "wniosek-kredytowy"
    Jeżeli "olga" pobiera listę zadań
    Wtedy zadanie "X1" jest "niewidoczne" z akcjami "—"

  @integration
  Scenariusz: RLS odcina innego tenanta nawet przy zapytaniu bez filtra
    Zakładając tenant "drugi" z zadaniem "X1" procesu "wniosek-kredytowy"
    Oraz kontekst sesji bazy z tenantem "<default>"
    Jeżeli wykonuję zapytanie o wszystkie zadania bez filtra tenanta
    Wtedy wynik nie zawiera zadania "X1"
