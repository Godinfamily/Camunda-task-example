# language: pl
Funkcja: Autoryzacje jako kod — jedno źródło dla Camunda i aplikacji

  @FR-21
  Scenariusz: Plan zmian pokazuje różnicę przed zastosowaniem
    Zakładając deklaracje z nowym przypisaniem grupy "PH-KREDYT-MGR" do roli "process-manager" dla procesu "aneks-kredytowy"
    Jeżeli reconciler działa w trybie podglądu
    Wtedy raport zawiera dodanie autoryzacji "READ_PROCESS_INSTANCE" dla "aneks-kredytowy"
    Oraz w Camunda nic się nie zmieniło

  @FR-21
  Scenariusz: Rozdział obowiązków blokuje konfigurację
    Zakładając deklaracje przypisujące grupie "PH-AUDYT" role "auditor" i "participant" w procesie "wniosek-kredytowy"
    Jeżeli reconciler waliduje deklaracje
    Wtedy walidacja kończy się błędem "R7"

  @FR-21
  Scenariusz: Rola tylko do odczytu nie może zawierać uprawnień zapisu
    Zakładając rolę "auditor" oznaczoną jako tylko do odczytu z uprawnieniem "Task.Reassign"
    Jeżeli reconciler waliduje deklaracje
    Wtedy walidacja kończy się błędem "ReadOnlyRoleWithWritePermission"

  @FR-21 @integration
  Scenariusz: Wykryty dryf trafia do audytu
    Zakładając, że ktoś ręcznie dodał w Camunda autoryzację spoza deklaracji
    Jeżeli uruchamia się nocne wykrywanie dryfu
    Wtedy dziennik bezpieczeństwa zawiera "Authorization.DriftDetected"
