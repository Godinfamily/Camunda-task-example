# Świat testowy (wspólny dla wszystkich plików .feature)

Wszystkie scenariusze używają tych samych osób, grup i procesów. Drivery tworzą ten świat krokiem „Zakładając świat testowy Process Hub”.

**Tenant:** `<default>` (scenariusze `@multi-tenant` dodają `drugi`).

**Profile i procesy:** profil `kredyty` — `wniosek-kredytowy` (etapy: Rejestracja, Ocena, Oferta, Zakończenie; zadania: `OcenaWniosku` → grupa `kre-analitycy`, `AkceptacjaUnderwritera` → `kre-underwriting`) i `aneks-kredytowy`; profil `aml` — `weryfikacja-aml` (zadanie `AnalizaAml` → `aml-analitycy`); profil `flota` — `rejestracja-samochodu` (etapy: Wniosek, Opiniowanie, Decyzja, Zakup i rejestracja, Zakończenie; zadania: `WeryfikacjaWniosku` i `RejestracjaPojazdu` → `flota-koordynatorzy`, `DecyzjaOPrzydziale` → `flota-decydenci`) i proces podrzędny `opiniowanie-rejestracji` (zadanie wielokrotne `OpiniaKomorki` → `flota-opinia-it`, `-hr`, `-prawny`, `-finanse`, `-ryzyko`). Katalog samochodów profilu `flota`: „Toyota Corolla Touring Sports 1.8 Hybrid” (dostępny), „Skoda Octavia Combi 2.0 TDI” (wycofany); limit emisji CO2 polityki floty: 130 g/km. Role projektowe: `profiles/kredyty/profile.yaml`, `profiles/aml/profile.yaml`, `profiles/flota/profile.yaml`.

| Osoba | Grupy kandydujące | Role projektowe (profil) → role platformy | Role globalne |
| --- | --- | --- | --- |
| anna | kre-analitycy | Analityk kredytowy (kredyty) → Uczestnik, Inicjator w wniosek-kredytowy | — |
| bartek | kre-analitycy | Analityk kredytowy (kredyty) → Uczestnik, Inicjator w wniosek-kredytowy | — |
| piotr | kre-analitycy | Analityk kredytowy (kredyty); Kierownik zespołu AML (aml) → Menadżer procesu w weryfikacja-aml | — |
| celina, ewa | kre-underwriting | Underwriter (kredyty) → Uczestnik w wniosek-kredytowy | — |
| darek | aml-analitycy | Analityk AML (aml) → Uczestnik w weryfikacja-aml | — |
| marta | — | Kierownik zespołu kredytowego (kredyty) → Menadżer procesu w procesach profilu | — |
| adam | — | Administrator procesów kredytowych (kredyty) → Administrator procesu w procesach profilu | — |
| tomasz | — | Wnioskodawca (flota) → Inicjator w rejestracja-samochodu | — |
| kamil | flota-koordynatorzy | Koordynator floty (flota) → Uczestnik w rejestracja-samochodu | — |
| igor, hanna, lena, filip, rafal | po kolei: flota-opinia-it, -hr, -prawny, -finanse, -ryzyko | Opiniujący (flota) → Uczestnik w opiniowanie-rejestracji | — |
| jan | flota-decydenci | Decydent floty (flota) → Uczestnik w rejestracja-samochodu | — |
| wiktor | — | Kierownik floty (flota) → Menadżer procesu w procesach profilu | — |
| alicja | — | Administrator procesów floty (flota) → Administrator procesu w procesach profilu | — |
| karol | — | Administrator katalogu samochodów (flota) — bez ról platformy, `flota.Catalog.Manage` | — |
| olga | — | — | Audytor (*) |
| zenon | — | — | Administrator platformy |

Przypisania: grupy AD z `profiles/*/authorization.yaml` (role projektowe) i `config/authorization/assignments.example.yaml` (role globalne). Scenariusze profili leżą w `profiles/<id>/specs/` (tagi `@KRE-FR-xx`, `@AML-FR-xx`, `@FLO-FR-xx`) i korzystają z tego samego świata.

**Formatki** (format Camunda Forms; każda należy do jednego procesu — R11; opis: `docs/architecture/14-form-management.md`):

| Formatka | Klucz (`ph:form/<klucz>`) | Proces | Zastosowanie | Stan w świecie testowym |
| --- | --- | --- | --- | --- |
| F-ocena | `ocena-wniosku` | wniosek-kredytowy | zadanie `OcenaWniosku` | opublikowane wersje 1–3, obowiązuje 3 |
| F-akceptacja | `akceptacja-underwritera` | wniosek-kredytowy | zadanie `AkceptacjaUnderwritera` | obowiązuje wersja 1 |
| F-wniosek | `wniosek-start` | wniosek-kredytowy | formatka startowa | obowiązuje wersja 5 |
| F-aneks | `analiza-zmian` | aneks-kredytowy | zadanie analizy zmian w umowie | opublikowane wersje 1–2, obowiązuje 2 |
| F-aml | `analiza-aml` | weryfikacja-aml | zadanie `AnalizaAml` | obowiązuje wersja 1 |

Formatkami procesów kredytowych zarządzają marta i adam, formatkami `weryfikacja-aml` — piotr, formatkami floty — wiktor i alicja; olga ma wgląd (`Form.View`) wszędzie. Wyniki w scenariuszach: `Succeeded`, `Denied:<uprawnienie>`, `Rejected:<kod walidacji>`.

**Konwencje:** `# language: pl`; tag FR na każdym scenariuszu; `@integration` = wymaga MSSQL + Camunda w Testcontainers; kody reguł R1–R11 z `docs/architecture/02-roles-and-authorization.md`.
