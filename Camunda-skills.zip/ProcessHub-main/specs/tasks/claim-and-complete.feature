# language: pl
Funkcja: Przejęcie, edycja i zakończenie zadania

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T2" procesu "wniosek-kredytowy" dla grupy "kre-underwriting" nieprzypisane

  @FR-01 @FR-02 @FR-04
  Scenariusz: Członek grupy kandydującej przejmuje zadanie
    Jeżeli "celina" przejmuje zadanie "T2"
    Wtedy assignee zadania "T2" to "celina"
    Oraz zadanie "T2" jest na liście "Moje zadania" osoby "celina"
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Succeeded" dla "celina"

  @FR-04
  Scenariusz: Osoba spoza grupy kandydującej nie przejmie zadania
    Jeżeli "anna" przejmuje zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz silnik nie otrzymał żadnego wywołania
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Denied" dla "anna"

  @FR-04 @integration
  Scenariusz: Wyścig o to samo zadanie rozstrzyga silnik
    Jeżeli "celina" i "ewa" jednocześnie przejmują zadanie "T2"
    Wtedy dokładnie jedna operacja kończy się sukcesem
    Oraz druga otrzymuje konflikt z informacją, kto przejął zadanie

  @FR-05
  Scenariusz: Zwolnić zadanie może tylko assignee
    Zakładając, że "celina" przejęła zadanie "T2"
    Jeżeli "ewa" zwalnia zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R1"

  @FR-06
  Szablon scenariusza: Szkic i zakończenie tylko przez assignee
    Zakładając, że "celina" przejęła zadanie "T2"
    Jeżeli "<osoba>" wykonuje akcję "<akcja>" na zadaniu "T2"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba  | akcja    | wynik     |
      | celina | szkic    | Succeeded |
      | celina | zakończ  | Succeeded |
      | ewa    | szkic    | Denied:R1 |
      | marta  | zakończ  | Denied:R1 |
      | olga   | zakończ  | Denied:R1 |

  @FR-06
  Scenariusz: Ponowione zakończenie nie wykonuje się dwa razy
    Zakładając, że "celina" zakończyła zadanie "T2" żądaniem "req-42"
    Jeżeli "celina" ponawia zakończenie zadania "T2" żądaniem "req-42"
    Wtedy silnik otrzymał dokładnie jedno wywołanie zakończenia
    Oraz operacja kończy się sukcesem
