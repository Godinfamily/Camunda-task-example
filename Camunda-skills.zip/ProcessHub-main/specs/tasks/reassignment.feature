# language: pl
Funkcja: Przekazanie zadania przez menadżera procesu w trakcie procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" dla grupy "kre-analitycy" przypisane do "anna" ze szkicem

  @FR-11
  Scenariusz: Przekazanie osobie z powodem
    Jeżeli "marta" przekazuje zadanie "T1" osobie "bartek" z powodem "urlop"
    Wtedy assignee zadania "T1" to "bartek"
    Oraz szkic zadania "T1" jest widoczny dla "bartek" z adnotacją o poprzednim wykonawcy
    Oraz "anna" i "bartek" otrzymują powiadomienie
    Oraz dziennik bezpieczeństwa zawiera "Task.Reassign" z poprzednim wykonawcą "anna" i nowym "bartek"

  @FR-11
  Scenariusz: Przekazanie grupie zwalnia zadanie
    Jeżeli "marta" przekazuje zadanie "T1" grupie "kre-underwriting" z powodem "obciążenie"
    Wtedy zadanie "T1" jest nieprzypisane z grupą kandydującą "kre-underwriting"
    Oraz zadanie "T1" jest widoczne do przejęcia dla "celina"

  @FR-11
  Scenariusz: Powód jest obowiązkowy
    Jeżeli "marta" przekazuje zadanie "T1" osobie "bartek" bez powodu
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-11
  Scenariusz: Nie można przekazać osobie bez roli uczestnika w procesie
    Jeżeli "marta" przekazuje zadanie "T1" osobie "darek" z powodem "urlop"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-11
  Scenariusz: Menadżer przekazuje, ale nie edytuje
    Zakładając, że "marta" przekazała zadanie "T1" osobie "bartek"
    Jeżeli "marta" wykonuje akcję "szkic" na zadaniu "T1"
    Wtedy wynik operacji to "Denied:R1"

  @FR-11
  Scenariusz: Przekazanie masowe wszystkich zadań nieobecnej osoby
    Zakładając, że "anna" ma 3 aktywne zadania w procesie "wniosek-kredytowy"
    Jeżeli "marta" przekazuje masowo zadania osoby "anna" osobie "bartek" z powodem "urlop"
    Wtedy raport partii zawiera 3 pozycje ze stanem "Done"
    Oraz każde przekazanie ma osobny wpis w dzienniku bezpieczeństwa z identyfikatorem partii

  @FR-11
  Scenariusz: Wznowienie partii po awarii nie dubluje przekazań
    Zakładając partię przekazania 3 zadań przerwaną po 2 pozycjach
    Jeżeli partia zostaje wznowiona
    Wtedy silnik otrzymał dokładnie 3 wywołania przypisania
