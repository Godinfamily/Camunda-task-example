# language: pl
Funkcja: Zastępstwa podczas nieobecności

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz "anna" jest nieobecna od "2026-11-02" do "2026-11-06" z zastępcą "bartek"

  @FR-12
  Scenariusz: Nowe zadanie przypisane do nieobecnej trafia do zastępcy
    Zakładając bieżącą datę "2026-11-03"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy assignee nowego zadania to "bartek"
    Oraz dziennik bezpieczeństwa zawiera "Substitution.Applied" z nieobecną "anna" i zastępcą "bartek"

  @FR-12
  Scenariusz: Poza okresem nieobecności nie ma korekty
    Zakładając bieżącą datę "2026-11-09"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy assignee nowego zadania to "anna"

  @FR-12
  Scenariusz: Nakładające się nieobecności są odrzucane
    Jeżeli "anna" zgłasza nieobecność od "2026-11-05" do "2026-11-10" z zastępcą "piotr"
    Wtedy operacja jest odrzucona błędem "AbsenceOverlap"

  @FR-12
  Scenariusz: Zastępca musi mieć rolę uczestnika w procesie
    Jeżeli "marta" rejestruje nieobecność osoby "bartek" z zastępcą "darek" dla procesu "wniosek-kredytowy"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-12 @integration
  Scenariusz: Awaria platformy nie blokuje tworzenia zadania
    Zakładając, że baza platformy jest niedostępna dla workera zastępstw
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy zadanie powstaje w silniku bez korekty
    Oraz po przywróceniu bazy job uzgadniający przekazuje je osobie "bartek"
