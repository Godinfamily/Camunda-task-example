# language: pl
Funkcja: Formatka na zadaniu — materializacja komponentami design systemu i walidacja na serwerze

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"
    Oraz zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Oraz wersja 3 formatki "F-ocena" ma pola "kwota:number" tylko do odczytu, "decyzja:radio" wymagane i "uzasadnienie:textarea" wymagane i widoczne tylko, gdy decyzja to "Odrzucam"

  @FR-32
  Szablon scenariusza: Każdy typ pola ma jeden komponent design systemu
    Jeżeli renderer materializuje pole typu "<typ>"
    Wtedy używa komponentu "<komponent>" z katalogu pól
    Oraz komponent nie dostaje żadnej własności wyglądu ze schematu

    Przykłady:
      | typ         | komponent        |
      | textfield   | ph-text-field    |
      | textarea    | ph-textarea      |
      | number      | ph-number-field  |
      | datetime    | ph-date-field    |
      | checkbox    | ph-checkbox      |
      | checklist   | ph-checklist     |
      | radio       | ph-radio-group   |
      | select      | ph-select        |
      | taglist     | ph-taglist       |
      | group       | ph-group         |
      | dynamiclist | ph-repeater      |
      | table       | ph-data-table    |
      | text        | ph-text-block    |

  @FR-32
  Scenariusz: Wykonawca dostaje formatkę do edycji, pozostali do odczytu
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" pobiera szczegóły zadania "T5"
    Wtedy formatka zadania "T5" jest w trybie "edycja"
    Jeżeli "bartek" pobiera szczegóły zadania "T5"
    Wtedy formatka zadania "T5" jest w trybie "odczyt"
    Oraz widzi informację "Edytować może tylko osoba, która przejęła zadanie: anna"

  @FR-32
  Scenariusz: Pole ukryte warunkiem nie jest wymagane ani przyjmowane
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "decyzja=Akceptuję"
    Wtedy wynik operacji to "Succeeded"
    Oraz silnik otrzymał zmienną "decyzja" o wartości "Akceptuję" i zmienną "uzasadnienie" bez wartości

  @FR-32 @FR-06
  Scenariusz: Serwer odrzuca brak pola wymaganego warunkowo
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "decyzja=Odrzucam"
    Wtedy walidacja kończy się błędem "Required:uzasadnienie"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-32 @FR-06
  Szablon scenariusza: Serwer nie ufa przeglądarce
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "<dane>"
    Wtedy walidacja kończy się błędem "<błąd>"
    Oraz silnik nie otrzymał żadnego wywołania

    Przykłady:
      | dane                                                   | błąd                |
      | decyzja=Akceptuję; kwota=1                             | ReadOnly:kwota      |
      | decyzja=Akceptuję; premia=500                          | UnknownField:premia |
      | decyzja=Może                                           | Option:decyzja      |
      | decyzja=Odrzucam; uzasadnienie=(tekst o długości 5001 znaków) | MaxLength:uzasadnienie |

  @FR-32
  Scenariusz: Ta sama formatka w obu motywach i na telefonie
    Jeżeli katalog komponentów renderuje wersję 3 formatki "F-ocena" w motywach "jasny" i "ciemny" przy szerokościach 390, 768 i 1280 pikseli
    Wtedy zrzuty są zgodne z zatwierdzonymi wzorcami
    Oraz przy szerokości 390 pikseli pola układają się w jednej kolumnie
    Oraz audyt axe-core nie zgłasza naruszeń

  @FR-32
  Scenariusz: Renderer platformy zachowuje się jak biblioteka form-js
    Jeżeli zestaw zgodności uruchamia formatki wzorcowe w rendererze platformy i w form-js
    Wtedy zbiór widocznych pól, błędy walidacji i dane wyjściowe są identyczne
