# language: pl
Funkcja: Separacja formatek — każdy proces ma formatki wyłącznie dla siebie

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" należy do procesu "wniosek-kredytowy"
    Oraz formatka "F-aneks" należy do procesu "aneks-kredytowy"
    Oraz formatka "F-aml" należy do procesu "weryfikacja-aml"

  @FR-31
  Szablon scenariusza: Lista formatek zawiera tylko procesy z zakresu roli
    Jeżeli "<osoba>" otwiera listę formatek procesu "<proces>"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba  | proces            | wynik            |
      | marta  | wniosek-kredytowy | Succeeded        |
      | marta  | aneks-kredytowy   | Succeeded        |
      | marta  | weryfikacja-aml   | Denied:Form.View |
      | piotr  | weryfikacja-aml   | Succeeded        |
      | piotr  | wniosek-kredytowy | Denied:Form.View |
      | wiktor | wniosek-kredytowy | Denied:Form.View |
      | olga   | weryfikacja-aml   | Succeeded        |
      | anna   | wniosek-kredytowy | Denied:Form.View |

  @FR-31
  Scenariusz: Menadżer innego procesu nie edytuje cudzej formatki
    Jeżeli "piotr" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy operacja jest odrzucona brakiem uprawnienia "Form.Edit"
    Oraz dziennik bezpieczeństwa zawiera "Form.Save" z wynikiem "Denied" dla "piotr"

  @FR-31
  Scenariusz: Ten sam klucz w dwóch procesach to dwie różne formatki
    Jeżeli "marta" tworzy w procesie "aneks-kredytowy" formatkę o kluczu "ocena-wniosku"
    Wtedy wynik operacji to "Succeeded"
    Oraz formatka "F-ocena" procesu "wniosek-kredytowy" pozostaje bez zmian

  @FR-31
  Scenariusz: Nowa wersja nie powstanie z wersji formatki innego procesu
    Jeżeli "marta" tworzy nową wersję formatki "F-aneks" z wersji 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona regułą "R11"
    Oraz dziennik bezpieczeństwa zawiera "Form.NewVersion" z wynikiem "Denied" dla "marta"

  @FR-31
  Scenariusz: Wersja zastępcza musi pochodzić z tej samej formatki
    Jeżeli "marta" wycofuje wersję 2 formatki "F-aneks" z powodem "Defect" i wersją zastępczą 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona regułą "R11"

  @FR-31
  Scenariusz: Referencja z BPMN jest rozwiązywana tylko w procesie zadania
    Zakładając zadanie "T8" procesu "aneks-kredytowy" z referencją formatki "ph:form/ocena-wniosku"
    Oraz proces "aneks-kredytowy" nie ma formatki o kluczu "ocena-wniosku"
    Jeżeli "anna" pobiera szczegóły zadania "T8"
    Wtedy zadanie "T8" nie ma przypiętej formatki
    Oraz "marta" widzi w projektancie procesu "aneks-kredytowy" brakującą formatkę "ocena-wniosku"

  @FR-31
  Scenariusz: Zadanie nie wyrenderuje formatki innego procesu
    Zakładając zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Jeżeli zadanie "T5" zostaje przepięte na wersję 2 formatki "F-aneks"
    Wtedy operacja jest odrzucona regułą "R11"
    Oraz zadanie "T5" renderuje wersję 3

  @FR-31
  Scenariusz: Przeniesienie treści między procesami tylko przez jawny eksport i import
    Zakładając opublikowaną wersję 3 formatki "F-ocena"
    Jeżeli "marta" eksportuje wersję 3 formatki "F-ocena"
    Oraz "marta" importuje ten plik do formatki "F-aneks"
    Wtedy wersja robocza formatki "F-aneks" jest w stanie "Draft"
    Oraz formatka "F-ocena" procesu "wniosek-kredytowy" pozostaje bez zmian
    Oraz dziennik bezpieczeństwa zawiera "Form.Export" z wynikiem "Succeeded" dla "marta"
    Oraz dziennik bezpieczeństwa zawiera "Form.Import" z wynikiem "Succeeded" dla "marta"

  @FR-31 @integration
  Scenariusz: Baza nie pozwala przypiąć zadania do wersji formatki innego procesu
    Jeżeli wiersz zadania procesu "aneks-kredytowy" dostaje przypięcie wersji formatki procesu "wniosek-kredytowy"
    Wtedy baza odrzuca zapis naruszeniem klucza obcego
