# language: pl
Funkcja: Formatki w formacie Camunda Forms — projektant, katalog pól, import i eksport

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"

  @FR-28
  Scenariusz: Zapisany szkic jest poprawnym dokumentem Camunda Forms
    Jeżeli "marta" zapisuje w szkicu formatki "F-ocena" pola "kwota:number", "decyzja:radio" i "uzasadnienie:textarea"
    Wtedy schemat szkicu ma typ "default" i platformę wykonania "Camunda Cloud" w wersji "8.9.0"
    Oraz schemat szkicu przechodzi walidację oficjalnym schematem formatu Camunda Forms
    Oraz dziennik bezpieczeństwa zawiera "Form.Save" z wynikiem "Succeeded" dla "marta"

  @FR-28
  Szablon scenariusza: Katalog pól rozstrzyga, co wolno przekazać do przeglądu
    Zakładając szkic formatki "F-ocena" z komponentem typu "<typ>"
    Jeżeli "marta" przekazuje formatkę "F-ocena" do przeglądu
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | typ             | wynik                       |
      | textfield       | Succeeded                   |
      | datetime        | Succeeded                   |
      | dynamiclist     | Succeeded                   |
      | html            | Rejected:FieldCatalog       |
      | iframe          | Rejected:FieldCatalog       |
      | button          | Rejected:FieldCatalog       |
      | filepicker      | Rejected:FieldCatalog       |

  @FR-28
  Scenariusz: Paleta projektanta pokazuje tylko typy z katalogu pól
    Jeżeli "marta" otwiera projektanta formatki "F-ocena"
    Wtedy paleta zawiera typ "textfield"
    Ale paleta nie zawiera typu "iframe"
    Oraz paleta nie zawiera pola profilu "flota.CarModels"

  @FR-28
  Scenariusz: Pole profilu jest dostępne tylko w formatkach procesów profilu
    Jeżeli "alicja" otwiera projektanta formatki startowej procesu "rejestracja-samochodu"
    Wtedy paleta zawiera pole profilu "flota.CarModels"

  @FR-28
  Scenariusz: Import pliku z Modelera tworzy szkic
    Jeżeli "adam" importuje do formatki "F-ocena" plik ".form" z polami "decyzja" i "uzasadnienie"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz autor ostatniej zmiany formatki "F-ocena" to "adam"
    Oraz dziennik bezpieczeństwa zawiera "Form.Import" z wynikiem "Succeeded" dla "adam"

  @FR-28
  Scenariusz: Import pliku z typem spoza katalogu jest odrzucony w całości
    Jeżeli "adam" importuje do formatki "F-ocena" plik ".form" z komponentem typu "iframe"
    Wtedy operacja jest odrzucona błędem "FieldCatalog"
    Oraz formatka "F-ocena" nie ma nowej wersji roboczej

  @FR-28
  Scenariusz: Eksport opublikowanej wersji daje plik z numerem wersji
    Zakładając opublikowaną wersję 3 formatki "F-ocena"
    Jeżeli "marta" eksportuje wersję 3 formatki "F-ocena"
    Wtedy plik ".form" ma znacznik wersji "3"
    Oraz dziennik bezpieczeństwa zawiera "Form.Export" z wynikiem "Succeeded" dla "marta"

  @FR-28
  Scenariusz: Błąd składni wyrażenia FEEL blokuje publikację
    Zakładając zatwierdzoną formatkę "F-ocena" z warunkiem ukrycia pola "uzasadnienie" o treści "=decyzja = "
    Jeżeli "adam" publikuje formatkę "F-ocena"
    Wtedy walidacja kończy się błędem "FeelSyntax"
