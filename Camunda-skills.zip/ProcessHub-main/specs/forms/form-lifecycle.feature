# language: pl
Funkcja: Formatki — edycja przez menadżera lub administratora, cztery oczy, wersje

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"

  @FR-17
  Szablon scenariusza: Kto może edytować formatkę
    Jeżeli "<osoba>" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba | wynik                      |
      | marta | Succeeded                  |
      | adam  | Succeeded                  |
      | anna  | Denied:Form.Edit           |
      | olga  | Denied:Form.Edit           |

  @FR-17
  Scenariusz: Autor ostatniej zmiany nie zatwierdzi formatki
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "marta" zatwierdza formatkę "F-ocena"
    Wtedy operacja jest odrzucona regułą "R8"

  @FR-17
  Scenariusz: Zatwierdzenie przez inną uprawnioną osobę i publikacja
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "adam" zatwierdza formatkę "F-ocena"
    Oraz "marta" publikuje formatkę "F-ocena"
    Wtedy formatka "F-ocena" ma opublikowaną nową wersję
    Oraz dziennik bezpieczeństwa zawiera "Form.Approve" dla "adam" i "Form.Publish" dla "marta"

  @FR-17
  Scenariusz: Odrzucenie do poprawy wymaga komentarza i wraca do szkicu
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "adam" odrzuca formatkę "F-ocena" do poprawy z komentarzem "Brak pomocy przy polu decyzji"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz "marta" widzi komentarz przeglądu "Brak pomocy przy polu decyzji"
    Oraz dziennik bezpieczeństwa zawiera "Form.Reject" z wynikiem "Succeeded" dla "adam"

  @FR-17
  Scenariusz: Zmiana treści po zatwierdzeniu unieważnia zatwierdzenie
    Zakładając zatwierdzoną przez "adam" formatkę "F-ocena"
    Jeżeli "marta" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz publikacja formatki "F-ocena" wymaga ponownego zatwierdzenia

  @FR-17
  Scenariusz: Publikacja niezgodna z kontraktem danych zadania
    Zakładając zatwierdzoną formatkę "F-ocena" bez pola "uzasadnienie"
    Jeżeli "adam" publikuje formatkę "F-ocena"
    Wtedy publikacja jest odrzucona z błędem kontraktu dla wyjścia "uzasadnienie"

  @FR-18
  Scenariusz: Zadanie w toku zachowuje przypiętą wersję
    Zakładając zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Jeżeli zostaje opublikowana wersja 4 formatki "F-ocena"
    Wtedy zadanie "T5" renderuje wersję 3

  @FR-18
  Scenariusz: Nowe zadanie dostaje wersję obowiązującą
    Zakładając opublikowaną wersję 4 formatki "F-ocena"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie "T6" typu "OcenaWniosku"
    Wtedy zadanie "T6" renderuje wersję 4
