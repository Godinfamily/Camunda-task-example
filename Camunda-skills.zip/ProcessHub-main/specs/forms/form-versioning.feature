# language: pl
Funkcja: Wersje formatki — historia, numeracja, porównanie, nowa wersja

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" ma opublikowane wersje 1, 2 i 3, z których obowiązuje wersja 3

  @FR-29
  Scenariusz: Publikacja nadaje kolejny numer i zastępuje poprzednią wersję
    Zakładając zatwierdzoną przez "adam" formatkę "F-ocena"
    Jeżeli "marta" publikuje formatkę "F-ocena"
    Wtedy formatka "F-ocena" ma obowiązującą wersję 4
    Oraz wersja 3 formatki "F-ocena" jest w stanie "Superseded"

  @FR-29
  Scenariusz: Opublikowanej wersji nie da się zmienić
    Jeżeli "marta" zapisuje zmianę w wersji 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona błędem "VersionImmutable"

  @FR-29
  Scenariusz: Formatka ma najwyżej jedną wersję roboczą
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta"
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 2
    Wtedy operacja jest odrzucona błędem "WorkingVersionExists"

  @FR-29
  Scenariusz: Nowa wersja z dowolnej wcześniejszej
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 2
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz treść wersji roboczej jest równa treści wersji 2
    Oraz dziennik bezpieczeństwa zawiera "Form.NewVersion" z wynikiem "Succeeded" dla "adam"

  @FR-29
  Scenariusz: Historia szkicu pokazuje każdą zmianę i jej autora
    Zakładając szkic formatki "F-ocena" zmieniony kolejno przez "marta" i "adam"
    Jeżeli "olga" otwiera historię formatki "F-ocena"
    Wtedy historia zawiera 2 rewizje szkicu z autorami "marta" i "adam"
    Oraz historia zawiera wersje 1, 2 i 3 z osobami zatwierdzającymi i publikującymi

  @FR-29
  Scenariusz: Zatwierdzający widzi różnicę względem wersji obowiązującej
    Zakładając szkic formatki "F-ocena" z dodanym polem "warunki" i zmienioną etykietą pola "decyzja", przekazany do przeglądu
    Jeżeli "adam" otwiera przegląd formatki "F-ocena"
    Wtedy porównanie z wersją 3 pokazuje pole dodane "warunki"
    Oraz porównanie z wersją 3 pokazuje pole zmienione "decyzja" z własnością "label"

  @FR-29
  Scenariusz: Porzucenie szkicu nie zmienia wersji opublikowanych
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta"
    Jeżeli "marta" porzuca szkic formatki "F-ocena"
    Wtedy formatka "F-ocena" ma obowiązującą wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Discard" z wynikiem "Succeeded" dla "marta"
