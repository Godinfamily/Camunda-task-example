# language: pl
Funkcja: Wycofanie wersji formatki i całej formatki

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" ma opublikowane wersje 1, 2 i 3, z których obowiązuje wersja 3
    Oraz zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"

  @FR-30
  Szablon scenariusza: Kto może wycofać wersję
    Jeżeli "<osoba>" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 2
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba | wynik                |
      | marta | Succeeded            |
      | adam  | Succeeded            |
      | anna  | Denied:Form.Withdraw |
      | olga  | Denied:Form.Withdraw |

  @FR-30
  Scenariusz: Wycofanie bez powodu jest odrzucone
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" bez powodu
    Wtedy operacja jest odrzucona błędem "ReasonRequired"
    Oraz formatka "F-ocena" ma obowiązującą wersję 3

  @FR-30
  Scenariusz: Wersja zastępcza staje się obowiązująca, zadania w toku zostają
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 2
    Wtedy wersja 3 formatki "F-ocena" jest w stanie "Withdrawn"
    Oraz formatka "F-ocena" ma obowiązującą wersję 2
    Oraz zadanie "T5" renderuje wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Withdraw" z wynikiem "Succeeded" dla "marta"

  @FR-30
  Scenariusz: Wycofanie z przepięciem zadań w toku
    Zakładając szkic danych zadania "T5" z wartościami pól "decyzja" i "uwagiDodatkowe"
    Oraz wersja 2 formatki "F-ocena" nie ma pola "uwagiDodatkowe"
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect", wersją zastępczą 2 i przepięciem zadań w toku
    Wtedy zadanie "T5" renderuje wersję 2
    Oraz szkic danych zadania "T5" zachowuje pole "decyzja" i nie zawiera pola "uwagiDodatkowe"
    Oraz assignee zadania "T5" widzi informację "Formatka zadania została zmieniona po wycofaniu wersji 3"
    Oraz dziennik bezpieczeństwa zawiera "Form.Repin" z wynikiem "Succeeded" dla "marta"

  @FR-30
  Scenariusz: Wersja zastępcza musi spełniać bieżący kontrakt danych
    Zakładając kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"
    Oraz wersja 1 formatki "F-ocena" nie ma pola "uzasadnienie"
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 1
    Wtedy operacja jest odrzucona błędem "ReplacementContract"
    Oraz formatka "F-ocena" ma obowiązującą wersję 3

  @FR-30
  Scenariusz: Wycofanie bez wersji zastępczej blokuje zakończenie nowych zadań
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Compliance" bez wersji zastępczej
    Oraz w procesie "wniosek-kredytowy" powstaje zadanie "T7" typu "OcenaWniosku"
    Wtedy zadanie "T7" nie ma przypiętej formatki
    Oraz "anna" widzi na zadaniu "T7" informację "Formatka tego zadania została wycofana. Zgłoś to menadżerowi procesu."
    Oraz zakończenie zadania "T7" jest odrzucone błędem "FormUnavailable"

  @FR-30
  Scenariusz: Zadanie bez formatki dostaje ją po kolejnej publikacji
    Zakładając zadanie "T7" typu "OcenaWniosku" bez przypiętej formatki
    Jeżeli zostaje opublikowana wersja 4 formatki "F-ocena"
    Oraz "anna" pobiera szczegóły zadania "T7"
    Wtedy zadanie "T7" renderuje wersję 4

  @FR-30
  Scenariusz: Wycofanej wersji nie da się przywrócić na skróty
    Zakładając wersję 3 formatki "F-ocena" w stanie "Withdrawn"
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 3
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz publikacja formatki "F-ocena" wymaga ponownego zatwierdzenia

  @FR-30
  Scenariusz: Wycofanie całej formatki
    Jeżeli "adam" wycofuje formatkę "F-ocena" z powodem "ProcessChange"
    Wtedy formatka "F-ocena" jest w stanie "Retired"
    Oraz formatka "F-ocena" nie ma wersji obowiązującej
    Oraz zadanie "T5" renderuje wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Retire" z wynikiem "Succeeded" dla "adam"

  @FR-30 @FR-07
  Scenariusz: Wycofana formatka startowa wyłącza start procesu z aplikacji
    Zakładając proces "wniosek-kredytowy" z formatką startową "F-wniosek" wycofaną bez wersji zastępczej
    Jeżeli "anna" otwiera katalog procesów do startu
    Wtedy widzi proces "wniosek-kredytowy" z informacją "Start chwilowo niedostępny: formatka startowa została wycofana"
