# language: pl
Funkcja: Audyt każdej akcji — bezpieczeństwo i analiza problemów

  Założenia:
    Zakładając świat testowy Process Hub

  @FR-20
  Scenariusz: Każde żądanie zostawia ślad operacyjny, także odrzucone
    Jeżeli "anna" wywołuje dowolny endpoint bez uprawnienia
    Wtedy ślad operacyjny zawiera żądanie z kodem 403, czasem trwania i identyfikatorem śladu
    Oraz dziennik bezpieczeństwa zawiera wpis z wynikiem "Denied" i kodem reguły

  @FR-20
  Scenariusz: Błąd silnika jest diagnozowalny ze śladu
    Zakładając, że silnik odrzuca zakończenie zadania "T2" błędem walidacji zmiennych
    Jeżeli "celina" kończy zadanie "T2"
    Wtedy ślad operacyjny zawiera kod problemu z silnika i liczbę ponowień
    Oraz dziennik bezpieczeństwa zawiera "Intent" i "Outcome" z wynikiem "Failed"

  @FR-20
  Scenariusz: Dziennik nie zawiera wartości danych osobowych
    Jeżeli "celina" kończy zadanie "T2" danymi zawierającymi PESEL
    Wtedy wpis dziennika zawiera skrót danych i listę zmienionych pól
    Ale nie zawiera wartości PESEL

  @FR-20
  Scenariusz: Przerwana komenda zostaje uzgodniona
    Zakładając wpis "Intent" przekazania zadania "T1" bez wpisu "Outcome"
    Oraz read model pokazuje "bartek" jako assignee zadania "T1"
    Jeżeli uruchamia się job uzgadniający
    Wtedy dziennik bezpieczeństwa zawiera "Outcome" z wynikiem "Reconciled"

  @FR-20 @integration
  Scenariusz: Wpisu dziennika nie da się zmienić nawet z poziomu SQL
    Zakładając dowolny wpis w dzienniku bezpieczeństwa
    Jeżeli login aplikacji wykonuje UPDATE na tym wpisie
    Wtedy baza odrzuca operację

  @FR-20
  Scenariusz: Przeglądanie dziennika jest audytowane
    Jeżeli "olga" przegląda dziennik bezpieczeństwa sprawy "K-001"
    Wtedy dziennik bezpieczeństwa zawiera "Audit.ViewJournal" dla "olga"
