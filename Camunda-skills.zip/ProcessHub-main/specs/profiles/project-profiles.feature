# language: pl
Funkcja: Profile projektów — część wspólna i część specyficzna
  Jako bank
  Chcę, aby każdy projekt korzystał z tej samej platformy przez własny profil
  Aby zespoły projektów realizowały swoje potrzeby niezależnie i bez wpływu na inne projekty

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zarejestrowane profile "kredyty" (procesy: wniosek-kredytowy, aneks-kredytowy) i "aml" (procesy: weryfikacja-aml)
    Oraz zadanie "T1" procesu "wniosek-kredytowy" typu "OcenaWniosku" przypisane do "anna"
    Oraz zadanie "T3" procesu "weryfikacja-aml" typu "AnalizaAml" przypisane do "darek"

  @FR-23
  Scenariusz: Manifest przypisujący proces innego profilu jest odrzucony
    Jeżeli zespół profilu "aml" zgłasza manifest z procesem "wniosek-kredytowy"
    Wtedy walidacja manifestu kończy się błędem "proces należy już do profilu kredyty"
    Oraz rejestr profili pozostaje bez zmian

  @FR-23
  Scenariusz: Manifest z uprawnieniem spoza przestrzeni nazw profilu jest odrzucony
    Jeżeli zespół profilu "aml" zgłasza manifest z uprawnieniem "kredyty.Case.Export"
    Wtedy walidacja manifestu kończy się błędem reguły "R10"

  @FR-24
  Szablon scenariusza: Rola projektowa działa tylko w procesach swojego profilu
    Jeżeli "<osoba>" sprawdza uprawnienie "<uprawnienie>" dla zadania "<zadanie>"
    Wtedy wynik to "<wynik>"

    Przykłady:
      | osoba | uprawnienie                 | zadanie | wynik                                  |
      | anna  | kredyty.Scoring.Recalculate | T1      | Allowed: kredyty/analityk-kredytowy    |
      | anna  | kredyty.Scoring.Recalculate | T3      | Denied: R9                             |
      | darek | aml.Sanctions.Recheck       | T3      | Allowed: aml/analityk-aml              |
      | darek | kredyty.Scoring.Recalculate | T1      | Denied: brak uprawnienia               |
      | olga  | kredyty.Applicant.View      | T1      | Denied: brak uprawnienia               |

  @FR-24
  Scenariusz: Audyt zapisuje rolę projektową i profil
    Jeżeli "celina" przejmuje zadanie "T2" procesu "wniosek-kredytowy" typu "AkceptacjaUnderwritera"
    Wtedy dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Succeeded", rolą "kredyty/underwriter" i profilem "kredyty"

  @FR-25
  Scenariusz: Operacja dedykowana pojawia się w akcjach zadania tylko dla uprawnionego assignee
    Jeżeli "anna" pobiera szczegóły zadania "T1"
    Wtedy dozwolone akcje zawierają "kredyty.RecalculateScoring"
    Ale "bartek" pobierający szczegóły zadania "T1" nie widzi akcji "kredyty.RecalculateScoring"

  @FR-25
  Scenariusz: Operacji profilu nie można wykonać na zadaniu innego profilu
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T3"
    Wtedy operacja jest odrzucona regułą "R9"
    Oraz kod profilu "kredyty" nie został wywołany
    Oraz dziennik bezpieczeństwa zawiera "kredyty.RecalculateScoring" z wynikiem "Denied" i kodem "R9"

  @FR-25
  Scenariusz: Awaria operacji profilu nie blokuje pracy na zadaniu
    Zakładając operacja "kredyty.RecalculateScoring" przekracza limit czasu
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja kończy się błędem "ProfileOperationTimeout"
    Oraz "anna" nadal może zapisać szkic i zakończyć zadanie "T1"

  @FR-26
  Scenariusz: Wzbogacenie widoku zadania tylko w procesach profilu
    Jeżeli "anna" pobiera szczegóły zadania "T1"
    Wtedy widok zawiera sekcję "extensions.kredyty"
    Ale widok zadania "T3" pobrany przez "darek" nie zawiera sekcji "extensions.kredyty"

  @FR-26 @integration
  Scenariusz: Kod profilu nie czyta danych platformy ani innego profilu
    Zakładając kod profilu "kredyty" działa w kontekście bazy "prj_kredyty"
    Jeżeli kod profilu odczytuje tabelę "task.WorkItem"
    Wtedy baza odmawia dostępu
    Oraz odczyt tabeli "prj_aml.WynikSankcji" również kończy się odmową bazy

  @FR-27
  Scenariusz: Slot UI profilu pojawia się tylko przy zadaniach jego procesów
    Jeżeli "anna" otwiera zadanie "T1"
    Wtedy panel "Wnioskodawca" profilu "kredyty" jest widoczny
    Ale "darek" otwierający zadanie "T3" nie widzi panelu "Wnioskodawca"
