# language: pl
Funkcja: Mapa etapów jako warstwa biznesowa nad BPMN

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz wdrożona wersja 7 procesu "wniosek-kredytowy" z elementami "WeryfikujDane", "OcenaWniosku", "WyliczOferte", "AkceptacjaKlienta", "WniosekZaakceptowany", "WniosekOdrzucony"

  @FR-15
  Scenariusz: Administrator mapuje elementy, menadżer nazywa etapy
    Jeżeli "adam" przypisuje element "OcenaWniosku" do etapu "ocena" w szkicu mapy wersji 7
    Oraz "marta" zmienia nazwę etapu "ocena" na "Ocena wniosku" i ustawia cel SLA "P2D"
    Wtedy szkic mapy zawiera etap "Ocena wniosku" z elementem "OcenaWniosku"

  @FR-15
  Scenariusz: Menadżer bez uprawnienia nie mapuje elementów
    Jeżeli "marta" przypisuje element "WyliczOferte" do etapu "oferta" w szkicu mapy wersji 7
    Wtedy operacja jest odrzucona brakiem uprawnienia "StageMap.MapElements"

  @FR-15
  Scenariusz: Element może należeć tylko do jednego etapu
    Zakładając, że element "OcenaWniosku" jest w etapie "ocena"
    Jeżeli "adam" przypisuje element "OcenaWniosku" do etapu "oferta" w szkicu mapy wersji 7
    Wtedy operacja jest odrzucona błędem "ElementAlreadyMapped"

  @FR-15
  Scenariusz: Publikacja wymaga zmapowania wszystkich user tasków
    Zakładając szkic mapy wersji 7 bez elementu "AkceptacjaKlienta"
    Jeżeli "adam" publikuje mapę wersji 7
    Wtedy publikacja jest odrzucona z błędem "UnmappedUserTask" dla "AkceptacjaKlienta"

  @FR-15
  Scenariusz: Nowa wersja definicji dziedziczy mapowanie i raportuje różnice
    Zakładając opublikowaną mapę wersji 7
    Jeżeli wdrożona zostaje wersja 8 z nowym elementem "WeryfikacjaDodatkowa"
    Wtedy powstaje szkic mapy wersji 8 z mapowaniami z wersji 7
    Oraz raport różnic wskazuje niezmapowany element "WeryfikacjaDodatkowa"

  @FR-16
  Szablon scenariusza: Stan etapów liczony z historii instancji
    Zakładając opublikowaną mapę wersji 7
    Oraz instancja "K-002" odwiedziła elementy "<odwiedzone>" i jest aktywna na "<aktywny>"
    Jeżeli "marta" otwiera instancję "K-002"
    Wtedy etap "Ocena" ma stan "<ocena>"
    Oraz etap "Oferta" ma stan "<oferta>"

    Przykłady:
      | odwiedzone                  | aktywny           | ocena     | oferta    |
      | WeryfikujDane               | OcenaWniosku      | Active    | Pending   |
      | WeryfikujDane,OcenaWniosku  | AkceptacjaKlienta | Completed | Active    |

  @FR-16
  Scenariusz: Aktywny element niezmapowany nie ujawnia swojej nazwy
    Zakładając opublikowaną mapę wersji 7, w której element techniczny "PobierzScoring" nie jest zmapowany
    Oraz instancja "K-003" jest aktywna na "PobierzScoring" po etapie "Ocena"
    Jeżeli "marta" otwiera instancję "K-003"
    Wtedy widzi etap "Ocena" z adnotacją "w toku"
    Ale nie widzi nazwy "PobierzScoring"

  @FR-16
  Scenariusz: Edytor formatki pokazuje etap jej zadania
    Zakładając opublikowaną mapę wersji 7
    Jeżeli "marta" otwiera formatkę zadania "OcenaWniosku"
    Wtedy widzi mapę etapów z zaznaczonym etapem "Ocena"
