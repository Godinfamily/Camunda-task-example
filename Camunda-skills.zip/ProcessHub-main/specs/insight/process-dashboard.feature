# language: pl
Funkcja: Dashboard menadżera procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz w okresie "2026-10-01" – "2026-10-31" w procesie "wniosek-kredytowy":
      | sprawa | start      | koniec     | zdarzenie końcowe     | wynik    | incydent |
      | K-101  | 2026-10-02 | 2026-10-05 | WniosekZaakceptowany  | success  | nie      |
      | K-102  | 2026-10-03 | 2026-10-06 | WniosekOdrzucony      | rejected | nie      |
      | K-103  | 2026-10-04 | 2026-10-04 | BladIntegracji        | error    | nie      |
      | K-104  | 2026-10-10 |            |                       |          | tak      |
      | K-105  | 2026-10-12 |            |                       |          | nie      |

  @FR-14
  Scenariusz: Liczniki wyników rozróżniają sukces, odmowę i błąd
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy liczniki wynoszą:
      | wystartowane | sukces | negatywnie | błąd | aktywne | z incydentem |
      | 5            | 1      | 1          | 1    | 2       | 1            |

  @FR-14
  Scenariusz: Progi zdrowia kolorują metrykę
    Zakładając próg wskaźnika incydentów: zielony do 5%, bursztynowy do 15%, powyżej czerwony
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy wskaźnik incydentów wynosi 20% ze statusem "czerwony"

  @FR-14
  Scenariusz: Metryka bez progów nie ma koloru
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy metryka "przepustowość" nie ma statusu zdrowia

  @FR-14
  Scenariusz: Dashboard pokazuje świeżość danych
    Zakładając opóźnienie projektora 3 sekundy
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy"
    Wtedy widzi informację "dane sprzed 3 s"

  @FR-14
  Scenariusz: Dashboard procesu spoza zakresu jest niedostępny
    Jeżeli "marta" otwiera dashboard procesu "weryfikacja-aml"
    Wtedy operacja jest odrzucona brakiem uprawnienia "Insight.Dashboard"
