# language: pl
Funkcja: Eskalacje widoczne dla menadżera procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz opublikowaną mapę etapów procesu "wniosek-kredytowy"

  @FR-13
  Scenariusz: Timer z oznaczeniem eskalacji tworzy aktywną eskalację
    Zakładając instancję "K-010" z aktywnym zadaniem "OcenaWniosku" przypisanym do "anna"
    Jeżeli uruchamia się zdarzenie "SlaOcenyPrzekroczone" z poziomem eskalacji 1
    Wtedy lista eskalowanych osoby "marta" zawiera sprawę "K-010" z etapem "Ocena", poziomem 1 i osobą "anna"

  @FR-13
  Scenariusz: Eskalacja wygasa wraz z zakresem
    Zakładając aktywną eskalację sprawy "K-010" na zadaniu "OcenaWniosku"
    Jeżeli "anna" kończy zadanie "OcenaWniosku" w sprawie "K-010"
    Wtedy sprawa "K-010" nie jest na liście aktywnych eskalacji
    Oraz historia sprawy "K-010" zawiera eskalację z czasem trwania

  @FR-13
  Scenariusz: Naruszenie SLA bez eskalacji w BPMN to osobna kategoria
    Zakładając zadanie "OcenaWniosku" w sprawie "K-011" po celu SLA etapu "Ocena"
    Jeżeli "marta" otwiera listę eskalowanych
    Wtedy sprawa "K-011" jest w kategorii "po terminie", a nie "eskalowane"

  @FR-13
  Scenariusz: Eskalacje innych procesów są niewidoczne
    Zakładając aktywną eskalację w procesie "weryfikacja-aml"
    Jeżeli "marta" otwiera listę eskalowanych
    Wtedy lista nie zawiera spraw procesu "weryfikacja-aml"
