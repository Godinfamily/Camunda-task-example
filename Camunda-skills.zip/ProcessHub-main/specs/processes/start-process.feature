# language: pl
Funkcja: Start procesu z aplikacji i „moje procesy”

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz proces "wniosek-kredytowy" ma opublikowaną formatkę startową "F-wniosek"

  @FR-07
  Scenariusz: Uprawniona osoba startuje proces
    Jeżeli "anna" startuje proces "wniosek-kredytowy" formatką "F-wniosek" z poprawnymi danymi
    Wtedy w silniku powstaje instancja z tenantem "<default>"
    Oraz instancja ma zmienne "initiatorPartyId", "initiatorGroupIds" i "caseId"
    Oraz dziennik bezpieczeństwa zawiera "Process.Start" z wynikiem "Succeeded" dla "anna"

  @FR-07
  Scenariusz: Brak uprawnienia startu dla definicji
    Jeżeli "celina" startuje proces "wniosek-kredytowy" formatką "F-wniosek" z poprawnymi danymi
    Wtedy operacja jest odrzucona brakiem uprawnienia "Process.Start"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-07
  Scenariusz: Katalog startowy pokazuje tylko dozwolone procesy
    Jeżeli "anna" otwiera katalog procesów do startu
    Wtedy widzi proces "wniosek-kredytowy"
    Ale nie widzi procesu "weryfikacja-aml"

  @FR-08
  Scenariusz: Moje procesy pokazują bieżący etap bez technikaliów
    Zakładając, że "anna" wystartowała proces "wniosek-kredytowy" jako sprawę "K-001"
    Oraz instancja sprawy "K-001" jest na elemencie "OcenaWniosku"
    Jeżeli "anna" otwiera listę "Moje procesy"
    Wtedy sprawa "K-001" ma bieżący etap "Ocena"
