---
description: Stan planu platformy albo profilu — kroki gotowe do startu, blokady, bramki (np. /status albo /status kredyty)
agent: orchestrator
---
Jeśli podano nazwę profilu ($ARGUMENTS), uruchom `python3 tools/agents/plan_status.py --backlog profiles/$ARGUMENTS/backlog.yaml`, w przeciwnym razie `python3 tools/agents/plan_status.py`. Bez Pythona: `ph step status` z tymi samymi opcjami. Przedstaw wynik zwięźle: najpierw kroki gotowe do startu (krytyczne na początku), potem blokady (kroki platformy, bramki, decyzje). Zaproponuj, które kroki uruchomić równolegle (maks. `parallelism` z planu).
