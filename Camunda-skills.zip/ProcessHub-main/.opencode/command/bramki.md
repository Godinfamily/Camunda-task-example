---
description: Uruchom bramki deterministyczne (dod) kroku i streść wynik (np. /bramki S10)
agent: orchestrator
---
Uruchom `python3 tools/agents/run_dod.py $ARGUMENTS` (bez Pythona: `ph step dod $ARGUMENTS`) i streść wynik: które komendy przeszły, które nie, i pierwszy błąd każdej czerwonej. Nie poprawiaj kodu.
