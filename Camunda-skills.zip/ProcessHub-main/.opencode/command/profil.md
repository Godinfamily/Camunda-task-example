---
description: Przeprowadź krok z planu zespołu profilu projektu (np. /profil kredyty KRE-02)
agent: orchestrator
---
Przeprowadź krok $2 z planu profilu $1 (`profiles/$1/backlog.yaml`). Pracujesz dla zespołu profilu — zmiany wyłącznie w `profiles/$1/**`.

1. Uruchom `python3 tools/agents/prepare_step.py $2 --backlog profiles/$1/backlog.yaml` (bez Pythona: `ph step prepare $2 --backlog profiles/$1/backlog.yaml`). Jeśli krok czeka na krok platformy (S..), powiedz który i zatrzymaj się. Nie używaj `--force`.
2. Uruchom agenta profilu wskazanego przez skrypt (`$1-<rola>`) jako osobną sesję w worktree: `opencode run --dir <worktree> --agent $1-<rola> "Wykonaj pakiet plan/packets/$2.md"`. Nie używaj agentów platformy do kodu profilu ani narzędzia `task` do implementacji.
3. `python3 tools/agents/run_dod.py $2 --backlog profiles/$1/backlog.yaml --dir <worktree>` (bez Pythona: `ph step dod …` z tymi samymi opcjami); czerwone → ci-triage dostaje `profiles/$1/progress/$2.gates.json`, poprawka w nowym uruchomieniu (najwyżej 2 próby, potem człowiek).
4. Zielone → `opencode run --dir <worktree> --agent reviewer "Zrecenzuj krok $2: git diff main...HEAD i pakiet plan/packets/$2.md"`; dla profilu z danymi `restricted` także security-reviewer; dla zmian w `profiles/$1/frontend/**` także ui-reviewer.
5. Zapisz przekazanie w `profiles/$1/progress/$2.json` i podsumuj, co musi zrobić zespół profilu (PR do przeglądu przez CODEOWNERS profilu). Nigdy nie scalaj.
