---
description: Przygotuj krok planu platformy i przeprowadź go przez agentów (np. /krok S10)
agent: orchestrator
---
Przeprowadź krok $1 z plan/backlog.yaml.

1. Uruchom `python3 tools/agents/prepare_step.py $1` (bez Pythona: `ph step prepare $1`) i przeczytaj wynik: ścieżkę worktree, plik `.agent-scope` i pakiet roboczy. Jeśli skrypt odmówi (niespełnione zależności lub bramka), zatrzymaj się i powiedz, czego brakuje. Nie używaj `--force`.
2. Uruchom wykonawcę wskazanego przez skrypt jako osobną sesję w worktree: `opencode run --dir <worktree> --agent <agent> "Wykonaj pakiet plan/packets/$1.md"`. Jeśli jest para: `bdd-tester` przed implementerem w tym samym worktree; recenzent — w punkcie 5; inna para — część z sekcji „Para” pakietu. Nie zlecaj implementacji narzędziem `task`.
3. Sprawdź przekazanie (`python3 tools/agents/validate_output.py agents/schemas/handoff.schema.json <plik>`) i uruchom `python3 tools/agents/run_dod.py $1 --dir <worktree>` (bez Pythona: `ph step dod $1 --dir <worktree>`).
4. Gdy bramka jest czerwona: przekaż ścieżkę `plan/progress/$1.gates.json` agentowi ci-triage, a jego raport wykonawcy w nowym uruchomieniu. Najwyżej 2 próby, potem jedna sesja od zera z diagnozą recenzenta, potem zgłoś blokadę człowiekowi.
5. Gdy bramki są zielone: `opencode run --dir <worktree> --agent reviewer "Zrecenzuj krok $1: git diff main...HEAD i pakiet plan/packets/$1.md"`; jeśli diff dotyka ścieżek security_sensitive albo krok ma `pair: security-reviewer` — także security-reviewer; jeśli krok ma `pair: ui-reviewer` albo diff dotyka `frontend/**` lub `design/**` — także ui-reviewer.
6. Zapisz przekazanie JSON w `plan/progress/$1.json` i podsumuj: co zrobiono, wynik bramek, ustalenia recenzji, co musi zrobić człowiek (PR, scalenie, `plan_status.py --merged $1`, kryteria akceptacji z pakietu). Nigdy nie scalaj ani nie wypychaj zmian.
