---
name: ddd-module
description: Szablon i konwencje modułu backendu Process Hub (DDD, architektura heksagonalna, potok komend z audytem). Używaj ZAWSZE przy tworzeniu lub zmianie agregatów, komend, zapytań, handlerów, endpointów, repozytoriów i migracji w src/Modules/**.
---
# Moduł DDD w Process Hub

## Struktura (tworzy `dotnet new ph-module -n <Nazwa>`)
```
src/Modules/<Nazwa>/
  AGENTS.md                     cel, inwarianty, komendy testów (≤ 1 strona)
  <Nazwa>.Contracts/            jedyna publiczna powierzchnia: interfejsy, DTO, zdarzenia integracyjne
  <Nazwa>.Domain/               agregaty, value objects, zdarzenia domenowe, specyfikacje — bez EF/HTTP/SDK
  <Nazwa>.Application/          komendy, zapytania, handlery, porty, autoryzatory zasobów
  <Nazwa>.Infrastructure/       EF Core (schemat modułu), repozytoria, outbox, adaptery portów
  <Nazwa>.Api/                  endpointy (minimal API) rejestrowane przez moduł
```

## Agregat
- Stan prywatny, zmiana tylko przez metody zwracające `Result`; każda zmiana podnosi zdarzenie domenowe.
- Inwariant w agregacie, nie w handlerze. Reguły R1–R11 jako kody w `Rule` (do audytu i asercji).
- `TenantId` w każdym agregacie; `rowversion` przez konfigurację EF.

## Komenda — wzorzec
```csharp
[Audited("Task.Reassign", SensitiveRead = false)]
public sealed record ReassignTask(TaskKey TaskKey, PartyId Target, ReassignReason Reason)
    : ICommand<Result>, IIdempotent;

// Autoryzacja zasobu: ustala zakres (proces) i pyta politykę — przed handlerem, w potoku.
internal sealed class ReassignTaskAuthorizer(ITaskScopeLookup scopes, IAccessPolicy policy)
    : IResourceAuthorizer<ReassignTask>
{
    public async ValueTask<AccessDecision> Authorize(Actor actor, ReassignTask cmd, CancellationToken ct) =>
        policy.Decide(actor, Permission.TaskReassign, await scopes.Of(cmd.TaskKey, ct));
}

internal sealed class ReassignTaskHandler(
    IWorkItemRepository items, IUserTaskCommands camunda, IReassignTargetPolicy targets, IActorContext actor)
    : ICommandHandler<ReassignTask, Result>
{
    public async ValueTask<Result> Handle(ReassignTask cmd, CancellationToken ct)
    {
        var item = await items.Get(cmd.TaskKey, ct);
        var result = item.Reassign(actor.Current, cmd.Target, cmd.Reason, targets);
        if (result.IsFailure) return result;                     // potok zapisze Outcome=Denied/Failed
        await camunda.AssignAsync(item.Key, cmd.Target, allowOverride: true, item.Tenant, ct);
        return Result.Ok();                                      // UoW: stan + Outcome + outbox w jednej transakcji
    }
}
```
Potok (nie handler) odpowiada za: ślad, walidację, `IResourceAuthorizer`, audyt `Intent/Outcome`, idempotencję, transakcję.

## Zapytanie
- Czyta read model (Dapper/SQL), filtruje przez `TaskAccess` i moje principale; zwraca `allowedActions` liczone przez `IAccessPolicy`.
- Odczyt wrażliwy oznacz `[AuditedRead("Task.ViewDetails")]`.

## Zakazy
Typy SDK Camunda poza `CamundaIntegration` · referencje do wnętrza innego modułu · `if (role == …)` · `DateTime.Now` (używaj `TimeProvider`) · logowanie wartości z formatek.

## AGENTS.md modułu — szablon
```
# <Nazwa>
Cel: <1 zdanie>. Kontekst: <core|wspierający>. Scenariusze: specs/<…>.
Inwarianty: <lista kodów reguł>.
Porty wychodzące: <…>. Zdarzenia publikowane: <…>.
Testy: dotnet test tests/<Nazwa>.UnitTests; dotnet test tests/<Nazwa>.Specs --filter "Category!=integration"
```
