---
name: design-system
description: Design system Process Hub — tokeny z Figma, core/theming, core/ui-kit, komponenty pól formatek, dostępność i regresja wizualna. Używaj ZAWSZE przy zmianach w design/**, frontend/libs/core/theming, frontend/libs/core/ui-kit, frontend/apps/ui-catalog oraz przy każdym nowym widoku lub komponencie interfejsu.
---
# Design system Process Hub

Wytyczne w jednym miejscu: `docs/artifacts/04-wytyczne-ui.md`. Wzorzec wizualny: `design/README.md`, makieta `design/mockups/index.html`. Formatki: `design/forms/README.md`.

## Źródła
- Wygląd projektuje człowiek w Figma; do repozytorium trafia eksport. Kod czyta tylko `design/tokens.json` i `design/forms/field-catalog.yaml`.
- `core/theming` zamienia tokeny na zmienne CSS (`--action`, `--ink`, `--space-4`…) i motyw Kendo. Motywy: jasny, ciemny, systemowy.

## Zasady twarde
- Żadnej wartości koloru, rozmiaru czcionki, odstępu ani promienia poza tokenami. Brakuje tokenu → pytanie do `ux-designer`, nie własna wartość.
- Widoki używają komponentów `core/ui-kit`; Kendo bezpośrednio tylko wewnątrz `ui-kit`.
- Flagowa czerwień (`flag-red`) wyłącznie dla elementów nietekstowych; tekst i akcje — `action`.
- Kolor nigdy nie jest jedynym nośnikiem informacji: status ma kształt i słowo (krytyczny — kwadrat, ostrzeżenie — trójkąt, poprawny — koło).
- Akcje tylko z `allowedActions`; akcji, której nie wolno wykonać, nie ma — zamiast niej jedno zdanie „dlaczego”.

## Komponent
- Kontrolka 44 px, obramowanie 1 px `line-strong`, promień 6 px, fokus 3 px z odstępem 2 px.
- Etykieta nad polem (700), „(wymagane)” słowem, podpowiedź 14 px pod polem, błąd 14 px/700 ze znacznikiem; `aria-describedby`, `aria-invalid`.
- Stany: domyślny, najechany, fokus, wypełniony, błąd, tylko do odczytu, wyłączony — każdy w obu motywach, każdy w `apps/ui-catalog`.
- Układ bez przewijania w poziomie od 390 px; cele dotykowe ≥ 44 px; `prefers-reduced-motion`.

## Formatki
- Jeden typ z katalogu pól = jeden komponent `ph-*`. Komponent nie zna schematu ani FEEL — dostaje etykietę, podpowiedź, stan, błąd i wartość.
- Siatka 16 kolumn, odstęp 16 px, szerokość formatki do 880 px, jedna kolumna poniżej 600 px.

## Testy
- Regresja wizualna: zrzuty Playwright katalogu komponentów w motywie jasnym i ciemnym przy 390, 768, 1280 px. Wzorce zmienia się tylko za zgodą projektanta UX.
- axe-core dla każdego komponentu i stanu; brak naruszeń WCAG 2.2 AA.
- Lint tokenów: brak literałów kolorów i pikseli w `frontend/libs/**` poza `core/theming`.
