---
name: profile-extension
description: Jak realizować część specyficzną profilu projektu w Process Hub (SDK rozszerzeń, operacje dedykowane, wzbogacenia zadań, dane w schemacie prj_<id>, sloty UI, model remote). Używaj ZAWSZE przy pracy w profiles/<id>/** oraz przy zmianach SDK rozszerzeń w src/Platform/ProcessHub.Extensibility i frontend/libs/platform/extension-sdk.
---
# Rozszerzenie w profilu projektu

Pełny opis: `docs/architecture/13-project-profiles.md`. Kontrakt profilu: `profiles/<id>/profile.yaml` (zmiany zatwierdza architekt platformy).

## Zasady
- Zależności: tylko `ProcessHub.Extensibility` (+ `ProcessHub.Extensibility.Testing` w testach) i `@process-hub/extension-sdk`. Test architektury odrzuci referencję do `ProcessHub.Modules.*` i do innych profili.
- Każda operacja, wzbogacenie i slot musi być zadeklarowany w `profile.yaml` — platforma rejestruje tylko zadeklarowane elementy; identyfikator w kodzie = identyfikator w manifeście.
- Operacja nie sprawdza uprawnień ani nie pisze audytu sama — robi to potok platformy (uprawnienie z manifestu, R1 dla `requiresAssignee`, R9, audyt Intent/Outcome, idempotencja). Ty implementujesz logikę biznesową.
- Dane: `ProfileDbContext` ze schematem `prj_<id>`; dane platformy przez `IPlatformQueries` albo widoki `platform_api`. Brak bezpośrednich zapytań do tabel platformy.
- Zmienne procesu zmieniasz tylko przez `ctx.Tasks` (szkic lub zakończenie zadania) — nigdy przez Camunda.

## Operacja na zadaniu (C#)
```csharp
[ProfileOperation("kredyty.RecalculateScoring")]               // = operations[].id w profile.yaml
internal sealed class RecalculateScoring(IScoringClient scoring, KredytyDb db)
    : ITaskOperation<RecalculateScoring.Input>
{
    public sealed record Input(string? Reason);

    public async ValueTask<OperationResult> ExecuteAsync(TaskOperationContext ctx, Input input, CancellationToken ct)
    {
        var applicationId = ctx.Task.Variables.GetRequired<string>("applicationId");
        var score = await scoring.CalculateAsync(applicationId, ct);
        db.ScoringResults.Add(ScoringResult.Record(applicationId, score, ctx.Actor.PartyId, ctx.Clock.UtcNow));
        await ctx.Tasks.SaveDraftAsync(new { scoring = score.Value }, ct);   // szkic zadania przez platformę (R1)
        return OperationResult.Ok(new { score = score.Value });
    }
}
```

## Operacja na danych profilu (C#, SDK 1.1, ADR-017)
Dla danych referencyjnych prowadzonych w aplikacji bez zadania i sprawy (katalog, słownik, progi). W manifeście: `kind: profile-action`, uprawnienie projektu rodzaju `write`, jawne `requiresAssignee: false`, bez `appliesTo`.
```csharp
[ProfileOperation("flota.SaveCatalogItem")]                    // = operations[].id w profile.yaml
internal sealed class SaveCatalogItem(FlotaDb db) : IProfileAction<SaveCatalogItem.Input>
{
    public sealed record Input(string? ItemId, string Brand, string Model, string Version, string Category, decimal NetPrice, int Co2);

    public async ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, Input input, CancellationToken ct)
    {
        if (input.Co2 > CarCatalogPolicy.MaxCo2)                 // reguła biznesowa profilu, nie uprawnienie
            return OperationResult.Invalid("co2", $"Emisja CO2 przekracza limit polityki floty ({CarCatalogPolicy.MaxCo2} g/km).");
        var item = await db.CatalogItems.FindOrNewAsync(input.ItemId, ct);
        item.Apply(input, ctx.Actor.PartyId, ctx.Clock.UtcNow); // historia zmian w prj_flota
        return OperationResult.Ok(new { itemId = item.Id });  // audyt, idempotencja, kontekst bazy — potok platformy
    }
}
```
Przyciski „Dodaj model”, „Zmień”, „Wycofaj” renderuje powłoka z `allowedActions` wyniku zapytania `flota.CarCatalog`.

## Rejestracja modułu profilu
```csharp
public sealed class KredytyProfile : IProfileModule
{
    public ProfileId Id => new("kredyty");
    public void Register(IProfileBuilder p) => p
        .UseDatabase<KredytyDb>()                                // schemat prj_kredyty, migracje profilu
        .AddTaskOperation<RecalculateScoring, RecalculateScoring.Input>()
        .AddTaskEnricher<ApplicantSummary>()                     // sekcja extensions.kredyty w widoku zadania
        .AddFormDataSource<ProductCatalog>("kredyty.ProductCatalog")
        .AddEventHandler<ScoringResultProjection>()              // zdarzenia platformy tylko dla procesów profilu
        .AddQuery<PortfolioReport, PortfolioReport.Result, PortfolioReportHandler>();
}
// profil z operacjami na danych profilu (SDK 1.1): .AddProfileAction<SaveCatalogItem, SaveCatalogItem.Input>()
```

## Slot UI (TypeScript)
```ts
export const kredytyUi: ProfileUiModule = {
  id: "kredyty",
  routes: [{ path: "portfel", loadComponent: () => import("./portfolio.page").then(m => m.PortfolioPage) }],  // /p/kredyty/portfel
  slots: [
    { slot: "task.panel", component: ApplicantPanelComponent, when: { process: "wniosek-kredytowy" } },
    { slot: "dashboard.widget", component: PortfolioWidgetComponent },
  ],
}
```
Przyciski operacji renderuje platforma z `allowedActions` — komponent profilu nie decyduje, czy akcja jest dozwolona.

Sekcja nawigacji profilu (`nav.section`) i trasy `/p/<id>/…` — przykład profilu `flota`:
```ts
export const flotaUi: ProfileUiModule = {
  id: "flota",
  routes: [{ path: "katalog", loadComponent: () => import("./catalog.page").then(m => m.CatalogPage) }],   // /p/flota/katalog
  slots: [
    { slot: "nav.section", component: FleetNavSectionComponent },          // grupa „Flota” w szufladzie nawigacji
    { slot: "form.field", component: CarModelSelectComponent, when: { process: "rejestracja-samochodu" } },
  ],
}
```
Pole formatki (`form.field`) to wariant typu bazowego Camunda Forms wskazany w schemacie własnością `ph:field = <profil>.<nazwa>`; komponent budujesz z `core/ui-kit`, bez własnych stylów, a formatkami zarządzają menadżer i administrator procesu (skill `camunda-forms`).

Widoczność sekcji i trasy liczy platforma z uprawnienia trasy (`flota.Catalog.View`); bez niego sekcji nie ma, a wejście z adresu kończy się odmową w dzienniku. Pełny przewodnik: `docs/guides/dedykowane-elementy-profilu.md`.

## Model remote
Usługa zespołu implementuje `profile-operations v1` (OpenAPI dostarcza platforma): `POST /operations/{operationId}` z kontekstem (zadanie, aktor, uprawnienie, requestId) w żądaniu podpisanym przez platformę (mTLS + krótki token). Zwraca wynik i ewentualne zmiany szkicu; audyt i autoryzację wykonuje platforma. Usługa nie łączy się z Camunda ani z bazą platformy.

## Testy
- `ProcessHub.Extensibility.Testing`: host w pamięci (zadania, aktorzy, asercje audytu) — scenariusze profilu bez platformy.
- Test zgodności SDK (dostarcza platforma) uruchamiany w CI profilu przy każdej zmianie wersji SDK.
