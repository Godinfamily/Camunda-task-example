---
name: camunda-practices
description: Praktyki integracji z Camunda 8.9 i oficjalnym SDK w Process Hub. Używaj ZAWSZE przy pracy z modułem CamundaIntegration, plikami BPMN, task listenerami, projekcją read modelu, autoryzacjami Camunda, startem procesów, przypisywaniem zadań i eskalacjami — także gdy zadanie tylko pośrednio dotyka Camunda.
---
# Praktyki Camunda w Process Hub

Pełne uzasadnienia: `docs/architecture/06-camunda-integration.md`. Tu jest lista kontrolna do stosowania przy każdej zmianie.

## Granica (ACL)
- SDK tylko w `CamundaIntegration.Infrastructure.Sdk`. Na zewnątrz wyłącznie porty z `CamundaIntegration.Contracts` i typy domenowe (`TaskKey`, `BpmnProcessId`, `TenantId`).
- Każdy port = adapter SDK + fake in-memory + jeden zestaw testów kontraktowych dziedziczony przez oba (`UserTaskCommandsContract<TSut>`).
- Każde wywołanie z jawnym `tenantId`. Brak tenanta → `MissingTenantException`, nigdy domyślny.
- Jeden klient SDK na rolę hosta (singleton). Ponowienia z SDK; własny Polly tylko tam, gdzie SDK ich nie ma.

## Zadania
- Przejęcie: `assignment(allowOverride: false)`; konflikt → wynik `AlreadyAssigned(by)`.
- Przekazanie przez menadżera: `assignment(allowOverride: true)`; zmiana grupy: zwolnienie (jeśli przypisane) + aktualizacja `candidateGroups`. Nigdy anulowanie i ponowne tworzenie zadania.
- Zakończenie: tylko zmienne z kontraktu `ph:outputs`; `requestId` w dzienniku; „już zakończone” przy tym samym `requestId` = sukces.

## Procesy
- Start tylko przez BFF: `initiatorPartyId`, `initiatorGroupIds`, `caseId`, jawny `tenantId`.
- Formatki przez `zeebe:formDefinition externalReference="ph:form/<klucz>"`; klucz rozwiązywany w procesie zadania (R11), wersja przypinana przy utworzeniu zadania. Nigdy `formId` ani formularz osadzony; formatek nie wdrażamy do silnika (skill `camunda-forms`).
- Wyrażenia FEEL formatek na serwerze: port `IExpressionEvaluator` (ADR-020).
- Eskalacje: nieprzerywający timer + `ph:escalationLevel`/`ph:escalationReason`; nigdy `error event` dla eskalacji ani odmowy.
- Każde zdarzenie końcowe ma `ph:outcome` ∈ {success, rejected, error}.

## Task listener `ph.substitution`
- Zdarzenia `creating`, `assigning`; korekta assignee/grup z rejestru `Absence`.
- Limit czasu odpowiedzi platformy; przekroczenie → zakończ job bez korekty + audyt `SubstitutionSkipped` (fail-open). Nie rzucaj błędu blokującego zadanie.
- Nie koryguj, jeśli docelowy assignee nie jest nieobecny (unikaj pętli przy `assigning`).

## Projekcja
- Upsert po kluczu Camunda; inbox na duplikaty; znacznik czasu z zakładką; metryka `read_model_lag_seconds`.
- Katalog elementów z XML raz na wersję definicji; XML nie wychodzi poza moduł bez `Bpmn.ViewTechnical`.

## BPMN (bpmnlint `ph`)
`zeebe:userTask` · nazwa na user tasku · `candidateGroups` jako FEEL/identyfikator dozwolony · `ph:outcome` na końcach · `ph:escalationLevel` na timerach eskalacji · `ph:outputs` przy formatkach · referencja formatki tylko `ph:form/<klucz>` · listenery `ph.substitution`.

## Autoryzacje
Nie zmieniaj ich ręcznie ani z kodu funkcji. Jedyna ścieżka: `config/authorization/*.yaml` → reconciler → `IAuthorizationAdmin`.
