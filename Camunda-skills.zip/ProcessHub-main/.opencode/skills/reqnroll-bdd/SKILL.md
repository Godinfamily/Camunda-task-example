---
name: reqnroll-bdd
description: Konwencje testów BDD w Reqnroll dla Process Hub (Gherkin po polsku, cienkie kroki, drivery in-memory i integracyjne, świat testowy). Używaj ZAWSZE przy pisaniu kroków, driverów, hooków i asercji w tests/*.Specs oraz przy uruchamianiu scenariuszy ze specs/.
---
# BDD w Reqnroll

## Układ
```
tests/<Moduł>.Specs/
  <Moduł>.Specs.csproj      pliki .feature dołączone jako linki ze specs/ (konfigurację MSBuild Reqnroll potwierdza S14)
  Steps/                     bindingi — tylko delegacja do driverów
  Drivers/                   I<Moduł>Driver + InMemory<Moduł>Driver + Integration<Moduł>Driver
  Hooks/                     wybór drivera po tagu, budowa świata testowego
tests/Shared/World/          osoby, grupy, procesy ze specs/README.md
```

## Zasady
- Pliki `.feature` są tylko do odczytu. Krok niejasny → RFC.
- Wyrażenia Cucumber (`{string}`, `{int}`); atrybuty `[Given]/[When]/[Then]` dopasowują polskie słowa kluczowe.
- Tag `@integration` → driver integracyjny (Testcontainers MSSQL + Camunda); brak tagu → in-memory. Tagi stają się kategoriami testów, więc filtr `--filter "Category!=integration"` działa w CI.
- Stan scenariusza w `ScenarioContext` lub obiekcie wstrzykiwanym; żadnych pól statycznych.
- Czas sterowany `FakeTimeProvider` („Zakładając bieżącą datę …”).
- Asercje domenowe z `tests/Shared/Assertions`: `ShouldBeDeniedBy(rule)`, `ShouldSucceed()`, `ShouldContainJournalEntry(action, outcome, actor)`.

## Przykład
```csharp
[Binding]
public sealed class ReassignmentSteps(ITaskWorkDriver driver, ScenarioContext ctx)
{
    [When("{string} przekazuje zadanie {string} osobie {string} z powodem {string}")]
    public async Task WhenReassigns(string manager, string task, string target, string reason) =>
        ctx.Set(await driver.ReassignAsync(manager, task, target, reason));

    [Then("operacja jest odrzucona regułą {string}")]
    public void ThenDenied(string rule) => ctx.Get<CommandResult>().ShouldBeDeniedBy(rule);

    [Then("dziennik bezpieczeństwa zawiera {string} z poprzednim wykonawcą {string} i nowym {string}")]
    public Task ThenJournal(string action, string previous, string current) =>
        driver.Journal.ShouldContainReassignmentAsync(action, previous, current);
}
```
