---
name: camunda-forms
description: Formatki Process Hub w formacie Camunda Forms (schemat form-js, FEEL) — cykl życia wersji, separacja per proces, katalog pól, walidacja i renderowanie. Używaj ZAWSZE przy pracy z modułami FormManagement i FormRuntime, bibliotekami form-designer i form-runtime, plikami .form, katalogiem pól oraz scenariuszami specs/forms.
---
# Formatki w formacie Camunda Forms

Pełny opis: `docs/architecture/14-form-management.md`; decyzje: ADR-018, ADR-019, ADR-020; katalog pól: `design/forms/field-catalog.yaml`; wzorzec pliku: `design/forms/examples/ocena-wniosku.form`.

## Format
- Treść wersji to dokument Camunda Forms: `type: "default"`, `id`, `schemaVersion` (≤ 19), `executionPlatform: "Camunda Cloud"`, `executionPlatformVersion: "8.9.0"`, `exporter`, `components`. Żadnych własnych pól najwyższego poziomu — metadane cyklu życia żyją obok schematu.
- Pole wiążące dane ma `key` (wzorzec `^\w+(\.\w+)*$`); kontenery (`group`, `dynamiclist`) mają `path` i `components`.
- Układ: `layout.row` + `layout.columns` (2–16 z 16 albo brak). Walidacja: `validate.required|minLength|maxLength|min|max|pattern|validationType`. Warunek: `conditional.hide` (FEEL). `readonly` i `disabled`: wartość logiczna albo wyrażenie.
- Schemat nie niesie wyglądu. Nie dodawaj własności stylu ani klas CSS; własne własności tylko w `properties` z prefiksem `ph:` (np. `ph:field` dla pól profili).
- Serwer waliduje dokument katalogiem pól (podzbiór formatu); w testach każda formatka wzorcowa i każda publikowana wersja musi przejść oficjalny schemat `@bpmn-io/form-json-schema`.

## Katalog pól
- Typ spoza statusu „wspierany” lub „z ograniczeniami” → odrzucenie przy imporcie, przekazaniu do przeglądu i publikacji (`Rejected:FieldCatalog`). Zablokowane: `html`, `iframe`, `button`; planowane: `filepicker`, `documentPreview`.
- Jeden typ = jedna implementacja `IFieldType` (backend) = jeden komponent `ph-*` (frontend). Test parytetu porównuje wszystkie trzy listy z katalogiem.

## Cykl życia
- Stany wersji: `Draft → InReview → Approved → Published → Superseded | Withdrawn`. Jedna wersja robocza, jedna obowiązująca.
- `Approve`: osoba ≠ autor ostatniej zmiany (R8), zatwierdzenie wiąże skrót treści. `SubmitForReview`: katalog pól + składnia FEEL. `Publish`: to samo + kontrakt danych (`ph:outputs`) + niezmieniony skrót zatwierdzonej treści.
- `Withdraw`: powód obowiązkowy; wersja zastępcza wcześniej opublikowana i zgodna z kontraktem; tryb zadań w toku `KeepPinned` (domyślny) albo `Repin`.
- Wersje `Published`, `Superseded`, `Withdrawn` są niezmienne. Formatek nie usuwamy.

## Separacja (R11)
- Tożsamość: `(TenantId, BpmnProcessId, FormKey)`. Każda komenda i każde zapytanie przyjmuje zakres procesu; trasy pod `/api/processes/{bpmnProcessId}/forms`.
- Referencja `ph:form/<klucz>` jest rozwiązywana tylko w procesie zadania. Żadna operacja nie łączy formatek dwóch procesów — odmowa z kodem `R11` i wpisem w dzienniku.
- Pola profilu (`ph:field`) i źródła danych tylko w formatkach procesów profilu (R9).

## Walidacja danych zadania (serwer)
- Poziom A zawsze: tylko znane klucze, typy, ograniczenia statyczne, opcje statyczne, pole stale `readonly` nie zmienia wartości wejściowej, pole stale `disabled` nie jest przyjmowane, kontrakt `ph:outputs` (wyjście pola ukrytego ma wartość pustą).
- Poziom B: wyrażenia FEEL przez `IExpressionEvaluator`; pole ukryte nie jest wymagane ani przyjmowane. Brak ewaluacji = błąd z ponowieniem, nigdy obniżenie walidacji.
- W dzienniku skrót i lista pól, bez wartości wpisanych przez wykonawcę.

## Frontend
- `form-designer`: osadzony `@bpmn-io/form-js-editor`, paleta i właściwości z katalogu; znak bpmn.io widoczny; edycja tylko w `Draft`.
- `form-runtime`: własny renderer — interpretacja schematu (`@bpmn-io/feelin`, `feelers`), materializacja komponentami `ph-*` z `core/ui-kit`; zero stylów w rendererze.
- Zestaw zgodności: te same widoczne pola, błędy i dane wyjściowe co referencyjny form-js.

## Audyt
`Form.Create`, `Form.Save`, `Form.Import`, `Form.Export`, `Form.SubmitForReview`, `Form.Recall`, `Form.Reject`, `Form.Approve`, `Form.Publish`, `Form.NewVersion`, `Form.Discard`, `Form.Withdraw`, `Form.Retire`, `Form.Repin` — zawsze z `BpmnProcessId`, kluczem formatki i numerem wersji.
