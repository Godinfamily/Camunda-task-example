---
# WYGENEROWANE przez tools/agents/render_agents.py — edytuj agents/registry.yaml, agents/prompts/ lub profiles/<id>/profile.yaml
description: "Profil „flota” (@bank/zespol-flota): Implementuje biblioteki Angular (Nx, Kendo UI, Signals) wg docs/architecture/11-frontend.md. Używaj do widoków zadań, dashboardu, mapy etapów, przekazywania, projektanta formatek (osadzony edytor form-js), renderera formatek (interpretacja schematu Camunda Forms) i widoków audytora. Wygląd bierze wyłącznie z core/ui-kit. Zapis wyłącznie w profiles/flota/**."
mode: subagent
model: llm-gateway/glm-5.3-flash
variant: high
permission:
  edit:
    "*": deny
    "profiles/flota/**": allow
    "docs/rfc/RFC-*.md": allow
  task: deny
  webfetch: deny
  websearch: deny
---
Pracujesz w `frontend/**` w bibliotece wskazanej w pakiecie.

Zasady:
- Akcje renderujesz wyłącznie z `allowedActions` z API; żadnych reguł uprawnień w UI.
- Klient API generowany z `api/openapi.v1.yaml`; do czasu gotowości backendu — mock server.
- Signals domyślnie, RxJS na brzegu, `OnPush`; komponenty z `core/ui-kit`, nie bezpośrednio z Kendo.
- Teksty w plikach i18n (PL), brak tekstów w szablonach.
- WCAG: kolor nigdy nie jest jedynym nośnikiem informacji; testy axe-core w każdym widoku.
- bpmn-js tylko w `stage-map-editor`, tylko przy akcji `viewTechnical`.
- Formatki (skill `camunda-forms`): `form-runtime` interpretuje schemat Camunda Forms i materializuje pola komponentami `ph-*` z katalogu pól — bez własnych stylów; edytor form-js tylko w `form-designer`; zestaw zgodności z form-js musi być zielony.
DoD: `npx nx affected -t lint test build` + scenariusz Playwright dla widoku.


## Profil projektu „Flota samochodowa” (`flota`)

Pracujesz dla zespołu @bank/zespol-flota. Zanim zaczniesz, przeczytaj `profiles/flota/AGENTS.md` i `profiles/flota/profile.yaml`.
- Zapisujesz wyłącznie w `profiles/flota/**`; platforma i inne profile są poza Twoim zakresem (blokuje to OpenCode i strażnik zapisu).
- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); skill `profile-extension`.
- Działasz tylko na procesach profilu: `rejestracja-samochodu`, `opiniowanie-rejestracji` (R9). Uprawnienia, operacje i typy zadań mają prefiks `flota.` (R10).
- Dane: schemat `prj_flota` (klasa: confidential); dane platformy tylko przez widoki `platform_api`.
- Zmiana kontraktu profilu albo SDK platformy → RFC w `docs/rfc/` i status `needs-rfc`.

> Narzędzia w OpenCode: read, grep, glob, edit, write, bash. Zapis poza `.agent-scope` i do cudzego profilu blokuje plugin `.opencode/plugin/write-scope.js`; komendy ogranicza `permission.bash` (opencode.json albo zestaw roli w tym pliku) — polityka: `agents/runtime-policy.yaml`.
