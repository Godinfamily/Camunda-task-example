// Plugin OpenCode: blokuje zapis poza .agent-scope, edycję ścieżek chronionych (specyfikacje, kontrakty, ADR,
// uprawnienia, SDK rozszerzeń, kontrakty profili) oraz zapis do cudzego profilu projektu.
// Logika: tools/guard/enforce_write_scope.py albo narzędzie .NET `ph guard` (tools/dotnet) — ta sama w CI.
import { check, targetsOf } from "../lib/write-scope-core.js"

export default async ({ directory, worktree }) => {
  const root = worktree || directory
  return {
    "tool.execute.before": async (input, output) => {
      for (const file of targetsOf(input?.tool, output?.args)) {
        const result = check(root, file, input?.tool)
        if (!result.ok) throw new Error(result.reason)
      }
    },
  }
}
