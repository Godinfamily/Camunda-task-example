# RFC-FLO-03: Operacja na danych profilu bez zadania i sprawy

| Pole | Wartość |
| --- | --- |
| Zgłasza | zespół profilu `flota` (`@bank/zespol-flota`) |
| Krok | FLO-03 — katalog samochodów (`profiles/flota/backlog.yaml`) |
| Dotyczy | kontrakt profili (`profiles/profile.schema.json`), SDK rozszerzeń, potok operacji (S38), sloty UI (S47) |
| Propozycja rozstrzygnięcia | ADR-017 (Proponowana) — zatwierdza architekt platformy w przeglądzie PR (`CODEOWNERS`) |

## Potrzeba

Wnioskodawca wybiera samochód z katalogu floty banku. Katalog — marka, model, wersja, kategoria floty, cena, emisja CO2, umowa ramowa — uzupełnia w aplikacji jedna rola profilu: **Administrator katalogu samochodów**. Wszystkie role profilu widzą katalog w sekcji nawigacji „Flota”; role innych profili go nie widzą, a formatki innych procesów nie mogą z niego korzystać.

## Dlaczego obecne punkty rozszerzeń nie wystarczają

| Punkt | Dlaczego nie |
| --- | --- |
| `query`, `form-data-source`, `task-enricher` | tylko odczyt |
| `task-action` | wymaga zadania i assignee (R1); dopisanie modelu do katalogu nie jest krokiem żadnego procesu |
| `case-action` | wymaga instancji procesu; katalog istnieje niezależnie od spraw |
| `event-handler` | reaguje na zdarzenia platformy, nie na decyzję użytkownika |

## Propozycja

Nowy rodzaj operacji `profile-action` — zapis danych profilu w `prj_<id>`, wykonywany przez ten sam potok co pozostałe operacje:

```yaml
- id: flota.SaveCatalogItem
  kind: profile-action
  title: Zapisz model w katalogu
  permission: flota.Catalog.Manage      # uprawnienie projektu rodzaju write
  requiresAssignee: false               # jawnie: nie ma zadania, R1 nie dotyczy
  idempotent: true                      # bez appliesTo — operacja nie dotyczy procesów (R9)
```

```csharp
public interface IProfileAction<TInput>
{
    ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, TInput input, CancellationToken ct);
}

public sealed record ProfileActionContext(ActorContext Actor, IClock Clock);   // bez zadania i bez komend Camunda
```

- Endpoint `POST /p/<id>/actions/{operationId}` z `requestId`; potok: uprawnienie, odmowa audytowana (`Denied`), audyt Intent/Outcome (zasób `profile:<id>/<encja>/<klucz>`), idempotencja, limit czasu, kontekst bazy `prj_<id>`.
- Wynik zapytania profilu (`query`) przychodzi z `allowedActions` — przyciski „Dodaj model”, „Zmień”, „Wycofaj” renderuje powłoka.
- SDK 1.1 (zmiana zgodna wstecz); profile na `^1.0` bez zmian.

## Rozważone alternatywy

| Wariant | Ocena |
| --- | --- |
| Proces BPMN „zmiana katalogu” (wniosek → zatwierdzenie → zapis przez workera) | działa na obecnych punktach i daje cztery oczy, ale każda poprawka ceny to sprawa w Camunda, a administrator czeka na zatwierdzenie, którego biznes nie wymaga. Zostaje zalecanym wzorcem, gdy cztery oczy są wymagane |
| Synchronizacja katalogu z systemu zakupowego (worker lub `event-handler`) | dobra, gdy katalog prowadzi inny system; tu katalog prowadzi zespół floty w aplikacji |
| Endpoint w kodzie platformy | odrzucone — profil nie obchodzi braku punktu rozszerzenia kodem platformy (ADR-012, `docs/architecture/13-project-profiles.md` §10) |

## Wpływ

| Obszar | Zmiana | Krok |
| --- | --- | --- |
| Kontrakt profilu | `profile-action` w `profiles/profile.schema.json`; reguły walidatora (Python i `ph`) z autotestem | ten PR |
| SDK | `IProfileAction<TInput>`, `ProfileActionContext`, rejestracja `AddProfileAction<…>()`, test zgodności | S19 |
| Potok | endpoint `/p/<id>/actions/…`, audyt, idempotencja, kontekst bazy | S38 |
| UI | `allowedActions` w wyniku zapytania profilu, przyciski w powłoce | S47 |
| Istniejące profile | bez zmian | — |

## Pytania do architekta platformy

1. Czy zasób audytu `profile:<id>/<encja>/<klucz>` wystarczy do raportów audytora, czy potrzebne jest osobne pole „typ zasobu”?
2. Czy limit czasu `profile-action` ma być taki jak operacji na zadaniu (propozycja NFR-13: 5 s)?
