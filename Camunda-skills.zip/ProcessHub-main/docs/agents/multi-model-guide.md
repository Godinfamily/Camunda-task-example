# Agenci w OpenCode z modelami GLM — przewodnik

Rój agentów działa w OpenCode z modelem `glm-5.3-flash` z rodziny GLM 5.3 Flash, uruchomionym zawsze w infrastrukturze banku (ADR-016). Role są zdefiniowane raz (`agents/registry.yaml`, `agents/prompts/`), a generator tworzy z nich agentów OpenCode — także agentów zespołów profili projektów, którzy mogą zapisywać tylko we własnym profilu. Ten przewodnik opisuje budowę harnessu, model i jego warianty, politykę danych, kwalifikację i zmianę modelu (ADR-015, ADR-016).

## 1. Jak to jest zbudowane

```mermaid
flowchart LR
  REG[agents/registry.yaml<br/>role, poziomy, klasy danych] --> GEN[tools/agents/render_agents.py]
  PR[agents/prompts/*.md] --> GEN
  MOD[config/models.yaml<br/>model w banku, warianty, polityka] --> GEN
  PROF[profiles/*/profile.yaml<br/>agenci zespołów profili] --> GEN
  POL[agents/runtime-policy.yaml<br/>komendy, zakazy] --> GEN
  GEN --> AG[.opencode/agent/*.md<br/>agenci platformy i profili]
  GEN --> CFG[opencode.json<br/>model, uprawnienia, dostawca]
  GEN --> AMD[AGENTS.md<br/>tabela agentów]
  AG --> OC[OpenCode]
  CFG --> OC
  SK[.opencode/skills/] --> OC
  PL[.opencode/plugin/write-scope.js] --> GUARD[tools/guard/enforce_write_scope.py]
  OC --> PL
  CI[CI: --verify-diff, --check] --> GUARD
```

| Plik | Kto edytuje | Rola |
| --- | --- | --- |
| `agents/registry.yaml`, `agents/prompts/*.md` | zespół platformy AI | definicje ról niezależne od narzędzia |
| `config/models.yaml` | zespół platformy AI + bezpieczeństwo | model na bramce banku, warianty rozumowania, limity, polityka danych |
| `profiles/<id>/profile.yaml` (`dev`) | zespół profilu + architekt | którzy agenci pracują dla profilu i jaka klasa danych |
| `agents/runtime-policy.yaml` | zespół platformy AI + bezpieczeństwo | dozwolone komendy i zakazy (→ `permission.bash`) |
| `.opencode/agent/*.md`, `opencode.json`, blok ról w `AGENTS.md` | nikt — generowane | konfiguracja OpenCode |
| `.opencode/skills/`, `.opencode/command/`, `.opencode/plugin/` | zespół platformy AI | skille, komendy `/status` `/krok` `/profil` `/bramki`, strażnik zapisu |

## 2. Model i warianty rozumowania

Jedyny profil modeli to `glm-self-hosted`: wagi GLM 5.3 Flash na bramce w infrastrukturze banku, zgodnej z API OpenAI (vLLM, SGLang, TGI albo LiteLLM), pod nazwą `glm-5.3-flash`. W `opencode.json` to dostawca `llm-gateway` z adresem i kluczem ze zmiennych `LLM_GATEWAY_URL` i `LLM_GATEWAY_KEY`, limitami kontekstu i wyjścia oraz wariantami rozumowania.

| Poziom | Role | Wariant | Co trafia do bramki |
| --- | --- | --- | --- |
| T0, T1, T2 | recenzja bezpieczeństwa, architektura, recenzja, implementacja | `high` | `chat_template_kwargs.enable_thinking: true` |
| T3 | triage logów, dokumentacja | `low` | `chat_template_kwargs.enable_thinking: false` |

Parametry wariantów zależą od serwera bramki [DO WERYFIKACJI w S06]; zmienia się je w `config/models.yaml` (`variants`). Eskalacja po dwóch nieudanych próbach: z `low` na `high` (tylko role T3), potem człowiek. Role T0–T2 mają już wariant `high` — dla nich „eskalacja” to jedna sesja od zera z diagnozą recenzenta zamiast historii nieudanych prób, a potem człowiek. Pole `reasoning` w rejestrze ról jest opisowe (trafia do plików dla runnera kwalifikacji); o wariancie decyduje poziom.

## 3. Polityka danych

Każda klasa danych (`internal`, `confidential`, `restricted`) trafia wyłącznie do modelu w infrastrukturze banku. Klasa nadal ma znaczenie: decyduje o przeglądzie bezpieczeństwa (np. profil `aml`, recenzja bezpieczeństwa), a generator odrzuci każdy profil modeli z hostingiem zewnętrznym. Do tego: `share: disabled` w `opencode.json`, brak `webfetch` i `websearch`, zakaz odczytu `.env` i `secrets/**`.

## 4. Separacja pracy agentów

| Agent | Może zapisywać | Komendy | Nie może |
| --- | --- | --- | --- |
| agenci wykonawczy platformy (np. `module-implementer`) | platforma i `profiles/_template/**`, w kroku: tylko `writes` | zestaw domyślny (build, testy, lint, `git add`/`commit`) | `profiles/<id>/**`, ścieżki chronione bez jawnego zakresu |
| role z własną listą ścieżek (`bdd-analyst`, `docs-writer`, `ux-designer`) | tylko ścieżki z pola `writes` roli | zestaw domyślny albo brak | reszta repozytorium |
| agenci profilu (np. `kredyty-module-implementer`) | `profiles/kredyty/**` i wniosek `docs/rfc/RFC-*.md` | zestaw domyślny | platforma, inne profile, kontrakt profilu bez zatwierdzenia |
| recenzenci (`reviewer`, `ui-reviewer`, `security-reviewer`) | nic | `git diff`, `git status`, `git log` | wszystko inne (zakaz, bez pytania) |
| `ci-triage` | nic | brak | — |
| orkiestrator | `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | skrypty kroków, `opencode run --dir ../wt-*`, odczyt git | kod, `backlog.yaml`, `--force`, `--merged`, `--approve-gate` |

Wszyscy agenci korzystają z tego samego modelu w banku; różni ich zakres zapisu i zestaw komend. Egzekwują to cztery warstwy: uprawnienia `edit` i `bash` w plikach agentów OpenCode, plugin strażnika (`.agent-scope` z dyrektywą `@profile <id>`) działający w sesji uruchomionej w worktree kroku, bramka zakresu w Definition of Done (`enforce_write_scope.py --verify-diff main` — obejmuje też zmiany zrobione komendą) oraz CI z przeglądem CODEOWNERS. Wniosek RFC (`docs/rfc/RFC-*.md`) może złożyć każdy agent z prawem zapisu. Przypadek kwalifikacyjny E08 sprawdza, że agent profilu zgłasza RFC zamiast zmieniać cudzy kod. Pełny opis dla ludzi: `docs/artifacts/05-agenci.md`.

## 5. Kwalifikacja

Każda rola przechodzi przypadki z `evals/agents/` (E01–E11) na bramce banku. Ponowna kwalifikacja po zmianie wersji modelu, wariantu, serwera bramki lub promptu roli. Progi: `evals/agents/README.md`.

## 6. Dopasowanie pracy do modelu

- **Kontekst.** Limit ustala serwer bramki (`context_limit_tokens`); pakiet roboczy nadal ogranicza się do plików z pola `reads` — mniej tokenów i mniej pomyłek.
- **Rozumowanie.** Wysoki wariant tam, gdzie liczy się poprawność (architektura, recenzja, bezpieczeństwo); niski do streszczeń i dokumentacji.
- **Ustrukturyzowane wyjście.** Ostatnia wiadomość agenta to JSON ze schematu roli; `tools/agents/validate_output.py` sprawdza go przed zapisaniem postępu.
- **Język.** Zasady i scenariusze są po polsku. Jeśli kwalifikacja wykaże problemy z językiem, można dodać `agents/prompts/<rola>.en.md`.

## 7. Zmiana modelu lub wersji

1. Zespół infrastruktury udostępnia nowy model na bramce banku (nowa nazwa albo nowa wersja pod tą samą nazwą).
2. Zmień `tiers` (i ewentualnie `variants`, limity) w `config/models.yaml`; zewnętrzny hosting jest wykluczony (ADR-016).
3. Sprawdź model: `opencode models llm-gateway --verbose` (warianty, limity, wywoływanie narzędzi).
4. Uruchom `render_agents.py` i przejdź kwalifikację E01–E11 dla ról, które mają używać nowego modelu.
5. Pilotaż na krokach o niskiej złożoności (S10, S41, S46), potem włączenie przez PR z bramką `render_agents.py --check`.

## 8. Komendy

```bash
python3 tools/agents/render_agents.py                    # agenci OpenCode, opencode.json, tabela w AGENTS.md
python3 tools/agents/render_agents.py --check             # bramka CI
python3 tools/agents/render_agents.py --targets json      # pliki dla runnera kwalifikacji (agents/dist/)
opencode models llm-gateway --verbose                      # model na bramce: warianty i limity
python3 tools/guard/enforce_write_scope.py --self-test    # strażnik zapisu
python3 tools/profiles/validate_profiles.py --check       # manifesty profili i CODEOWNERS
python3 tools/plan/validate_plan.py --check               # plany ↔ role, zakresy zapisu, reads, scenariusze
opencode agent list                                       # agenci widoczni dla OpenCode
opencode debug agent kredyty-module-implementer           # model, wariant i uprawnienia agenta
```

Bez Pythona te same polecenia wykonuje narzędzie .NET: `ph agents render [--check]`, `ph guard --self-test`, `ph profiles validate --check` (`tools/dotnet/README.md`).
