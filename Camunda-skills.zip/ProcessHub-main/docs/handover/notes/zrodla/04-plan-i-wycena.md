# 04-plan-i-wycena — Plan wykonawczy platformy, backlog maszynowy, szablon pakietu, model i raport wyceny

Pakiet zawiera 8 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: plan/execution-plan.md

# Plan wykonywalny (harmonogram bez dat)

Plan platformy dzieli prace na 57 kroków w 6 fazach, rozdzielonych czterema bramkami decyzji człowieka. Ścieżka krytyczna (najdłuższa ścieżka ważona rozmiarem kroków) biegnie przez PoC SDK i autoryzacji, kontrakty, adaptery SDK, projekcję, politykę dostępu i pracę na zadaniach, a dalej przez mapę etapów, dashboard i jego UI — to wgląd menadżera, a nie skrzynka zadań, wydłuża projekt. Przekazywanie, zastępstwa, kroki profili projektów (SDK, izolacja, operacje, sloty UI, onboarding) i pozostałe UI mają zapas. Moduł formatek (PoC S07–S09, backend S26, S28, S29, S37, S39, frontend S49, S40, S45, hardening S55 — opis: `docs/architecture/14-form-management.md`) nie wydłuża kalendarza, ale jego łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma tylko ok. 2,6 dnia zapasu — to druga ścieżka do pilnowania. Część specyficzną projektów realizują zespoły profili według własnych planów (`profiles/<id>/backlog.yaml`) — zaczynają po krokach S27, S38 i S47. Ten sam plan w formie maszynowej: `plan/backlog.yaml` (Orkiestrator czyta tylko ten plik). Złożoność i pracochłonność kroków: `plan/estimation.md`.

## Ścieżka krytyczna

```mermaid
flowchart TD
    S01[S01 PoC SDK] --> S02[S02 PoC autoryzacji] --> G0{{G0}}
    G0 --> S10[S10 Szkielet] --> S12[S12 Building Blocks] --> S15[S15 Kontrakty v1] --> G1{{G1}}
    G1 --> S22[S22 Adaptery SDK] --> S23[S23 Projekcja] --> S24[S24 Access Policy] --> S30[S30 Task Work] --> G2{{G2}}
    G2 --> S34[S34 Mapa etapów] --> S36[S36 Dashboard] --> S42[S42 UI wglądu] --> S50[S50 E2E integracyjne]
    S50 --> S51[S51 Bezpieczeństwo] --> S54[S54 Pentest i compliance] --> G3{{G3}} --> S60[S60 Pilotaż]

    G1 --> S20[S20 Party] --> S24
    G1 --> S21[S21 Autoryzacje jako kod] --> S24
    G1 --> S25[S25 Audyt] --> S30
    G1 --> S26[S26 Formatki: cykl życia] --> S29[S29 Powiązania z BPMN] --> S37[S37 Form Runtime] --> S40[S40 Zadania i renderer formatek] --> S45[S45 Projektant formatek] --> S50
    S23 --> S29
    S37 --> S39[S39 Wycofanie i przepięcie] --> S50
    S28[S28 Schemat form] --> S39
    S07[S07 PoC formatek w UI] --> S49[S49 Komponenty pól] --> S40
    S08[S08 PoC walidacji i FEEL] --> S37
    S09[S09 Warstwa wizualna i Figma] --> S16
    S07 --> G1
    S08 --> G1
    S09 --> G1
    G1 --> S16[S16 Frontend shell i ui-kit] --> UI[S41, S43, S44, S46 UI]
    S16 --> S49
    S50 --> S55[S55 Zgodność i spójność formatek] --> S54
    S15 --> S19[S19 SDK rozszerzeń] --> S27[S27 Izolacja profili] --> S38[S38 Operacje profili] --> S50
    S19 --> S47[S47 Sloty UI profili] --> S50
    S38 --> S48[S48 Onboarding zespołów profili] --> S60
    G2 --> S32[S32 Przekazywanie] --> S50
    G2 --> S31[S31 Start procesu]
    S34 --> S35[S35 Eskalacje] --> S42
    S22 --> S33[S33 Zastępstwa] --> S50
    UI --> S50

    classDef crit stroke-width:3px
    class S01,S02,S10,S12,S15,S22,S23,S24,S30,S34,S36,S42,S50,S51,S54,S60 crit
```

## Bramki

| Bramka | Warunek przejścia | Kto decyduje |
| --- | --- | --- |
| **G0** | ADR-003, ADR-004, ADR-007, ADR-010 mają status „Przyjęta” na podstawie raportów PoC; pliki `specs/**` zatwierdzone przez PO | Architekt + PO |
| **G1** | Kontrakty v1 i `api/openapi.v1.yaml` zamrożone; szkielet zielony w CI; baza i harness Reqnroll działają (scenariusze w stanie „pending”); ADR-019 i ADR-020 mają status „Przyjęta” na podstawie PoC formatek (S07, S08), a tokeny i katalog pól są zatwierdzone przez projektanta UX (S09) | Architekt + tech lead |
| **G2** | Scenariusze `@FR-04`, `@FR-06` przechodzą `@integration` na prawdziwej Camunda przez oficjalne SDK (walking skeleton) | Tech lead |
| **G3** | Wszystkie scenariusze zielone; test kompletności audytu, macierz autoryzacji, pentest i przegląd compliance zaakceptowane | Bezpieczeństwo + compliance |

## Kroki

Legenda: **K** = ścieżka krytyczna · rozmiar S/M/L (względny, do budżetowania tokenów i równoległości).

### Faza 0 — Przygotowanie i PoC (→ G0)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S00 | Repozytorium: ten pakiet, `.opencode/` (agenci, skille, plugin strażnika), skrypty kroków, pusty pipeline CI | człowiek (tech lead) | — | repo gotowe dla agentów | S |
| S01 **K** | PoC oficjalnego SDK na Camunda 8.9: lista kontrolna z `06-camunda-integration.md` | camunda-integrator + DevOps | S00 | `poc/sdk/REPORT.md`, decyzja ADR-003 | M |
| S02 **K** | PoC autoryzacji: autoryzacje per `bpmnProcessId`, audytor `*`, token delegowany przez SDK, autoryzacje na poziomie zadania w 8.9 | camunda-integrator + security-reviewer | S01 | `poc/authz/REPORT.md`, decyzja ADR-004 | M |
| S03 | PoC task listenera: korekty assignee/grup, czas odpowiedzi, fail-open | camunda-integrator | S01 | `poc/listener/REPORT.md`, decyzja ADR-007 | S |
| S04 | PoC zasilania read modelu: wyszukiwanie przyrostowe vs eksporter, pomiar opóźnienia | camunda-integrator | S01 | `poc/feed/REPORT.md`, decyzja ADR-010 | M |
| S05 | Przegląd scenariuszy z biznesem, uzupełnienie świata testowego | bdd-analyst + PO | S00 | `specs/**` zatwierdzone | M |
| S06 | Środowisko dev: Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, dostępy sieciowe | DevOps + data-engineer | S00 | środowisko wg checklisty DevOps (sekcja 11) | L |
| S07 | PoC formatek w UI: edytor form-js w Angularze, renderer na design systemie kontra viewer, zestaw zgodności na formatkach wzorcowych | frontend-developer + ux-designer | S00 | `poc/forms-ui/REPORT.md`, decyzja ADR-019 | M |
| S08 | PoC walidacji formatek na serwerze: reguły schematu w .NET, ewaluacja FEEL przez API klastra 8.9, różnice względem przeglądarki | camunda-integrator + module-implementer | S01 | `poc/forms-validation/REPORT.md`, decyzja ADR-020 | S |
| S09 | Warstwa wizualna: biblioteka w Figma, tokeny, katalog pól i specyfikacje komponentów zatwierdzone przez projektanta UX | ux-designer + projektant UX | S00 | `design/**` zatwierdzone, decyzja D-16 | M |

### Faza 1 — Fundament (→ G1)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S10 **K** | Szkielet rozwiązania, Host z rolami, szablon `dotnet new ph-module` | module-implementer | S01–S05 (G0) | `src/`, `templates/ph-module/` | M |
| S11 | Testy architektury i bramki CI | module-implementer | S10 | `tests/ProcessHub.ArchitectureTests`, pipeline | S |
| S12 **K** | Building Blocks: potok, `Actor`, `ITenantContext`, `Permission`, middleware śladu, outbox/inbox/lease | module-implementer | S10 | `src/BuildingBlocks/**` | L |
| S13 | MSSQL: schematy, RLS, Ledger, partycje śladu, temporal, fixture Testcontainers | data-engineer | S10 | `db/**`, `tests/Shared/MsSqlFixture` | M |
| S14 | Harness Reqnroll: projekty `*.Specs`, interfejsy driverów, budowniczy świata testowego, asercje domenowe | bdd-tester | S10, S05 | `tests/*.Specs`, `tests/Shared/World` | M |
| S15 **K** | Kontrakty v1 wszystkich modułów + OpenAPI v1 | architect | S12 | `src/Modules/*/Contracts`, `api/openapi.v1.yaml` | L |
| S16 | Frontend: Nx, shell, motyw z tokenów (`core/theming`), ui-kit, katalog komponentów, i18n, mock server z OpenAPI — startuje po G1 (zamrożone OpenAPI, ADR-019) | frontend-developer + design-system-engineer | S15, S09 (G1) | `frontend/**` | M |
| S17 | Wtyczka bpmnlint `ph` + przykładowe procesy BPMN świata testowego | camunda-integrator | G0 | `bpmn/**` | S |
| S18 | BFF: OIDC z RHBK, ciasteczko, CSRF, wylogowanie | module-implementer | S12 | `src/ProcessHub.Host/Auth/**` | M |
| S19 | SDK rozszerzeń i rejestr profili: manifesty, walidacja, kompozycja modułów, kontrakt slotów UI | architect + module-implementer | S10, S15 | `ProcessHub.Extensibility`, moduł `ExtensionHost`, `extension-sdk` | L |

### Faza 2 — Domena dostępu, Camunda, audyt, formatki (równolegle po G1)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S20 | Party & Accountability: `Actor` z tokenu, migawka grup, `Absence` | module-implementer | G1 | moduł `PartyAccountability` | M |
| S21 | Autoryzacje jako kod: loader YAML, walidacja (R7, readOnly), reconciler (dry-run, apply, dryf) | module-implementer + camunda-integrator | G1 | moduł `PlatformAdministration`, adapter `IAuthorizationAdmin` | M |
| S22 **K** | Adaptery SDK dla wszystkich portów + fake + testy kontraktowe | camunda-integrator | G1 | `CamundaIntegration/**` | L |
| S23 **K** | Projekcja: instancje, zadania, odwiedziny elementów, incydenty, katalog elementów z XML | camunda-integrator + data-engineer | S22 | `CamundaIntegration` + schematy `task`, `insight` | L |
| S24 **K** | Access Policy: uprawnienia efektywne, R1–R11, `TaskAccess`, generowana macierz autoryzacji | module-implementer | S20, S21, S23 | moduł `AccessPolicy` | L |
| S25 | Audyt: dziennik dwufazowy, uzgadnianie, API przeglądu, test kompletności | module-implementer + data-engineer | G1 | moduł `Audit` | M |
| S26 | Form Management: formatki Camunda Forms, cykl życia wersji, R8, R11, publikacja z kontraktem i katalogiem pól, wycofanie, import i eksport | module-implementer | G1 | moduł `FormManagement` | L |
| S27 | Izolacja profili: schemat i użytkownik bazy per profil, widoki `platform_api`, role projektowe w reconcilerze, testy architektury profili | data-engineer + security-reviewer | S13, S19, S21 | migracje, reguły R10, testy izolacji | M |
| S28 | Schemat `form`: wersje, przeglądy, wycofania, unikalność i klucze per proces, historia przypięć | data-engineer | S13, S15 (G1) | migracje `form`, test klucza obcego przypięcia | S |
| S29 | Powiązania formatek z procesem: referencje `ph:form` i kontrakt danych z katalogu elementów, kontrola spójności, reguła bpmnlint `ph/form-reference` | camunda-integrator + module-implementer | S17, S23, S26 | `CamundaIntegration`, `FormManagement` (powiązania), `bpmnlint-plugin-ph` | M |

### Faza 3 — Funkcje rdzenia (→ G2 po S30)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S30 **K** | Task Work: przejęcie, zwolnienie, szkic, zakończenie, idempotencja | module-implementer | S24, S25 | moduł `TaskWork` | L |
| S31 | Process Lifecycle: katalog startowy, start, moje procesy | module-implementer | S30 (G2), S37 | moduł `ProcessLifecycle` | M |
| S32 | Przekazywanie: osoba, grupa, partia (saga) z wznowieniem | module-implementer | S30 (G2) | `TaskWork` (+ `ReassignmentBatch`) | M |
| S33 | Zastępstwa: worker task listenera (fail-open), uzgadnianie | camunda-integrator | S20, S22, S25 | rola `worker`, `Substitution*` | M |
| S34 **K** | Mapa etapów: agregat, API edytora, dziedziczenie wersji, algorytm stanu | module-implementer | S23, S24, S30 (G2) | moduł `ProcessInsight` | L |
| S35 | Eskalacje: wykrywanie, zakres, lista, „po terminie” | module-implementer | S34 | `ProcessInsight` | M |
| S36 **K** | Dashboard: agregaty, metryki `IProcessMetric`, progi zdrowia, świeżość | module-implementer + data-engineer | S34 | `ProcessInsight` | L |
| S37 | Form Runtime: schemat przypiętej wersji, walidacja danych na serwerze (reguły Camunda Forms, FEEL przez `IExpressionEvaluator`), przypięcie wersji | module-implementer | S26, S29, S08 | moduł `FormRuntime`, port `IExpressionEvaluator` | M |
| S38 | Potok operacji profili (zadanie, sprawa, dane profilu — ADR-017), wzbogacenia, zdarzenia; profil przykładowy i testy zgodności SDK | module-implementer + bdd-tester | S27, S30 | `ExtensionHost`, `ProcessHub.Extensibility.Testing` | M |
| S39 | Wycofanie formatek w toku: przepięcie zadań (saga ze wznowieniem), zadania bez formatki, powiadomienia | module-implementer + bdd-tester | S28, S30, S37 | `FormManagement`, `TaskWork` | M |

### Faza 4 — Frontend funkcjonalny (na mockach od S16, na API po odpowiednim kroku backendu)

| Krok | Cel | Agent | Zależy od | R. |
| --- | --- | --- | --- | --- |
| S40 | Skrzynka zadań + renderer formatek Camunda Forms (interpretacja schematu, FEEL, układ, rejestr komponentów pól) | frontend-developer + ui-reviewer | S16 (mock), S49 → S30, S37 (API) | L |
| S41 | Start procesu, moje procesy | frontend-developer | S16 → S31 | M |
| S42 **K** | Dashboard, eskalacje, instancja z mapą etapów | frontend-developer | S16 → S34, S35, S36 | L |
| S43 | Przekazywanie (pojedyncze, masowe), zastępstwa | frontend-developer | S16 → S32, S33 | M |
| S44 | Edytor mapy etapów (bpmn-js viewer dla `Bpmn.ViewTechnical`) | frontend-developer | S16 → S34 | M |
| S45 | Projektant formatek: osadzony edytor form-js z paletą z katalogu pól, cykl życia, wersje i porównanie, wycofanie, import i eksport, podgląd jak u wykonawcy | frontend-developer + ui-reviewer | S16, S40 → S26 | L |
| S46 | Widoki audytora i przegląd audytu | frontend-developer | S16 → S25 | S |
| S47 | Sloty UI i trasy profili w powłoce (panel zadania i sprawy, widżet, pole formatki, nawigacja) | frontend-developer | S16, S19, S40 | M |
| S48 | Onboarding zespołów profili: szablon, przewodnik, kwalifikacja agentów profilu (E08), przegląd manifestów | architect + docs-writer | S38 | S |
| S49 | Komponenty pól formatek w `ui-kit` wg katalogu pól, katalog komponentów, regresja wizualna i axe | design-system-engineer + ui-reviewer | S16, S07, S09 | M |

### Faza 5 — Integracja i hardening (→ G3) oraz Faza 6 — pilotaż

| Krok | Cel | Agent | Zależy od | R. |
| --- | --- | --- | --- | --- |
| S50 **K** | Wszystkie `@integration` zielone na dev; ścieżki Playwright per rola i profil | bdd-tester | S06, S32, S33, S38, S39, S40–S47 | L |
| S51 **K** | Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacja tenantów, kompletność audytu, DAST, skan zależności | bdd-tester + security-reviewer (recenzja, tylko odczyt) | S50 | M |
| S52 | Wydajność i pojemność: `TaskAccess`, dashboard, opóźnienie projektora, wolumen śladu | data-engineer | S50 | M |
| S53 | Dostępność (WCAG) i przegląd UX | frontend-developer + ui-reviewer + projektant UX | S50 | S |
| S55 | Zgodność formatek z Camunda Forms i spójność wizualna w CI: zestaw zgodności z form-js, schemat `.form`, parytet katalogu pól, regresja wizualna | frontend-developer + ui-reviewer | S50 | S |
| S54 **K** | Pentest, przegląd compliance, Deklaracja Dostępności | ludzie | S51, S52, S53, S55 | M |
| S60 **K** | Pilotaż jednego obszaru (profil `kredyty`): wdrożenie, odcięcie użytkowników od webapp Tasklist, monitoring | ludzie + DevOps + zespół profilu | G3, S48 | M |

## Zasady wykonania (dla Orkiestratora)

1. Krok jest gotowy, gdy wszystkie `depends_on` mają status `done` i `merged`, a bramka `gate_before` jest zatwierdzona. Bramkę zatwierdza człowiek dopiero po scaleniu kroków z jej pola `after` (`plan_status.py --approve-gate` to sprawdza).
2. Równolegle najwyżej tyle agentów implementujących, ile ustawiono w `backlog.yaml` (`parallelism`); kroki **K** mają pierwszeństwo. Kroków z nakładającym się zakresem zapisu nie prowadzi się jednocześnie — lista: `python3 tools/plan/validate_plan.py`, kontrola przed startem: `--conflicts <krok> <krok>`.
3. Dla kroku: `tools/agents/prepare_step.py` tworzy osobny worktree `../wt-<krok>`, plik `.agent-scope` z polem `writes` (dla kroku profilu z dyrektywą `@profile <id>`) i pakiet roboczy wg `plan/work-packet-template.md` — z oczekiwanym wynikiem (`outcome`), wskazówkami startowymi (`notes`), materiałami do wyszukiwania punktowego (`refs`), wejściem od poprzedników i podziałem pracy w parze.
4. Wykonawca pracuje w osobnej sesji OpenCode uruchomionej w worktree kroku (`opencode run --dir ../wt-<krok> --agent <rola> …`) — tylko tam strażnik widzi `.agent-scope`. Na koniec zatwierdza zmiany na gałęzi kroku (`git add`, `git commit`); wypychanie i scalanie należą do człowieka.
5. Jeśli krok ma `pair: bdd-tester`, Tester pisze kroki i drivery przed implementacją w tym samym worktree; implementer nie edytuje `tests/*.Specs/**`. `pair: ui-reviewer` i `pair: security-reviewer` oznaczają obowiązkowy przegląd po zielonych bramkach (tylko odczyt); wzorce regresji wizualnej zmienia się tylko za zgodą projektanta UX. Pozostałe pary wykonują część opisaną w `pair_task`.
6. Bramki deterministyczne (pole `dod`) przed recenzją LLM; pierwszą jest zawsze bramka zakresu (`enforce_write_scope.py --verify-diff main`), która obejmuje także zmiany zrobione komendą, a nie edytorem. Recenzent bezpieczeństwa, gdy diff dotyka ścieżek z `security_sensitive` w `backlog.yaml`. Kryteria, których nie sprawdzi komenda, są w polu `acceptance` — potwierdza je człowiek.
7. Ponowienia: 2 próby. Eskalacja na wyższy wariant rozumowania modelu GLM 5.3 Flash dotyczy tylko ról T3 (wariant `low` → `high`); role T0–T2 mają już wariant najwyższy, więc po dwóch próbach następuje jedna sesja od zera z diagnozą recenzenta, a potem człowiek.
8. Kroki profili prowadzą agenci profilu (`<profil>-<rola>`) w planie zespołu profilu; agenci platformy nie zapisują w `profiles/<id>/**`, agenci profili — poza nim.
9. Zmiana kontraktu lub scenariusza = RFC w `docs/rfc/` (plik `RFC-<krok>-<temat>.md` wolno utworzyć w każdym kroku), decyzja Architekta i człowieka, podbicie wersji kontraktu, ponowne uruchomienie zależnych kroków.
10. Po zakończeniu kroku: przekazanie JSON zapisane do `plan/progress/<krok>.json`; Orkiestrator aktualizuje `plan/progress/STATUS.md`.
11. Rzeczywista praca ludzi trafia do `plan/progress/<krok>.effort.json`; `tools/plan/estimate.py` przelicza prognozę (metoda: `plan/estimation.md`).
12. Narzędzia: skrypty `tools/*.py` albo ich odpowiedniki .NET `ph` (`tools/dotnet`) — identyczne wyniki; `ph step dod` sam zamienia polecenia Pythona w Definition of Done, gdy Pythona brak. Wyjątek: `tools/plan/validate_plan.py` jest na razie tylko w Pythonie.

## Uwagi do zależności (przegląd planu)

- **S16 po G1.** Diagram ścieżki krytycznej prowadzi S16 za bramką G1; backlog ma teraz `gate_before: G1`, więc także S49 (komponenty pól) nie ruszy przed przyjęciem ADR-019.
- **S19 przed workspace Nx.** S19 pisze `frontend/libs/platform/extension-sdk` bez zależności od S16 — biblioteka powstaje jako samodzielny pakiet typów, a do workspace włącza ją S16 albo S47. Jeśli kontrakt slotów ma być budowany i testowany w Nx, dodaj `S16` do `depends_on` kroku S19 (decyzja architekta; łańcuch profili ma zapas).
- **S21 równolegle z S22.** Oba kroki piszą w `CamundaIntegration` (S21: adapter `IAuthorizationAdmin`). Wspólne pliki projektu i rejestracji DI grożą konfliktem scalania — prowadź je po kolei albo uzgodnij podział.
- **Frontend a backend.** Kroki S40–S46 mają w `depends_on` kroki backendu, choć nagłówek fazy 4 mówi o pracy na mockach od S16. Dziś narzędzia traktują to jako twardą zależność (krok nie wystartuje przed scaleniem backendu). Skrócenie ścieżki S36 → S42 wymagałoby podziału kroków UI na część „na mockach” i część „na API” — to decyzja planistyczna zmieniająca wycenę.
- **Pilotaż a plan profilu.** S60 wymaga ukończenia planu `kredyty`; narzędzia nie znają zależności platforma → profil, więc warunek jest w `acceptance` kroku S60.
- **Kroki w tym samym module.** S32 i S39 (`TaskWork`), S35 i S36 (`ProcessInsight`), S53 i S55 (`frontend`), S27 i kroki ze schematami w `db/**` mogą być gotowe jednocześnie — `validate_plan.py` wypisuje je jako ostrzeżenia.

## Otwarte decyzje biznesowe (do G0)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-01 | Definicja „grupy uprawnień” dla widoczności uczestnika | grupy kandydujące zadania ∪ grupy inicjatora |
| D-02 | Czy menadżer może przekazać zadanie osobie spoza grup kandydujących | tak, jeśli ma rolę Uczestnika w procesie (R6) |
| D-03 | Kto mapuje elementy BPMN na etapy | administrator procesu; menadżer — gdy dostanie `StageMap.MapElements` w konfiguracji |
| D-04 | Zastępstwa: tylko nowe zadania czy także istniejące | nowe automatycznie; istniejące — propozycja przekazania masowego dla menadżera |
| D-05 | Szkic przy przekazaniu | przechodzi z zadaniem, z adnotacją i audytem |
| D-06 | Czy anulowanie instancji liczyć jako „błąd” na dashboardzie | osobny licznik „anulowane”, nie błąd |
| D-07 | Czy audytor widzi techniczny BPMN | nie domyślnie; osobna rola „audytor techniczny”, jeśli potrzebna |

## Decyzje dotyczące profili projektów (przed S19 i S27)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-08 | Domyślny model integracji profili | in-process; remote na wniosek zespołu |
| D-09 | Monorepo z `CODEOWNERS` czy osobne repozytoria profili | monorepo na start |
| D-10 | Rytm pociągu wydań dla profili in-process | co dwa tygodnie, razem z wydaniem platformy |
| D-11 | Zakres danych platformy w widokach `platform_api` | zadania, instancje i stany etapów procesów profilu |

## Decyzje dotyczące formatek i warstwy wizualnej (przed S09 i S26)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-12 | Cztery oczy przy formatkach: autor ostatniej zmiany czy każdy współautor szkicu | autor ostatniej zmiany (R8); lista współautorów widoczna dla zatwierdzającego |
| D-13 | Czy wycofanie wersji formatki wymaga drugiej osoby | nie — operacja awaryjna jednej osoby z powodem, powiadomieniem i wpisem w dzienniku |
| D-14 | Domyślny skutek wycofania dla zadań w toku | zadania pozostają na wycofanej wersji; przepięcie jako świadomy wybór |
| D-15 | Załączniki w formatkach: magazyn dokumentów dla pól plikowych | obsługa dokumentów Camunda albo magazyn banku; do decyzji typy plikowe poza katalogiem pól |
| D-16 | Właściciel biblioteki w Figma i tryb przenoszenia zmian wyglądu | projektant UX banku; eksport jako pull request w `design/**`, najwyżej raz na wydanie |

Rozstrzygnięcia techniczne z PoC: ADR-019 (S07 — renderer na design systemie) i ADR-020 (S08 — FEEL przez silnik) — przed G1.

## Plany zespołów profili

Każdy profil ma własny plan (`profiles/<id>/backlog.yaml`) prowadzony tymi samymi narzędziami (`plan_status.py`, `prepare_step.py`, `run_dod.py` z `--backlog`, komenda `/profil <id> <krok>`). Kroki profilu mogą zależeć od kroków platformy; postęp zapisuje się w `profiles/<id>/progress/`. Plan pilotażowego profilu `kredyty` (KRE-01…KRE-04) musi być ukończony przed S60. Profil `flota` (FLO-01…FLO-05) jest przykładem dedykowanych elementów jednego projektu — katalog samochodów z operacjami na danych profilu (ADR-017) i opinie komórek banku — i nie blokuje pilotażu.

## Plik: plan/backlog.yaml

````yaml
# Plan wykonywalny w formie maszynowej. Źródło prawdy dla Orkiestratora.
# Opis i uzasadnienia: plan/execution-plan.md. Bez dat — kolejność wynika z depends_on i bramek.
# Spójność planu sprawdza: python3 tools/plan/validate_plan.py --check
#
# Pola kroku:
#   depends_on  kroki, które muszą być scalone        gate_before  bramka, która musi być zatwierdzona
#   agent, pair rola wykonawcy i pary (agents/registry.yaml); pair_task — co robi para, gdy nie wynika to z roli
#   reads       pliki do przeczytania w całości (budżet kontekstu!)   refs — materiały do wyszukiwania punktowego
#   writes      zakres zapisu → .agent-scope           specs — scenariusze do zaliczenia
#   outcome     co ma powstać                          notes — wskazówki startowe, granice z innymi krokami, decyzje
#   dod         komendy bramek (kod wyjścia 0)         acceptance — kryteria potwierdzane przez człowieka
version: 3
parallelism: 4                      # maks. równoległych agentów implementujących
retries_per_tier: 2
escalation: [T3, T2, T1, human]          # wyższy wariant rozumowania GLM 5.3 Flash, potem człowiek (T0–T2 mają już wariant najwyższy)
security_sensitive:                 # diff w tych ścieżkach => obowiązkowy security-reviewer
  - "src/Modules/AccessPolicy/**"
  - "src/Modules/Audit/**"
  - "src/ProcessHub.Host/Auth/**"
  - "src/BuildingBlocks/**/Authorization/**"
  - "db/**/security/**"
  - "config/authorization/**"
  - "src/Modules/CamundaIntegration/**/Authorization*/**"
  - "src/Modules/ExtensionHost/**"
  - "src/Platform/ProcessHub.Extensibility/**"
  - "profiles/*/profile.yaml"
  - "profiles/*/authorization.yaml"
  - "tools/guard/**"
  - "design/forms/field-catalog.yaml"
  - "agents/runtime-policy.yaml"          # harness agentów: komendy, role, strażnik
  - "agents/registry.yaml"
  - ".opencode/plugin/**"
  - ".opencode/lib/**"

common_dod: &dotnet_dod
  - python3 tools/guard/enforce_write_scope.py --verify-diff main
  - dotnet build ProcessHub.sln -warnaserror
  - dotnet test ProcessHub.sln --filter "Category!=integration"
  - dotnet test tests/ProcessHub.ArchitectureTests

gates:
  G0: { after: [S01, S02, S03, S04, S05], approver: [architect-human, product-owner] }
  G1: { after: [S07, S08, S09, S11, S13, S14, S15, S18], approver: [architect-human, tech-lead] }
  G2: { after: [S30], approver: [tech-lead], evidence: 'dotnet test tests/TaskWork.Specs --filter "Category=integration&(Category=FR-04|Category=FR-06)"' }
  G3: { after: [S54], approver: [security, compliance] }

steps:
  # ---------- Faza 0: przygotowanie i PoC ----------
  - id: S00
    title: "Repozytorium, harness agentów, skrypt worktree, pusty pipeline CI"
    phase: 0
    agent: human
    depends_on: []
    writes: ["**"]
    outcome:
      - "repozytorium w banku z ochroną gałęzi `main` i wymaganym przeglądem CODEOWNERS"
      - "pipeline CI z bramkami: `render_agents.py --check`, `validate_profiles.py --check`, `estimate.py --check`, `validate_plan.py --check`, `enforce_write_scope.py --verify-diff origin/main`, lint Gherkin"
      - "OpenCode i bramka modelu sprawdzone wg `docs/opencode/start.md` (kroki 1–5), w tym test strażnika zapisu"
    notes:
      - "instrukcja krok po kroku: `docs/opencode/start.md`; opis harnessu dla ludzi: `docs/artifacts/05-agenci.md`"
      - "`validate_plan.py` nie ma jeszcze odpowiednika .NET — w potoku bez Pythona pomiń tę bramkę do czasu jego dodania"
    dod:
      - "test -f AGENTS.md && test -f plan/backlog.yaml"
      - "python3 tools/guard/enforce_write_scope.py --self-test"
      - "python3 tools/agents/render_agents.py --check"
      - "python3 tools/profiles/validate_profiles.py --self-test"
      - "python3 tools/profiles/validate_profiles.py --check"

  - id: S01
    title: "PoC oficjalnego SDK Camunda na 8.9 (lista kontrolna)"
    phase: 0
    agent: camunda-integrator
    tier: T2
    size: M
    critical: true
    depends_on: [S00]
    reads: [AGENTS.md, docs/architecture/06-camunda-integration.md, docs/adr/ADR-003-official-camunda-sdk-behind-acl.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["poc/sdk/**"]
    outcome:
      - "`poc/sdk/` — projekt testowy przechodzący listę kontrolną z `06-camunda-integration.md` na Camunda 8.9"
      - "`poc/sdk/REPORT.md`: co działa, czego brakuje w SDK, ryzyka, rekomendacja statusu ADR-003 — każda teza z dowodem (test lub log)"
    notes:
      - "PoC jest kodem jednorazowym: nie twórz `src/`, nie projektuj portów — to robią S10, S15 i S22"
      - "potrzebna lokalna Camunda 8.9 (Docker); brak środowiska = status `blocked` z pytaniem, nie atrapa"
      - "raport czytają S02, S08, S22 — zapisz w nim nazwy użytych klas SDK i wersję paczki"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test poc/sdk"
      - "test -f poc/sdk/REPORT.md"

  - id: S02
    title: "PoC autoryzacji zasobów, roli audytora i tożsamości wywołań"
    phase: 0
    agent: camunda-integrator
    pair: security-reviewer
    tier: T2
    size: M
    critical: true
    depends_on: [S01]
    reads: [AGENTS.md, docs/architecture/02-roles-and-authorization.md, docs/adr/ADR-004-authorization-two-levels-as-code.md, config/authorization/roles.example.yaml, poc/sdk/REPORT.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["poc/authz/**"]
    outcome:
      - "`poc/authz/` — testy autoryzacji per `bpmnProcessId`, roli audytora (`*`), tokenu delegowanego i autoryzacji na poziomie zadania w 8.9"
      - "`poc/authz/REPORT.md` z rekomendacją statusu ADR-004 i nazwami uprawnień Camunda potrzebnych klientowi technicznemu"
    notes:
      - "raport czytają S21 (reconciler) i S26 (prawo wdrażania zasobów — ADR-018); nazwij uprawnienia dokładnie tak, jak w 8.9"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test poc/authz"
      - "test -f poc/authz/REPORT.md"

  - id: S03
    title: "PoC task listenera zastępstw (korekty, czas odpowiedzi, fail-open)"
    phase: 0
    agent: camunda-integrator
    tier: T2
    size: S
    depends_on: [S01]
    reads: [AGENTS.md, docs/adr/ADR-007-substitution-task-listener.md, docs/architecture/06-camunda-integration.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["poc/listener/**"]
    outcome:
      - "`poc/listener/` — task listener korygujący assignee i grupy, pomiar czasu odpowiedzi, zachowanie fail-open"
      - "`poc/listener/REPORT.md` z rekomendacją statusu ADR-007"
    notes:
      - "raport czyta S33; podaj zmierzone czasy i limit, po którym silnik pomija listener"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test poc/listener"
      - "test -f poc/listener/REPORT.md"

  - id: S04
    title: "PoC zasilania read modelu (wyszukiwanie przyrostowe vs eksporter)"
    phase: 0
    agent: camunda-integrator
    tier: T2
    size: M
    depends_on: [S01]
    reads: [AGENTS.md, docs/adr/ADR-010-read-model-feed.md, docs/architecture/06-camunda-integration.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["poc/feed/**"]
    outcome:
      - "`poc/feed/` — porównanie wyszukiwania przyrostowego i eksportera z pomiarem opóźnienia i kompletności"
      - "`poc/feed/REPORT.md` z rekomendacją statusu ADR-010"
    notes:
      - "raport czyta S23; opisz kolejność i duplikaty zdarzeń zaobserwowane w PoC"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test poc/feed"
      - "test -f poc/feed/REPORT.md"

  - id: S05
    title: "Przegląd scenariuszy z biznesem, decyzje D-01..D-07"
    phase: 0
    agent: bdd-analyst
    tier: T2
    size: M
    depends_on: [S00]
    reads: [AGENTS.md, docs/architecture/01-requirements.md, specs/README.md, plan/execution-plan.md]
    writes: ["specs/**", "docs/rfc/**"]
    outcome:
      - "`specs/**` przejrzane z biznesem: każdy scenariusz ma tag FR, świat testowy w `specs/README.md` kompletny"
      - "decyzje D-01…D-07 z `plan/execution-plan.md` rozstrzygnięte albo zapisane jako pytania w `docs/rfc/RFC-S05-pytania.md`"
      - "tabela FR → scenariusze w przekazaniu"
    notes:
      - "jedyny krok agenta, który zmienia `specs/**`; po G0 zmiana scenariusza wymaga RFC"
      - "agent nie ma komend — lint Gherkin uruchamia orkiestrator w bramkach"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx gherkin-lint specs"
    acceptance:
      - "Product Owner zatwierdził `specs/**` (warunek bramki G0)"

  - id: S06
    title: "Środowisko dev — Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, dostępy sieciowe"
    phase: 0
    agent: human
    pair: data-engineer
    pair_task: "wspiera DevOps przy konfiguracji MSSQL: skrypty i checklisty w `deploy/**`, bez sekretów w repozytorium"
    size: L
    depends_on: [S00]
    reads: [AGENTS.md, docs/adr/ADR-003-official-camunda-sdk-behind-acl.md, docs/adr/ADR-005-mssql-rls-ledger-trace.md]
    writes: ["deploy/**", "infra/**"]
    outcome:
      - "środowisko dev: Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, dostępy sieciowe"
      - "`deploy/dev/READINESS.md` — odhaczona checklista gotowości z adresami usług (bez sekretów)"
    notes:
      - "prowadzi DevOps; `data-engineer` pomaga przy MSSQL (uprawnienia DBA, Ledger, RLS)"
      - "parametry wariantów rozumowania bramki modelu oznaczone [DO WERYFIKACJI] w `config/models.yaml` potwierdź przy okazji"
    dod:
      - "test -f deploy/dev/READINESS.md"
    acceptance:
      - "checklista gotowości środowiska z dokumentu DevOps (sekcja 11) odhaczona"
      - "logowanie kontem AD testowym przez RHBK działa"

  - id: S07
    title: "PoC formatek w UI — edytor form-js w Angularze, renderer na design systemie kontra viewer, zestaw zgodności"
    phase: 0
    agent: frontend-developer
    pair: ux-designer
    pair_task: "ocenia zgodność renderera z tokenami i katalogiem pól; uwagi dopisuje do `poc/forms-ui/REPORT.md`"
    tier: T2
    size: M
    depends_on: [S00]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/adr/ADR-019-form-designer-and-design-system-materialization.md, design/forms/README.md, design/forms/field-catalog.yaml, design/forms/examples/ocena-wniosku.form, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/design-system/SKILL.md]
    writes: ["poc/forms-ui/**"]
    outcome:
      - "`poc/forms-ui/` — edytor form-js osadzony w Angularze i renderer na komponentach design systemu obok viewera form-js"
      - "zestaw zgodności na formatkach wzorcowych (`design/forms/examples/`) z pomiarem rozbieżności zachowania"
      - "`poc/forms-ui/REPORT.md` z rekomendacją statusu ADR-019 i wersją form-js zgodną z Modelerem dla 8.9"
    notes:
      - "raport czytają S40, S45, S49; wypisz typy pól, których własny renderer nie obsługuje"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npm test --prefix poc/forms-ui"
      - "test -f poc/forms-ui/REPORT.md"

  - id: S08
    title: "PoC walidacji formatek na serwerze — reguły schematu w .NET, ewaluacja FEEL przez API klastra 8.9, różnice względem przeglądarki"
    phase: 0
    agent: camunda-integrator
    pair: module-implementer
    pair_task: "pisze część .NET walidacji schematu; `camunda-integrator` — wywołania klastra"
    tier: T2
    size: S
    depends_on: [S01]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/adr/ADR-020-form-server-validation-and-feel.md, docs/architecture/06-camunda-integration.md, poc/sdk/REPORT.md, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["poc/forms-validation/**"]
    outcome:
      - "`poc/forms-validation/` — walidacja reguł schematu Camunda Forms w .NET i ewaluacja FEEL przez API klastra 8.9"
      - "`poc/forms-validation/REPORT.md`: różnice FEEL przeglądarka–silnik, wariant zapasowy, rekomendacja statusu ADR-020"
    notes:
      - "raport czyta S37; port `IExpressionEvaluator` projektuje dopiero S15 — tu tylko dowód wykonalności"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test poc/forms-validation"
      - "test -f poc/forms-validation/REPORT.md"

  - id: S09
    title: "Warstwa wizualna — biblioteka w Figma, tokeny, katalog pól i specyfikacje komponentów zatwierdzone przez projektanta UX"
    phase: 0
    agent: ux-designer
    tier: T1
    size: M
    depends_on: [S00]
    reads: [AGENTS.md, docs/artifacts/04-wytyczne-ui.md, design/README.md, design/forms/README.md, design/forms/field-catalog.yaml, design/tokens.json, .opencode/skills/design-system/SKILL.md]
    writes: ["design/**"]
    outcome:
      - "`design/tokens.json`, `design/forms/field-catalog.yaml` i specyfikacje komponentów zgodne z eksportem z Figma"
      - "`contrast_checked` zaktualizowane dla każdego zmienionego koloru"
    notes:
      - "agent nie ma dostępu do Figma — pracuje na eksportach dostarczonych przez projektanta UX w `design/**`; brak eksportu = `blocked`"
      - "status typu pola w katalogu zmienia tylko architekt platformy (plik jest na liście security_sensitive)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "python3 tools/artifacts/render_artifacts.py --check"
    acceptance:
      - "projektant UX zatwierdził eksport zmiennych z Figma, pomiar kontrastu i komplet stanów komponentów pól (decyzja D-16, warunek bramki G1)"

  # ---------- Faza 1: fundament ----------
  - id: S10
    title: "Szkielet rozwiązania, Host z rolami, szablon dotnet new ph-module"
    phase: 1
    gate_before: G0
    agent: module-implementer
    tier: T2
    size: M
    critical: true
    depends_on: [S01, S02, S03, S04, S05]
    reads: [AGENTS.md, docs/architecture/05-solution-architecture.md, docs/adr/ADR-001-modular-monolith.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["ProcessHub.sln", "Directory.*.props", "src/ProcessHub.Host/**", "src/BuildingBlocks/**", "src/Modules/*/**", "templates/**", "tests/**/*.csproj"]
    outcome:
      - "`ProcessHub.sln`, `Directory.*.props`, Host z rolami uruchomieniowymi, puste szkielety wszystkich modułów i projektów testów"
      - "szablon `dotnet new ph-module` w `templates/ph-module/`"
    notes:
      - "nie twórz katalogów `Contracts` — kontrakty v1 pisze architekt w S15 (strażnik zablokuje zapis)"
      - "utwórz projekty testów (`tests/**/*.csproj`) dla wszystkich modułów i dodaj je do rozwiązania — późniejsze kroki nie mają `ProcessHub.sln` w zakresie"
      - "bez nowych paczek NuGet poza wymienionymi w `05-solution-architecture.md`; każda inna wymaga ADR"
    dod: *dotnet_dod

  - id: S11
    title: "Testy architektury i bramki CI"
    phase: 1
    agent: module-implementer
    tier: T2
    size: S
    depends_on: [S10]
    reads: [AGENTS.md, docs/architecture/05-solution-architecture.md, docs/architecture/12-testing-strategy.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["tests/ProcessHub.ArchitectureTests/**", ".pipelines/**"]
    outcome:
      - "`tests/ProcessHub.ArchitectureTests` — granice modułów, zakaz typów SDK Camunda poza `CamundaIntegration`, endpoint bez potoku = błąd"
      - "definicja potoku CI w `.pipelines/` uruchamiająca bramki z `AGENTS.md`"
    notes:
      - "testy profili (`FullyQualifiedName~Profiles`) dopisuje S27 — zostaw na nie miejsce w strukturze projektu"
    dod: *dotnet_dod

  - id: S12
    title: "Building Blocks — potok, Actor, ITenantContext, Permission, middleware śladu, outbox/inbox/lease"
    phase: 1
    agent: module-implementer
    pair: bdd-tester
    pair_task: "pisze testy zachowania potoku (odmowa, audyt, idempotencja) w `tests/BuildingBlocks.UnitTests`"
    tier: T2
    size: L
    critical: true
    depends_on: [S10]
    reads: [AGENTS.md, docs/architecture/05-solution-architecture.md, docs/architecture/10-audit-and-security.md, docs/architecture/02-roles-and-authorization.md, docs/adr/ADR-002-single-tenant-multi-tenant-ready.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/BuildingBlocks/**", "src/ProcessHub.Host/Middleware/**", "tests/BuildingBlocks.UnitTests/**"]
    outcome:
      - "`src/BuildingBlocks/**`: potok komend i zapytań, `Actor`, `ITenantContext`, `Permission`, outbox, inbox, lease"
      - "middleware śladu w `src/ProcessHub.Host/Middleware/`"
      - "testy jednostkowe w `tests/BuildingBlocks.UnitTests`"
    notes:
      - "błąd w potoku powiela się w każdym module: deny by default i wpis audytu `Denied` muszą wynikać z potoku, nie z handlerów"
      - "ścieżka `src/BuildingBlocks/**/Authorization/**` jest security_sensitive — recenzja bezpieczeństwa obowiązkowa"
    dod: *dotnet_dod

  - id: S13
    title: "MSSQL — schematy, RLS, Ledger, partycje śladu, temporal, fixture Testcontainers"
    phase: 1
    agent: data-engineer
    tier: T2
    size: M
    depends_on: [S10]
    reads: [AGENTS.md, docs/architecture/09-persistence-mssql.md, docs/adr/ADR-005-mssql-rls-ledger-trace.md]
    writes: ["db/**", "tests/Shared/MsSql*/**", "tests/Db.IntegrationTests/**"]
    outcome:
      - "`db/**`: schematy modułów, RLS (FILTER + BLOCK), `audit.SecurityJournal` jako Ledger, partycje śladu, tabele temporalne"
      - "`tests/Shared/MsSqlFixture` (Testcontainers) i `tests/Db.IntegrationTests` z testem odrzuconego UPDATE na dzienniku"
    notes:
      - "tworzysz schematy i infrastrukturę; tabele modułów dodają ich kroki we własnych katalogach `db/**/<schemat>/`"
      - "wymaga Dockera (Testcontainers MSSQL)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test tests/Db.IntegrationTests --filter Category=integration"

  - id: S14
    title: "Harness Reqnroll — projekty Specs, drivery, świat testowy, asercje"
    phase: 1
    agent: bdd-tester
    tier: T2
    size: M
    depends_on: [S10, S05]
    reads: [AGENTS.md, specs/README.md, docs/architecture/12-testing-strategy.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["tests/*.Specs/**", "tests/Shared/World/**"]
    outcome:
      - "projekty `tests/*.Specs` dla każdego pliku `.feature`, interfejsy `I<Moduł>Driver`, budowniczy świata testowego w `tests/Shared/World`"
      - "asercje domenowe (`ShouldBeDeniedBy`, `ShouldContainJournalEntry`); scenariusze w stanie `pending`"
    notes:
      - "scenariusze mają się budować i być `pending`, nie zielone — implementacja przychodzi w krokach modułów"
      - "pliki `.feature` są tylko do odczytu"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test ProcessHub.sln --filter \"Category!=integration\""

  - id: S15
    title: "Kontrakty v1 wszystkich modułów i OpenAPI v1"
    phase: 1
    agent: architect
    tier: T1
    size: L
    critical: true
    depends_on: [S12]
    reads: [AGENTS.md, docs/architecture/03-context-map.md, docs/architecture/04-domain-model.md, docs/architecture/05-solution-architecture.md, docs/architecture/02-roles-and-authorization.md, docs/architecture/14-form-management.md]
    writes: ["src/Modules/*/Contracts/**", "api/openapi.v1.yaml"]
    outcome:
      - "`src/Modules/*/Contracts/**` dla wszystkich modułów (w tym porty `CamundaIntegration`, `IExpressionEvaluator`, `IAuthorizationAdmin`)"
      - "`api/openapi.v1.yaml` zgodne z kontraktami: `TenantId`, `Idempotency-Key`, `allowedActions`"
    notes:
      - "po bramce G1 kontrakty są zamrożone — każda zmiana to RFC i podbicie wersji; projektuj wąsko"
      - "nazwy wyłącznie ze słownika `docs/glossary.md`; żadnych typów SDK Camunda w kontraktach"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "npx @redocly/cli lint api/openapi.v1.yaml"
    acceptance:
      - "architekt (człowiek) i tech lead zamrażają kontrakty v1 i OpenAPI (warunek bramki G1)"

  - id: S16
    title: "Frontend — Nx, shell, motyw z tokenów (core/theming), ui-kit, katalog komponentów, i18n, mock server z OpenAPI"
    phase: 1
    gate_before: G1
    agent: frontend-developer
    pair: design-system-engineer
    pair_task: "buduje `core/theming` i `core/ui-kit` (tokeny, motyw); `frontend-developer` — workspace, powłokę, i18n i mock server"
    tier: T2
    size: M
    depends_on: [S15, S09]
    reads: [AGENTS.md, docs/architecture/11-frontend.md, api/openapi.v1.yaml, docs/artifacts/04-wytyczne-ui.md, design/README.md, design/tokens.json, .opencode/skills/design-system/SKILL.md]
    writes: ["frontend/**"]
    outcome:
      - "workspace Nx w `frontend/`, aplikacja `process-hub` z powłoką, `core/theming` (tokeny → zmienne CSS i motyw Kendo), `core/ui-kit`"
      - "aplikacja `ui-catalog`, i18n (PL), klient API generowany z OpenAPI i mock server"
    notes:
      - "startuje po G1 (zamrożone OpenAPI, przyjęty ADR-019) — tak jak na diagramie planu"
      - "`frontend/libs/platform/extension-sdk/**` należy do S19 i jest chronione: włącz bibliotekę do workspace, nie zmieniaj jej plików"
      - "Kendo UI wymaga licencji i prywatnego rejestru npm (decyzja S-4 w `docs/opencode/start.md`)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx run-many -t lint test build"

  - id: S17
    title: "Wtyczka bpmnlint ph i procesy BPMN świata testowego"
    phase: 1
    gate_before: G0
    agent: camunda-integrator
    tier: T2
    size: S
    depends_on: [S05]
    reads: [AGENTS.md, docs/architecture/06-camunda-integration.md, specs/README.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["bpmn/**"]
    outcome:
      - "`bpmn/bpmnlint-plugin-ph` z regułami `ph` i testami"
      - "procesy BPMN świata testowego ze `specs/README.md` w `bpmn/`"
    notes:
      - "regułę `ph/form-reference` dodaje S29 — nie implementuj jej tutaj"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npm test --prefix bpmn/bpmnlint-plugin-ph"
      - "npx bpmnlint \"bpmn/**/*.bpmn\""

  - id: S18
    title: "BFF — OIDC z RHBK, ciasteczko __Host-, CSRF, wylogowanie"
    phase: 1
    agent: module-implementer
    tier: T2
    size: M
    depends_on: [S12]
    reads: [AGENTS.md, docs/adr/ADR-008-bff-cookie.md, docs/architecture/10-audit-and-security.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["src/ProcessHub.Host/Auth/**", "tests/Host.Auth.Tests/**"]
    outcome:
      - "`src/ProcessHub.Host/Auth/**`: logowanie OIDC przez RHBK, ciasteczko `__Host-`, CSRF, wylogowanie"
      - "`tests/Host.Auth.Tests`"
    notes:
      - "cała ścieżka jest security_sensitive — recenzja bezpieczeństwa obowiązkowa; tokenów nie logujemy"
    dod: *dotnet_dod

  - id: S19
    title: "SDK rozszerzeń i rejestr profili — manifesty, walidacja, kompozycja modułów, kontrakt slotów UI"
    phase: 1
    agent: architect
    pair: module-implementer
    pair_task: "implementuje `ExtensionHost` i testy; architekt projektuje publiczne API SDK"
    tier: T1
    size: L
    depends_on: [S10, S15]
    reads: [AGENTS.md, docs/architecture/13-project-profiles.md, docs/adr/ADR-012-project-profiles-and-extension-points.md, docs/adr/ADR-017-profile-data-actions.md, profiles/profile.schema.json, profiles/kredyty/profile.yaml, .opencode/skills/profile-extension/SKILL.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["src/Platform/ProcessHub.Extensibility/**", "src/Platform/ProcessHub.Extensibility.Testing/**", "src/Modules/ExtensionHost/**", "frontend/libs/platform/extension-sdk/**", "tests/ExtensionHost.*/**"]
    specs: ["specs/profiles/project-profiles.feature @FR-23"]
    outcome:
      - "`ProcessHub.Extensibility` (SDK .NET) i `ProcessHub.Extensibility.Testing`"
      - "moduł `ExtensionHost`: rejestr profili, walidacja manifestów, kompozycja modułów"
      - "`frontend/libs/platform/extension-sdk` — kontrakt slotów UI"
    notes:
      - "decyzje D-08 i D-09 muszą być rozstrzygnięte przed startem (człowiek)"
      - "biblioteka TS powstaje jako samodzielny pakiet typów; do workspace Nx włącza ją S16 albo S47 — nie zakładaj, że `frontend/` już istnieje"
      - "to publiczny kontrakt dla zespołów profili: zgodność z `profiles/profile.schema.json` i przykładami w `profiles/`"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test ProcessHub.sln --filter \"Category!=integration\""
      - "dotnet test tests/ProcessHub.ArchitectureTests"
      - "python3 tools/profiles/validate_profiles.py --check"

  # ---------- Faza 2: domena dostępu, Camunda, audyt, formatki ----------
  - id: S20
    title: "Party & Accountability — Actor z tokenu, migawka grup, Absence"
    phase: 2
    gate_before: G1
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S15]
    reads: [AGENTS.md, docs/architecture/04-domain-model.md, docs/architecture/02-roles-and-authorization.md, src/Modules/PartyAccountability/Contracts, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/PartyAccountability/**", "tests/PartyAccountability.*/**"]
    specs: ["specs/tasks/substitution.feature @FR-12 (walidacje Absence)"]
    outcome:
      - "moduł `PartyAccountability`: `Actor` z tokenu, migawka grup, agregat `Absence` z walidacjami czasu"
    notes:
      - "worker zastępstw i uzgadnianie to S33 — tutaj tylko model i walidacje nieobecności"
    dod: *dotnet_dod

  - id: S21
    title: "Autoryzacje jako kod — loader YAML, walidacja R7/readOnly, reconciler"
    phase: 2
    gate_before: G1
    agent: module-implementer
    pair: camunda-integrator
    pair_task: "pisze adapter `IAuthorizationAdmin` na oficjalnym SDK; `module-implementer` — moduł `PlatformAdministration`"
    tier: T2
    size: M
    depends_on: [S15]
    reads: [AGENTS.md, docs/architecture/02-roles-and-authorization.md, config/authorization/roles.example.yaml, config/authorization/assignments.example.yaml, poc/authz/REPORT.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["src/Modules/PlatformAdministration/**", "src/Modules/CamundaIntegration/**/Authorization*/**", "config/authorization/**", "tests/PlatformAdministration.*/**"]
    specs: ["specs/access/authorization-as-code.feature"]
    outcome:
      - "moduł `PlatformAdministration`: loader YAML, walidacja (R7, readOnly), reconciler z trybami dry-run, apply i wykrywaniem dryfu"
      - "adapter `IAuthorizationAdmin` w `CamundaIntegration` (katalogi `Authorization*`)"
    notes:
      - "biegnie równolegle z S22, który pisze w całym `CamundaIntegration` — uzgodnij z nim wspólne pliki (projekt, rejestracja DI) albo prowadź kroki po kolei"
      - "nazwy uprawnień Camunda bierz z `poc/authz/REPORT.md`"
    dod: *dotnet_dod

  - id: S22
    title: "Adaptery oficjalnego SDK dla wszystkich portów, fake, testy kontraktowe"
    phase: 2
    gate_before: G1
    agent: camunda-integrator
    tier: T2
    size: L
    critical: true
    depends_on: [S15]
    reads: [AGENTS.md, docs/architecture/06-camunda-integration.md, docs/adr/ADR-003-official-camunda-sdk-behind-acl.md, poc/sdk/REPORT.md, src/Modules/CamundaIntegration/Contracts, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["src/Modules/CamundaIntegration/**", "tests/CamundaIntegration.*/**"]
    outcome:
      - "adaptery oficjalnego SDK dla wszystkich portów z `CamundaIntegration.Contracts`"
      - "fake in-memory każdego portu"
      - "`tests/CamundaIntegration.ContractTests` — jeden zestaw dla fake i Testcontainers"
    notes:
      - "tylko `CamundaIntegration.Infrastructure.Sdk` referuje SDK; adapter `IAuthorizationAdmin` należy do S21"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test tests/CamundaIntegration.ContractTests"
      - "dotnet test tests/ProcessHub.ArchitectureTests"

  - id: S23
    title: "Projekcja — instancje, zadania, odwiedziny elementów, incydenty, katalog elementów"
    phase: 2
    agent: camunda-integrator
    pair: data-engineer
    pair_task: "projektuje tabele i indeksy schematów `task` i `insight` oraz migracje w `db/**`"
    tier: T2
    size: L
    critical: true
    depends_on: [S22, S13]
    reads: [AGENTS.md, docs/adr/ADR-010-read-model-feed.md, poc/feed/REPORT.md, docs/architecture/09-persistence-mssql.md, docs/architecture/07-process-stage-overlay.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["src/Modules/CamundaIntegration/**", "db/**/task/**", "db/**/insight/**", "tests/CamundaIntegration.*/**"]
    outcome:
      - "projekcja instancji, zadań, odwiedzin elementów i incydentów (upsert po kluczach Camunda, inbox, znacznik postępu, metryka opóźnienia)"
      - "katalog elementów z XML definicji"
      - "migracje schematów `task` i `insight`"
    notes:
      - "spójność ostateczna: obsłuż duplikaty, kolejność i wznowienie — wnioski z `poc/feed/REPORT.md`"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test tests/CamundaIntegration.ContractTests"
      - "dotnet test tests/CamundaIntegration.Projection.Tests --filter Category=integration"

  - id: S24
    title: "Access Policy — uprawnienia efektywne, R1–R11, TaskAccess, generowana macierz autoryzacji"
    phase: 2
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: L
    critical: true
    depends_on: [S20, S21, S23]
    reads: [AGENTS.md, docs/architecture/02-roles-and-authorization.md, docs/architecture/09-persistence-mssql.md, src/Modules/AccessPolicy/Contracts, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/AccessPolicy/**", "tests/AccessPolicy.*/**", "db/**/access/**"]
    specs: ["specs/access/visibility.feature"]
    outcome:
      - "moduł `AccessPolicy`: uprawnienia efektywne, reguły R1–R11, `TaskAccess`"
      - "generowana macierz autoryzacji"
      - "migracje schematu `access`"
    notes:
      - "serce bezpieczeństwa — recenzja bezpieczeństwa obowiązkowa; decyzje D-01 i D-02 ze S05 określają widoczność i przekazywanie"
    dod: *dotnet_dod

  - id: S25
    title: "Audyt — dziennik dwufazowy, uzgadnianie, API przeglądu, test kompletności"
    phase: 2
    gate_before: G1
    agent: module-implementer
    pair: data-engineer
    pair_task: "tabele Ledger i partycje śladu w `db/**/audit/**` oraz testy na Testcontainers"
    tier: T2
    size: M
    depends_on: [S15, S13]
    reads: [AGENTS.md, docs/architecture/10-audit-and-security.md, docs/adr/ADR-005-mssql-rls-ledger-trace.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["src/Modules/Audit/**", "tests/Audit.*/**", "db/**/audit/**"]
    specs: ["specs/audit/audit.feature"]
    outcome:
      - "moduł `Audit`: dziennik dwufazowy, uzgadnianie, API przeglądu"
      - "test kompletności audytu"
      - "migracje schematu `audit`"
    notes:
      - "wpisy nie zawierają PII; login aplikacji nie ma UPDATE ani DELETE na dzienniku (ADR-005)"
    dod: *dotnet_dod

  - id: S26
    title: "Form Management — formatki Camunda Forms, cykl życia wersji, R8, R11, publikacja z kontraktem i katalogiem pól, wycofanie, import i eksport"
    phase: 2
    gate_before: G1
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: L
    depends_on: [S15]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/adr/ADR-018-camunda-forms-format-lifecycle-isolation.md, docs/architecture/04-domain-model.md, docs/architecture/06-camunda-integration.md, design/forms/field-catalog.yaml, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/FormManagement/**", "tests/FormManagement.*/**"]
    specs: ["specs/forms/form-lifecycle.feature @FR-17", "specs/forms/form-designer.feature @FR-28", "specs/forms/form-versioning.feature @FR-29", "specs/forms/form-withdrawal.feature @FR-30", "specs/forms/form-isolation.feature @FR-31"]
    outcome:
      - "moduł `FormManagement`: maszyna stanów wersji formatki, cztery oczy (R8), separacja per proces (R11)"
      - "publikacja z walidacją kontraktu danych i katalogu pól, wycofanie, import i eksport"
    notes:
      - "decyzje D-12…D-14 określają cztery oczy i skutek wycofania; formatek nie wdrażasz do silnika (ADR-018)"
      - "tabele schematu `form` tworzy S28; powiązania z BPMN — S29; przepięcie zadań w toku — S39"
    dod: *dotnet_dod

  - id: S27
    title: "Izolacja profili — schemat i użytkownik bazy per profil, widoki platform_api, role projektowe w reconcilerze, testy architektury profili"
    phase: 2
    agent: data-engineer
    pair: security-reviewer
    tier: T2
    size: M
    depends_on: [S13, S19, S21]
    reads: [AGENTS.md, docs/architecture/13-project-profiles.md, docs/adr/ADR-013-profile-code-separation-and-ownership.md, docs/adr/ADR-014-profile-data-isolation.md, docs/architecture/09-persistence-mssql.md, config/authorization/assignments.example.yaml, profiles/kredyty/authorization.yaml, .opencode/skills/profile-extension/SKILL.md]
    writes: ["db/**", "src/Modules/ExtensionHost/Infrastructure/**", "src/Modules/PlatformAdministration/**", "tests/ProcessHub.ArchitectureTests/**", "tests/ExtensionHost.*/**"]
    specs: ["specs/profiles/project-profiles.feature @FR-24 @FR-26"]
    outcome:
      - "schemat i użytkownik bazy per profil, widoki `platform_api` z RLS"
      - "role projektowe w reconcilerze (R10)"
      - "testy architektury profili (`FullyQualifiedName~Profiles`) i testy izolacji w `tests/ExtensionHost.Specs`"
    notes:
      - "decyzja D-11 określa zakres danych w `platform_api`"
      - "zakres `db/**` jest szeroki — nie zmieniaj schematów innych modułów; dodawaj tylko obiekty izolacji profili"
      - "od tego kroku zależą plany profili (KRE-01, FLO-01)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test tests/ExtensionHost.Specs --filter Category=integration"
      - "dotnet test tests/ProcessHub.ArchitectureTests"
      - "python3 tools/profiles/validate_profiles.py --self-test"

  - id: S28
    title: "Schemat form — wersje, przeglądy, wycofania, unikalność i klucze per proces, historia przypięć"
    phase: 2
    gate_before: G1
    agent: data-engineer
    tier: T2
    size: S
    depends_on: [S13, S15]
    reads: [AGENTS.md, docs/architecture/09-persistence-mssql.md, docs/architecture/14-form-management.md]
    writes: ["db/**/form/**", "db/**/task/**", "tests/Db.IntegrationTests/**"]
    specs: ["specs/forms/form-isolation.feature @FR-31 @integration"]
    outcome:
      - "migracje schematu `form`: wersje, przeglądy, wycofania, unikalność i klucze per proces"
      - "historia przypięć w schemacie `task`"
      - "test klucza obcego przypięcia w `tests/Db.IntegrationTests`"
    notes:
      - "w `db/**/task/**` dodajesz wyłącznie obiekty przypięć — tabele projekcji należą do S23"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test tests/Db.IntegrationTests --filter Category=integration"

  - id: S29
    title: "Powiązania formatek z procesem — referencje ph:form i kontrakt danych z katalogu elementów, kontrola spójności, reguła bpmnlint ph/form-reference"
    phase: 2
    agent: camunda-integrator
    pair: module-implementer
    pair_task: "pisze kontrolę spójności w `FormManagement/**/Bindings`; `camunda-integrator` — katalog elementów i regułę bpmnlint"
    tier: T2
    size: M
    depends_on: [S17, S23, S26]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/architecture/06-camunda-integration.md, docs/adr/ADR-018-camunda-forms-format-lifecycle-isolation.md, .opencode/skills/camunda-practices/SKILL.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["src/Modules/CamundaIntegration/**", "src/Modules/FormManagement/**/Bindings/**", "bpmn/bpmnlint-plugin-ph/**", "tests/CamundaIntegration.*/**", "tests/FormManagement.*/**"]
    specs: ["specs/forms/form-isolation.feature @FR-31"]
    outcome:
      - "referencje `ph:form` i kontrakt danych w katalogu elementów"
      - "kontrola spójności formatka–proces w `FormManagement` (katalog `Bindings`)"
      - "reguła bpmnlint `ph/form-reference` z testami"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test ProcessHub.sln --filter \"Category!=integration\""
      - "dotnet test tests/CamundaIntegration.ContractTests"
      - "npm test --prefix bpmn/bpmnlint-plugin-ph"

  # ---------- Faza 3: funkcje rdzenia ----------
  - id: S30
    title: "Task Work — przejęcie, zwolnienie, szkic, zakończenie, idempotencja"
    phase: 3
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: L
    critical: true
    depends_on: [S24, S25]
    reads: [AGENTS.md, docs/architecture/04-domain-model.md, docs/architecture/06-camunda-integration.md, src/Modules/TaskWork/Contracts, src/Modules/CamundaIntegration/Contracts, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/TaskWork/**", "tests/TaskWork.*/**"]
    specs: ["specs/tasks/claim-and-complete.feature"]
    outcome:
      - "moduł `TaskWork`: przejęcie, zwolnienie, szkic, zakończenie z idempotencją"
      - "scenariusze `@FR-04` i `@FR-06` zielone także z tagiem `@integration` na prawdziwej Camunda (dowód bramki G2)"
    notes:
      - "edycja i zakończenie tylko przez assignee (R1); obsłuż wyścig dwóch przejęć"
      - "pierwsza pełna ścieżka przez potok, SDK i read model — wzorzec dla kolejnych modułów, opisz go w `src/Modules/TaskWork/AGENTS.md`"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet build ProcessHub.sln -warnaserror"
      - "dotnet test ProcessHub.sln --filter \"Category!=integration\""
      - "dotnet test tests/TaskWork.Specs --filter Category=integration"
      - "dotnet test tests/ProcessHub.ArchitectureTests"

  - id: S31
    title: "Process Lifecycle — katalog startowy, start, moje procesy"
    phase: 3
    gate_before: G2
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S30, S37]
    reads: [AGENTS.md, docs/architecture/06-camunda-integration.md, src/Modules/ProcessLifecycle/Contracts, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/ProcessLifecycle/**", "tests/ProcessLifecycle.*/**"]
    specs: ["specs/processes/start-process.feature"]
    outcome:
      - "moduł `ProcessLifecycle`: katalog startowy, start procesu z formatką startową, moje procesy"
    notes:
      - "formatka startowa nie ma przypięcia — start waliduje dane względem wersji podanej w żądaniu (`14-form-management.md`, sekcja 9)"
    dod: *dotnet_dod

  - id: S32
    title: "Przekazywanie — osoba, grupa, partia z wznowieniem"
    phase: 3
    gate_before: G2
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S30]
    reads: [AGENTS.md, docs/architecture/04-domain-model.md, docs/architecture/06-camunda-integration.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/TaskWork/**", "tests/TaskWork.*/**"]
    specs: ["specs/tasks/reassignment.feature"]
    outcome:
      - "przekazanie zadania osobie i grupie"
      - "partia `ReassignmentBatch` jako saga ze wznowieniem"
    notes:
      - "menadżer przekazuje, ale nie edytuje treści zadania (R1); decyzje D-02 i D-05"
      - "S39 pisze w tym samym module — nie prowadź obu kroków równolegle"
    dod: *dotnet_dod

  - id: S33
    title: "Zastępstwa — worker task listenera (fail-open), uzgadnianie"
    phase: 3
    agent: camunda-integrator
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S20, S22, S25]
    reads: [AGENTS.md, docs/adr/ADR-007-substitution-task-listener.md, poc/listener/REPORT.md, .opencode/skills/reqnroll-bdd/SKILL.md, .opencode/skills/camunda-practices/SKILL.md]
    writes: ["src/Modules/CamundaIntegration/**/Substitution*/**", "src/Modules/PartyAccountability/Application/Substitution/**", "src/ProcessHub.Host/Roles/Worker/**", "tests/Substitution.*/**"]
    specs: ["specs/tasks/substitution.feature"]
    outcome:
      - "worker task listenera `ph.substitution` w roli `worker` (limit czasu, fail-open, audyt korekty lub pominięcia)"
      - "uzgadnianie zastępstw"
    notes:
      - "decyzja D-04: nowe zadania automatycznie, istniejące — propozycja przekazania masowego"
    dod: *dotnet_dod

  - id: S34
    title: "Mapa etapów — agregat, API edytora, dziedziczenie wersji, algorytm stanu"
    phase: 3
    gate_before: G2
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: L
    critical: true
    depends_on: [S23, S24, S30]
    reads: [AGENTS.md, docs/architecture/07-process-stage-overlay.md, docs/adr/ADR-006-stage-map-overlay.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/ProcessInsight/**", "tests/ProcessInsight.*/**", "db/**/insight/**"]
    specs: ["specs/insight/stage-map.feature"]
    outcome:
      - "moduł `ProcessInsight`: agregat mapy etapów, API edytora, dziedziczenie wersji, algorytm stanu etapów"
      - "migracje schematu `insight`"
    notes:
      - "algorytm stanu musi obsłużyć równoległość, pętle i call activity; decyzja D-03 określa, kto mapuje elementy"
    dod: *dotnet_dod

  - id: S35
    title: "Eskalacje — wykrywanie, zakres, lista, kategoria po terminie"
    phase: 3
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S34]
    reads: [AGENTS.md, docs/architecture/08-process-dashboard.md, docs/architecture/06-camunda-integration.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/ProcessInsight/**", "tests/ProcessInsight.*/**"]
    specs: ["specs/insight/escalations.feature"]
    outcome:
      - "wykrywanie eskalacji i ich zakresu, lista eskalacji, kategoria „po terminie”"
    notes:
      - "S36 pisze w tym samym module — nie prowadź obu kroków równolegle (S36 jest na ścieżce krytycznej, ma pierwszeństwo)"
    dod: *dotnet_dod

  - id: S36
    title: "Dashboard — agregaty, IProcessMetric, progi zdrowia, świeżość"
    phase: 3
    agent: module-implementer
    pair: data-engineer
    pair_task: "zapytania agregujące, indeksy i plany wykonania w `db/**/insight/**`"
    tier: T2
    size: L
    critical: true
    depends_on: [S34]
    reads: [AGENTS.md, docs/architecture/08-process-dashboard.md, docs/adr/ADR-011-business-outcome-on-end-events.md, .opencode/skills/ddd-module/SKILL.md]
    writes: ["src/Modules/ProcessInsight/**", "tests/ProcessInsight.*/**", "db/**/insight/**"]
    specs: ["specs/insight/process-dashboard.feature"]
    outcome:
      - "agregaty dashboardu, metryki `IProcessMetric`, progi zdrowia, znacznik świeżości danych"
    notes:
      - "decyzja D-06: anulowane instancje to osobny licznik, nie błąd; wynik biznesowy z end eventów (ADR-011)"
    dod: *dotnet_dod

  - id: S37
    title: "Form Runtime — schemat przypiętej wersji, walidacja danych na serwerze (reguły Camunda Forms, FEEL przez IExpressionEvaluator), przypięcie wersji"
    phase: 3
    gate_before: G1
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S26, S29, S08]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/adr/ADR-020-form-server-validation-and-feel.md, docs/architecture/04-domain-model.md, design/forms/field-catalog.yaml, poc/forms-validation/REPORT.md, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/FormRuntime/**", "src/Modules/CamundaIntegration/**/Expression*/**", "tests/FormRuntime.*/**", "tests/CamundaIntegration.*/**"]
    specs: ["specs/forms/form-lifecycle.feature @FR-18", "specs/forms/form-rendering.feature @FR-32 @FR-06"]
    outcome:
      - "moduł `FormRuntime`: schemat przypiętej wersji, walidacja danych na serwerze wg reguł Camunda Forms, przypięcie wersji"
      - "adapter `IExpressionEvaluator` (FEEL przez silnik) w `CamundaIntegration`"
    notes:
      - "brak trasy „pobierz formatkę po identyfikatorze” — schemat wydawany tylko dla przypięcia zadania"
      - "błąd walidacji przepuszcza złe dane do procesu: wariant zapasowy z `poc/forms-validation/REPORT.md` musi być jawny"
    dod: *dotnet_dod

  - id: S38
    title: "Potok operacji profili (zadanie, sprawa, dane profilu), wzbogacenia i zdarzenia; profil przykładowy i testy zgodności SDK"
    phase: 3
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S27, S30]
    reads: [AGENTS.md, docs/architecture/13-project-profiles.md, docs/adr/ADR-017-profile-data-actions.md, docs/architecture/10-audit-and-security.md, src/Modules/TaskWork/Contracts, src/Platform/ProcessHub.Extensibility, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["src/Modules/ExtensionHost/**", "src/Platform/ProcessHub.Extensibility.Testing/**", "tests/ExtensionHost.*/**"]
    specs: ["specs/profiles/project-profiles.feature @FR-25 @FR-26"]
    outcome:
      - "potok operacji profili w `ExtensionHost` (zadanie, sprawa, dane profilu — ADR-017), wzbogacenia, zdarzenia"
      - "profil przykładowy i testy zgodności SDK w `ProcessHub.Extensibility.Testing`"
    notes:
      - "operacje profili przechodzą przez ten sam audyt i autoryzację co platforma; limit czasu i izolacja awarii profilu"
      - "SDK (`src/Platform/ProcessHub.Extensibility/**`) jest chronione — brak w kontrakcie = RFC"
      - "od tego kroku zależą KRE-02, FLO-03, FLO-05 i AML-01"
    dod: *dotnet_dod

  - id: S39
    title: "Wycofanie formatek w toku — przepięcie zadań (saga ze wznowieniem), zadania bez formatki, powiadomienia"
    phase: 3
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S28, S30, S37]
    reads: [AGENTS.md, docs/architecture/14-form-management.md, docs/adr/ADR-018-camunda-forms-format-lifecycle-isolation.md, docs/architecture/04-domain-model.md, src/Modules/TaskWork/Contracts, src/Modules/FormManagement/Contracts, .opencode/skills/ddd-module/SKILL.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["src/Modules/FormManagement/**", "src/Modules/TaskWork/**", "tests/FormManagement.*/**", "tests/TaskWork.*/**"]
    specs: ["specs/forms/form-withdrawal.feature @FR-30"]
    outcome:
      - "wycofanie wersji w toku: przepięcie zadań (`Repin`) jako saga ze wznowieniem"
      - "obsługa zadań bez formatki i powiadomienia"
    notes:
      - "szkic danych przechodzi dla pól o tym samym kluczu i typie; każde przepięcie to wpis `Form.Repin`"
      - "S32 pisze w tym samym module `TaskWork` — nie prowadź obu kroków równolegle"
    dod: *dotnet_dod

  # ---------- Faza 4: frontend funkcjonalny ----------
  - id: S40
    title: "Skrzynka zadań i renderer formatek Camunda Forms (interpretacja schematu, FEEL, układ, rejestr komponentów pól)"
    phase: 4
    agent: frontend-developer
    pair: ui-reviewer
    tier: T2
    size: L
    depends_on: [S16, S30, S37, S49]
    reads: [AGENTS.md, design/README.md, design/forms/README.md, design/forms/field-catalog.yaml, docs/architecture/11-frontend.md, docs/architecture/14-form-management.md, poc/forms-ui/REPORT.md, api/openapi.v1.yaml, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderTasks` i `renderTask`; nie wczytuj całości"
    writes: ["frontend/libs/task-workspace/**", "frontend/libs/form-runtime/**"]
    specs: ["specs/forms/form-rendering.feature @FR-32"]
    outcome:
      - "`frontend/libs/task-workspace` — skrzynka zadań i widok zadania"
      - "`frontend/libs/form-runtime` — renderer schematu Camunda Forms na komponentach `ph-*`"
    notes:
      - "do czasu scalenia backendu pracujesz na mock serverze z S16; akcje wyłącznie z `allowedActions`"
      - "renderer nie zawiera stylów; typy pól zablokowane i planowane nie są renderowane"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S41
    title: "Start procesu i moje procesy"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: M
    depends_on: [S16, S31]
    reads: [AGENTS.md, design/README.md, docs/architecture/11-frontend.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderStartCatalog`, `renderStartForm`, `renderMyProcesses`; nie wczytuj całości"
    writes: ["frontend/libs/process-lifecycle/**"]
    outcome:
      - "`frontend/libs/process-lifecycle` — katalog startowy, formatka startowa, moje procesy"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S42
    title: "Dashboard, eskalacje, instancja z mapą etapów"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: L
    critical: true
    depends_on: [S16, S35, S36]
    reads: [AGENTS.md, design/README.md, docs/architecture/08-process-dashboard.md, docs/architecture/07-process-stage-overlay.md, docs/architecture/11-frontend.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderDashboard`, `renderEscalations`, `renderCases`, `renderCase`; nie wczytuj całości"
    writes: ["frontend/libs/process-insight/**"]
    outcome:
      - "`frontend/libs/process-insight` — dashboard, lista eskalacji, widok instancji ze wstęgą etapów"
    notes:
      - "wykresy muszą być dostępne bez koloru jako jedynego nośnika; znacznik świeżości danych widoczny"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S43
    title: "Przekazywanie pojedyncze i masowe, zastępstwa"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: M
    depends_on: [S16, S32, S33]
    reads: [AGENTS.md, design/README.md, docs/architecture/11-frontend.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderBulk` i `renderAbsences`; nie wczytuj całości"
    writes: ["frontend/libs/reassignment/**"]
    outcome:
      - "`frontend/libs/reassignment` — przekazanie pojedyncze, kreator partii, zastępstwa"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S44
    title: "Edytor mapy etapów (bpmn-js viewer)"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: M
    depends_on: [S16, S34]
    reads: [AGENTS.md, design/README.md, docs/architecture/07-process-stage-overlay.md, docs/architecture/11-frontend.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderStageMap`; nie wczytuj całości"
    writes: ["frontend/libs/stage-map-editor/**"]
    outcome:
      - "`frontend/libs/stage-map-editor` — edytor mapy etapów z podglądem bpmn-js"
    notes:
      - "bpmn-js tylko w tej bibliotece i tylko przy akcji `viewTechnical`"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S45
    title: "Projektant formatek — osadzony edytor form-js z paletą z katalogu pól, cykl życia, wersje i porównanie, wycofanie, import i eksport, podgląd jak u wykonawcy"
    phase: 4
    agent: frontend-developer
    pair: ui-reviewer
    tier: T2
    size: L
    depends_on: [S16, S26, S40]
    reads: [AGENTS.md, design/README.md, design/forms/README.md, design/forms/field-catalog.yaml, docs/architecture/11-frontend.md, docs/architecture/14-form-management.md, docs/adr/ADR-019-form-designer-and-design-system-materialization.md, poc/forms-ui/REPORT.md, .opencode/skills/camunda-forms/SKILL.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderForms` i `renderFormDesigner`; nie wczytuj całości"
    writes: ["frontend/libs/form-designer/**"]
    specs: ["specs/forms/form-designer.feature @FR-28"]
    outcome:
      - "`frontend/libs/form-designer` — osadzony edytor form-js z paletą z katalogu pól, cykl życia, wersje i porównanie, wycofanie, import i eksport, podgląd"
    notes:
      - "edytor form-js tylko w tej bibliotece; znak bpmn.io pozostaje widoczny; podgląd używa renderera z S40"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S46
    title: "Widoki audytora i przegląd audytu"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: S
    depends_on: [S16, S25]
    reads: [AGENTS.md, design/README.md, docs/architecture/10-audit-and-security.md, docs/architecture/11-frontend.md, .opencode/skills/design-system/SKILL.md]
    refs:
      - "design/mockups/index.html — makieta w jednym pliku (145 kB, ok. 45 tys. tokenów): wyszukaj funkcje `renderAudit`; nie wczytuj całości"
    writes: ["frontend/libs/audit-viewer/**"]
    outcome:
      - "`frontend/libs/audit-viewer` — widoki audytora i przegląd dziennika (tylko odczyt)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S47
    title: "Sloty UI i trasy profili w powłoce"
    phase: 4
    agent: frontend-developer
    tier: T2
    size: M
    depends_on: [S16, S19, S40]
    reads: [AGENTS.md, docs/architecture/13-project-profiles.md, docs/adr/ADR-017-profile-data-actions.md, docs/architecture/11-frontend.md, design/README.md, .opencode/skills/design-system/SKILL.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["frontend/libs/platform/**", "frontend/apps/process-hub/**"]
    specs: ["specs/profiles/project-profiles.feature @FR-27"]
    outcome:
      - "rejestr slotów i leniwe ładowanie tras profili `/p/<id>/` w powłoce"
      - "sloty: panel zadania i sprawy, widżet pulpitu, pole formatki, sekcja nawigacji"
    notes:
      - "`extension-sdk` jest chronione — brak w kontrakcie slotów = RFC"
      - "od tego kroku zależą KRE-03, KRE-04, FLO-04, FLO-05 i AML-02"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"

  - id: S48
    title: "Onboarding zespołów profili: szablon, przewodnik, kwalifikacja agentów profilu, przegląd manifestów"
    phase: 4
    agent: architect
    pair: docs-writer
    pair_task: "pisze przewodnik w `docs/guides/**`; architekt — szablon i przegląd manifestów"
    tier: T1
    size: S
    depends_on: [S38]
    reads: [AGENTS.md, profiles/README.md, docs/architecture/13-project-profiles.md, evals/agents/README.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/_template/**", "profiles/README.md", "docs/guides/**", "evals/agents/**"]
    outcome:
      - "`profiles/_template/**` i `profiles/README.md` zaktualizowane po S38"
      - "przewodnik onboardingu w `docs/guides/`"
      - "przypadek kwalifikacyjny E08 aktualny"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "python3 tools/profiles/validate_profiles.py --check"
      - "python3 tools/agents/render_agents.py --check"
    acceptance:
      - "manifesty profili przejrzane z zespołami kredytów, AML i floty"

  - id: S49
    title: "Komponenty pól formatek w ui-kit wg katalogu pól, katalog komponentów, regresja wizualna i axe"
    phase: 4
    agent: design-system-engineer
    pair: ui-reviewer
    tier: T2
    size: M
    depends_on: [S16, S07, S09]
    reads: [AGENTS.md, docs/artifacts/04-wytyczne-ui.md, design/forms/README.md, design/forms/field-catalog.yaml, design/tokens.json, docs/architecture/11-frontend.md, poc/forms-ui/REPORT.md, .opencode/skills/design-system/SKILL.md]
    writes: ["frontend/libs/core/ui-kit/**", "frontend/libs/core/theming/**", "frontend/apps/ui-catalog/**", "frontend/apps/ui-catalog-e2e/**"]
    specs: ["specs/forms/form-rendering.feature @FR-32"]
    outcome:
      - "komponenty pól `ph-*` w `core/ui-kit` — po jednym na typ z katalogu pól, komplet stanów, oba motywy"
      - "strony w `ui-catalog`, zrzuty regresji wizualnej i testy axe"
    notes:
      - "wzorce zrzutów zatwierdza projektant UX — nie nadpisuj istniejących bez zgody zapisanej w pakiecie"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx affected -t lint test build"
      - "npx nx e2e ui-catalog-e2e"
    acceptance:
      - "projektant UX zatwierdził wzorce regresji wizualnej nowych komponentów"

  # ---------- Faza 5: integracja i hardening ----------
  - id: S50
    title: "Wszystkie @integration zielone na dev; Playwright per rola"
    phase: 5
    agent: bdd-tester
    tier: T2
    size: L
    critical: true
    depends_on: [S06, S32, S33, S38, S39, S40, S41, S42, S43, S44, S45, S46, S47]
    reads: [AGENTS.md, docs/architecture/12-testing-strategy.md, docs/architecture/13-project-profiles.md, docs/architecture/14-form-management.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["tests/**", "frontend/apps/e2e/**"]
    outcome:
      - "wszystkie scenariusze `@integration` zielone na środowisku dev"
      - "ścieżki Playwright per rola i profil w `frontend/apps/e2e`"
    notes:
      - "poprawki kodu produkcyjnego są poza zakresem (`tests/**`, e2e): błąd w module zgłoś w `open_questions` ze wskazaniem kroku, który go naprawi"
      - "niestabilny test = ustalenie do naprawy, nie do pominięcia"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test ProcessHub.sln"
      - "npx nx e2e e2e"

  - id: S51
    title: "Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacja, kompletność audytu, DAST"
    phase: 5
    agent: bdd-tester
    pair: security-reviewer
    pair_task: "wskazuje scenariusze obejść do pokrycia i recenzuje wynik (tylko odczyt)"
    tier: T2
    size: M
    critical: true
    depends_on: [S50]
    reads: [AGENTS.md, docs/architecture/10-audit-and-security.md, docs/architecture/02-roles-and-authorization.md, .opencode/skills/reqnroll-bdd/SKILL.md]
    writes: ["tests/Security.*/**", "docs/security/**"]
    outcome:
      - "`tests/Security.Tests`: macierz autoryzacji przez HTTP, izolacja tenantów i profili, kompletność audytu"
      - "`docs/security/` — wyniki DAST i skanu zależności"
    notes:
      - "testy pisze `bdd-tester`; `security-reviewer` (tylko odczyt) wskazuje scenariusze obejść i ocenia wynik"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test tests/Security.Tests"
    acceptance:
      - "zespół bezpieczeństwa ocenił wyniki DAST i skanu zależności"

  - id: S52
    title: "Wydajność i pojemność"
    phase: 5
    agent: data-engineer
    tier: T2
    size: M
    depends_on: [S50]
    reads: [AGENTS.md, docs/architecture/09-persistence-mssql.md, docs/architecture/08-process-dashboard.md]
    writes: ["tests/Performance/**", "db/**", "docs/perf/**"]
    outcome:
      - "`tests/Performance` — `TaskAccess`, dashboard, opóźnienie projektora, wolumen śladu"
      - "`docs/perf/` — raport z planami zapytań"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "dotnet test tests/Performance --filter Category=integration"

  - id: S53
    title: "Dostępność i UX"
    phase: 5
    agent: frontend-developer
    pair: ui-reviewer
    tier: T2
    size: S
    depends_on: [S50]
    reads: [AGENTS.md, docs/architecture/11-frontend.md, docs/artifacts/04-wytyczne-ui.md, .opencode/skills/design-system/SKILL.md]
    writes: ["frontend/**"]
    outcome:
      - "scenariusze `@a11y` zielone"
      - "poprawki WCAG 2.2 AA w `frontend/**`"
    notes:
      - "S55 pisze w tym samym zakresie — nie prowadź obu kroków równolegle"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx e2e e2e --grep @a11y"
    acceptance:
      - "projektant UX wykonał testy z czytnikiem ekranu i klawiaturą"

  - id: S55
    title: "Zgodność formatek z Camunda Forms i spójność wizualna w CI — zestaw zgodności z form-js, schemat .form, parytet katalogu pól, regresja wizualna"
    phase: 5
    agent: frontend-developer
    pair: ui-reviewer
    tier: T2
    size: S
    depends_on: [S50]
    reads: [AGENTS.md, docs/architecture/12-testing-strategy.md, docs/architecture/14-form-management.md, design/forms/field-catalog.yaml, .opencode/skills/design-system/SKILL.md]
    writes: ["frontend/**", "tests/FormRuntime.*/**", ".pipelines/**"]
    outcome:
      - "zestaw zgodności z form-js, walidacja schematu `.form`, parytet katalogu pól i regresja wizualna uruchamiane w CI (`.pipelines/`)"
    dod:
      - "python3 tools/guard/enforce_write_scope.py --verify-diff main"
      - "npx nx run-many -t test --projects=form-runtime,ui-kit"
      - "npx nx e2e ui-catalog-e2e"
      - "dotnet test tests/FormRuntime.UnitTests"

  - id: S54
    title: "Pentest, compliance, Deklaracja Dostępności"
    phase: 5
    agent: human
    critical: true
    depends_on: [S51, S52, S53, S55]
    writes: ["docs/security/**", "docs/compliance/**"]
    outcome:
      - "`docs/security/pentest-report.md`"
      - "`docs/compliance/deklaracja-dostepnosci.md` i protokół przeglądu compliance"
    dod:
      - "test -f docs/security/pentest-report.md"
      - "test -f docs/compliance/deklaracja-dostepnosci.md"
    acceptance:
      - "raport pentestu bez ustaleń krytycznych i wysokich"
      - "przegląd compliance zaakceptowany (warunek bramki G3)"

  # ---------- Faza 6: pilotaż ----------
  - id: S60
    title: "Pilotaż jednego obszaru; odcięcie użytkowników od webapp Tasklist"
    phase: 6
    gate_before: G3
    agent: human
    critical: true
    depends_on: [S48, S54]
    writes: ["deploy/**"]
    outcome:
      - "pilotaż jednego obszaru (profil `kredyty`) na produkcji"
      - "`deploy/pilot/CHECKLIST.md` — podpisana checklista"
    notes:
      - "plan profilu `kredyty` (KRE-01…KRE-04) musi być ukończony — sprawdź `python3 tools/agents/plan_status.py --backlog profiles/kredyty/backlog.yaml`"
    dod:
      - "test -f deploy/pilot/CHECKLIST.md"
    acceptance:
      - "checklista pilotażu podpisana"
      - "plan profilu `kredyty` ukończony (KRE-01…KRE-04 scalone)"
      - "użytkownicy pilotażu odcięci od webapp Tasklist"
````

## Plik: plan/work-packet-template.md

# Pakiet roboczy — <ID kroku>: <tytuł>

> Generowany przez `tools/agents/prepare_step.py` z `plan/backlog.yaml`. Agent czyta tylko ten plik i pliki z sekcji „Czytaj”. Sekcje bez treści są pomijane.

## Cel
<pole `title`> · wykonawca, para, rozmiar, ścieżka krytyczna

## Wynik (co ma powstać)
<pole `outcome` — pliki, moduły i dowody, po których poznać, że krok jest zrobiony>

## Wskazówki startowe
<pole `notes` — granice z innymi krokami, decyzje D-xx, pułapki>

## Czytaj (w tej kolejności)
1. `AGENTS.md` (i `profiles/<id>/AGENTS.md` dla kroku profilu)
2. <pliki z `reads` — w całości; pilnuj budżetu kontekstu>

## Sięgaj punktowo (wyszukuj fragment, nie czytaj w całości)
<pole `refs` — duże pliki, np. makieta>

## Wejście od poprzedników
<kroki z `depends_on` z tytułem i plikiem przekazania — pytania otwarte i lista zmienionych plików>

## Wolno zapisywać (`.agent-scope`)
<globy z `writes`> oraz zawsze `docs/rfc/RFC-<ID>-<temat>.md`

## Para
<rola pary i jej część pracy: `pair_task` albo domyślna dla roli>

## Scenariusze do zaliczenia
<pliki i tagi z `specs`, np. `specs/tasks/reassignment.feature @FR-11`>

## Kontrakty zależności (tylko do odczytu)
<`*/Contracts` modułów, od których zależy krok>

## Definition of Done
- [ ] <komendy z `dod`> kończą się kodem 0 (pierwsza: bramka zakresu `enforce_write_scope.py --verify-diff main`)
- [ ] brak nowych ostrzeżeń analizatorów
- [ ] każda nowa komenda ma deskryptor audytu; każdy endpoint — politykę autoryzacji
- [ ] `AGENTS.md` modułu lub profilu zaktualizowany (cel, inwarianty, komendy)

## Kryteria akceptacji człowieka (poza bramkami)
<pole `acceptance`>

## Budżet
Próby: 2 · potem jedna sesja od zera z diagnozą recenzenta (albo wyższy wariant rozumowania, jeśli rola go ma) · potem człowiek · zakaz zmian poza `writes`

## Przekazanie
Zatwierdzenie zmian na gałęzi kroku (`git add`, `git commit`, bez `push`), potem ostatnia wiadomość: JSON wg `AGENTS.md` → `plan/progress/<ID>.json` (krok profilu: `profiles/<id>/progress/<ID>.json`)

## Plik: plan/estimation.md

# Szacowanie złożoności i czasochłonności (hybryda AI + ludzie)

**Wynik modelu:** pierwszy obszar biznesowy po pilotażu za ok. **28 tygodni** (P80: 31) przy zespole 6,2 FTE z rojem agentów, wobec ok. **38 tygodni** (P80: 43) dla tego samego zespołu bez AI. Pracy ludzi ubywa o ok. 23% (459 zamiast 597 osobodni). Kalendarz hybrydy wyznacza ścieżka krytyczna, którą wydłużają kroki, w których AI pomaga mało: PoC na nieznanej wersji 8.9, decyzje przy bramkach, pentest i pilotaż; bez AI wąskim gardłem staje się zespół backendu (192 dni robocze). Moduł zarządzania formatkami z warstwą wizualną (v4) dodał 8 kroków i ok. 59 osobodni pracy ludzi, nie zmieniając kalendarza.

To są szacunki z modelu, nie z historii projektu. Po PoC (S01–S04) i pierwszych trzech krokach budowy (S10–S12) trzeba je skalibrować rzeczywistymi danymi — mechanizm jest opisany na końcu. Pełne tabele per krok: `plan/estimation-report.md` (generowany przez `tools/plan/estimate.py`).

## 1. Jak liczymy

Każdy krok ma cztery oceny 1–5 w `plan/estimates.yaml`:

| Wymiar | 1 | 3 | 5 |
| --- | --- | --- | --- |
| **T** — technika | szablon, CRUD | kilka mechanizmów, nietrywialna logika | algorytm, spójność rozproszona, bezpieczeństwo |
| **N** — niepewność | wszystko znane | część do odkrycia | zależne od nieznanego zachowania Camunda 8.9/SDK lub decyzji zewnętrznych |
| **I** — integracje | jeden moduł | 2–3 systemy | Camunda + RHBK + MSSQL + AD + CI naraz |
| **B** — biznes i regulacje | brak decyzji | decyzje zespołu | decyzje biznesu, compliance, formalne akceptacje |

- **Indeks złożoności** C = 0,35·T + 0,30·N + 0,20·I + 0,15·B. Klasy: niska ≤ 2,2 · średnia ≤ 3,0 · wysoka ≤ 3,7 · bardzo wysoka > 3,7.
- **Pracochłonność bez AI**: trzy punkty (optymistyczny, najbardziej prawdopodobny, pesymistyczny) w osobodniach doświadczonego zespołu, średnia PERT.
- **Pracochłonność ludzi w hybrydzie** = bez AI × [(1 − udział AI) + udział AI × koszt przeglądu]. Przykład: szkielet S10 — agenci robią 80% pracy, przegląd kosztuje 25% → ludzie robią 40% pracy bez AI.
- **Narzuty**: nadzór roju 12% (pakiety, eskalacje, scalanie) i koordynacja 10% (dla wariantu bez AI tylko koordynacja).
- **Kalendarz** = większa z dwóch wartości: ścieżka krytyczna (z oczekiwaniem na bramki) albo czas najbardziej obciążonej roli. P80 liczone ostrożnie — ryzyka kroków traktujemy jako skorelowane.

Parametry (wagi, zespół, narzuty, oczekiwanie na bramki) są w `plan/estimation-params.yaml` — zmiana i ponowne uruchomienie skryptu daje nowy raport.

## 2. Najtrudniejsze elementy

Kroki o najwyższym indeksie skupiają się w czterech obszarach. Wspólna cecha: trudność bierze się z niewiadomych i decyzji, a nie z ilości kodu — dlatego tam agenci oszczędzają najmniej.

| Krok | C | Dlaczego trudny | Udział AI | Bez AI → hybryda (osobodni) |
| --- | --- | --- | --- | --- |
| **Camunda 8.9 i oficjalne SDK** | | | | |
| S02 PoC autoryzacji zasobów i tożsamości wywołań | 4,15 | semantyka autoryzacji, token delegowany, decyzja bezpieczeństwa | 35% | 8,7 → 7,1 |
| S23 Projekcja read modelu | 3,85 | kolejność, duplikaty, wznowienie po awarii, katalog elementów z XML | 55% | 18,7 → 13,0 |
| S21 Autoryzacje jako kod (reconciler) | 3,85 | stan docelowy vs faktyczny w Camunda, dryf, rozdział obowiązków | 55% | 12,3 → 8,6 |
| S22 Adaptery SDK + testy kontraktowe | 3,55 | 7 portów, fake i Testcontainers, luki w SDK | 60% | 14,7 → 9,4 |
| S01 PoC oficjalnego SDK | 3,50 | nieznane pokrycie SDK dla 8.9 decyduje o ADR-003 | 40% | 8,5 → 6,8 |
| **Rdzeń bezpieczeństwa** | | | | |
| S24 Access Policy (R1–R11, `TaskAccess`) | 3,65 | reguły widoczności i materializacja — błąd = wyciek danych | 55% | 15,3 → 11,1 |
| S27 Izolacja profili (schemat i użytkownik bazy per profil, widoki `platform_api`) | 3,65 | `EXECUTE AS USER` z pulą połączeń, RLS widoków, R10 — błąd = wyciek danych między projektami | 40% | 9,5 → 8,2 |
| S18 BFF z RHBK (OIDC, ciasteczka, CSRF) | 3,55 | integracja z bankowym IdP, wylogowanie globalne | 50% | 8,2 → 6,1 |
| **Algorytmy domenowe** | | | | |
| S34 Mapa etapów i stan etapów | 3,65 | równoległość, pętle, call activity, wersje mapy; uzgodnienia z biznesem | 60% | 15,3 → 9,8 |
| **Środowisko i organizacja** | | | | |
| S50 Testy integracyjne end-to-end | 3,90 | pierwsze zderzenie całości z prawdziwym środowiskiem, niestabilne testy | 50% | 15,8 → 11,9 |
| S60 Pilotaż | 3,80 | wdrożenie, szkolenia, dual-run, wsparcie — praca ludzi | 10% | 20,8 → 20,8 |
| S06 Środowisko dev w banku | 3,70 | dostępy (AD, sieć, RHBK), procedury — czas zależy od organizacji | 30% | 16,7 → 14,7 |

Poza czołówką warto pilnować **S19 SDK rozszerzeń** (C 3,20, 12,3 → 10,1 osobodni) — publiczny kontrakt dla wszystkich zespołów profili, którego błąd projektu kosztuje każdy zespół — oraz **formatek w interfejsie**: S40 renderer Camunda Forms (C 3,50, 18,5 → 10,7 osobodni) i S45 projektant formatek (C 3,35, 17,7 → 10,8) to największy blok frontendu, a o ich powodzeniu rozstrzygają PoC S07 (C 3,30) i S08 (C 3,15) — i **S12 Building Blocks**: indeks tylko „średni” (2,70), ale każdy błąd w potoku audytu i autoryzacji powiela się w dziesięciu modułach — tu oszczędzanie na przeglądzie jest najdroższe.

## 3. Najprostsze elementy

| Krok | C | Dlaczego prosty | Udział AI | Oszczędność pracy ludzi |
| --- | --- | --- | --- | --- |
| S41 Start procesu i moje procesy (UI) | 1,50 | formularze i listy na gotowym API i makiecie | 80% | 60% |
| S46 Widoki audytora (UI) | 1,50 | tabele tylko do odczytu | 80% | 60% |
| S10 Szkielet rozwiązania | 1,55 | powtarzalny układ modułów z szablonu | 80% | 60% |
| S17 Wtyczka bpmnlint i przykładowe BPMN | 1,65 | małe, dobrze określone reguły | 75% | 53% |
| S43 Przekazywanie i zastępstwa (UI) | 1,85 | okna dialogowe i kreator na gotowych komendach | 75% | 56% |
| S11 Testy architektury i bramki CI | 1,85 | reguły deklaratywne | 75% | 53% |

To kandydaci na pierwsze pakiety pilotażowe roju i na niższy wariant rozumowania modelu (`config/models.yaml`) — ryzyko jest małe, a wynik łatwo zweryfikować bramkami. Równie prosty jest S48 (onboarding zespołów profili, C 1,60), ale to głównie praca ludzi.

## 4. Gdzie AI daje najwięcej, a gdzie najmniej

| Faza | Bez AI (osobodni) | Hybryda (osobodni) | Oszczędność | Okno w harmonogramie (tydzień) |
| --- | --- | --- | --- | --- |
| 0 — przygotowanie i PoC (w tym PoC formatek i warstwa wizualna) | 78 | 64 | 19% | 1 – 3,5 |
| 1 — fundament (w tym SDK rozszerzeń, motyw i ui-kit) | 77 | 48 | 37% | 3 – 8 |
| 2 — dostęp, Camunda, audyt, formatki, izolacja profili | 112 | 76 | 32% | 7 – 12 |
| 3 — funkcje rdzenia, Form Runtime i operacje profili | 96 | 61 | 36% | 9 – 15,5 |
| 4 — frontend funkcjonalny, komponenty pól, sloty profili, onboarding zespołów | 99 | 56 | 43% | 8 – 16 |
| 5 — integracja i hardening (w tym zgodność formatek) | 61 | 51 | 17% | 17 – 22,5 |
| 6 — pilotaż | 21 | 21 | 0% | 23 – 28 |

Okna to najwcześniejsze możliwe terminy wg zależności (bez dat kalendarzowych). Fazy 3 i 4 zaczynają się w tygodniu 9, bo część kroków (formatki, UI na mockach) nie czeka na ścieżkę krytyczną.

## 5. Ścieżka krytyczna i co ją skraca

S00 → S01 → S02 → **G0** → S10 → S12 → S15 → **G1** → S22 → S23 → S24 → S30 → **G2** → S34 → S36 → S42 → S50 → S51 → S54 → **G3** → S60

Najdłużej trwa wgląd menadżera (mapa etapów → dashboard → jego UI), a nie skrzynka zadań. Wrażliwość modelu:

| Scenariusz | Praca ludzi (osobodni) | Kalendarz | P80 |
| --- | --- | --- | --- |
| Bazowy | 459 | 27,6 tyg. | 30,8 tyg. |
| A: agenci słabsi (udział AI −20 pkt, np. słabsze wyniki kwalifikacji GLM) | 529 | 30,3 tyg. | 33,9 tyg. |
| B: droższy przegląd (+15 pkt) | 512 | 29,6 tyg. | 33,1 tyg. |
| C: wolne procedury banku (bramki ×2, środowisko i pentest pesymistycznie) | 475 | 32,5 tyg. | 36,3 tyg. |
| D: większy zespół (+1 backend, PO 0,75, bezpieczeństwo 0,3) | 459 | 27,6 tyg. | 30,8 tyg. |
| E: dwie osoby na krokach ścieżki krytycznej (podział na podpakiety) | 459 | 25,6 tyg. | 28,7 tyg. |

Wnioski:

- **Dokładanie ludzi ogólnie nie skraca projektu** (D) — ogranicza go ścieżka krytyczna, nie liczba rąk.
- **Kroki profili nie leżą na ścieżce krytycznej** (S19, S27, S38, S47, S48 mają zapas 1–8 tygodni): zwiększają pracę ludzi o ok. 39 osobodni, ale nie wydłużają kalendarza — pod warunkiem, że backend (najbardziej obciążona rola, 128 dni) nie zostanie dodatkowo obciążony.
- **Moduł formatek jest drugą ścieżką do pilnowania.** Łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma tylko ok. 2,6 dnia zapasu: poślizg PoC (S07, S08), decyzji o warstwie wizualnej (S09) albo renderera przesuwa testy end-to-end. Moduł dokłada też pracy backendowi (S08, S26, S29, S37, S39): jego obciążenie rośnie ze 114 do 128 dni roboczych i to ono — a nie ścieżka krytyczna (22,4 tyg. po podziale kroków) — ogranicza scenariusz E do 25,6 tygodnia zamiast wcześniejszych 22,8.
- **Najsilniejsza dźwignia to dzielenie kroków ścieżki krytycznej** (S23, S24, S34, S36) na podpakiety wykonywane równolegle przez dwie osoby z agentami (E: około −2 tygodnie; dalej ogranicza już obciążenie backendu — podział kroków razem z dodatkową osobą w backendzie daje ok. 24,8 tyg.). Orkiestrator może to zrobić bez zmiany architektury, bo kontrakty są zamrożone od G1.
- **Największe ryzyko zewnętrzne to procedury banku** (C: około +5 tygodni). Środowisko (S06), decyzje G0 i termin pentestu warto uruchomić w pierwszym tygodniu, równolegle do PoC.
- **Jakość modeli ma umiarkowany wpływ na kalendarz** (A: około +3 tygodnie), ale wyraźny na koszt pracy ludzi (+61 osobodni). Kwalifikacja z `evals/agents` chroni przed tym scenariuszem.
- **Role bliskie przeciążenia:** backend (128 dni), architekt (124), PO/analityk (0,5 FTE, 116) i bezpieczeństwo (0,2 FTE, 106) mają obciążenie zbliżone do długości ścieżki krytycznej (138 dni). Projektant UX (0,5 FTE, 37 dni) ma zapas, ale jego praca skupia się na początku (S09) i przy komponentach pól (S49). Każde opóźnienie decyzji z ich strony przesuwa projekt, więc dostępność tych osób trzeba zarezerwować z góry.

## 6. Czego model nie obejmuje

- Utrzymania po pilotażu i wdrażania kolejnych obszarów biznesowych (każdy kolejny obszar to głównie konfiguracja: autoryzacje, mapy etapów, formatki).
- Pracy zespołów profili nad częścią specyficzną (`profiles/<id>/backlog.yaml`) — wycenia ją każdy zespół projektu; plan platformy obejmuje SDK, izolację, sloty UI i onboarding (S19, S27, S38, S47, S48).
- Środowisk test i prod, procesu zakupu licencji Kendo i infrastruktury modelu GLM w banku.
- Kosztu tokenów — zmierzymy go na krokach S10–S12 i dopiszemy do raportu.
- Materiałów szkoleniowych i zmian organizacyjnych poza pilotażem.
- Urlopy i prace utrzymaniowe uwzględnia tylko globalnie wykorzystanie zespołu na poziomie 75%.

## 7. Kalibracja w trakcie prac

1. Po każdym kroku Orkiestrator (lub tech lead) zapisuje `plan/progress/<krok>.effort.json`: `{"step": "S10", "actual_human_pd": 3.5}`.
2. `python3 tools/plan/estimate.py` liczy współczynnik k = średnia(rzeczywistość / szacunek) i stosuje go do pozostałych kroków; zakończone kroki wchodzą do sumy z wartością rzeczywistą.
3. Po PoC (S01–S04) zespół aktualizuje oceny **N** w `plan/estimates.yaml` — niepewność Camunda i SDK spada albo rośnie, co zmienia pracochłonność S21–S23 i S33.
4. Raport `plan/estimation-report.md` jest generowany i sprawdzany w CI (`estimate.py --check`), więc plan i liczby nie rozjadą się w repozytorium.

## Plik: plan/estimation-report.md

<!-- WYGENEROWANE przez tools/plan/estimate.py — nie edytuj ręcznie -->
# Raport szacowania (generowany)

Kalibracja: brak danych rzeczywistych, k = 1,0. Zespół referencyjny: 6,2 FTE, wykorzystanie 75%. P80 liczone ostrożnie: odchylenia kroków sumowane liniowo (ryzyka skorelowane).

## Podsumowanie

| Wielkość | Bez AI: oczekiwane | Bez AI: P80 | Hybryda: oczekiwane | Hybryda: P80 |
| --- | --- | --- | --- | --- |
| Praca ludzi w krokach (osobodni) | 543 | 608 | 376 | 422 |
| Praca ludzi z narzutami (osobodni) | 597 | 669 | 459 | 515 |
| Ścieżka krytyczna z bramkami (dni robocze) | 177 | 197 | 138 | 154 |
| Najbardziej obciążona rola (dni robocze) | 192 (Backend .NET) | — | 128 (Backend .NET) | — |
| **Czas kalendarzowy** (większa z dwóch powyższych) | **38 tyg.** | **43 tyg.** | **28 tyg.** | **31 tyg.** |

Narzuty: hybryda = nadzór roju + koordynacja; bez AI = koordynacja. Czas pracy agentów nie jest wąskim gardłem — ogranicza go przegląd i decyzje ludzi.

## Kroki

| Krok | Tytuł | C | Klasa | T/N/I/B | AI | Bez AI (od) | Hybryda (od) | Oszczędność | Dni kal. | Ścieżka kryt. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S00 | Repozytorium, harness agentów, skrypt worktree, pusty pipeline CI | 1,85 | niska | 2/2/2/1 | 30% | 3,2 | 2,7 | 15% | 2,7 | tak |
| S01 | PoC oficjalnego SDK Camunda na 8.9 (lista kontrolna) | 3,50 | wysoka | 3/5/4/1 | 40% | 8,5 | 6,8 | 20% | 6,8 | tak |
| S02 | PoC autoryzacji zasobów, roli audytora i tożsamości wywołań | 4,15 | bardzo wysoka | 4/5/4/3 | 35% | 8,7 | 7,1 | 18% | 7,1 | tak |
| S03 | PoC task listenera zastępstw (korekty, czas odpowiedzi, fail-open) | 3,00 | średnia | 3/4/3/1 | 50% | 4,2 | 2,9 | 30% | 2,9 |  |
| S04 | PoC zasilania read modelu (wyszukiwanie przyrostowe vs eksporter) | 3,00 | średnia | 3/4/3/1 | 50% | 5,3 | 3,7 | 30% | 3,7 |  |
| S05 | Przegląd scenariuszy z biznesem, decyzje D-01..D-07 | 2,20 | niska | 1/3/1/5 | 40% | 8,7 | 7,3 | 16% | 7,3 |  |
| S06 | Środowisko dev — Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, | 3,70 | wysoka | 3/4/5/3 | 30% | 16,7 | 14,7 | 12% | 9,8 |  |
| S07 | PoC formatek w UI — edytor form-js w Angularze, renderer na design sys | 3,30 | wysoka | 4/4/2/2 | 50% | 8,3 | 6,0 | 28% | 6,0 |  |
| S08 | PoC walidacji formatek na serwerze — reguły schematu w .NET, ewaluacja | 3,15 | wysoka | 3/4/3/2 | 50% | 5,3 | 3,9 | 28% | 3,9 |  |
| S09 | Warstwa wizualna — biblioteka w Figma, tokeny, katalog pól i specyfika | 2,40 | średnia | 2/3/1/4 | 30% | 9,5 | 8,4 | 12% | 8,4 |  |
| S10 | Szkielet rozwiązania, Host z rolami, szablon dotnet new ph-module | 1,55 | niska | 2/1/2/1 | 80% | 4,2 | 1,7 | 60% | 7,2 | tak |
| S11 | Testy architektury i bramki CI | 1,85 | niska | 2/2/2/1 | 75% | 3,2 | 1,5 | 53% | 1,5 |  |
| S12 | Building Blocks — potok, Actor, ITenantContext, Permission, middleware | 2,70 | średnia | 4/2/2/2 | 65% | 12,3 | 7,5 | 39% | 5,0 | tak |
| S13 | MSSQL — schematy, RLS, Ledger, partycje śladu, temporal, fixture Testc | 2,65 | średnia | 3/3/2/2 | 60% | 7,3 | 4,7 | 36% | 4,7 |  |
| S14 | Harness Reqnroll — projekty Specs, drivery, świat testowy, asercje | 2,20 | niska | 3/2/2/1 | 70% | 6,2 | 3,1 | 49% | 3,1 |  |
| S15 | Kontrakty v1 wszystkich modułów i OpenAPI v1 | 3,35 | wysoka | 4/3/3/3 | 55% | 9,3 | 6,8 | 28% | 4,5 | tak |
| S16 | Frontend — Nx, shell, motyw z tokenów (core/theming), ui-kit, katalog  | 2,20 | niska | 3/2/2/1 | 70% | 10,3 | 5,3 | 49% | 7,4 |  |
| S17 | Wtyczka bpmnlint ph i procesy BPMN świata testowego | 1,65 | niska | 2/2/1/1 | 75% | 3,2 | 1,5 | 53% | 7,0 |  |
| S18 | BFF — OIDC z RHBK, ciasteczko __Host-, CSRF, wylogowanie | 3,55 | wysoka | 4/3/4/3 | 50% | 8,2 | 6,1 | 25% | 6,1 |  |
| S19 | SDK rozszerzeń i rejestr profili — manifesty, walidacja, kompozycja mo | 3,20 | wysoka | 4/3/3/2 | 45% | 12,3 | 10,1 | 18% | 6,7 |  |
| S20 | Party & Accountability — Actor z tokenu, migawka grup, Absence | 2,50 | średnia | 3/2/2/3 | 70% | 7,2 | 3,9 | 45% | 6,1 |  |
| S21 | Autoryzacje jako kod — loader YAML, walidacja R7/readOnly, reconciler | 3,85 | bardzo wysoka | 4/4/4/3 | 55% | 12,3 | 8,6 | 30% | 10,8 |  |
| S22 | Adaptery oficjalnego SDK dla wszystkich portów, fake, testy kontraktow | 3,55 | wysoka | 4/4/4/1 | 60% | 14,7 | 9,4 | 36% | 8,4 | tak |
| S23 | Projekcja — instancje, zadania, odwiedziny elementów, incydenty, katal | 3,85 | bardzo wysoka | 5/4/3/2 | 55% | 18,7 | 13,0 | 30% | 8,7 | tak |
| S24 | Access Policy — uprawnienia efektywne, R1–R11, TaskAccess, generowana  | 3,65 | wysoka | 5/3/2/4 | 55% | 15,3 | 11,1 | 28% | 7,4 | tak |
| S25 | Audyt — dziennik dwufazowy, uzgadnianie, API przeglądu, test kompletno | 3,00 | średnia | 4/2/2/4 | 60% | 10,3 | 6,9 | 33% | 9,1 |  |
| S26 | Form Management — formatki Camunda Forms, cykl życia wersji, R8, R11,  | 3,00 | średnia | 4/2/2/4 | 65% | 14,3 | 8,7 | 39% | 8,0 |  |
| S27 | Izolacja profili — schemat i użytkownik bazy per profil, widoki platfo | 3,65 | wysoka | 4/4/3/3 | 40% | 9,5 | 8,2 | 14% | 8,2 |  |
| S28 | Schemat form — wersje, przeglądy, wycofania, unikalność i klucze per p | 1,80 | niska | 2/2/1/2 | 70% | 3,2 | 1,7 | 45% | 3,9 |  |
| S29 | Powiązania formatek z procesem — referencje ph:form i kontrakt danych  | 2,85 | średnia | 3/3/3/2 | 60% | 6,2 | 3,9 | 36% | 3,9 |  |
| S30 | Task Work — przejęcie, zwolnienie, szkic, zakończenie, idempotencja | 3,35 | wysoka | 4/3/3/3 | 60% | 12,3 | 7,9 | 36% | 5,3 | tak |
| S31 | Process Lifecycle — katalog startowy, start, moje procesy | 2,35 | średnia | 3/2/2/2 | 70% | 6,2 | 3,4 | 45% | 4,7 |  |
| S32 | Przekazywanie — osoba, grupa, partia z wznowieniem | 3,15 | wysoka | 4/3/2/3 | 60% | 9,3 | 6,0 | 36% | 7,3 |  |
| S33 | Zastępstwa — worker task listenera (fail-open), uzgadnianie | 3,50 | wysoka | 4/4/3/2 | 55% | 8,2 | 5,7 | 30% | 5,7 |  |
| S34 | Mapa etapów — agregat, API edytora, dziedziczenie wersji, algorytm sta | 3,65 | wysoka | 5/3/2/4 | 60% | 15,3 | 9,8 | 36% | 7,9 | tak |
| S35 | Eskalacje — wykrywanie, zakres, lista, kategoria po terminie | 2,80 | średnia | 3/3/2/3 | 65% | 6,2 | 3,6 | 42% | 3,6 |  |
| S36 | Dashboard — agregaty, IProcessMetric, progi zdrowia, świeżość | 3,30 | wysoka | 4/3/2/4 | 60% | 12,3 | 7,9 | 36% | 5,3 | tak |
| S37 | Form Runtime — schemat przypiętej wersji, walidacja danych na serwerze | 3,35 | wysoka | 4/3/3/3 | 60% | 10,3 | 6,6 | 36% | 8,8 |  |
| S38 | Potok operacji profili (zadanie, sprawa, dane profilu), wzbogacenia i  | 2,85 | średnia | 3/3/3/2 | 55% | 9,2 | 6,6 | 28% | 6,6 |  |
| S39 | Wycofanie formatek w toku — przepięcie zadań (saga ze wznowieniem), za | 2,85 | średnia | 4/2/2/3 | 60% | 6,2 | 3,9 | 36% | 3,9 |  |
| S40 | Skrzynka zadań i renderer formatek Camunda Forms (interpretacja schema | 3,50 | wysoka | 5/3/2/3 | 65% | 18,5 | 10,7 | 42% | 7,1 |  |
| S41 | Start procesu i moje procesy | 1,50 | niska | 2/1/1/2 | 80% | 5,3 | 2,1 | 60% | 2,1 |  |
| S42 | Dashboard, eskalacje, instancja z mapą etapów | 2,30 | średnia | 3/2/1/3 | 70% | 11,3 | 5,8 | 49% | 3,9 | tak |
| S43 | Przekazywanie pojedyncze i masowe, zastępstwa | 1,85 | niska | 3/1/1/2 | 75% | 7,2 | 3,1 | 56% | 3,1 |  |
| S44 | Edytor mapy etapów (bpmn-js viewer) | 3,15 | wysoka | 4/3/2/3 | 60% | 11,3 | 6,9 | 39% | 6,9 |  |
| S45 | Projektant formatek — osadzony edytor form-js z paletą z katalogu pól, | 3,35 | wysoka | 4/3/3/3 | 60% | 17,7 | 10,8 | 39% | 7,2 |  |
| S46 | Widoki audytora i przegląd audytu | 1,50 | niska | 2/1/1/2 | 80% | 4,2 | 1,7 | 60% | 1,7 |  |
| S47 | Sloty UI i trasy profili w powłoce | 2,35 | średnia | 3/2/2/2 | 65% | 7,3 | 4,7 | 36% | 4,7 |  |
| S48 | Onboarding zespołów profili: szablon, przewodnik, kwalifikacja agentów | 1,60 | niska | 1/2/1/3 | 50% | 4,0 | 2,8 | 30% | 2,8 |  |
| S49 | Komponenty pól formatek w ui-kit wg katalogu pól, katalog komponentów, | 2,30 | średnia | 3/2/1/3 | 65% | 12,3 | 7,5 | 39% | 7,5 |  |
| S50 | Wszystkie @integration zielone na dev; Playwright per rola | 3,90 | bardzo wysoka | 4/4/5/2 | 50% | 15,8 | 11,9 | 25% | 7,9 | tak |
| S51 | Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacja, kompletność  | 3,50 | wysoka | 4/3/3/4 | 45% | 9,3 | 7,7 | 18% | 7,7 | tak |
| S52 | Wydajność i pojemność | 3,50 | wysoka | 4/4/3/2 | 45% | 8,5 | 6,8 | 20% | 6,8 |  |
| S53 | Dostępność i UX | 1,95 | niska | 2/2/1/3 | 40% | 6,3 | 5,3 | 16% | 5,3 |  |
| S54 | Pentest, compliance, Deklaracja Dostępności | 3,40 | wysoka | 3/4/2/5 | 10% | 15,8 | 15,8 | 0% | 15,8 | tak |
| S55 | Zgodność formatek z Camunda Forms i spójność wizualna w CI — zestaw zg | 2,65 | średnia | 3/3/2/2 | 60% | 5,2 | 3,3 | 36% | 3,3 |  |
| S60 | Pilotaż jednego obszaru; odcięcie użytkowników od webapp Tasklist | 3,80 | bardzo wysoka | 3/4/4/5 | 10% | 20,8 | 20,8 | 0% | 26,3 | tak |

## Fazy

| Faza | Bez AI (od) | Hybryda (od) | Oszczędność |
| --- | --- | --- | --- |
| 0 | 78,3 | 63,5 | 19% |
| 1 | 76,5 | 48,3 | 37% |
| 2 | 111,7 | 75,5 | 32% |
| 3 | 95,5 | 61,4 | 36% |
| 4 | 99,2 | 56,1 | 43% |
| 5 | 61,0 | 50,8 | 17% |
| 6 | 20,8 | 20,8 | 0% |

## Obciążenie ról (z narzutami)

| Rola | FTE | Praca (od) | Dni robocze przy wykorzystaniu |
| --- | --- | --- | --- |
| Backend .NET | 2,0 | 191,9 | 128 |
| Architekt / tech lead | 1,0 | 92,9 | 124 |
| PO / analityk | 0,5 | 43,5 | 116 |
| Bezpieczeństwo | 0,2 | 15,9 | 106 |
| Frontend Angular | 1,0 | 66,2 | 88 |
| DevOps | 0,5 | 22,1 | 59 |
| Projektant UX | 0,5 | 14,0 | 37 |
| QA / BDD | 0,5 | 12,8 | 34 |

## Ścieżka krytyczna

S00 → S01 → S02 → S10 → S12 → S15 → S22 → S23 → S24 → S30 → S34 → S36 → S42 → S50 → S51 → S54 → S60

## Ranking złożoności

| Miejsce | Krok | C | Główny czynnik |
| --- | --- | --- | --- |
| 1 | S02 PoC autoryzacji zasobów, roli audytora i tożsamości wyw | 4,15 | semantyka autoryzacji zasobów i token delegowany; decyzja bezpieczeństwa |
| 2 | S50 Wszystkie @integration zielone na dev; Playwright per r | 3,90 | pierwsze spotkanie wszystkiego z prawdziwym środowiskiem; niestabilne testy |
| 3 | S23 Projekcja — instancje, zadania, odwiedziny elementów, i | 3,85 | spójność ostateczna: kolejność, duplikaty, wznowienie, katalog z XML |
| 4 | S21 Autoryzacje jako kod — loader YAML, walidacja R7/readOn | 3,85 | reconciler stanu docelowego autoryzacji, dryf, rozdział obowiązków |
| 5 | S60 Pilotaż jednego obszaru; odcięcie użytkowników od webap | 3,80 | wdrożenie, szkolenia, praca równoległa z Tasklist, wsparcie użytkowników |
| 6 | S06 Środowisko dev — Camunda 8.9 na K8s, realm RHBK z feder | 3,70 | dostępy w banku (AD, sieć, RHBK, rejestry), Camunda na K8s; czas zależy od procedur |
| 7 | S24 Access Policy — uprawnienia efektywne, R1–R11, TaskAcce | 3,65 | reguły R1–R11 i materializacja widoczności — serce bezpieczeństwa |
| 8 | S27 Izolacja profili — schemat i użytkownik bazy per profil | 3,65 | EXECUTE AS USER w transakcji z pulą połączeń, RLS widoków platform_api, reguły R10 w reconcilerze — bezpieczeństwo danych |
| 9 | S34 Mapa etapów — agregat, API edytora, dziedziczenie wersj | 3,65 | algorytm stanu etapów (równoległość, pętle, call activity), wersje mapy |
| 10 | S18 BFF — OIDC z RHBK, ciasteczko __Host-, CSRF, wylogowani | 3,55 | OIDC z RHBK, ciasteczka, CSRF, wylogowanie globalne — bezpieczeństwo |
| 11 | S22 Adaptery oficjalnego SDK dla wszystkich portów, fake, t | 3,55 | 7 portów na SDK (w tym ewaluacja wyrażeń) + fake + testy kontraktowe na Testcontainers |
| 12 | S01 PoC oficjalnego SDK Camunda na 8.9 (lista kontrolna) | 3,50 | pokrycie oficjalnego SDK dla 8.9 nieznane; wynik decyduje o ADR-003 |
| 13 | S33 Zastępstwa — worker task listenera (fail-open), uzgadni | 3,50 | worker na ścieżce silnika; fail-open i uzgadnianie |
| 14 | S40 Skrzynka zadań i renderer formatek Camunda Forms (inter | 3,50 | skrzynka zadań i własny renderer Camunda Forms (FEEL, układ, listy powtarzane) — najczęściej używany ekran |
| 15 | S51 Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacj | 3,50 | macierz obejść, izolacja, DAST — wyniki wymagają oceny człowieka |
| 16 | S52 Wydajność i pojemność | 3,50 | wolumeny, plany zapytań, opóźnienie projektora |
| 17 | S54 Pentest, compliance, Deklaracja Dostępności | 3,40 | zewnętrzny pentest i formalne akceptacje |
| 18 | S15 Kontrakty v1 wszystkich modułów i OpenAPI v1 | 3,35 | decyzje projektowe dla 10 modułów naraz; pomyłka kosztuje RFC później |
| 19 | S30 Task Work — przejęcie, zwolnienie, szkic, zakończenie,  | 3,35 | pierwsza pełna ścieżka przez potok, SDK i read model; wyścigi przejęcia |
| 20 | S37 Form Runtime — schemat przypiętej wersji, walidacja dan | 3,35 | walidacja schematu Camunda Forms na serwerze, FEEL przez silnik, przypięcie wersji — błąd przepuszcza złe dane do procesu |
| 21 | S45 Projektant formatek — osadzony edytor form-js z paletą  | 3,35 | osadzenie edytora form-js i ograniczenie go do katalogu pól, porównanie wersji, wycofanie, import i eksport, podgląd |
| 22 | S07 PoC formatek w UI — edytor form-js w Angularze, rendere | 3,30 | edytor form-js (Preact) w Angularze, własny renderer kontra viewer, pomiar rozbieżności zachowania |
| 23 | S36 Dashboard — agregaty, IProcessMetric, progi zdrowia, św | 3,30 | definicje metryk uzgadniane z biznesem, agregaty, percentyle |
| 24 | S19 SDK rozszerzeń i rejestr profili — manifesty, walidacja | 3,20 | nowy publiczny kontrakt SDK — błąd projektu kosztuje wszystkie zespoły profili |
| 25 | S08 PoC walidacji formatek na serwerze — reguły schematu w  | 3,15 | endpoint ewaluacji wyrażeń 8.9 przez SDK, różnice FEEL przeglądarka–silnik, wariant zapasowy |
| 26 | S32 Przekazywanie — osoba, grupa, partia z wznowieniem | 3,15 | saga partii z wznowieniem; przekazanie osobie i grupie |
| 27 | S44 Edytor mapy etapów (bpmn-js viewer) | 3,15 | bpmn-js, interakcja na diagramie, walidacja mapy |
| 28 | S03 PoC task listenera zastępstw (korekty, czas odpowiedzi, | 3,00 | korekty w task listenerze i fail-open do potwierdzenia na 8.9 |
| 29 | S04 PoC zasilania read modelu (wyszukiwanie przyrostowe vs  | 3,00 | pomiar opóźnienia i kompletności zasilania read modelu |
| 30 | S25 Audyt — dziennik dwufazowy, uzgadnianie, API przeglądu, | 3,00 | audyt dwufazowy, uzgadnianie, test kompletności; wymogi compliance |
| 31 | S26 Form Management — formatki Camunda Forms, cykl życia we | 3,00 | maszyna stanów wersji, cztery oczy, wycofanie z wersją zastępczą, separacja per proces, walidacja katalogu i kontraktu |
| 32 | S29 Powiązania formatek z procesem — referencje ph:form i k | 2,85 | referencje i kontrakt z katalogu elementów per wersja definicji, kontrola spójności, reguła bpmnlint |
| 33 | S38 Potok operacji profili (zadanie, sprawa, dane profilu), | 2,85 | potok operacji używa istniejących zachowań; ryzyko w limitach czasu, idempotencji i izolacji awarii profilu |
| 34 | S39 Wycofanie formatek w toku — przepięcie zadań (saga ze w | 2,85 | saga przepięcia zadań ze wznowieniem, przeniesienie szkicu danych, zadania bez formatki |
| 35 | S35 Eskalacje — wykrywanie, zakres, lista, kategoria po ter | 2,80 | wykrywanie eskalacji i ich zakresu |
| 36 | S12 Building Blocks — potok, Actor, ITenantContext, Permiss | 2,70 | fundament: potok, audyt, outbox, lease — błąd tu powiela się w każdym module |
| 37 | S13 MSSQL — schematy, RLS, Ledger, partycje śladu, temporal | 2,65 | RLS, Ledger, partycje; uprawnienia DBA w banku |
| 38 | S55 Zgodność formatek z Camunda Forms i spójność wizualna w | 2,65 | zestaw zgodności z form-js i regresja wizualna w CI; niestabilne zrzuty |
| 39 | S20 Party & Accountability — Actor z tokenu, migawka grup,  | 2,50 | model Party, przypisania ról, nieobecności z regułami czasowymi |
| 40 | S09 Warstwa wizualna — biblioteka w Figma, tokeny, katalog  | 2,40 | biblioteka w Figma, księga znaku banku, uzgodnienie katalogu pól — głównie praca projektanta UX |
| 41 | S31 Process Lifecycle — katalog startowy, start, moje proce | 2,35 | start z formatką i zmiennymi inicjatora |
| 42 | S47 Sloty UI i trasy profili w powłoce | 2,35 | rejestr slotów i leniwe ładowanie — znany wzorzec; ryzyko w granicach Nx i widoczności slotów |
| 43 | S42 Dashboard, eskalacje, instancja z mapą etapów | 2,30 | wykresy, wstęga etapów, dostępność wykresów |
| 44 | S49 Komponenty pól formatek w ui-kit wg katalogu pól, katal | 2,30 | komponenty pól w kompletach stanów, oba motywy, regresja wizualna i axe; wzorce zatwierdza projektant UX |
| 45 | S05 Przegląd scenariuszy z biznesem, decyzje D-01..D-07 | 2,20 | warsztaty z biznesem i decyzje D-01..D-07; tempo zależy od dostępności ludzi |
| 46 | S14 Harness Reqnroll — projekty Specs, drivery, świat testo | 2,20 | Reqnroll z dwoma driverami i wspólnym światem testowym |
| 47 | S16 Frontend — Nx, shell, motyw z tokenów (core/theming), u | 2,20 | Nx, Kendo (licencja, prywatny rejestr), motyw z tokenów, katalog komponentów, mock server |
| 48 | S53 Dostępność i UX | 1,95 | testy z czytnikiem ekranu i klawiaturą to praca człowieka |
| 49 | S00 Repozytorium, harness agentów, skrypt worktree, pusty p | 1,85 | CI, sekrety, worktree i hooki — głównie konfiguracja człowieka |
| 50 | S11 Testy architektury i bramki CI | 1,85 | reguły architektury i pipeline; specyfika CI banku |
| 51 | S43 Przekazywanie pojedyncze i masowe, zastępstwa | 1,85 | okna przekazania i kreator partii |
| 52 | S28 Schemat form — wersje, przeglądy, wycofania, unikalność | 1,80 | tabele wersji i wycofań, indeksy filtrowane, klucz obcy przypięcia z procesem |
| 53 | S17 Wtyczka bpmnlint ph i procesy BPMN świata testowego | 1,65 | wtyczka bpmnlint i przykładowe modele |
| 54 | S48 Onboarding zespołów profili: szablon, przewodnik, kwali | 1,60 | przewodnik, szablon i przegląd manifestów z zespołami — głównie praca ludzi |
| 55 | S10 Szkielet rozwiązania, Host z rolami, szablon dotnet new | 1,55 | szablonowy szkielet — agenci robią to dobrze |
| 56 | S41 Start procesu i moje procesy | 1,50 | proste formularze i listy |
| 57 | S46 Widoki audytora i przegląd audytu | 1,50 | tabele tylko do odczytu |

## Plik: plan/estimates.yaml

````yaml
# Szacunki złożoności i pracochłonności kroków planu (łączone z backlog.yaml po id).
# Skale 1–5: T technika · N niepewność · I integracje · B wymagania biznesowe/regulacyjne.
# ai_share: część pracy wytwórczej (kod, testy, dokumenty), którą robią agenci.
# review: czas człowieka na weryfikację jednostki pracy agenta względem zrobienia jej samodzielnie.
# trad_pd: [optymistycznie, najbardziej prawdopodobnie, pesymistycznie] w osobodniach zespołu bez AI.
# Metoda i kalibracja: plan/estimation.md. Raport liczy: python3 tools/plan/estimate.py
version: 1
steps:
  S00: {T: 2, N: 2, I: 2, B: 1, ai_share: 0.30, review: 0.50, trad_pd: [2, 3, 5],    driver: "CI, sekrety, worktree i hooki — głównie konfiguracja człowieka"}
  S06: {T: 3, N: 4, I: 5, B: 3, ai_share: 0.30, review: 0.60, trad_pd: [10, 15, 30], driver: "dostępy w banku (AD, sieć, RHBK, rejestry), Camunda na K8s; czas zależy od procedur"}
  S01: {T: 3, N: 5, I: 4, B: 1, ai_share: 0.40, review: 0.50, trad_pd: [5, 8, 14],   driver: "pokrycie oficjalnego SDK dla 8.9 nieznane; wynik decyduje o ADR-003"}
  S02: {T: 4, N: 5, I: 4, B: 3, ai_share: 0.35, review: 0.50, trad_pd: [5, 8, 15],   driver: "semantyka autoryzacji zasobów i token delegowany; decyzja bezpieczeństwa"}
  S03: {T: 3, N: 4, I: 3, B: 1, ai_share: 0.50, review: 0.40, trad_pd: [2, 4, 7],    driver: "korekty w task listenerze i fail-open do potwierdzenia na 8.9"}
  S04: {T: 3, N: 4, I: 3, B: 1, ai_share: 0.50, review: 0.40, trad_pd: [3, 5, 9],    driver: "pomiar opóźnienia i kompletności zasilania read modelu"}
  S05: {T: 1, N: 3, I: 1, B: 5, ai_share: 0.40, review: 0.60, trad_pd: [5, 8, 15],   driver: "warsztaty z biznesem i decyzje D-01..D-07; tempo zależy od dostępności ludzi"}
  S07: {T: 4, N: 4, I: 2, B: 2, ai_share: 0.50, review: 0.45, trad_pd: [5, 8, 13],   driver: "edytor form-js (Preact) w Angularze, własny renderer kontra viewer, pomiar rozbieżności zachowania"}
  S08: {T: 3, N: 4, I: 3, B: 2, ai_share: 0.50, review: 0.45, trad_pd: [3, 5, 9],    driver: "endpoint ewaluacji wyrażeń 8.9 przez SDK, różnice FEEL przeglądarka–silnik, wariant zapasowy"}
  S09: {T: 2, N: 3, I: 1, B: 4, ai_share: 0.30, review: 0.60, trad_pd: [6, 9, 15],   driver: "biblioteka w Figma, księga znaku banku, uzgodnienie katalogu pól — głównie praca projektanta UX"}
  S10: {T: 2, N: 1, I: 2, B: 1, ai_share: 0.80, review: 0.25, trad_pd: [3, 4, 6],    driver: "szablonowy szkielet — agenci robią to dobrze"}
  S11: {T: 2, N: 2, I: 2, B: 1, ai_share: 0.75, review: 0.30, trad_pd: [2, 3, 5],    driver: "reguły architektury i pipeline; specyfika CI banku"}
  S12: {T: 4, N: 2, I: 2, B: 2, ai_share: 0.65, review: 0.40, trad_pd: [8, 12, 18],  driver: "fundament: potok, audyt, outbox, lease — błąd tu powiela się w każdym module"}
  S13: {T: 3, N: 3, I: 2, B: 2, ai_share: 0.60, review: 0.40, trad_pd: [5, 7, 11],   driver: "RLS, Ledger, partycje; uprawnienia DBA w banku"}
  S14: {T: 3, N: 2, I: 2, B: 1, ai_share: 0.70, review: 0.30, trad_pd: [4, 6, 9],    driver: "Reqnroll z dwoma driverami i wspólnym światem testowym"}
  S15: {T: 4, N: 3, I: 3, B: 3, ai_share: 0.55, review: 0.50, trad_pd: [6, 9, 14],   driver: "decyzje projektowe dla 10 modułów naraz; pomyłka kosztuje RFC później"}
  S16: {T: 3, N: 2, I: 2, B: 1, ai_share: 0.70, review: 0.30, trad_pd: [7, 10, 15],  driver: "Nx, Kendo (licencja, prywatny rejestr), motyw z tokenów, katalog komponentów, mock server"}
  S17: {T: 2, N: 2, I: 1, B: 1, ai_share: 0.75, review: 0.30, trad_pd: [2, 3, 5],    driver: "wtyczka bpmnlint i przykładowe modele"}
  S18: {T: 4, N: 3, I: 4, B: 3, ai_share: 0.50, review: 0.50, trad_pd: [5, 8, 12],   driver: "OIDC z RHBK, ciasteczka, CSRF, wylogowanie globalne — bezpieczeństwo"}
  S19: {T: 4, N: 3, I: 3, B: 2, ai_share: 0.45, review: 0.60, trad_pd: [8, 12, 18],  driver: "nowy publiczny kontrakt SDK — błąd projektu kosztuje wszystkie zespoły profili"}
  S20: {T: 3, N: 2, I: 2, B: 3, ai_share: 0.70, review: 0.35, trad_pd: [5, 7, 10],   driver: "model Party, przypisania ról, nieobecności z regułami czasowymi"}
  S21: {T: 4, N: 4, I: 4, B: 3, ai_share: 0.55, review: 0.45, trad_pd: [8, 12, 18],  driver: "reconciler stanu docelowego autoryzacji, dryf, rozdział obowiązków"}
  S22: {T: 4, N: 4, I: 4, B: 1, ai_share: 0.60, review: 0.40, trad_pd: [10, 14, 22], driver: "7 portów na SDK (w tym ewaluacja wyrażeń) + fake + testy kontraktowe na Testcontainers"}
  S23: {T: 5, N: 4, I: 3, B: 2, ai_share: 0.55, review: 0.45, trad_pd: [12, 18, 28], driver: "spójność ostateczna: kolejność, duplikaty, wznowienie, katalog z XML"}
  S24: {T: 5, N: 3, I: 2, B: 4, ai_share: 0.55, review: 0.50, trad_pd: [10, 15, 22], driver: "reguły R1–R11 i materializacja widoczności — serce bezpieczeństwa"}
  S25: {T: 4, N: 2, I: 2, B: 4, ai_share: 0.60, review: 0.45, trad_pd: [7, 10, 15],  driver: "audyt dwufazowy, uzgadnianie, test kompletności; wymogi compliance"}
  S26: {T: 4, N: 2, I: 2, B: 4, ai_share: 0.65, review: 0.40, trad_pd: [10, 14, 20], driver: "maszyna stanów wersji, cztery oczy, wycofanie z wersją zastępczą, separacja per proces, walidacja katalogu i kontraktu"}
  S27: {T: 4, N: 4, I: 3, B: 3, ai_share: 0.40, review: 0.65, trad_pd: [6, 9, 15],   driver: "EXECUTE AS USER w transakcji z pulą połączeń, RLS widoków platform_api, reguły R10 w reconcilerze — bezpieczeństwo danych"}
  S28: {T: 2, N: 2, I: 1, B: 2, ai_share: 0.70, review: 0.35, trad_pd: [2, 3, 5],    driver: "tabele wersji i wycofań, indeksy filtrowane, klucz obcy przypięcia z procesem"}
  S29: {T: 3, N: 3, I: 3, B: 2, ai_share: 0.60, review: 0.40, trad_pd: [4, 6, 9],    driver: "referencje i kontrakt z katalogu elementów per wersja definicji, kontrola spójności, reguła bpmnlint"}
  S30: {T: 4, N: 3, I: 3, B: 3, ai_share: 0.60, review: 0.40, trad_pd: [8, 12, 18],  driver: "pierwsza pełna ścieżka przez potok, SDK i read model; wyścigi przejęcia"}
  S31: {T: 3, N: 2, I: 2, B: 2, ai_share: 0.70, review: 0.35, trad_pd: [4, 6, 9],    driver: "start z formatką i zmiennymi inicjatora"}
  S32: {T: 4, N: 3, I: 2, B: 3, ai_share: 0.60, review: 0.40, trad_pd: [6, 9, 14],   driver: "saga partii z wznowieniem; przekazanie osobie i grupie"}
  S33: {T: 4, N: 4, I: 3, B: 2, ai_share: 0.55, review: 0.45, trad_pd: [5, 8, 12],   driver: "worker na ścieżce silnika; fail-open i uzgadnianie"}
  S34: {T: 5, N: 3, I: 2, B: 4, ai_share: 0.60, review: 0.40, trad_pd: [10, 15, 22], driver: "algorytm stanu etapów (równoległość, pętle, call activity), wersje mapy"}
  S35: {T: 3, N: 3, I: 2, B: 3, ai_share: 0.65, review: 0.35, trad_pd: [4, 6, 9],    driver: "wykrywanie eskalacji i ich zakresu"}
  S36: {T: 4, N: 3, I: 2, B: 4, ai_share: 0.60, review: 0.40, trad_pd: [8, 12, 18],  driver: "definicje metryk uzgadniane z biznesem, agregaty, percentyle"}
  S37: {T: 4, N: 3, I: 3, B: 3, ai_share: 0.60, review: 0.40, trad_pd: [7, 10, 15],  driver: "walidacja schematu Camunda Forms na serwerze, FEEL przez silnik, przypięcie wersji — błąd przepuszcza złe dane do procesu"}
  S38: {T: 3, N: 3, I: 3, B: 2, ai_share: 0.55, review: 0.50, trad_pd: [6, 9, 13],   driver: "potok operacji używa istniejących zachowań; ryzyko w limitach czasu, idempotencji i izolacji awarii profilu"}
  S39: {T: 4, N: 2, I: 2, B: 3, ai_share: 0.60, review: 0.40, trad_pd: [4, 6, 9],    driver: "saga przepięcia zadań ze wznowieniem, przeniesienie szkicu danych, zadania bez formatki"}
  S40: {T: 5, N: 3, I: 2, B: 3, ai_share: 0.65, review: 0.35, trad_pd: [13, 18, 26], driver: "skrzynka zadań i własny renderer Camunda Forms (FEEL, układ, listy powtarzane) — najczęściej używany ekran"}
  S41: {T: 2, N: 1, I: 1, B: 2, ai_share: 0.80, review: 0.25, trad_pd: [4, 5, 8],    driver: "proste formularze i listy"}
  S42: {T: 3, N: 2, I: 1, B: 3, ai_share: 0.70, review: 0.30, trad_pd: [8, 11, 16],  driver: "wykresy, wstęga etapów, dostępność wykresów"}
  S43: {T: 3, N: 1, I: 1, B: 2, ai_share: 0.75, review: 0.25, trad_pd: [5, 7, 10],   driver: "okna przekazania i kreator partii"}
  S44: {T: 4, N: 3, I: 2, B: 3, ai_share: 0.60, review: 0.35, trad_pd: [8, 11, 16],  driver: "bpmn-js, interakcja na diagramie, walidacja mapy"}
  S45: {T: 4, N: 3, I: 3, B: 3, ai_share: 0.60, review: 0.35, trad_pd: [12, 17, 26], driver: "osadzenie edytora form-js i ograniczenie go do katalogu pól, porównanie wersji, wycofanie, import i eksport, podgląd"}
  S46: {T: 2, N: 1, I: 1, B: 2, ai_share: 0.80, review: 0.25, trad_pd: [3, 4, 6],    driver: "tabele tylko do odczytu"}
  S47: {T: 3, N: 2, I: 2, B: 2, ai_share: 0.65, review: 0.45, trad_pd: [5, 7, 11],   driver: "rejestr slotów i leniwe ładowanie — znany wzorzec; ryzyko w granicach Nx i widoczności slotów"}
  S48: {T: 1, N: 2, I: 1, B: 3, ai_share: 0.50, review: 0.40, trad_pd: [2, 4, 6],    driver: "przewodnik, szablon i przegląd manifestów z zespołami — głównie praca ludzi"}
  S49: {T: 3, N: 2, I: 1, B: 3, ai_share: 0.65, review: 0.40, trad_pd: [8, 12, 18],  driver: "komponenty pól w kompletach stanów, oba motywy, regresja wizualna i axe; wzorce zatwierdza projektant UX"}
  S50: {T: 4, N: 4, I: 5, B: 2, ai_share: 0.50, review: 0.50, trad_pd: [10, 15, 25], driver: "pierwsze spotkanie wszystkiego z prawdziwym środowiskiem; niestabilne testy"}
  S51: {T: 4, N: 3, I: 3, B: 4, ai_share: 0.45, review: 0.60, trad_pd: [6, 9, 14],   driver: "macierz obejść, izolacja, DAST — wyniki wymagają oceny człowieka"}
  S52: {T: 4, N: 4, I: 3, B: 2, ai_share: 0.45, review: 0.55, trad_pd: [5, 8, 14],   driver: "wolumeny, plany zapytań, opóźnienie projektora"}
  S53: {T: 2, N: 2, I: 1, B: 3, ai_share: 0.40, review: 0.60, trad_pd: [4, 6, 10],   driver: "testy z czytnikiem ekranu i klawiaturą to praca człowieka"}
  S55: {T: 3, N: 3, I: 2, B: 2, ai_share: 0.60, review: 0.40, trad_pd: [3, 5, 8],    driver: "zestaw zgodności z form-js i regresja wizualna w CI; niestabilne zrzuty"}
  S54: {T: 3, N: 4, I: 2, B: 5, ai_share: 0.10, review: 1.00, trad_pd: [10, 15, 25], driver: "zewnętrzny pentest i formalne akceptacje", external_calendar_days: [10, 15, 25]}
  S60: {T: 3, N: 4, I: 4, B: 5, ai_share: 0.10, review: 1.00, trad_pd: [15, 20, 30], driver: "wdrożenie, szkolenia, praca równoległa z Tasklist, wsparcie użytkowników"}
````

## Plik: plan/estimation-params.yaml

````yaml
# Parametry modelu szacowania — zmieniaj tu, potem uruchom: python3 tools/plan/estimate.py
weights: {T: 0.35, N: 0.30, I: 0.20, B: 0.15}       # indeks złożoności C = suma(waga × ocena)
classes:                                              # progi klas złożoności
  - {name: "niska", max: 2.2}
  - {name: "średnia", max: 3.0}
  - {name: "wysoka", max: 3.7}
  - {name: "bardzo wysoka", max: 5.0}
overheads:                                            # narzuty na pracę ludzi w hybrydzie (ułamek)
  swarm_supervision: 0.12                             # nadzór nad rojem: pakiety, eskalacje, scalanie
  coordination: 0.10                                  # spotkania, decyzje, zarządzanie projektem
calendar:
  parallel_factor: {S: 1.0, M: 1.0, L: 1.5}           # ilu ludzi efektywnie pracuje nad krokiem danego rozmiaru
  gate_wait_days:                                     # oczekiwanie na decyzje przy bramkach [O, M, P]
    G0: [3, 5, 10]
    G1: [1, 2, 4]
    G2: [1, 1, 3]
    G3: [3, 5, 10]
team_fte:                                             # zespół referencyjny (pełne etaty)
  architekt_tech_lead: 1.0
  backend_dotnet: 2.0
  frontend_angular: 1.0
  ux_designer: 0.5                                    # projektant UX: biblioteka w Figma, tokeny, wzorce regresji wizualnej
  devops: 0.5
  qa_bdd: 0.5
  product_owner_analityk: 0.5
  bezpieczenstwo: 0.2
utilization: 0.75                                     # ile czasu zespołu idzie na plan (reszta: utrzymanie, urlopy)
percentile_z: 0.84                                    # P80 dla rozkładu normalnego sumy PERT
````

## Plik: plan/progress/README.md

# Postęp wykonania

| Plik | Kto zapisuje | Zawartość |
| --- | --- | --- |
| `<krok>.json` | orkiestrator (przekazanie agenta), człowiek przez `plan_status.py --merged` | status `done/blocked/needs-rfc`, zmienione pliki, bramki, pytania; `merged: true` po scaleniu |
| `<krok>.gates.json` | `tools/agents/run_dod.py` | wynik każdej komendy dod, ogon logu przy błędzie |
| `<krok>.effort.json` | człowiek | `{"step": "S10", "actual_human_pd": 3.5}` — rzeczywista praca ludzi, do kalibracji wyceny |
| `gates.json` | człowiek przez `plan_status.py --approve-gate` (dopiero po scaleniu kroków z pola `after` bramki) | kto i kiedy zatwierdził bramkę, dowód |
| `logs/` | `run_dod.py` | pełne logi bramek (poza gitem) |

Narzędzia: `tools/agents/*.py` albo ich odpowiedniki .NET `ph step status | prepare | dod` (`tools/dotnet/README.md`).

Krok jest gotowy do startu, gdy wszystkie zależności mają `status: done` i `merged: true`, a bramka z `gate_before` jest w `gates.json`.

Plany zespołów profili (`profiles/<id>/backlog.yaml`) zapisują postęp w tym samym formacie w `profiles/<id>/progress/` (narzędzia z opcją `--backlog`).

