# 00 — Indeks źródeł Process Hub

Każdy plik źródłowy to pakiet plików repozytorium. Sekcja `## Plik: <ścieżka>` oznacza oryginalną ścieżkę w repozytorium — cytuj ją w odpowiedziach. Pliki wygenerowane (raport wyceny, dane dashboardu, AGENTS.md, agents/dist) są pochodne: zmienia się ich źródła i uruchamia generator.

| Źródło | Zawartość | Pliki |
| --- | --- | --- |
| `01-wejscie-i-architektura.md` | Wejście do repozytorium, zasady dla agentów i ludzi, słownik i architektura (docs/architecture 00–14) | 18 (158 KB) |
| `02-decyzje-i-uprawnienia.md` | Decyzje architektoniczne (ADR-001…020), wnioski RFC, uprawnienia jako kod i własność kodu | 26 (47 KB) |
| `03-specyfikacje-bdd.md` | Świat testowy i scenariusze Gherkin platformy (Reqnroll, # language: pl) | 18 (51 KB) |
| `04-plan-i-wycena.md` | Plan wykonawczy platformy, backlog maszynowy, szablon pakietu, model i raport wyceny | 8 (130 KB) |
| `05-profile-projektow.md` | Profile projektów: przewodnik i instrukcja dedykowanych elementów, schemat manifestu, szablon, profile kredyty, aml i flota (manifesty, plany, scenariusze) | 24 (101 KB) |
| `06-roj-agentow.md` | Rój agentów w OpenCode z modelem GLM w banku: instrukcja startu, przewodnik, skille, komendy, rejestr ról, model i polityka, kwalifikacja, narzędzia .NET | 34 (89 KB) |
| `07-ui-i-dashboard.md` | Propozycja UI, tokeny, formatki (założenia wizualne i katalog pól), dashboard harmonogramu: rejestr ryzyk i decyzji oraz dane | 13 (80 KB) |
| `08-artefakty-i-podsumowanie.md` | Artefakty projektowe (plan systemu, aktorzy, założenia, wytyczne UI) i podsumowanie projektu z rejestrem wymagań W-01…W-48 | 6 (74 KB) |
| `09-narzedzia-kod.md` | Kod narzędzi repozytorium (opcjonalne źródło): wycena, eksport, artefakty, generator agentów, prowadzenie kroków, strażnik, profile | 14 (106 KB) |

Nie ma w źródłach stron do oglądania (`design/mockups/index.html`, `plan/dashboard/index.html`, `docs/artifacts/index.html`) ani pierwotnych dokumentów v1 z projektu (można je wgrać osobno jako tło).
