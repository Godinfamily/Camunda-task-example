# 03-specyfikacje-bdd — Świat testowy i scenariusze Gherkin platformy (Reqnroll, # language: pl)

Pakiet zawiera 18 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: specs/README.md

# Świat testowy (wspólny dla wszystkich plików .feature)

Wszystkie scenariusze używają tych samych osób, grup i procesów. Drivery tworzą ten świat krokiem „Zakładając świat testowy Process Hub”.

**Tenant:** `<default>` (scenariusze `@multi-tenant` dodają `drugi`).

**Profile i procesy:** profil `kredyty` — `wniosek-kredytowy` (etapy: Rejestracja, Ocena, Oferta, Zakończenie; zadania: `OcenaWniosku` → grupa `kre-analitycy`, `AkceptacjaUnderwritera` → `kre-underwriting`) i `aneks-kredytowy`; profil `aml` — `weryfikacja-aml` (zadanie `AnalizaAml` → `aml-analitycy`); profil `flota` — `rejestracja-samochodu` (etapy: Wniosek, Opiniowanie, Decyzja, Zakup i rejestracja, Zakończenie; zadania: `WeryfikacjaWniosku` i `RejestracjaPojazdu` → `flota-koordynatorzy`, `DecyzjaOPrzydziale` → `flota-decydenci`) i proces podrzędny `opiniowanie-rejestracji` (zadanie wielokrotne `OpiniaKomorki` → `flota-opinia-it`, `-hr`, `-prawny`, `-finanse`, `-ryzyko`). Katalog samochodów profilu `flota`: „Toyota Corolla Touring Sports 1.8 Hybrid” (dostępny), „Skoda Octavia Combi 2.0 TDI” (wycofany); limit emisji CO2 polityki floty: 130 g/km. Role projektowe: `profiles/kredyty/profile.yaml`, `profiles/aml/profile.yaml`, `profiles/flota/profile.yaml`.

| Osoba | Grupy kandydujące | Role projektowe (profil) → role platformy | Role globalne |
| --- | --- | --- | --- |
| anna | kre-analitycy | Analityk kredytowy (kredyty) → Uczestnik, Inicjator w wniosek-kredytowy | — |
| bartek | kre-analitycy | Analityk kredytowy (kredyty) → Uczestnik, Inicjator w wniosek-kredytowy | — |
| piotr | kre-analitycy | Analityk kredytowy (kredyty); Kierownik zespołu AML (aml) → Menadżer procesu w weryfikacja-aml | — |
| celina, ewa | kre-underwriting | Underwriter (kredyty) → Uczestnik w wniosek-kredytowy | — |
| darek | aml-analitycy | Analityk AML (aml) → Uczestnik w weryfikacja-aml | — |
| marta | — | Kierownik zespołu kredytowego (kredyty) → Menadżer procesu w procesach profilu | — |
| adam | — | Administrator procesów kredytowych (kredyty) → Administrator procesu w procesach profilu | — |
| tomasz | — | Wnioskodawca (flota) → Inicjator w rejestracja-samochodu | — |
| kamil | flota-koordynatorzy | Koordynator floty (flota) → Uczestnik w rejestracja-samochodu | — |
| igor, hanna, lena, filip, rafal | po kolei: flota-opinia-it, -hr, -prawny, -finanse, -ryzyko | Opiniujący (flota) → Uczestnik w opiniowanie-rejestracji | — |
| jan | flota-decydenci | Decydent floty (flota) → Uczestnik w rejestracja-samochodu | — |
| wiktor | — | Kierownik floty (flota) → Menadżer procesu w procesach profilu | — |
| alicja | — | Administrator procesów floty (flota) → Administrator procesu w procesach profilu | — |
| karol | — | Administrator katalogu samochodów (flota) — bez ról platformy, `flota.Catalog.Manage` | — |
| olga | — | — | Audytor (*) |
| zenon | — | — | Administrator platformy |

Przypisania: grupy AD z `profiles/*/authorization.yaml` (role projektowe) i `config/authorization/assignments.example.yaml` (role globalne). Scenariusze profili leżą w `profiles/<id>/specs/` (tagi `@KRE-FR-xx`, `@AML-FR-xx`, `@FLO-FR-xx`) i korzystają z tego samego świata.

**Formatki** (format Camunda Forms; każda należy do jednego procesu — R11; opis: `docs/architecture/14-form-management.md`):

| Formatka | Klucz (`ph:form/<klucz>`) | Proces | Zastosowanie | Stan w świecie testowym |
| --- | --- | --- | --- | --- |
| F-ocena | `ocena-wniosku` | wniosek-kredytowy | zadanie `OcenaWniosku` | opublikowane wersje 1–3, obowiązuje 3 |
| F-akceptacja | `akceptacja-underwritera` | wniosek-kredytowy | zadanie `AkceptacjaUnderwritera` | obowiązuje wersja 1 |
| F-wniosek | `wniosek-start` | wniosek-kredytowy | formatka startowa | obowiązuje wersja 5 |
| F-aneks | `analiza-zmian` | aneks-kredytowy | zadanie analizy zmian w umowie | opublikowane wersje 1–2, obowiązuje 2 |
| F-aml | `analiza-aml` | weryfikacja-aml | zadanie `AnalizaAml` | obowiązuje wersja 1 |

Formatkami procesów kredytowych zarządzają marta i adam, formatkami `weryfikacja-aml` — piotr, formatkami floty — wiktor i alicja; olga ma wgląd (`Form.View`) wszędzie. Wyniki w scenariuszach: `Succeeded`, `Denied:<uprawnienie>`, `Rejected:<kod walidacji>`.

**Konwencje:** `# language: pl`; tag FR na każdym scenariuszu; `@integration` = wymaga MSSQL + Camunda w Testcontainers; kody reguł R1–R11 z `docs/architecture/02-roles-and-authorization.md`.

## Plik: specs/access/authorization-as-code.feature

````gherkin
# language: pl
Funkcja: Autoryzacje jako kod — jedno źródło dla Camunda i aplikacji

  @FR-21
  Scenariusz: Plan zmian pokazuje różnicę przed zastosowaniem
    Zakładając deklaracje z nowym przypisaniem grupy "PH-KREDYT-MGR" do roli "process-manager" dla procesu "aneks-kredytowy"
    Jeżeli reconciler działa w trybie podglądu
    Wtedy raport zawiera dodanie autoryzacji "READ_PROCESS_INSTANCE" dla "aneks-kredytowy"
    Oraz w Camunda nic się nie zmieniło

  @FR-21
  Scenariusz: Rozdział obowiązków blokuje konfigurację
    Zakładając deklaracje przypisujące grupie "PH-AUDYT" role "auditor" i "participant" w procesie "wniosek-kredytowy"
    Jeżeli reconciler waliduje deklaracje
    Wtedy walidacja kończy się błędem "R7"

  @FR-21
  Scenariusz: Rola tylko do odczytu nie może zawierać uprawnień zapisu
    Zakładając rolę "auditor" oznaczoną jako tylko do odczytu z uprawnieniem "Task.Reassign"
    Jeżeli reconciler waliduje deklaracje
    Wtedy walidacja kończy się błędem "ReadOnlyRoleWithWritePermission"

  @FR-21 @integration
  Scenariusz: Wykryty dryf trafia do audytu
    Zakładając, że ktoś ręcznie dodał w Camunda autoryzację spoza deklaracji
    Jeżeli uruchamia się nocne wykrywanie dryfu
    Wtedy dziennik bezpieczeństwa zawiera "Authorization.DriftDetected"
````

## Plik: specs/access/visibility.feature

````gherkin
# language: pl
Funkcja: Widoczność wynika z ról w zakresach i z reguł wierszowych

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" dla grupy "kre-analitycy" przypisane do "anna"
    Oraz zadanie "T2" procesu "wniosek-kredytowy" dla grupy "kre-underwriting" nieprzypisane
    Oraz zadanie "T3" procesu "weryfikacja-aml" dla grupy "aml-analitycy" przypisane do "darek"

  @FR-03 @FR-10 @FR-19
  Szablon scenariusza: Kto widzi które zadanie i z jakimi akcjami
    Jeżeli "<osoba>" pobiera listę zadań
    Wtedy zadanie "<zadanie>" jest "<widoczność>" z akcjami "<akcje>"

    Przykłady:
      | osoba  | zadanie | widoczność  | akcje                 |
      | anna   | T1      | widoczne    | edit,complete,unclaim |
      | bartek | T1      | widoczne    | —                     |
      | celina | T1      | niewidoczne | —                     |
      | celina | T2      | widoczne    | claim                 |
      | marta  | T1      | widoczne    | reassign              |
      | marta  | T3      | niewidoczne | —                     |
      | piotr  | T3      | widoczne    | reassign              |
      | olga   | T1      | widoczne    | —                     |
      | olga   | T3      | widoczne    | —                     |
      | adam   | T1      | niewidoczne | —                     |
      | zenon  | T1      | niewidoczne | —                     |

  @FR-09
  Scenariusz: Uprawnienia wielu ról sumują się, a audyt zapisuje rolę uzasadniającą
    Jeżeli "piotr" przekazuje zadanie "T3" osobie "darek" z powodem "obciążenie"
    Wtedy operacja kończy się sukcesem
    Oraz dziennik bezpieczeństwa zawiera "Task.Reassign" dla "piotr" z rolą uzasadniającą "aml/kierownik-aml" (rola platformy "process-manager", proces "weryfikacja-aml")

  @FR-09
  Scenariusz: Rola w jednym procesie nie daje uprawnień w innym
    Jeżeli "piotr" przekazuje zadanie "T1" osobie "bartek" z powodem "obciążenie"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-19
  Scenariusz: Audytor nie wykona żadnej akcji zapisu
    Jeżeli "olga" przejmuje zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-10
  Scenariusz: Menadżer procesu nie widzi technikaliów BPMN
    Jeżeli "marta" otwiera szczegóły instancji zadania "T1"
    Wtedy widzi mapę etapów z bieżącym etapem "Ocena"
    Ale nie widzi identyfikatorów elementów ani zmiennych spoza formatki

  @multi-tenant
  Scenariusz: Zadania drugiego tenanta są niewidoczne nawet dla audytora pierwszego
    Zakładając tenant "drugi" z zadaniem "X1" procesu "wniosek-kredytowy"
    Jeżeli "olga" pobiera listę zadań
    Wtedy zadanie "X1" jest "niewidoczne" z akcjami "—"

  @integration
  Scenariusz: RLS odcina innego tenanta nawet przy zapytaniu bez filtra
    Zakładając tenant "drugi" z zadaniem "X1" procesu "wniosek-kredytowy"
    Oraz kontekst sesji bazy z tenantem "<default>"
    Jeżeli wykonuję zapytanie o wszystkie zadania bez filtra tenanta
    Wtedy wynik nie zawiera zadania "X1"
````

## Plik: specs/audit/audit.feature

````gherkin
# language: pl
Funkcja: Audyt każdej akcji — bezpieczeństwo i analiza problemów

  Założenia:
    Zakładając świat testowy Process Hub

  @FR-20
  Scenariusz: Każde żądanie zostawia ślad operacyjny, także odrzucone
    Jeżeli "anna" wywołuje dowolny endpoint bez uprawnienia
    Wtedy ślad operacyjny zawiera żądanie z kodem 403, czasem trwania i identyfikatorem śladu
    Oraz dziennik bezpieczeństwa zawiera wpis z wynikiem "Denied" i kodem reguły

  @FR-20
  Scenariusz: Błąd silnika jest diagnozowalny ze śladu
    Zakładając, że silnik odrzuca zakończenie zadania "T2" błędem walidacji zmiennych
    Jeżeli "celina" kończy zadanie "T2"
    Wtedy ślad operacyjny zawiera kod problemu z silnika i liczbę ponowień
    Oraz dziennik bezpieczeństwa zawiera "Intent" i "Outcome" z wynikiem "Failed"

  @FR-20
  Scenariusz: Dziennik nie zawiera wartości danych osobowych
    Jeżeli "celina" kończy zadanie "T2" danymi zawierającymi PESEL
    Wtedy wpis dziennika zawiera skrót danych i listę zmienionych pól
    Ale nie zawiera wartości PESEL

  @FR-20
  Scenariusz: Przerwana komenda zostaje uzgodniona
    Zakładając wpis "Intent" przekazania zadania "T1" bez wpisu "Outcome"
    Oraz read model pokazuje "bartek" jako assignee zadania "T1"
    Jeżeli uruchamia się job uzgadniający
    Wtedy dziennik bezpieczeństwa zawiera "Outcome" z wynikiem "Reconciled"

  @FR-20 @integration
  Scenariusz: Wpisu dziennika nie da się zmienić nawet z poziomu SQL
    Zakładając dowolny wpis w dzienniku bezpieczeństwa
    Jeżeli login aplikacji wykonuje UPDATE na tym wpisie
    Wtedy baza odrzuca operację

  @FR-20
  Scenariusz: Przeglądanie dziennika jest audytowane
    Jeżeli "olga" przegląda dziennik bezpieczeństwa sprawy "K-001"
    Wtedy dziennik bezpieczeństwa zawiera "Audit.ViewJournal" dla "olga"
````

## Plik: specs/forms/form-designer.feature

````gherkin
# language: pl
Funkcja: Formatki w formacie Camunda Forms — projektant, katalog pól, import i eksport

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"

  @FR-28
  Scenariusz: Zapisany szkic jest poprawnym dokumentem Camunda Forms
    Jeżeli "marta" zapisuje w szkicu formatki "F-ocena" pola "kwota:number", "decyzja:radio" i "uzasadnienie:textarea"
    Wtedy schemat szkicu ma typ "default" i platformę wykonania "Camunda Cloud" w wersji "8.9.0"
    Oraz schemat szkicu przechodzi walidację oficjalnym schematem formatu Camunda Forms
    Oraz dziennik bezpieczeństwa zawiera "Form.Save" z wynikiem "Succeeded" dla "marta"

  @FR-28
  Szablon scenariusza: Katalog pól rozstrzyga, co wolno przekazać do przeglądu
    Zakładając szkic formatki "F-ocena" z komponentem typu "<typ>"
    Jeżeli "marta" przekazuje formatkę "F-ocena" do przeglądu
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | typ             | wynik                       |
      | textfield       | Succeeded                   |
      | datetime        | Succeeded                   |
      | dynamiclist     | Succeeded                   |
      | html            | Rejected:FieldCatalog       |
      | iframe          | Rejected:FieldCatalog       |
      | button          | Rejected:FieldCatalog       |
      | filepicker      | Rejected:FieldCatalog       |

  @FR-28
  Scenariusz: Paleta projektanta pokazuje tylko typy z katalogu pól
    Jeżeli "marta" otwiera projektanta formatki "F-ocena"
    Wtedy paleta zawiera typ "textfield"
    Ale paleta nie zawiera typu "iframe"
    Oraz paleta nie zawiera pola profilu "flota.CarModels"

  @FR-28
  Scenariusz: Pole profilu jest dostępne tylko w formatkach procesów profilu
    Jeżeli "alicja" otwiera projektanta formatki startowej procesu "rejestracja-samochodu"
    Wtedy paleta zawiera pole profilu "flota.CarModels"

  @FR-28
  Scenariusz: Import pliku z Modelera tworzy szkic
    Jeżeli "adam" importuje do formatki "F-ocena" plik ".form" z polami "decyzja" i "uzasadnienie"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz autor ostatniej zmiany formatki "F-ocena" to "adam"
    Oraz dziennik bezpieczeństwa zawiera "Form.Import" z wynikiem "Succeeded" dla "adam"

  @FR-28
  Scenariusz: Import pliku z typem spoza katalogu jest odrzucony w całości
    Jeżeli "adam" importuje do formatki "F-ocena" plik ".form" z komponentem typu "iframe"
    Wtedy operacja jest odrzucona błędem "FieldCatalog"
    Oraz formatka "F-ocena" nie ma nowej wersji roboczej

  @FR-28
  Scenariusz: Eksport opublikowanej wersji daje plik z numerem wersji
    Zakładając opublikowaną wersję 3 formatki "F-ocena"
    Jeżeli "marta" eksportuje wersję 3 formatki "F-ocena"
    Wtedy plik ".form" ma znacznik wersji "3"
    Oraz dziennik bezpieczeństwa zawiera "Form.Export" z wynikiem "Succeeded" dla "marta"

  @FR-28
  Scenariusz: Błąd składni wyrażenia FEEL blokuje publikację
    Zakładając zatwierdzoną formatkę "F-ocena" z warunkiem ukrycia pola "uzasadnienie" o treści "=decyzja = "
    Jeżeli "adam" publikuje formatkę "F-ocena"
    Wtedy walidacja kończy się błędem "FeelSyntax"
````

## Plik: specs/forms/form-isolation.feature

````gherkin
# language: pl
Funkcja: Separacja formatek — każdy proces ma formatki wyłącznie dla siebie

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" należy do procesu "wniosek-kredytowy"
    Oraz formatka "F-aneks" należy do procesu "aneks-kredytowy"
    Oraz formatka "F-aml" należy do procesu "weryfikacja-aml"

  @FR-31
  Szablon scenariusza: Lista formatek zawiera tylko procesy z zakresu roli
    Jeżeli "<osoba>" otwiera listę formatek procesu "<proces>"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba  | proces            | wynik            |
      | marta  | wniosek-kredytowy | Succeeded        |
      | marta  | aneks-kredytowy   | Succeeded        |
      | marta  | weryfikacja-aml   | Denied:Form.View |
      | piotr  | weryfikacja-aml   | Succeeded        |
      | piotr  | wniosek-kredytowy | Denied:Form.View |
      | wiktor | wniosek-kredytowy | Denied:Form.View |
      | olga   | weryfikacja-aml   | Succeeded        |
      | anna   | wniosek-kredytowy | Denied:Form.View |

  @FR-31
  Scenariusz: Menadżer innego procesu nie edytuje cudzej formatki
    Jeżeli "piotr" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy operacja jest odrzucona brakiem uprawnienia "Form.Edit"
    Oraz dziennik bezpieczeństwa zawiera "Form.Save" z wynikiem "Denied" dla "piotr"

  @FR-31
  Scenariusz: Ten sam klucz w dwóch procesach to dwie różne formatki
    Jeżeli "marta" tworzy w procesie "aneks-kredytowy" formatkę o kluczu "ocena-wniosku"
    Wtedy wynik operacji to "Succeeded"
    Oraz formatka "F-ocena" procesu "wniosek-kredytowy" pozostaje bez zmian

  @FR-31
  Scenariusz: Nowa wersja nie powstanie z wersji formatki innego procesu
    Jeżeli "marta" tworzy nową wersję formatki "F-aneks" z wersji 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona regułą "R11"
    Oraz dziennik bezpieczeństwa zawiera "Form.NewVersion" z wynikiem "Denied" dla "marta"

  @FR-31
  Scenariusz: Wersja zastępcza musi pochodzić z tej samej formatki
    Jeżeli "marta" wycofuje wersję 2 formatki "F-aneks" z powodem "Defect" i wersją zastępczą 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona regułą "R11"

  @FR-31
  Scenariusz: Referencja z BPMN jest rozwiązywana tylko w procesie zadania
    Zakładając zadanie "T8" procesu "aneks-kredytowy" z referencją formatki "ph:form/ocena-wniosku"
    Oraz proces "aneks-kredytowy" nie ma formatki o kluczu "ocena-wniosku"
    Jeżeli "anna" pobiera szczegóły zadania "T8"
    Wtedy zadanie "T8" nie ma przypiętej formatki
    Oraz "marta" widzi w projektancie procesu "aneks-kredytowy" brakującą formatkę "ocena-wniosku"

  @FR-31
  Scenariusz: Zadanie nie wyrenderuje formatki innego procesu
    Zakładając zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Jeżeli zadanie "T5" zostaje przepięte na wersję 2 formatki "F-aneks"
    Wtedy operacja jest odrzucona regułą "R11"
    Oraz zadanie "T5" renderuje wersję 3

  @FR-31
  Scenariusz: Przeniesienie treści między procesami tylko przez jawny eksport i import
    Zakładając opublikowaną wersję 3 formatki "F-ocena"
    Jeżeli "marta" eksportuje wersję 3 formatki "F-ocena"
    Oraz "marta" importuje ten plik do formatki "F-aneks"
    Wtedy wersja robocza formatki "F-aneks" jest w stanie "Draft"
    Oraz formatka "F-ocena" procesu "wniosek-kredytowy" pozostaje bez zmian
    Oraz dziennik bezpieczeństwa zawiera "Form.Export" z wynikiem "Succeeded" dla "marta"
    Oraz dziennik bezpieczeństwa zawiera "Form.Import" z wynikiem "Succeeded" dla "marta"

  @FR-31 @integration
  Scenariusz: Baza nie pozwala przypiąć zadania do wersji formatki innego procesu
    Jeżeli wiersz zadania procesu "aneks-kredytowy" dostaje przypięcie wersji formatki procesu "wniosek-kredytowy"
    Wtedy baza odrzuca zapis naruszeniem klucza obcego
````

## Plik: specs/forms/form-lifecycle.feature

````gherkin
# language: pl
Funkcja: Formatki — edycja przez menadżera lub administratora, cztery oczy, wersje

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"

  @FR-17
  Szablon scenariusza: Kto może edytować formatkę
    Jeżeli "<osoba>" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba | wynik                      |
      | marta | Succeeded                  |
      | adam  | Succeeded                  |
      | anna  | Denied:Form.Edit           |
      | olga  | Denied:Form.Edit           |

  @FR-17
  Scenariusz: Autor ostatniej zmiany nie zatwierdzi formatki
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "marta" zatwierdza formatkę "F-ocena"
    Wtedy operacja jest odrzucona regułą "R8"

  @FR-17
  Scenariusz: Zatwierdzenie przez inną uprawnioną osobę i publikacja
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "adam" zatwierdza formatkę "F-ocena"
    Oraz "marta" publikuje formatkę "F-ocena"
    Wtedy formatka "F-ocena" ma opublikowaną nową wersję
    Oraz dziennik bezpieczeństwa zawiera "Form.Approve" dla "adam" i "Form.Publish" dla "marta"

  @FR-17
  Scenariusz: Odrzucenie do poprawy wymaga komentarza i wraca do szkicu
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta" i przekazany do przeglądu
    Jeżeli "adam" odrzuca formatkę "F-ocena" do poprawy z komentarzem "Brak pomocy przy polu decyzji"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz "marta" widzi komentarz przeglądu "Brak pomocy przy polu decyzji"
    Oraz dziennik bezpieczeństwa zawiera "Form.Reject" z wynikiem "Succeeded" dla "adam"

  @FR-17
  Scenariusz: Zmiana treści po zatwierdzeniu unieważnia zatwierdzenie
    Zakładając zatwierdzoną przez "adam" formatkę "F-ocena"
    Jeżeli "marta" edytuje szkic formatki "F-ocena" zadania "OcenaWniosku"
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz publikacja formatki "F-ocena" wymaga ponownego zatwierdzenia

  @FR-17
  Scenariusz: Publikacja niezgodna z kontraktem danych zadania
    Zakładając zatwierdzoną formatkę "F-ocena" bez pola "uzasadnienie"
    Jeżeli "adam" publikuje formatkę "F-ocena"
    Wtedy publikacja jest odrzucona z błędem kontraktu dla wyjścia "uzasadnienie"

  @FR-18
  Scenariusz: Zadanie w toku zachowuje przypiętą wersję
    Zakładając zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Jeżeli zostaje opublikowana wersja 4 formatki "F-ocena"
    Wtedy zadanie "T5" renderuje wersję 3

  @FR-18
  Scenariusz: Nowe zadanie dostaje wersję obowiązującą
    Zakładając opublikowaną wersję 4 formatki "F-ocena"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie "T6" typu "OcenaWniosku"
    Wtedy zadanie "T6" renderuje wersję 4
````

## Plik: specs/forms/form-rendering.feature

````gherkin
# language: pl
Funkcja: Formatka na zadaniu — materializacja komponentami design systemu i walidacja na serwerze

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"
    Oraz zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"
    Oraz wersja 3 formatki "F-ocena" ma pola "kwota:number" tylko do odczytu, "decyzja:radio" wymagane i "uzasadnienie:textarea" wymagane i widoczne tylko, gdy decyzja to "Odrzucam"

  @FR-32
  Szablon scenariusza: Każdy typ pola ma jeden komponent design systemu
    Jeżeli renderer materializuje pole typu "<typ>"
    Wtedy używa komponentu "<komponent>" z katalogu pól
    Oraz komponent nie dostaje żadnej własności wyglądu ze schematu

    Przykłady:
      | typ         | komponent        |
      | textfield   | ph-text-field    |
      | textarea    | ph-textarea      |
      | number      | ph-number-field  |
      | datetime    | ph-date-field    |
      | checkbox    | ph-checkbox      |
      | checklist   | ph-checklist     |
      | radio       | ph-radio-group   |
      | select      | ph-select        |
      | taglist     | ph-taglist       |
      | group       | ph-group         |
      | dynamiclist | ph-repeater      |
      | table       | ph-data-table    |
      | text        | ph-text-block    |

  @FR-32
  Scenariusz: Wykonawca dostaje formatkę do edycji, pozostali do odczytu
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" pobiera szczegóły zadania "T5"
    Wtedy formatka zadania "T5" jest w trybie "edycja"
    Jeżeli "bartek" pobiera szczegóły zadania "T5"
    Wtedy formatka zadania "T5" jest w trybie "odczyt"
    Oraz widzi informację "Edytować może tylko osoba, która przejęła zadanie: anna"

  @FR-32
  Scenariusz: Pole ukryte warunkiem nie jest wymagane ani przyjmowane
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "decyzja=Akceptuję"
    Wtedy wynik operacji to "Succeeded"
    Oraz silnik otrzymał zmienną "decyzja" o wartości "Akceptuję" i zmienną "uzasadnienie" bez wartości

  @FR-32 @FR-06
  Scenariusz: Serwer odrzuca brak pola wymaganego warunkowo
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "decyzja=Odrzucam"
    Wtedy walidacja kończy się błędem "Required:uzasadnienie"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-32 @FR-06
  Szablon scenariusza: Serwer nie ufa przeglądarce
    Zakładając zadanie "T5" przypisane do "anna"
    Jeżeli "anna" kończy zadanie "T5" z danymi "<dane>"
    Wtedy walidacja kończy się błędem "<błąd>"
    Oraz silnik nie otrzymał żadnego wywołania

    Przykłady:
      | dane                                                   | błąd                |
      | decyzja=Akceptuję; kwota=1                             | ReadOnly:kwota      |
      | decyzja=Akceptuję; premia=500                          | UnknownField:premia |
      | decyzja=Może                                           | Option:decyzja      |
      | decyzja=Odrzucam; uzasadnienie=(tekst o długości 5001 znaków) | MaxLength:uzasadnienie |

  @FR-32
  Scenariusz: Ta sama formatka w obu motywach i na telefonie
    Jeżeli katalog komponentów renderuje wersję 3 formatki "F-ocena" w motywach "jasny" i "ciemny" przy szerokościach 390, 768 i 1280 pikseli
    Wtedy zrzuty są zgodne z zatwierdzonymi wzorcami
    Oraz przy szerokości 390 pikseli pola układają się w jednej kolumnie
    Oraz audyt axe-core nie zgłasza naruszeń

  @FR-32
  Scenariusz: Renderer platformy zachowuje się jak biblioteka form-js
    Jeżeli zestaw zgodności uruchamia formatki wzorcowe w rendererze platformy i w form-js
    Wtedy zbiór widocznych pól, błędy walidacji i dane wyjściowe są identyczne
````

## Plik: specs/forms/form-versioning.feature

````gherkin
# language: pl
Funkcja: Wersje formatki — historia, numeracja, porównanie, nowa wersja

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" ma opublikowane wersje 1, 2 i 3, z których obowiązuje wersja 3

  @FR-29
  Scenariusz: Publikacja nadaje kolejny numer i zastępuje poprzednią wersję
    Zakładając zatwierdzoną przez "adam" formatkę "F-ocena"
    Jeżeli "marta" publikuje formatkę "F-ocena"
    Wtedy formatka "F-ocena" ma obowiązującą wersję 4
    Oraz wersja 3 formatki "F-ocena" jest w stanie "Superseded"

  @FR-29
  Scenariusz: Opublikowanej wersji nie da się zmienić
    Jeżeli "marta" zapisuje zmianę w wersji 3 formatki "F-ocena"
    Wtedy operacja jest odrzucona błędem "VersionImmutable"

  @FR-29
  Scenariusz: Formatka ma najwyżej jedną wersję roboczą
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta"
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 2
    Wtedy operacja jest odrzucona błędem "WorkingVersionExists"

  @FR-29
  Scenariusz: Nowa wersja z dowolnej wcześniejszej
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 2
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz treść wersji roboczej jest równa treści wersji 2
    Oraz dziennik bezpieczeństwa zawiera "Form.NewVersion" z wynikiem "Succeeded" dla "adam"

  @FR-29
  Scenariusz: Historia szkicu pokazuje każdą zmianę i jej autora
    Zakładając szkic formatki "F-ocena" zmieniony kolejno przez "marta" i "adam"
    Jeżeli "olga" otwiera historię formatki "F-ocena"
    Wtedy historia zawiera 2 rewizje szkicu z autorami "marta" i "adam"
    Oraz historia zawiera wersje 1, 2 i 3 z osobami zatwierdzającymi i publikującymi

  @FR-29
  Scenariusz: Zatwierdzający widzi różnicę względem wersji obowiązującej
    Zakładając szkic formatki "F-ocena" z dodanym polem "warunki" i zmienioną etykietą pola "decyzja", przekazany do przeglądu
    Jeżeli "adam" otwiera przegląd formatki "F-ocena"
    Wtedy porównanie z wersją 3 pokazuje pole dodane "warunki"
    Oraz porównanie z wersją 3 pokazuje pole zmienione "decyzja" z własnością "label"

  @FR-29
  Scenariusz: Porzucenie szkicu nie zmienia wersji opublikowanych
    Zakładając szkic formatki "F-ocena" zmieniony ostatnio przez "marta"
    Jeżeli "marta" porzuca szkic formatki "F-ocena"
    Wtedy formatka "F-ocena" ma obowiązującą wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Discard" z wynikiem "Succeeded" dla "marta"
````

## Plik: specs/forms/form-withdrawal.feature

````gherkin
# language: pl
Funkcja: Wycofanie wersji formatki i całej formatki

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz formatka "F-ocena" ma opublikowane wersje 1, 2 i 3, z których obowiązuje wersja 3
    Oraz zadanie "T5" utworzone przy opublikowanej wersji 3 formatki "F-ocena"

  @FR-30
  Szablon scenariusza: Kto może wycofać wersję
    Jeżeli "<osoba>" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 2
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba | wynik                |
      | marta | Succeeded            |
      | adam  | Succeeded            |
      | anna  | Denied:Form.Withdraw |
      | olga  | Denied:Form.Withdraw |

  @FR-30
  Scenariusz: Wycofanie bez powodu jest odrzucone
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" bez powodu
    Wtedy operacja jest odrzucona błędem "ReasonRequired"
    Oraz formatka "F-ocena" ma obowiązującą wersję 3

  @FR-30
  Scenariusz: Wersja zastępcza staje się obowiązująca, zadania w toku zostają
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 2
    Wtedy wersja 3 formatki "F-ocena" jest w stanie "Withdrawn"
    Oraz formatka "F-ocena" ma obowiązującą wersję 2
    Oraz zadanie "T5" renderuje wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Withdraw" z wynikiem "Succeeded" dla "marta"

  @FR-30
  Scenariusz: Wycofanie z przepięciem zadań w toku
    Zakładając szkic danych zadania "T5" z wartościami pól "decyzja" i "uwagiDodatkowe"
    Oraz wersja 2 formatki "F-ocena" nie ma pola "uwagiDodatkowe"
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect", wersją zastępczą 2 i przepięciem zadań w toku
    Wtedy zadanie "T5" renderuje wersję 2
    Oraz szkic danych zadania "T5" zachowuje pole "decyzja" i nie zawiera pola "uwagiDodatkowe"
    Oraz assignee zadania "T5" widzi informację "Formatka zadania została zmieniona po wycofaniu wersji 3"
    Oraz dziennik bezpieczeństwa zawiera "Form.Repin" z wynikiem "Succeeded" dla "marta"

  @FR-30
  Scenariusz: Wersja zastępcza musi spełniać bieżący kontrakt danych
    Zakładając kontrakt zadania "OcenaWniosku" wymaga wyjść "decyzja:string" i "uzasadnienie:string"
    Oraz wersja 1 formatki "F-ocena" nie ma pola "uzasadnienie"
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Defect" i wersją zastępczą 1
    Wtedy operacja jest odrzucona błędem "ReplacementContract"
    Oraz formatka "F-ocena" ma obowiązującą wersję 3

  @FR-30
  Scenariusz: Wycofanie bez wersji zastępczej blokuje zakończenie nowych zadań
    Jeżeli "marta" wycofuje wersję 3 formatki "F-ocena" z powodem "Compliance" bez wersji zastępczej
    Oraz w procesie "wniosek-kredytowy" powstaje zadanie "T7" typu "OcenaWniosku"
    Wtedy zadanie "T7" nie ma przypiętej formatki
    Oraz "anna" widzi na zadaniu "T7" informację "Formatka tego zadania została wycofana. Zgłoś to menadżerowi procesu."
    Oraz zakończenie zadania "T7" jest odrzucone błędem "FormUnavailable"

  @FR-30
  Scenariusz: Zadanie bez formatki dostaje ją po kolejnej publikacji
    Zakładając zadanie "T7" typu "OcenaWniosku" bez przypiętej formatki
    Jeżeli zostaje opublikowana wersja 4 formatki "F-ocena"
    Oraz "anna" pobiera szczegóły zadania "T7"
    Wtedy zadanie "T7" renderuje wersję 4

  @FR-30
  Scenariusz: Wycofanej wersji nie da się przywrócić na skróty
    Zakładając wersję 3 formatki "F-ocena" w stanie "Withdrawn"
    Jeżeli "adam" tworzy nową wersję formatki "F-ocena" z wersji 3
    Wtedy wersja robocza formatki "F-ocena" jest w stanie "Draft"
    Oraz publikacja formatki "F-ocena" wymaga ponownego zatwierdzenia

  @FR-30
  Scenariusz: Wycofanie całej formatki
    Jeżeli "adam" wycofuje formatkę "F-ocena" z powodem "ProcessChange"
    Wtedy formatka "F-ocena" jest w stanie "Retired"
    Oraz formatka "F-ocena" nie ma wersji obowiązującej
    Oraz zadanie "T5" renderuje wersję 3
    Oraz dziennik bezpieczeństwa zawiera "Form.Retire" z wynikiem "Succeeded" dla "adam"

  @FR-30 @FR-07
  Scenariusz: Wycofana formatka startowa wyłącza start procesu z aplikacji
    Zakładając proces "wniosek-kredytowy" z formatką startową "F-wniosek" wycofaną bez wersji zastępczej
    Jeżeli "anna" otwiera katalog procesów do startu
    Wtedy widzi proces "wniosek-kredytowy" z informacją "Start chwilowo niedostępny: formatka startowa została wycofana"
````

## Plik: specs/insight/escalations.feature

````gherkin
# language: pl
Funkcja: Eskalacje widoczne dla menadżera procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz opublikowaną mapę etapów procesu "wniosek-kredytowy"

  @FR-13
  Scenariusz: Timer z oznaczeniem eskalacji tworzy aktywną eskalację
    Zakładając instancję "K-010" z aktywnym zadaniem "OcenaWniosku" przypisanym do "anna"
    Jeżeli uruchamia się zdarzenie "SlaOcenyPrzekroczone" z poziomem eskalacji 1
    Wtedy lista eskalowanych osoby "marta" zawiera sprawę "K-010" z etapem "Ocena", poziomem 1 i osobą "anna"

  @FR-13
  Scenariusz: Eskalacja wygasa wraz z zakresem
    Zakładając aktywną eskalację sprawy "K-010" na zadaniu "OcenaWniosku"
    Jeżeli "anna" kończy zadanie "OcenaWniosku" w sprawie "K-010"
    Wtedy sprawa "K-010" nie jest na liście aktywnych eskalacji
    Oraz historia sprawy "K-010" zawiera eskalację z czasem trwania

  @FR-13
  Scenariusz: Naruszenie SLA bez eskalacji w BPMN to osobna kategoria
    Zakładając zadanie "OcenaWniosku" w sprawie "K-011" po celu SLA etapu "Ocena"
    Jeżeli "marta" otwiera listę eskalowanych
    Wtedy sprawa "K-011" jest w kategorii "po terminie", a nie "eskalowane"

  @FR-13
  Scenariusz: Eskalacje innych procesów są niewidoczne
    Zakładając aktywną eskalację w procesie "weryfikacja-aml"
    Jeżeli "marta" otwiera listę eskalowanych
    Wtedy lista nie zawiera spraw procesu "weryfikacja-aml"
````

## Plik: specs/insight/process-dashboard.feature

````gherkin
# language: pl
Funkcja: Dashboard menadżera procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz w okresie "2026-10-01" – "2026-10-31" w procesie "wniosek-kredytowy":
      | sprawa | start      | koniec     | zdarzenie końcowe     | wynik    | incydent |
      | K-101  | 2026-10-02 | 2026-10-05 | WniosekZaakceptowany  | success  | nie      |
      | K-102  | 2026-10-03 | 2026-10-06 | WniosekOdrzucony      | rejected | nie      |
      | K-103  | 2026-10-04 | 2026-10-04 | BladIntegracji        | error    | nie      |
      | K-104  | 2026-10-10 |            |                       |          | tak      |
      | K-105  | 2026-10-12 |            |                       |          | nie      |

  @FR-14
  Scenariusz: Liczniki wyników rozróżniają sukces, odmowę i błąd
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy liczniki wynoszą:
      | wystartowane | sukces | negatywnie | błąd | aktywne | z incydentem |
      | 5            | 1      | 1          | 1    | 2       | 1            |

  @FR-14
  Scenariusz: Progi zdrowia kolorują metrykę
    Zakładając próg wskaźnika incydentów: zielony do 5%, bursztynowy do 15%, powyżej czerwony
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy wskaźnik incydentów wynosi 20% ze statusem "czerwony"

  @FR-14
  Scenariusz: Metryka bez progów nie ma koloru
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy" za okres "2026-10-01" – "2026-10-31"
    Wtedy metryka "przepustowość" nie ma statusu zdrowia

  @FR-14
  Scenariusz: Dashboard pokazuje świeżość danych
    Zakładając opóźnienie projektora 3 sekundy
    Jeżeli "marta" otwiera dashboard procesu "wniosek-kredytowy"
    Wtedy widzi informację "dane sprzed 3 s"

  @FR-14
  Scenariusz: Dashboard procesu spoza zakresu jest niedostępny
    Jeżeli "marta" otwiera dashboard procesu "weryfikacja-aml"
    Wtedy operacja jest odrzucona brakiem uprawnienia "Insight.Dashboard"
````

## Plik: specs/insight/stage-map.feature

````gherkin
# language: pl
Funkcja: Mapa etapów jako warstwa biznesowa nad BPMN

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz wdrożona wersja 7 procesu "wniosek-kredytowy" z elementami "WeryfikujDane", "OcenaWniosku", "WyliczOferte", "AkceptacjaKlienta", "WniosekZaakceptowany", "WniosekOdrzucony"

  @FR-15
  Scenariusz: Administrator mapuje elementy, menadżer nazywa etapy
    Jeżeli "adam" przypisuje element "OcenaWniosku" do etapu "ocena" w szkicu mapy wersji 7
    Oraz "marta" zmienia nazwę etapu "ocena" na "Ocena wniosku" i ustawia cel SLA "P2D"
    Wtedy szkic mapy zawiera etap "Ocena wniosku" z elementem "OcenaWniosku"

  @FR-15
  Scenariusz: Menadżer bez uprawnienia nie mapuje elementów
    Jeżeli "marta" przypisuje element "WyliczOferte" do etapu "oferta" w szkicu mapy wersji 7
    Wtedy operacja jest odrzucona brakiem uprawnienia "StageMap.MapElements"

  @FR-15
  Scenariusz: Element może należeć tylko do jednego etapu
    Zakładając, że element "OcenaWniosku" jest w etapie "ocena"
    Jeżeli "adam" przypisuje element "OcenaWniosku" do etapu "oferta" w szkicu mapy wersji 7
    Wtedy operacja jest odrzucona błędem "ElementAlreadyMapped"

  @FR-15
  Scenariusz: Publikacja wymaga zmapowania wszystkich user tasków
    Zakładając szkic mapy wersji 7 bez elementu "AkceptacjaKlienta"
    Jeżeli "adam" publikuje mapę wersji 7
    Wtedy publikacja jest odrzucona z błędem "UnmappedUserTask" dla "AkceptacjaKlienta"

  @FR-15
  Scenariusz: Nowa wersja definicji dziedziczy mapowanie i raportuje różnice
    Zakładając opublikowaną mapę wersji 7
    Jeżeli wdrożona zostaje wersja 8 z nowym elementem "WeryfikacjaDodatkowa"
    Wtedy powstaje szkic mapy wersji 8 z mapowaniami z wersji 7
    Oraz raport różnic wskazuje niezmapowany element "WeryfikacjaDodatkowa"

  @FR-16
  Szablon scenariusza: Stan etapów liczony z historii instancji
    Zakładając opublikowaną mapę wersji 7
    Oraz instancja "K-002" odwiedziła elementy "<odwiedzone>" i jest aktywna na "<aktywny>"
    Jeżeli "marta" otwiera instancję "K-002"
    Wtedy etap "Ocena" ma stan "<ocena>"
    Oraz etap "Oferta" ma stan "<oferta>"

    Przykłady:
      | odwiedzone                  | aktywny           | ocena     | oferta    |
      | WeryfikujDane               | OcenaWniosku      | Active    | Pending   |
      | WeryfikujDane,OcenaWniosku  | AkceptacjaKlienta | Completed | Active    |

  @FR-16
  Scenariusz: Aktywny element niezmapowany nie ujawnia swojej nazwy
    Zakładając opublikowaną mapę wersji 7, w której element techniczny "PobierzScoring" nie jest zmapowany
    Oraz instancja "K-003" jest aktywna na "PobierzScoring" po etapie "Ocena"
    Jeżeli "marta" otwiera instancję "K-003"
    Wtedy widzi etap "Ocena" z adnotacją "w toku"
    Ale nie widzi nazwy "PobierzScoring"

  @FR-16
  Scenariusz: Edytor formatki pokazuje etap jej zadania
    Zakładając opublikowaną mapę wersji 7
    Jeżeli "marta" otwiera formatkę zadania "OcenaWniosku"
    Wtedy widzi mapę etapów z zaznaczonym etapem "Ocena"
````

## Plik: specs/processes/start-process.feature

````gherkin
# language: pl
Funkcja: Start procesu z aplikacji i „moje procesy”

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz proces "wniosek-kredytowy" ma opublikowaną formatkę startową "F-wniosek"

  @FR-07
  Scenariusz: Uprawniona osoba startuje proces
    Jeżeli "anna" startuje proces "wniosek-kredytowy" formatką "F-wniosek" z poprawnymi danymi
    Wtedy w silniku powstaje instancja z tenantem "<default>"
    Oraz instancja ma zmienne "initiatorPartyId", "initiatorGroupIds" i "caseId"
    Oraz dziennik bezpieczeństwa zawiera "Process.Start" z wynikiem "Succeeded" dla "anna"

  @FR-07
  Scenariusz: Brak uprawnienia startu dla definicji
    Jeżeli "celina" startuje proces "wniosek-kredytowy" formatką "F-wniosek" z poprawnymi danymi
    Wtedy operacja jest odrzucona brakiem uprawnienia "Process.Start"
    Oraz silnik nie otrzymał żadnego wywołania

  @FR-07
  Scenariusz: Katalog startowy pokazuje tylko dozwolone procesy
    Jeżeli "anna" otwiera katalog procesów do startu
    Wtedy widzi proces "wniosek-kredytowy"
    Ale nie widzi procesu "weryfikacja-aml"

  @FR-08
  Scenariusz: Moje procesy pokazują bieżący etap bez technikaliów
    Zakładając, że "anna" wystartowała proces "wniosek-kredytowy" jako sprawę "K-001"
    Oraz instancja sprawy "K-001" jest na elemencie "OcenaWniosku"
    Jeżeli "anna" otwiera listę "Moje procesy"
    Wtedy sprawa "K-001" ma bieżący etap "Ocena"
````

## Plik: specs/profiles/project-profiles.feature

````gherkin
# language: pl
Funkcja: Profile projektów — część wspólna i część specyficzna
  Jako bank
  Chcę, aby każdy projekt korzystał z tej samej platformy przez własny profil
  Aby zespoły projektów realizowały swoje potrzeby niezależnie i bez wpływu na inne projekty

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zarejestrowane profile "kredyty" (procesy: wniosek-kredytowy, aneks-kredytowy) i "aml" (procesy: weryfikacja-aml)
    Oraz zadanie "T1" procesu "wniosek-kredytowy" typu "OcenaWniosku" przypisane do "anna"
    Oraz zadanie "T3" procesu "weryfikacja-aml" typu "AnalizaAml" przypisane do "darek"

  @FR-23
  Scenariusz: Manifest przypisujący proces innego profilu jest odrzucony
    Jeżeli zespół profilu "aml" zgłasza manifest z procesem "wniosek-kredytowy"
    Wtedy walidacja manifestu kończy się błędem "proces należy już do profilu kredyty"
    Oraz rejestr profili pozostaje bez zmian

  @FR-23
  Scenariusz: Manifest z uprawnieniem spoza przestrzeni nazw profilu jest odrzucony
    Jeżeli zespół profilu "aml" zgłasza manifest z uprawnieniem "kredyty.Case.Export"
    Wtedy walidacja manifestu kończy się błędem reguły "R10"

  @FR-24
  Szablon scenariusza: Rola projektowa działa tylko w procesach swojego profilu
    Jeżeli "<osoba>" sprawdza uprawnienie "<uprawnienie>" dla zadania "<zadanie>"
    Wtedy wynik to "<wynik>"

    Przykłady:
      | osoba | uprawnienie                 | zadanie | wynik                                  |
      | anna  | kredyty.Scoring.Recalculate | T1      | Allowed: kredyty/analityk-kredytowy    |
      | anna  | kredyty.Scoring.Recalculate | T3      | Denied: R9                             |
      | darek | aml.Sanctions.Recheck       | T3      | Allowed: aml/analityk-aml              |
      | darek | kredyty.Scoring.Recalculate | T1      | Denied: brak uprawnienia               |
      | olga  | kredyty.Applicant.View      | T1      | Denied: brak uprawnienia               |

  @FR-24
  Scenariusz: Audyt zapisuje rolę projektową i profil
    Jeżeli "celina" przejmuje zadanie "T2" procesu "wniosek-kredytowy" typu "AkceptacjaUnderwritera"
    Wtedy dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Succeeded", rolą "kredyty/underwriter" i profilem "kredyty"

  @FR-25
  Scenariusz: Operacja dedykowana pojawia się w akcjach zadania tylko dla uprawnionego assignee
    Jeżeli "anna" pobiera szczegóły zadania "T1"
    Wtedy dozwolone akcje zawierają "kredyty.RecalculateScoring"
    Ale "bartek" pobierający szczegóły zadania "T1" nie widzi akcji "kredyty.RecalculateScoring"

  @FR-25
  Scenariusz: Operacji profilu nie można wykonać na zadaniu innego profilu
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T3"
    Wtedy operacja jest odrzucona regułą "R9"
    Oraz kod profilu "kredyty" nie został wywołany
    Oraz dziennik bezpieczeństwa zawiera "kredyty.RecalculateScoring" z wynikiem "Denied" i kodem "R9"

  @FR-25
  Scenariusz: Awaria operacji profilu nie blokuje pracy na zadaniu
    Zakładając operacja "kredyty.RecalculateScoring" przekracza limit czasu
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja kończy się błędem "ProfileOperationTimeout"
    Oraz "anna" nadal może zapisać szkic i zakończyć zadanie "T1"

  @FR-26
  Scenariusz: Wzbogacenie widoku zadania tylko w procesach profilu
    Jeżeli "anna" pobiera szczegóły zadania "T1"
    Wtedy widok zawiera sekcję "extensions.kredyty"
    Ale widok zadania "T3" pobrany przez "darek" nie zawiera sekcji "extensions.kredyty"

  @FR-26 @integration
  Scenariusz: Kod profilu nie czyta danych platformy ani innego profilu
    Zakładając kod profilu "kredyty" działa w kontekście bazy "prj_kredyty"
    Jeżeli kod profilu odczytuje tabelę "task.WorkItem"
    Wtedy baza odmawia dostępu
    Oraz odczyt tabeli "prj_aml.WynikSankcji" również kończy się odmową bazy

  @FR-27
  Scenariusz: Slot UI profilu pojawia się tylko przy zadaniach jego procesów
    Jeżeli "anna" otwiera zadanie "T1"
    Wtedy panel "Wnioskodawca" profilu "kredyty" jest widoczny
    Ale "darek" otwierający zadanie "T3" nie widzi panelu "Wnioskodawca"
````

## Plik: specs/tasks/claim-and-complete.feature

````gherkin
# language: pl
Funkcja: Przejęcie, edycja i zakończenie zadania

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T2" procesu "wniosek-kredytowy" dla grupy "kre-underwriting" nieprzypisane

  @FR-01 @FR-02 @FR-04
  Scenariusz: Członek grupy kandydującej przejmuje zadanie
    Jeżeli "celina" przejmuje zadanie "T2"
    Wtedy assignee zadania "T2" to "celina"
    Oraz zadanie "T2" jest na liście "Moje zadania" osoby "celina"
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Succeeded" dla "celina"

  @FR-04
  Scenariusz: Osoba spoza grupy kandydującej nie przejmie zadania
    Jeżeli "anna" przejmuje zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz silnik nie otrzymał żadnego wywołania
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Denied" dla "anna"

  @FR-04 @integration
  Scenariusz: Wyścig o to samo zadanie rozstrzyga silnik
    Jeżeli "celina" i "ewa" jednocześnie przejmują zadanie "T2"
    Wtedy dokładnie jedna operacja kończy się sukcesem
    Oraz druga otrzymuje konflikt z informacją, kto przejął zadanie

  @FR-05
  Scenariusz: Zwolnić zadanie może tylko assignee
    Zakładając, że "celina" przejęła zadanie "T2"
    Jeżeli "ewa" zwalnia zadanie "T2"
    Wtedy operacja jest odrzucona regułą "R1"

  @FR-06
  Szablon scenariusza: Szkic i zakończenie tylko przez assignee
    Zakładając, że "celina" przejęła zadanie "T2"
    Jeżeli "<osoba>" wykonuje akcję "<akcja>" na zadaniu "T2"
    Wtedy wynik operacji to "<wynik>"

    Przykłady:
      | osoba  | akcja    | wynik     |
      | celina | szkic    | Succeeded |
      | celina | zakończ  | Succeeded |
      | ewa    | szkic    | Denied:R1 |
      | marta  | zakończ  | Denied:R1 |
      | olga   | zakończ  | Denied:R1 |

  @FR-06
  Scenariusz: Ponowione zakończenie nie wykonuje się dwa razy
    Zakładając, że "celina" zakończyła zadanie "T2" żądaniem "req-42"
    Jeżeli "celina" ponawia zakończenie zadania "T2" żądaniem "req-42"
    Wtedy silnik otrzymał dokładnie jedno wywołanie zakończenia
    Oraz operacja kończy się sukcesem
````

## Plik: specs/tasks/reassignment.feature

````gherkin
# language: pl
Funkcja: Przekazanie zadania przez menadżera procesu w trakcie procesu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" dla grupy "kre-analitycy" przypisane do "anna" ze szkicem

  @FR-11
  Scenariusz: Przekazanie osobie z powodem
    Jeżeli "marta" przekazuje zadanie "T1" osobie "bartek" z powodem "urlop"
    Wtedy assignee zadania "T1" to "bartek"
    Oraz szkic zadania "T1" jest widoczny dla "bartek" z adnotacją o poprzednim wykonawcy
    Oraz "anna" i "bartek" otrzymują powiadomienie
    Oraz dziennik bezpieczeństwa zawiera "Task.Reassign" z poprzednim wykonawcą "anna" i nowym "bartek"

  @FR-11
  Scenariusz: Przekazanie grupie zwalnia zadanie
    Jeżeli "marta" przekazuje zadanie "T1" grupie "kre-underwriting" z powodem "obciążenie"
    Wtedy zadanie "T1" jest nieprzypisane z grupą kandydującą "kre-underwriting"
    Oraz zadanie "T1" jest widoczne do przejęcia dla "celina"

  @FR-11
  Scenariusz: Powód jest obowiązkowy
    Jeżeli "marta" przekazuje zadanie "T1" osobie "bartek" bez powodu
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-11
  Scenariusz: Nie można przekazać osobie bez roli uczestnika w procesie
    Jeżeli "marta" przekazuje zadanie "T1" osobie "darek" z powodem "urlop"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-11
  Scenariusz: Menadżer przekazuje, ale nie edytuje
    Zakładając, że "marta" przekazała zadanie "T1" osobie "bartek"
    Jeżeli "marta" wykonuje akcję "szkic" na zadaniu "T1"
    Wtedy wynik operacji to "Denied:R1"

  @FR-11
  Scenariusz: Przekazanie masowe wszystkich zadań nieobecnej osoby
    Zakładając, że "anna" ma 3 aktywne zadania w procesie "wniosek-kredytowy"
    Jeżeli "marta" przekazuje masowo zadania osoby "anna" osobie "bartek" z powodem "urlop"
    Wtedy raport partii zawiera 3 pozycje ze stanem "Done"
    Oraz każde przekazanie ma osobny wpis w dzienniku bezpieczeństwa z identyfikatorem partii

  @FR-11
  Scenariusz: Wznowienie partii po awarii nie dubluje przekazań
    Zakładając partię przekazania 3 zadań przerwaną po 2 pozycjach
    Jeżeli partia zostaje wznowiona
    Wtedy silnik otrzymał dokładnie 3 wywołania przypisania
````

## Plik: specs/tasks/substitution.feature

````gherkin
# language: pl
Funkcja: Zastępstwa podczas nieobecności

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz "anna" jest nieobecna od "2026-11-02" do "2026-11-06" z zastępcą "bartek"

  @FR-12
  Scenariusz: Nowe zadanie przypisane do nieobecnej trafia do zastępcy
    Zakładając bieżącą datę "2026-11-03"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy assignee nowego zadania to "bartek"
    Oraz dziennik bezpieczeństwa zawiera "Substitution.Applied" z nieobecną "anna" i zastępcą "bartek"

  @FR-12
  Scenariusz: Poza okresem nieobecności nie ma korekty
    Zakładając bieżącą datę "2026-11-09"
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy assignee nowego zadania to "anna"

  @FR-12
  Scenariusz: Nakładające się nieobecności są odrzucane
    Jeżeli "anna" zgłasza nieobecność od "2026-11-05" do "2026-11-10" z zastępcą "piotr"
    Wtedy operacja jest odrzucona błędem "AbsenceOverlap"

  @FR-12
  Scenariusz: Zastępca musi mieć rolę uczestnika w procesie
    Jeżeli "marta" rejestruje nieobecność osoby "bartek" z zastępcą "darek" dla procesu "wniosek-kredytowy"
    Wtedy operacja jest odrzucona regułą "R6"

  @FR-12 @integration
  Scenariusz: Awaria platformy nie blokuje tworzenia zadania
    Zakładając, że baza platformy jest niedostępna dla workera zastępstw
    Jeżeli w procesie "wniosek-kredytowy" powstaje zadanie przypisane do "anna"
    Wtedy zadanie powstaje w silniku bez korekty
    Oraz po przywróceniu bazy job uzgadniający przekazuje je osobie "bartek"
````

