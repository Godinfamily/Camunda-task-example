# 09-narzedzia-kod — Kod narzędzi repozytorium (opcjonalne źródło): wycena, eksport, artefakty, generator agentów, prowadzenie kroków, strażnik, profile

Pakiet zawiera 14 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: tools/plan/estimate.py

````python
#!/usr/bin/env python3
"""Model szacowania pracochłonności planu (hybryda AI + ludzie).

Wejście:  plan/backlog.yaml (kroki, zależności, bramki), plan/estimates.yaml (oceny), plan/estimation-params.yaml
          opcjonalnie plan/progress/<krok>.effort.json: {"step": "S10", "actual_human_pd": 3.5} (kalibracja)
Wyjście:  plan/estimation-report.md (generowany) albo --check (kod 1, gdy raport nieaktualny)

Model (opis w plan/estimation.md):
  C        = Σ waga × ocena (T, N, I, B)                                indeks złożoności 1–5
  E_trad   = (O + 4M + P) / 6,  σ = (P − O) / 6                         PERT, osobodni bez AI
  f        = (1 − ai_share) + ai_share × review                         udział pracy ludzi w hybrydzie
  E_hyb    = E_trad × f × k                                             k = współczynnik kalibracji (domyślnie 1)
  dni_kal  = E_hyb / parallel_factor[rozmiar] (+ oczekiwanie na bramkę), dla S54 max z kalendarzem zewnętrznym
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
ROLE_OF_AGENT = {"module-implementer": "backend_dotnet", "camunda-integrator": "backend_dotnet", "data-engineer": "backend_dotnet",
                 "frontend-developer": "frontend_angular", "bdd-tester": "qa_bdd", "bdd-analyst": "product_owner_analityk",
                 "architect": "architekt_tech_lead", "security-reviewer": "bezpieczenstwo", "orchestrator": "architekt_tech_lead",
                 "ux-designer": "ux_designer", "design-system-engineer": "frontend_angular", "ui-reviewer": "ux_designer"}
ROLE_SPLIT = {  # kroki prowadzone przez ludzi lub z wyraźnym podziałem ról
    "S00": {"architekt_tech_lead": 0.6, "devops": 0.4},
    "S01": {"backend_dotnet": 0.6, "devops": 0.2, "architekt_tech_lead": 0.2},
    "S02": {"backend_dotnet": 0.4, "bezpieczenstwo": 0.3, "architekt_tech_lead": 0.3},
    "S06": {"devops": 0.7, "backend_dotnet": 0.15, "architekt_tech_lead": 0.15},
    "S07": {"frontend_angular": 0.65, "ux_designer": 0.2, "architekt_tech_lead": 0.15},
    "S09": {"ux_designer": 0.7, "frontend_angular": 0.15, "product_owner_analityk": 0.15},
    "S16": {"frontend_angular": 0.85, "ux_designer": 0.15},
    "S19": {"architekt_tech_lead": 0.4, "backend_dotnet": 0.45, "frontend_angular": 0.15},
    "S27": {"backend_dotnet": 0.5, "bezpieczenstwo": 0.25, "architekt_tech_lead": 0.15, "devops": 0.1},
    "S40": {"frontend_angular": 0.9, "ux_designer": 0.1},
    "S45": {"frontend_angular": 0.9, "ux_designer": 0.1},
    "S48": {"architekt_tech_lead": 0.5, "product_owner_analityk": 0.3, "qa_bdd": 0.2},
    "S49": {"frontend_angular": 0.75, "ux_designer": 0.25},
    "S50": {"qa_bdd": 0.5, "backend_dotnet": 0.3, "devops": 0.2},
    "S51": {"bezpieczenstwo": 0.5, "qa_bdd": 0.3, "backend_dotnet": 0.2},
    "S53": {"frontend_angular": 0.7, "ux_designer": 0.3},
    "S54": {"bezpieczenstwo": 0.5, "architekt_tech_lead": 0.3, "product_owner_analityk": 0.2},
    "S55": {"frontend_angular": 0.6, "qa_bdd": 0.25, "ux_designer": 0.15},
    "S60": {"product_owner_analityk": 0.4, "devops": 0.3, "architekt_tech_lead": 0.3},
}
ROLE_LABEL = {"architekt_tech_lead": "Architekt / tech lead", "backend_dotnet": "Backend .NET", "frontend_angular": "Frontend Angular",
              "devops": "DevOps", "qa_bdd": "QA / BDD", "product_owner_analityk": "PO / analityk", "bezpieczenstwo": "Bezpieczeństwo",
              "ux_designer": "Projektant UX"}


def pert(o, m, p):
    return (o + 4 * m + p) / 6, (p - o) / 6


def load():
    backlog = yaml.safe_load((ROOT / "plan/backlog.yaml").read_text(encoding="utf-8"))
    est = yaml.safe_load((ROOT / "plan/estimates.yaml").read_text(encoding="utf-8"))["steps"]
    params = yaml.safe_load((ROOT / "plan/estimation-params.yaml").read_text(encoding="utf-8"))
    actuals = {}
    for f in sorted(glob.glob(str(ROOT / "plan/progress/*.effort.json"))):
        try:
            d = json.loads(Path(f).read_text(encoding="utf-8"))
            if "actual_human_pd" in d:
                actuals[d["step"]] = float(d["actual_human_pd"])
        except (ValueError, KeyError):
            continue
    return backlog, est, params, actuals


def compute(backlog, est, params, actuals, mode="hyb"):
    steps = {s["id"]: s for s in backlog["steps"]}
    missing = sorted(set(steps) - set(est)) + sorted(set(est) - set(steps))
    if missing:
        raise SystemExit(f"Niespójność backlog.yaml ↔ estimates.yaml: {missing}")
    w = params["weights"]
    rows = {}
    for sid, s in steps.items():
        e = est[sid]
        c = sum(w[k] * e[k] for k in "TNIB")
        cls = next(x["name"] for x in params["classes"] if c <= x["max"])
        tm, ts = pert(*e["trad_pd"])
        f = (1 - e["ai_share"]) + e["ai_share"] * e["review"]
        rows[sid] = {"id": sid, "title": s["title"], "phase": s.get("phase"), "size": s.get("size", "M"), "agent": s.get("agent"),
                     "C": c, "cls": cls, "e": e, "trad": tm, "trad_s": ts, "f": f, "hyb": tm * f, "hyb_s": ts * f,
                     "deps": s.get("depends_on", []), "gate": s.get("gate_before"), "critical_flag": bool(s.get("critical"))}
    # kalibracja: średni stosunek rzeczywistość / szacunek dla zakończonych kroków
    done = [sid for sid in actuals if sid in rows and rows[sid]["hyb"] > 0]
    k = (sum(actuals[s] / rows[s]["hyb"] for s in done) / len(done)) if done else 1.0
    for sid, r in rows.items():
        if mode == "trad":
            r["hyb_final"], r["hyb_final_s"] = r["trad"], r["trad_s"]
        elif sid in actuals:
            r["hyb_final"], r["hyb_final_s"] = actuals[sid], 0.0
        else:
            r["hyb_final"], r["hyb_final_s"] = r["hyb"] * k, r["hyb_s"] * k
        pf = params["calendar"]["parallel_factor"].get(r["size"], 1.0)
        dur, dur_s = r["hyb_final"] / pf, r["hyb_final_s"] / pf
        ext = r["e"].get("external_calendar_days")
        if ext:
            em, es = pert(*ext)
            if em > dur:
                dur, dur_s = em, es
        if r["gate"]:
            gm, gs = pert(*params["calendar"]["gate_wait_days"][r["gate"]])
            dur += gm
            dur_s = math.sqrt(dur_s ** 2 + gs ** 2)
        r["dur"], r["dur_s"] = dur, dur_s
    # ścieżka krytyczna (najdłuższa wg kalendarza)
    memo = {}

    def finish(sid):
        if sid not in memo:
            r = rows[sid]
            best = max(r["deps"], key=lambda d: finish(d)[0], default=None)
            base = (0.0, 0.0, []) if best is None else finish(best)
            memo[sid] = (base[0] + r["dur"], base[1] + r["dur_s"], base[2] + [sid])  # σ sumowane liniowo: ryzyka skorelowane
        return memo[sid]

    end = max(rows, key=lambda s: finish(s)[0])
    cp_days, cp_sig, cp_path = finish(end)
    # obciążenie ról
    ov = params["overheads"]
    role_load = {r: 0.0 for r in params["team_fte"]}
    for sid, r in rows.items():
        split = ROLE_SPLIT.get(sid) or {ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        for role, share in split.items():
            role_load[role] += r["hyb_final"] * share
    base_hyb = sum(r["hyb_final"] for r in rows.values())
    sup = 0.0 if mode == "trad" else ov["swarm_supervision"]
    role_load["architekt_tech_lead"] += base_hyb * (sup + ov["coordination"] * 0.4)
    role_load["product_owner_analityk"] += base_hyb * ov["coordination"] * 0.6
    util = params["utilization"]
    role_days = {role: (load / (params["team_fte"][role] * util) if params["team_fte"][role] else float("inf"))
                 for role, load in role_load.items()}
    return rows, (cp_days, cp_sig, cp_path), role_load, role_days, k, done


def fmt(x, n=1):
    return f"{x:,.{n}f}".replace(",", " ").replace(".", ",")


def report(rows, cp, role_load, role_days, k, done, params, trad_view):
    z = params["percentile_z"]
    ov = params["overheads"]
    mult_h = 1 + ov["swarm_supervision"] + ov["coordination"]
    mult_t = 1 + ov["coordination"]
    trad = sum(r["trad"] for r in rows.values())
    trad_s = sum(r["trad_s"] for r in rows.values())            # ostrożnie: ryzyka skorelowane
    hyb = sum(r["hyb_final"] for r in rows.values())
    hyb_s = sum(r["hyb_final_s"] for r in rows.values())
    cp_days, cp_s, cp_path = cp
    t_cp, t_role_days = trad_view
    fte = sum(params["team_fte"].values())
    bn = max(role_days, key=role_days.get)
    t_bn = max(t_role_days, key=t_role_days.get)
    cal = max(cp_days, role_days[bn])
    cal80 = max(cp_days + z * cp_s, role_days[bn] * (1 + z * hyb_s / hyb))
    t_cal = max(t_cp[0], t_role_days[t_bn])
    t_cal80 = max(t_cp[0] + z * t_cp[1], t_role_days[t_bn] * (1 + z * trad_s / trad))
    util = params["utilization"]
    out = ["<!-- WYGENEROWANE przez tools/plan/estimate.py — nie edytuj ręcznie -->",
           "# Raport szacowania (generowany)", "",
           f"Kalibracja: {'brak danych rzeczywistych, k = 1,0' if not done else f'k = {fmt(k, 2)} z {len(done)} zakończonych kroków'}. "
           f"Zespół referencyjny: {fmt(fte)} FTE, wykorzystanie {int(util*100)}%. P80 liczone ostrożnie: odchylenia kroków sumowane liniowo (ryzyka skorelowane).", "",
           "## Podsumowanie", "",
           "| Wielkość | Bez AI: oczekiwane | Bez AI: P80 | Hybryda: oczekiwane | Hybryda: P80 |", "| --- | --- | --- | --- | --- |",
           f"| Praca ludzi w krokach (osobodni) | {fmt(trad, 0)} | {fmt(trad + z * trad_s, 0)} | {fmt(hyb, 0)} | {fmt(hyb + z * hyb_s, 0)} |",
           f"| Praca ludzi z narzutami (osobodni) | {fmt(trad * mult_t, 0)} | {fmt((trad + z * trad_s) * mult_t, 0)} | {fmt(hyb * mult_h, 0)} | {fmt((hyb + z * hyb_s) * mult_h, 0)} |",
           f"| Ścieżka krytyczna z bramkami (dni robocze) | {fmt(t_cp[0], 0)} | {fmt(t_cp[0] + z * t_cp[1], 0)} | {fmt(cp_days, 0)} | {fmt(cp_days + z * cp_s, 0)} |",
           f"| Najbardziej obciążona rola (dni robocze) | {fmt(t_role_days[t_bn], 0)} ({ROLE_LABEL[t_bn]}) | — | {fmt(role_days[bn], 0)} ({ROLE_LABEL[bn]}) | — |",
           f"| **Czas kalendarzowy** (większa z dwóch powyższych) | **{fmt(t_cal / 5, 0)} tyg.** | **{fmt(t_cal80 / 5, 0)} tyg.** | **{fmt(cal / 5, 0)} tyg.** | **{fmt(cal80 / 5, 0)} tyg.** |",
           "", "Narzuty: hybryda = nadzór roju + koordynacja; bez AI = koordynacja. Czas pracy agentów nie jest wąskim gardłem — ogranicza go przegląd i decyzje ludzi.", "",
           "## Kroki", "",
           "| Krok | Tytuł | C | Klasa | T/N/I/B | AI | Bez AI (od) | Hybryda (od) | Oszczędność | Dni kal. | Ścieżka kryt. |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for r in sorted(rows.values(), key=lambda r: (r["phase"], r["id"])):
        e = r["e"]
        out.append(f"| {r['id']} | {r['title'][:70]} | {fmt(r['C'], 2)} | {r['cls']} | {e['T']}/{e['N']}/{e['I']}/{e['B']} | {int(e['ai_share']*100)}% | "
                   f"{fmt(r['trad'])} | {fmt(r['hyb_final'])} | {int(round((1 - r['hyb_final']/r['trad'])*100))}% | {fmt(r['dur'])} | {'tak' if r['id'] in cp_path else ''} |")
    out += ["", "## Fazy", "", "| Faza | Bez AI (od) | Hybryda (od) | Oszczędność |", "| --- | --- | --- | --- |"]
    for ph in sorted({r["phase"] for r in rows.values()}):
        t = sum(r["trad"] for r in rows.values() if r["phase"] == ph)
        h = sum(r["hyb_final"] for r in rows.values() if r["phase"] == ph)
        out.append(f"| {ph} | {fmt(t)} | {fmt(h)} | {int(round((1-h/t)*100))}% |")
    out += ["", "## Obciążenie ról (z narzutami)", "", "| Rola | FTE | Praca (od) | Dni robocze przy wykorzystaniu |", "| --- | --- | --- | --- |"]
    for role in sorted(role_load, key=lambda x: -role_days[x]):
        out.append(f"| {ROLE_LABEL[role]} | {fmt(params['team_fte'][role])} | {fmt(role_load[role])} | {fmt(role_days[role], 0)} |")
    out += ["", "## Ścieżka krytyczna", "", " → ".join(cp_path), "",
            "## Ranking złożoności", "", "| Miejsce | Krok | C | Główny czynnik |", "| --- | --- | --- | --- |"]
    for i, r in enumerate(sorted(rows.values(), key=lambda r: -r["C"]), 1):
        out.append(f"| {i} | {r['id']} {r['title'][:55]} | {fmt(r['C'], 2)} | {r['e']['driver']} |")
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--json", action="store_true", help="wypisz podsumowanie jako JSON")
    a = ap.parse_args()
    backlog, est, params, actuals = load()
    rows, cp, role_load, role_days, k, done = compute(backlog, est, params, actuals)
    _, t_cp, _, t_role_days, _, _ = compute(backlog, est, params, actuals, mode="trad")
    text = report(rows, cp, role_load, role_days, k, done, params, (t_cp, t_role_days))
    path = ROOT / "plan/estimation-report.md"
    if a.json:
        print(json.dumps({"cp_days": cp[0], "cp_sigma": cp[1], "cp_path": cp[2], "role_days": role_days, "trad_cp": t_cp[:2], "trad_role_days": t_role_days,
                          "trad": sum(r["trad"] for r in rows.values()), "hyb": sum(r["hyb_final"] for r in rows.values())},
                         ensure_ascii=False, indent=1))
        return 0
    if a.check:
        ok = path.exists() and path.read_text(encoding="utf-8") == text
        print("aktualny" if ok else "NIEAKTUALNY: uruchom python3 tools/plan/estimate.py", file=sys.stderr)
        return 0 if ok else 1
    path.write_text(text, encoding="utf-8")
    print(f"zapisano {path.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/plan/export_dashboard_data.py

````python
#!/usr/bin/env python3
"""Eksport danych planu do zbiorów dashboardu harmonogramu (plan/dashboard/data/*.json).

Źródła: plan/backlog.yaml, plan/estimates.yaml, plan/estimation-params.yaml, plan/dashboard/register.yaml
oraz model z tools/plan/estimate.py. Uruchom po każdej zmianie planu lub szacunków, potem podmień pliki w dashboardzie.
"""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "plan/dashboard/data"
spec = importlib.util.spec_from_file_location("est", ROOT / "tools/plan/estimate.py")
est = importlib.util.module_from_spec(spec)
spec.loader.exec_module(est)

PHASES = {0: "Przygotowanie i PoC", 1: "Fundament", 2: "Dostęp, Camunda, audyt, formatki", 3: "Funkcje rdzenia",
          4: "Frontend funkcjonalny", 5: "Integracja i hardening", 6: "Pilotaż"}
AGENT_LABEL = {"human": "Ludzie", "module-implementer": "Implementer modułu", "camunda-integrator": "Agent Camunda",
               "data-engineer": "Agent danych", "frontend-developer": "Agent frontendu", "bdd-tester": "Tester BDD",
               "bdd-analyst": "Analityk BDD", "architect": "Architekt", "security-reviewer": "Recenzent bezpieczeństwa",
               "docs-writer": "Dokumentalista", "ux-designer": "Agent UX", "design-system-engineer": "Agent design systemu",
               "ui-reviewer": "Recenzent UI"}
SCOPES = {  # zakres główny, zakresy dodatkowe
    "S00": ["Infrastruktura"], "S01": ["Camunda", "Backend"], "S02": ["Bezpieczeństwo", "Camunda"], "S03": ["Camunda"],
    "S04": ["Camunda", "Dane"], "S05": ["Biznes", "Testy"], "S06": ["Infrastruktura", "Camunda", "Dane", "Bezpieczeństwo"],
    "S07": ["Frontend", "Camunda"], "S08": ["Camunda", "Backend"], "S09": ["Frontend", "Biznes"],
    "S10": ["Backend"], "S11": ["Testy", "Infrastruktura"], "S12": ["Backend", "Bezpieczeństwo"], "S13": ["Dane", "Bezpieczeństwo"],
    "S14": ["Testy"], "S15": ["Backend", "Frontend"], "S16": ["Frontend"], "S17": ["Camunda"], "S18": ["Bezpieczeństwo", "Backend"], "S19": ["Backend", "Frontend"],
    "S20": ["Backend"], "S21": ["Bezpieczeństwo", "Camunda"], "S22": ["Camunda", "Backend"], "S23": ["Camunda", "Dane"],
    "S24": ["Bezpieczeństwo", "Backend", "Dane"], "S25": ["Bezpieczeństwo", "Dane"], "S26": ["Backend", "Biznes"], "S27": ["Bezpieczeństwo", "Dane"],
    "S28": ["Dane"], "S29": ["Camunda", "Backend"], "S39": ["Backend"], "S49": ["Frontend"], "S55": ["Frontend", "Testy"],
    "S30": ["Backend", "Camunda"], "S31": ["Backend", "Camunda"], "S32": ["Backend"], "S33": ["Camunda"],
    "S34": ["Backend", "Biznes"], "S35": ["Backend"], "S36": ["Dane", "Biznes"], "S37": ["Backend", "Frontend"], "S38": ["Backend", "Testy"],
    "S40": ["Frontend"], "S41": ["Frontend"], "S42": ["Frontend"], "S43": ["Frontend"], "S44": ["Frontend", "Camunda"],
    "S45": ["Frontend"], "S46": ["Frontend"], "S47": ["Frontend"], "S48": ["Biznes"], "S50": ["Testy", "Infrastruktura"], "S51": ["Bezpieczeństwo", "Testy"],
    "S52": ["Dane", "Testy"], "S53": ["Frontend", "Testy"], "S54": ["Bezpieczeństwo", "Biznes"], "S60": ["Biznes", "Infrastruktura"]}
EXTERNAL = {"S02": "decyzja zespołu bezpieczeństwa", "S05": "dostępność biznesu na warsztatach", "S06": "dostępy i procedury IT banku",
            "S09": "dostępność projektanta UX i księgi znaku banku", "S16": "licencja Kendo UI i dostęp do rejestru npm", "S54": "termin zewnętrznego pentestu i akceptacje compliance",
            "S48": "dostępność zespołów profili projektów",
            "S60": "gotowość obszaru biznesowego, szkolenia i profilu pilotażowego (zespół projektu)"}
RISK_LABEL = {1: "niskie", 2: "niskie", 3: "średnie", 4: "wysokie", 5: "krytyczne"}
APPROVER = {"architect-human": "Architekt", "product-owner": "Product Owner", "tech-lead": "Tech lead",
            "security": "Bezpieczeństwo", "compliance": "Compliance"}
SHORT = {"S00": "Repozytorium i harness", "S01": "PoC SDK Camunda", "S02": "PoC autoryzacji", "S03": "PoC task listenera",
         "S04": "PoC zasilania read modelu", "S05": "Scenariusze z biznesem", "S06": "Środowisko dev w banku",
         "S07": "PoC formatek w UI", "S08": "PoC walidacji i FEEL", "S09": "Warstwa wizualna i Figma",
         "S10": "Szkielet rozwiązania", "S11": "Testy architektury i CI", "S12": "Building Blocks", "S13": "Baza MSSQL",
         "S14": "Harness BDD", "S15": "Kontrakty v1 i OpenAPI", "S16": "Frontend: shell i ui-kit", "S17": "bpmnlint i modele BPMN",
         "S18": "BFF i logowanie RHBK", "S19": "SDK rozszerzeń i rejestr profili", "S20": "Party i zastępstwa", "S21": "Autoryzacje jako kod", "S22": "Adaptery SDK",
         "S23": "Projekcja read modelu", "S24": "Polityka dostępu R1–R11", "S25": "Audyt", "S26": "Formatki: cykl życia", "S27": "Izolacja profili",
         "S28": "Formatki: schemat bazy", "S29": "Formatki: powiązania z BPMN", "S39": "Formatki: wycofanie i przepięcie",
         "S49": "UI: komponenty pól", "S55": "Zgodność i spójność formatek",
         "S30": "Praca na zadaniach", "S31": "Start procesu", "S32": "Przekazywanie zadań", "S33": "Zastępstwa (listener)",
         "S34": "Mapa etapów", "S35": "Eskalacje", "S36": "Dashboard menadżera", "S37": "Form Runtime", "S38": "Operacje profili",
         "S40": "UI: zadania i renderer formatek", "S41": "UI: start i moje procesy", "S42": "UI: dashboard i etapy", "S43": "UI: przekazywanie",
         "S44": "UI: edytor mapy etapów", "S45": "UI: projektant formatek", "S46": "UI: audytor", "S47": "UI: sloty profili", "S48": "Onboarding zespołów profili", "S50": "Testy end-to-end",
         "S51": "Testy bezpieczeństwa", "S52": "Wydajność", "S53": "Dostępność i UX", "S54": "Pentest i compliance", "S60": "Pilotaż"}


def schedule(rows):
    order, seen = [], set()

    def visit(s):
        if s in seen:
            return
        seen.add(s)
        for d in rows[s]["deps"]:
            visit(d)
        order.append(s)
    for s in rows:
        visit(s)
    es, ef = {}, {}
    for s in order:
        es[s] = max([ef[d] for d in rows[s]["deps"]], default=0.0)
        ef[s] = es[s] + rows[s]["dur"]
    end = max(ef.values())
    succ = {s: [t for t in rows if s in rows[t]["deps"]] for s in rows}
    lf, ls = {}, {}
    for s in reversed(order):
        lf[s] = min([ls[t] for t in succ[s]], default=end)
        ls[s] = lf[s] - rows[s]["dur"]
    return es, ef, ls, lf, end, succ


def scenario_runs(backlog, estimates, params, actuals):
    def run(b, e, p):
        rows, cp, _, rd, _, _ = est.compute(b, e, p, actuals)
        hyb = sum(r["hyb_final"] for r in rows.values())
        hs = sum(r["hyb_final_s"] for r in rows.values())
        ov = p["overheads"]
        mult = 1 + ov["swarm_supervision"] + ov["coordination"]
        bn = max(rd, key=rd.get)
        z = p["percentile_z"]
        return {"effort_pd": round(hyb * mult, 1), "cal_weeks": round(max(cp[0], rd[bn]) / 5, 1),
                "cal_p80_weeks": round(max(cp[0] + z * cp[1], rd[bn] * (1 + z * hs / hyb)) / 5, 1)}
    out = []
    base = run(backlog, estimates, params)
    defs = [("bazowy", "Bazowy", "plan i szacunki bez zmian", lambda e, p: None)]

    def weaker(e, p):
        for v in e.values():
            v["ai_share"] = max(0.1, v["ai_share"] - 0.2)

    def review(e, p):
        for v in e.values():
            v["review"] = min(1.0, v["review"] + 0.15)

    def slow(e, p):
        for g in p["calendar"]["gate_wait_days"]:
            p["calendar"]["gate_wait_days"][g] = [x * 2 for x in p["calendar"]["gate_wait_days"][g]]
        e["S06"]["trad_pd"] = [20, 30, 45]
        e["S54"]["external_calendar_days"] = [15, 25, 40]

    def team(e, p):
        p["team_fte"]["backend_dotnet"] = 3.0
        p["team_fte"]["product_owner_analityk"] = 0.75
        p["team_fte"]["bezpieczenstwo"] = 0.3

    def split(e, p):
        p["calendar"]["parallel_factor"]["L"] = 2.0
        p["calendar"]["parallel_factor"]["M"] = 1.3

    defs += [("slabsi_agenci", "Słabsi agenci", "udział AI niższy o 20 pkt, np. słabsze wyniki kwalifikacji modelu", weaker),
             ("drozszy_przeglad", "Droższy przegląd", "przegląd pracy agentów droższy o 15 pkt", review),
             ("wolne_procedury", "Wolne procedury banku", "oczekiwanie na bramki ×2, środowisko i pentest pesymistycznie", slow),
             ("wiekszy_zespol", "Większy zespół", "+1 backend, PO 0,75 etatu, bezpieczeństwo 0,3 etatu", team),
             ("podzial_krytycznych", "Podział kroków krytycznych", "dwie osoby z agentami na krokach ścieżki krytycznej", split)]
    for sid, name, desc, fn in defs:
        e, p = copy.deepcopy(estimates), copy.deepcopy(params)
        fn(e, p)
        r = run(backlog, e, p)
        r.update({"id": sid, "name": name, "description": desc,
                  "delta_weeks": round(r["cal_weeks"] - base["cal_weeks"], 1),
                  "delta_effort_pd": round(r["effort_pd"] - base["effort_pd"], 1)})
        out.append(r)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="nie zapisuj; kod 1, gdy dane dashboardu są nieaktualne")
    args = ap.parse_args()
    backlog, estimates, params, actuals = est.load()
    rows, cp, role_load, role_days, k, done = est.compute(backlog, estimates, params, actuals)
    _, t_cp, _, t_role_days, _, _ = est.compute(backlog, estimates, params, actuals, mode="trad")
    es, ef, ls, lf, end, succ = schedule(rows)
    register = yaml.safe_load((ROOT / "plan/dashboard/register.yaml").read_text(encoding="utf-8"))
    bl = {s["id"]: s for s in backlog["steps"]}
    z = params["percentile_z"]
    ov = params["overheads"]
    gates_cfg = backlog["gates"]

    steps = []
    for sid, r in sorted(rows.items(), key=lambda x: (es[x[0]], x[0])):
        e = r["e"]
        split = est.ROLE_SPLIT.get(sid) or {est.ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        wait = est.pert(*params["calendar"]["gate_wait_days"][r["gate"]])[0] if r["gate"] else 0.0
        risk = round((e["N"] + max(e["T"], e["B"])) / 2)
        sc = SCOPES[sid]
        blockers = [f"po {d}" for d in r["deps"]] + ([f"bramka {r['gate']}"] if r["gate"] else []) + ([EXTERNAL[sid]] if sid in EXTERNAL else [])
        steps.append({
            "id": sid, "short": SHORT[sid], "title": r["title"], "phase": r["phase"], "phase_name": PHASES[r["phase"]],
            "agent": AGENT_LABEL.get(r["agent"], r["agent"]), "size": r["size"],
            "scope": sc[0], "scopes": ", ".join(sc),
            "roles": ", ".join(est.ROLE_LABEL[x] for x in split), "lead_role": est.ROLE_LABEL[max(split, key=split.get)],
            "role_split": ", ".join(f"{est.ROLE_LABEL[x]} {round(v*100)}%" for x, v in split.items()),
            "critical": sid in cp[2], "complexity": round(r["C"], 2), "complexity_class": r["cls"],
            "t": e["T"], "n": e["N"], "i": e["I"], "b": e["B"],
            "ai_share": e["ai_share"], "review": e["review"],
            "trad_pd": round(r["trad"], 1), "trad_o": e["trad_pd"][0], "trad_p": e["trad_pd"][2],
            "hyb_pd": round(r["hyb_final"], 1), "saving": round(1 - r["hyb_final"] / r["trad"], 2),
            "start_week": round(es[sid] / 5, 1), "work_start_week": round((es[sid] + wait) / 5, 1),
            "end_week": round(ef[sid] / 5, 1), "late_end_week": round(lf[sid] / 5, 1),
            "float_days": round(ls[sid] - es[sid], 1), "duration_days": round(r["dur"], 1),
            "gate": r["gate"] or "", "gate_wait_days": round(wait, 1),
            "depends_on": ", ".join(r["deps"]), "unblocks": ", ".join(sorted(succ[sid])),
            "blockers": "; ".join(blockers), "external_blocker": EXTERNAL.get(sid, ""),
            "risk_level": risk, "risk_label": RISK_LABEL[risk], "risk_driver": e["driver"],
            "status": "Planowany", "progress": 0,
            "dod": "; ".join(bl[sid].get("dod", []))[:300]})

    gates = []
    for g, cfg in gates_cfg.items():
        gw = est.pert(*params["calendar"]["gate_wait_days"][g])
        decided = max(ef[s] for s in cfg["after"])
        gates.append({"gate": g, "week": round(decided / 5, 1), "wait_days": round(gw[0], 1), "after": ", ".join(cfg["after"]),
                      "approver": ", ".join(APPROVER.get(a, a) for a in cfg["approver"]), "condition": register["gate_conditions"][g]})

    trad = sum(r["trad"] for r in rows.values())
    trad_s = sum(r["trad_s"] for r in rows.values())
    hyb = sum(r["hyb_final"] for r in rows.values())
    hyb_s = sum(r["hyb_final_s"] for r in rows.values())
    mh, mt = 1 + ov["swarm_supervision"] + ov["coordination"], 1 + ov["coordination"]
    bn, tbn = max(role_days, key=role_days.get), max(t_role_days, key=t_role_days.get)
    cal = max(cp[0], role_days[bn]) / 5
    cal80 = max(cp[0] + z * cp[1], role_days[bn] * (1 + z * hyb_s / hyb)) / 5
    tcal = max(t_cp[0], t_role_days[tbn]) / 5
    tcal80 = max(t_cp[0] + z * t_cp[1], t_role_days[tbn] * (1 + z * trad_s / trad)) / 5
    summary = [{"cal_hyb_weeks": round(cal, 1), "cal_hyb_p80_weeks": round(cal80, 1), "cal_trad_weeks": round(tcal, 1),
                "cal_trad_p80_weeks": round(tcal80, 1), "cal_saving_weeks": round(tcal - cal, 1),
                "effort_hyb_pd": round(hyb * mh), "effort_hyb_p80_pd": round((hyb + z * hyb_s) * mh),
                "effort_trad_pd": round(trad * mt), "effort_trad_p80_pd": round((trad + z * trad_s) * mt),
                "effort_saving": round(1 - (hyb * mh) / (trad * mt), 2), "cp_days": round(cp[0]),
                "team_fte": round(sum(params["team_fte"].values()), 1), "steps_total": len(rows),
                "steps_critical": len(cp[2]), "gates_total": len(gates_cfg),
                "bottleneck_role": est.ROLE_LABEL[bn], "calibration_k": round(k, 2), "steps_with_actuals": len(done)}]

    phases = []
    for ph, name in PHASES.items():
        ids = [s for s in rows if rows[s]["phase"] == ph]
        t = sum(rows[s]["trad"] for s in ids)
        h = sum(rows[s]["hyb_final"] for s in ids)
        phases.append({"phase": ph, "name": name, "trad_pd": round(t, 1), "hyb_pd": round(h, 1), "saving": round(1 - h / t, 2),
                       "start_week": round(min(es[s] for s in ids) / 5, 1), "end_week": round(max(ef[s] for s in ids) / 5, 1),
                       "steps": len(ids)})

    util = params["utilization"]
    roles = [{"role": r, "role_label": est.ROLE_LABEL[r], "fte": params["team_fte"][r], "load_pd": round(role_load[r], 1),
              "days_needed": round(role_days[r]), "cp_days": round(cp[0]),
              "load_vs_cp": round(role_days[r] / cp[0], 2)} for r in params["team_fte"]]

    weeks = math.ceil(end / 5)
    daily = {r: [0.0] * (weeks * 5) for r in params["team_fte"]}
    for sid, r in rows.items():
        split = est.ROLE_SPLIT.get(sid) or {est.ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        wait = est.pert(*params["calendar"]["gate_wait_days"][r["gate"]])[0] if r["gate"] else 0.0
        a, b = es[sid] + wait, ef[sid]
        span = max(b - a, 0.5)
        for role, share in split.items():
            per_day = r["hyb_final"] * share / span
            for d in range(int(a), min(int(math.ceil(b)), weeks * 5)):
                overlap = min(b, d + 1) - max(a, d)
                if overlap > 0:
                    daily[role][d] += per_day * overlap
    base = sum(r["hyb_final"] for r in rows.values())
    over = {"architekt_tech_lead": base * (ov["swarm_supervision"] + ov["coordination"] * 0.4),
            "product_owner_analityk": base * ov["coordination"] * 0.6}
    for role, total in over.items():
        for d in range(int(math.ceil(end))):
            daily[role][d] += total / end
    role_weekly = []
    for role in params["team_fte"]:
        for w in range(weeks):
            fte_needed = sum(daily[role][w * 5:(w + 1) * 5]) / 5
            avail = params["team_fte"][role] * util
            role_weekly.append({"key": f"{role}-{w+1}", "week": w + 1, "role": role, "role_label": est.ROLE_LABEL[role],
                                "fte_needed": round(fte_needed, 2), "fte_available": round(avail, 2),
                                "utilization": round(fte_needed / avail, 2) if avail else 0})

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data = {"steps": steps, "gates": gates, "summary": summary, "phases": phases, "roles": roles,
            "role_weekly": role_weekly, "scenarios": scenario_runs(backlog, estimates, params, actuals),
            "risks": register["risks"], "decisions": register["decisions"]}
    week_of = {s["id"]: s["start_week"] for s in steps}
    for d in data["decisions"]:
        d["needed_by_week"] = round(min(week_of.get(x, 0) for x in d["before_steps"].split(", ")), 1)
    for r in data["risks"]:
        r["score"] = r["probability"] * r["impact"]
    outputs = {OUT / f"{name}.json": json.dumps(rows_, ensure_ascii=False, indent=1) + "\n" for name, rows_ in data.items()}
    # Ten sam komplet danych dla strony otwieranej z dysku (bez serwera i bez fetch).
    outputs[OUT.parent / "data.js"] = ("// WYGENEROWANE przez tools/plan/export_dashboard_data.py — nie edytuj ręcznie\nwindow.PH_DATA = "
                                       + json.dumps(data, ensure_ascii=False) + ";\n")
    stale = [p for p, c in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != c]
    if args.check:
        for p in stale:
            print(f"NIEAKTUALNE: {p.relative_to(ROOT)}", file=sys.stderr)
        return 1 if stale else 0
    OUT.mkdir(parents=True, exist_ok=True)
    for p, c in outputs.items():
        p.write_text(c, encoding="utf-8")
    (OUT / "_generated.json").write_text(json.dumps({"at": stamp, "files": sorted(data)}, indent=1) + "\n", encoding="utf-8")
    print(f"zapisano {len(data)} zbiorów do {OUT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/artifacts/render_artifacts.py

````python
#!/usr/bin/env python3
"""Generuje artefakty projektowe: plan systemu, aktorów i założenia (Markdown) oraz stronę docs/artifacts/index.html.

Źródła: docs/artifacts/actors.yaml, docs/artifacts/assumptions.yaml, docs/artifacts/templates/*, profiles/*/profile.yaml,
plan/dashboard/data/*.json (najpierw: tools/plan/estimate.py i tools/plan/export_dashboard_data.py).

  python3 tools/artifacts/render_artifacts.py           # zapisuje pliki
  python3 tools/artifacts/render_artifacts.py --check   # bramka CI: kod 1, gdy pliki są nieaktualne
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / "docs/artifacts"
DATA = ROOT / "plan/dashboard/data"
GENERATED = "<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->"

SPLIT = [
    ("Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4)", "Role projektowe z ról platformy i uprawnień projektu"),
    ("Start procesu, moje procesy, przekazywanie, zastępstwa", "Operacje dedykowane na zadaniach i sprawach"),
    ("Eskalacje, dashboard menadżera, mapa etapów, formatki", "Dane projektu w schemacie prj_<id>"),
    ("Audyt każdej akcji, autoryzacje jako kod", "Sloty UI: panel zadania i sprawy, widżet, pole formatki, trasy /p/<id>/"),
    ("Integracja z Camunda (wyłącznie platforma)", "Workery typów zadań <id>.* i integracje z systemami projektu"),
    ("SDK rozszerzeń i jego zgodność wsteczna", "Model integracji in-process albo remote, własny plan i rytm wydań"),
]
LAYERS = [
    ("Repozytorium", "profiles/<id>/** z CODEOWNERS; kontrakt profilu zatwierdza też architekt platformy"),
    ("Kompilacja", "profil zależy tylko od SDK; testy architektury i granice Nx"),
    ("Uprawnienia", "przestrzeń nazw profilu; walidator i reconciler odrzucają naruszenia (R10)"),
    ("Wykonanie", "operacje i dane profilu tylko w procesach profilu (R9)"),
    ("Dane", "schemat i użytkownik bazy per profil; dane platformy przez widoki platform_api"),
    ("Wdrożenie", "in-process w pociągu wydań; remote — niezależnie"),
    ("CI", "filtry ścieżek per profil; strażnik zakresu zmian dla PR zespołu"),
    ("Agenci AI", "agenci profilu zapisują tylko w swoim profilu; agenci platformy — nigdy w profilach"),
]


def load_json(name):
    return json.loads((DATA / f"{name}.json").read_text(encoding="utf-8"))


def n1(v) -> str:
    return f"{round(float(v), 1):.1f}".replace(".", ",")


def profiles():
    out = []
    for d in sorted(p for p in (ROOT / "profiles").iterdir() if p.is_dir() and not p.name.startswith("_")):
        if not (d / "profile.yaml").exists():
            continue
        p = yaml.safe_load((d / "profile.yaml").read_text(encoding="utf-8"))
        ops = [o.get("title") or o["id"].split(".", 1)[1] for o in p.get("operations", []) if o["kind"] in ("task-action", "case-action", "profile-action")]
        out.append({"id": p["id"], "name": p["name"].split(" (")[0], "integration": p.get("integration", "in-process"),
                    "classification": p["data"]["classification"], "processes": [x["bpmnProcessId"] for x in p["processes"]],
                    "operations": ops or ["—"], "team": p["owner"]["team"], "roles": [r["name"] for r in p["roles"]]})
    return out


def plan_md(summary, phases, gates) -> str:
    tmpl = (ART / "templates/01-plan-systemu.md.tmpl").read_text(encoding="utf-8")
    s = summary
    line = (f"Według modelu wyceny pierwszy projekt kończy pilotaż po {n1(s['cal_hyb_weeks'])} tyg. z rojem agentów AI "
            f"(ostrożnie {n1(s['cal_hyb_p80_weeks'])} tyg.), wobec {n1(s['cal_trad_weeks'])} tyg. bez AI, przy {round(s['effort_hyb_pd'])} "
            f"osobodniach pracy ludzi zamiast {round(s['effort_trad_pd'])}.")
    rows = ["| Faza | Tygodnie (najwcześniej) | Kroki | Praca ludzi bez AI | Z AI | Oszczędność |", "| --- | --- | --- | --- | --- | --- |"]
    rows += [f"| {p['phase']} — {p['name']} | {n1(p['start_week'])}–{n1(p['end_week'])} | {p['steps']} | {n1(p['trad_pd'])} | {n1(p['hyb_pd'])} | {round(p['saving'] * 100)}% |"
             for p in phases]
    grows = ["| Bramka | Tydzień | Warunek | Kto decyduje |", "| --- | --- | --- | --- |"]
    grows += [f"| {g['gate']} | {n1(g['week'])} | {g['condition']} | {g['approver']} |" for g in gates]
    return (GENERATED + "\n" + tmpl.replace("{{SUMMARY_LINE}}", line).replace("{{PHASES_TABLE}}", "\n".join(rows))
            .replace("{{GATES_TABLE}}", "\n".join(grows)))


def actors_md(actors) -> str:
    out = [GENERATED, "# Aktorzy Process Hub", "",
           "Kto korzysta z systemu, kto go wytwarza i z jakimi systemami współpracuje. Osoby w kolumnie „Kto” to świat testowy ze scenariuszy BDD (`specs/README.md`). Źródło: `actors.yaml`.", "",
           "```mermaid", "flowchart LR",
           '  subgraph B["Użytkownicy biznesowi"]', '    UB["Uczestnik · Inicjator · Menadżer procesu<br/>Administrator procesu · Audytor · Administrator platformy"]',
           '    UP["Role projektowe z profili<br/>np. Analityk kredytowy, Underwriter, Analityk AML"]', "  end",
           '  subgraph W["Wytwarzanie"]', '    TP["Zespół platformy"]', '    TPR["Zespoły profili projektów"]', '    AI["Rój agentów AI<br/>OpenCode + GLM 5.3 Flash"]', "  end",
           '  PH["Process Hub<br/>platforma + profile"]', '  CAM[("Camunda 8.9")]', '  IDP[("RHBK + AD")]', '  DB[("MS SQL Server")]', '  SYS["Systemy i usługi projektów"]',
           "  UB --> PH", "  UP --> PH", "  TP -->|platforma, SDK| PH", "  TPR -->|profiles/&lt;id&gt;| PH", "  AI -.->|pakiety robocze, człowiek scala| PH",
           "  PH --> CAM", "  PH --> IDP", "  PH --> DB", "  PH --> SYS", "```", ""]
    for g in actors["groups"]:
        out += [f"## {g['name']}", "", g["note"], "", "| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |", "| --- | --- | --- | --- | --- | --- | --- |"]
        for a in actors["actors"]:
            if a["group"] == g["id"]:
                out.append(f"| {a['id']} | {a['name']} | {a.get('persona') or '—'} | {a['goal']} | {a['does']} | {a.get('rules') or '—'} | {a.get('reqs') or '—'} |")
        out.append("")
    return "\n".join(out)


def assumptions_md(data) -> str:
    items = data["assumptions"]
    counts = {s: sum(1 for a in items if a["status"] == s) for s in ("przyjęte", "do weryfikacji", "decyzja otwarta")}
    out = [GENERATED, "# Założenia Process Hub", "",
           f"Rejestr {len(items)} założeń: {counts['przyjęte']} przyjętych, {counts['do weryfikacji']} do weryfikacji w PoC lub w trakcie prac, "
           f"{counts['decyzja otwarta']} czekających na decyzję. Każde ma źródło, punkt sprawdzenia i skutek, jeśli okaże się nieprawdą. Źródło: `assumptions.yaml`.", ""]
    for cat in data["categories"]:
        rows = [a for a in items if a["category"] == cat]
        if not rows:
            continue
        out += [f"## {cat}", "", "| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |", "| --- | --- | --- | --- | --- | --- |"]
        out += [f"| {a['id']} | {a['statement']} | {a['source']} | {a['status']} | {a['verify']} | {a['impact']} |" for a in rows]
        out.append("")
    return "\n".join(out)


def index_html(summary, phases, gates, decisions, actors, assumptions, profs, stamp) -> str:
    data = {"summary": summary, "phases": phases, "gates": gates, "decisions": decisions, "actors": actors,
            "assumptions": assumptions, "profiles": profs, "split": SPLIT, "layers": LAYERS, "generated": stamp}
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    return (ART / "templates/index.html.tmpl").read_text(encoding="utf-8").replace("/*__DATA__*/", blob)


def readme() -> str:
    return "\n".join([
        "# Artefakty projektowe", "",
        "Plan systemu, aktorzy, przyjęte założenia i wytyczne UI — dla decydentów, zespołów platformy i profili oraz dla agentów AI. Pliki 01–03 i strona `index.html` są generowane; źródła edytujesz ręcznie.", "",
        "| Plik | Zawartość | Źródło |", "| --- | --- | --- |",
        "| `index.html` | strona do przeglądania (działa z dysku, jasny i ciemny motyw, telefon) | wszystkie poniższe |",
        "| `01-plan-systemu.md` | system w kontekście, część wspólna i specyficzna, przepływy, plan realizacji, wytwarzanie | `templates/01-plan-systemu.md.tmpl` + dane planu |",
        "| `02-aktorzy.md` | użytkownicy, role projektowe, zespoły, systemy | `actors.yaml` |",
        "| `03-zalozenia.md` | rejestr założeń ze statusem, źródłem, sprawdzeniem i skutkiem | `assumptions.yaml` |",
        "| `04-wytyczne-ui.md`, `wytyczne-ui.html` | wytyczne i założenia interfejsu dla osób zaczynających pracę nad UI (pisane ręcznie; strona działa z dysku) | `design/README.md`, `design/tokens.json`, `design/forms/` |", "",
        "Odświeżenie (po zmianie planu, profili lub rejestrów):", "", "```bash",
        "python3 tools/plan/estimate.py && python3 tools/plan/export_dashboard_data.py",
        "python3 tools/artifacts/render_artifacts.py",
        "# bez Pythona: ph plan estimate && ph plan export && ph artifacts render", "```", ""])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    summary = load_json("summary")[0]
    phases, gates, decisions = load_json("phases"), load_json("gates"), load_json("decisions")
    stamp = json.loads((DATA / "_generated.json").read_text(encoding="utf-8"))["at"][:10]
    actors = yaml.safe_load((ART / "actors.yaml").read_text(encoding="utf-8"))
    assumptions = yaml.safe_load((ART / "assumptions.yaml").read_text(encoding="utf-8"))
    profs = profiles()
    outputs = {
        ART / "01-plan-systemu.md": plan_md(summary, phases, gates),
        ART / "02-aktorzy.md": actors_md(actors),
        ART / "03-zalozenia.md": assumptions_md(assumptions),
        ART / "index.html": index_html(summary, phases, gates, decisions, actors, assumptions, profs, stamp),
        ART / "README.md": readme(),
    }
    stale = [p for p, c in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != c]
    if args.check:
        for p in stale:
            print(f"NIEAKTUALNE: {p.relative_to(ROOT)}", file=sys.stderr)
        return 1 if stale else 0
    for p in stale:
        p.write_text(outputs[p], encoding="utf-8")
    print(f"zapisano {len(stale)} plików artefaktów, bez zmian {len(outputs) - len(stale)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/agents/render_agents.py

````python
#!/usr/bin/env python3
"""Generator definicji agentów OpenCode z kanonicznego rejestru ról i profili projektów.

Wejście:  agents/registry.yaml, agents/prompts/*.md, config/models.yaml, agents/runtime-policy.yaml,
          profiles/*/profile.yaml (agenci zespołów profili), AGENTS.md (zasady projektu)
Wyjście:  .opencode/agent/*.md + opencode.json (OpenCode) · blok ról w AGENTS.md
          · opcjonalnie agents/dist/<profil-modeli>/<rola>.json (runtime'y wywołujące API bezpośrednio, cel `json`)

Agenci platformy nie zapisują w profiles/<id>/**; agenci profilu (np. `kredyty-module-implementer`) zapisują wyłącznie
w profiles/<id>/**. Klasa danych profilu może wymusić model w infrastrukturze banku (data_policy).

Użycie:
  python3 tools/agents/render_agents.py                         # profil modeli z config/models.yaml (default_profile)
  python3 tools/agents/render_agents.py --targets json          # dodatkowo pliki dla runtime'ów API
  python3 tools/agents/render_agents.py --check                 # bramka CI: pliki aktualne?
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
GENERATED = "WYGENEROWANE przez tools/agents/render_agents.py — edytuj agents/registry.yaml, agents/prompts/ lub profiles/<id>/profile.yaml"
CLASS_RANK = {"internal": 0, "confidential": 1, "restricted": 2}
WRITE_TOOLS = {"edit_file", "write_file"}
WEB_DENY = {"webfetch": "deny", "websearch": "deny"}
ROLE_BEGIN = "<!-- ROLE:BEGIN"
ROLE_END = "<!-- ROLE:END -->"
RFC_GLOB = "docs/rfc/RFC-*.md"          # wniosek o zmianę poza zakresem — wolno każdemu agentowi z prawem zapisu


class ConfigError(Exception):
    pass


def load():
    registry = yaml.safe_load((ROOT / "agents/registry.yaml").read_text(encoding="utf-8"))
    models = yaml.safe_load((ROOT / "config/models.yaml").read_text(encoding="utf-8"))
    tools = json.loads((ROOT / "agents/schemas/tools.json").read_text(encoding="utf-8"))["tools"]
    agents_md = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    project_rules = agents_md.split(ROLE_BEGIN)[0].rstrip() + "\n"
    profiles = []
    for d in sorted(p for p in (ROOT / "profiles").iterdir() if p.is_dir() and not p.name.startswith("_")):
        if (d / "profile.yaml").exists():
            profiles.append(yaml.safe_load((d / "profile.yaml").read_text(encoding="utf-8")))
    return registry, models, tools, agents_md, project_rules, profiles


def allowed(models: dict, data_class: str, hosting: str) -> bool:
    return hosting in models["data_policy"].get(data_class, [])


def resolve(role: dict, profile_name: str, models: dict, data_class: str | None = None) -> dict:
    """Ustala profil modeli, poziom, model i wariant rozumowania dla roli (z polityką danych)."""
    profiles = models["profiles"]
    if profile_name not in profiles:
        raise ConfigError(f"nieznany profil modeli: {profile_name}")
    data_class = data_class or role["data_class"]
    prof = profiles[profile_name]
    override = prof.get("roles", {}).get(role["name"], {})
    effective = override.get("profile", profile_name)
    tier = override.get("tier", role["tier"])
    if not allowed(models, data_class, profiles[effective]["hosting"]):
        on_prem = [n for n, p in profiles.items() if allowed(models, data_class, p["hosting"])]
        if not on_prem:
            raise ConfigError(f"rola {role['name']} (dane: {data_class}) nie ma dozwolonego profilu modeli")
        effective = on_prem[0]
    cfg = profiles[effective]
    tier_cfg = cfg["tiers"][tier]
    return {"profile": effective, "cfg": cfg, "tier": tier, "model": tier_cfg["model"],
            "variant": tier_cfg.get("variant"), "hosting": cfg["hosting"], "data_class": data_class}


def env_resolve(value: str | None) -> str | None:
    """Podstawia ${VAR} ze środowiska; None, gdy zmienna nie jest ustawiona."""
    if value is None:
        return None
    if any(not os.environ.get(v) for v in re.findall(r"\$\{(\w+)\}", value)):
        return None
    return re.sub(r"\$\{(\w+)\}", lambda m: os.environ[m.group(1)], value)


def opencode_model(res: dict) -> str | None:
    model = env_resolve(res["model"])
    provider = res["cfg"].get("opencode_provider")
    return f"{provider}/{model}" if provider and model else None


def prompt_for(role: dict) -> str:
    return (ROOT / role["prompt"]).read_text(encoding="utf-8")


def profile_addendum(prof: dict) -> str:
    pid = prof["id"]
    processes = ", ".join(f"`{p['bpmnProcessId']}`" for p in prof["processes"])
    return (
        f"\n\n## Profil projektu „{prof['name']}” (`{pid}`)\n\n"
        f"Pracujesz dla zespołu {prof['owner']['team']}. Zanim zaczniesz, przeczytaj `profiles/{pid}/AGENTS.md` i `profiles/{pid}/profile.yaml`.\n"
        f"- Zapisujesz wyłącznie w `profiles/{pid}/**`; platforma i inne profile są poza Twoim zakresem (blokuje to OpenCode i strażnik zapisu).\n"
        f"- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); skill `profile-extension`.\n"
        f"- Działasz tylko na procesach profilu: {processes} (R9). Uprawnienia, operacje i typy zadań mają prefiks `{pid}.` (R10).\n"
        f"- Dane: schemat `{prof['data']['schema']}` (klasa: {prof['data']['classification']}); dane platformy tylko przez widoki `platform_api`.\n"
        f"- Zmiana kontraktu profilu albo SDK platformy → RFC w `docs/rfc/` i status `needs-rfc`.\n"
    )


def permissions_block(edit) -> list[str]:
    lines = ["permission:"]
    if isinstance(edit, str):
        lines.append(f"  edit: {edit}")
    else:
        lines.append("  edit:")
        lines += [f"    {json.dumps(k)}: {v}" for k, v in edit.items()]
    return lines


def bash_block(role: dict) -> list[str]:
    """Uprawnienia komend agenta: brak narzędzia = zakaz; własny zestaw roli (pole `commands`) = reguły w pliku agenta."""
    if "run_command" not in role["tools"]:
        return ["  bash: deny"]
    if not role.get("commands"):
        return []                            # zestaw domyślny z opencode.json
    return ["  bash:"] + [f"    {json.dumps(k)}: {v}" for k, v in bash_rules(role["commands"]).items()]


def render_opencode_agent(name: str, role: dict, res: dict, description: str, edit, body: str, primary: bool) -> str:
    front = ["---", f"# {GENERATED}", f"description: {json.dumps(description, ensure_ascii=False)}",
             f"mode: {'primary' if primary else 'subagent'}"]
    model = opencode_model(res)
    front.append(f"model: {model}" if model else f"# model nieustalony ({res['model']}) — ustaw zmienne profilu {res['profile']}")
    if res.get("variant"):
        front.append(f"variant: {res['variant']}")
    front += permissions_block(edit)
    front += bash_block(role)
    front.append(f"  task: {'allow' if primary else 'deny'}")
    front += [f"  {k}: {v}" for k, v in WEB_DENY.items()]
    front.append("---")
    note = ("\n\n> Narzędzia w OpenCode: read, grep, glob, edit, write, bash. Zapis poza `.agent-scope` i do cudzego profilu "
            "blokuje plugin `.opencode/plugin/write-scope.js`; komendy ogranicza `permission.bash` (opencode.json albo zestaw roli "
            "w tym pliku) — polityka: `agents/runtime-policy.yaml`.\n")
    return "\n".join(front) + "\n" + body.rstrip() + note


def platform_edit(role: dict):
    if not WRITE_TOOLS & set(role["tools"]):
        return "deny"
    if role.get("writes"):                   # rola z własną listą ścieżek zapisu (np. orkiestrator: tylko postęp i pakiety)
        rules = {"*": "deny"}
        rules.update({w: "allow" for w in role["writes"]})
        return rules
    # Agenci platformy nie zmieniają kodu profili (z wyjątkiem szablonu utrzymywanego przez platformę).
    return {"*": "allow", "profiles/*/**": "deny", "profiles/_template/**": "allow"}


def runtime_policy() -> dict:
    return yaml.safe_load((ROOT / "agents/runtime-policy.yaml").read_text(encoding="utf-8"))


def bash_rules(set_name: str | None = None) -> dict:
    """Reguły komend: zestaw domyślny (None) albo nazwany zestaw roli; zakazy wspólne zawsze na końcu."""
    run = runtime_policy()["run_command"]
    if set_name and set_name not in run.get("sets", {}):
        raise ConfigError(f"nieznany zestaw komend: {set_name} (agents/runtime-policy.yaml, run_command.sets)")
    cfg = run["sets"][set_name] if set_name else run
    bash = {"*": cfg.get("default", "ask")}  # OpenCode stosuje OSTATNIĄ pasującą regułę: ogólne → szczegółowe → zakazy
    for prefix in cfg["allow"]:
        p = prefix.rstrip()
        if p.endswith("/") or p.endswith("-"):   # prefiks ścieżki lub nazwy (np. ../wt-) — bez spacji przed resztą
            bash[p + "*"] = "allow"
            continue
        bash[p] = "allow"
        bash[p + " *"] = "allow"
    for pattern in run["deny_patterns"]:
        p = pattern.strip()
        if p in ("env", "printenv"):
            bash[p] = "deny"
            bash[p + " *"] = "deny"
        else:
            bash["*" + p + "*"] = "deny"
    return bash


def read_rules() -> dict:
    """Zakazy odczytu z polityki (read_guard.deny): nazwy plików z kropką na początku dopasowane w każdym katalogu."""
    rules = {"*": "allow"}
    for pattern in runtime_policy()["read_guard"]["deny"]:
        rules[("*" + pattern) if pattern.startswith(".") else pattern] = "deny"
    return rules


def render_opencode_config(models: dict, resolved: list[dict], default_res: dict, small_res: dict) -> str:
    cfg = {"$schema": "https://opencode.ai/config.json",
           "share": "disabled",              # rozmowy z kodem banku nie trafiają do publicznych linków
           "autoupdate": "notify",           # aktualizacja narzędzia to decyzja zespołu
           "permission": {"edit": "allow", "bash": bash_rules(), "webfetch": "deny", "websearch": "deny",
                          "read": read_rules()}}
    for key, res in (("model", default_res), ("small_model", small_res)):
        m = opencode_model(res)
        if m:
            cfg[key] = m
    used = {r["profile"] for r in resolved}
    for name in sorted(used):
        p = models["profiles"][name]
        if p.get("kind") != "openai-compatible":
            continue
        names = sorted({m for m in (env_resolve(t["model"]) for t in p["tiers"].values()) if m})
        mods = {}
        for m in names:
            mods[m] = {"name": m, "reasoning": True, "tool_call": True}
            if p.get("context_limit_tokens"):
                mods[m]["limit"] = {"context": p["context_limit_tokens"], "output": p.get("output_limit_tokens", 32768)}
            if p.get("variants"):
                mods[m]["variants"] = p["variants"]      # warianty rozumowania przekazywane bramce w treści żądania
        entry = {"npm": "@ai-sdk/openai-compatible", "name": p.get("display_name", p["opencode_provider"]),
                 "options": {"baseURL": "{env:" + p["api_base_env"] + "}", "apiKey": "{env:" + p["api_key_env"] + "}"}}
        if mods:
            entry["models"] = mods
        cfg.setdefault("provider", {})[p["opencode_provider"]] = entry
    return json.dumps(cfg, ensure_ascii=False, indent=2) + "\n"


def render_json(role: dict, res: dict, tools: list, project_rules: str, body: str) -> str:
    schema = json.loads((ROOT / role["output_schema"]).read_text(encoding="utf-8"))
    system = (project_rules.strip() + "\n\n---\n\n# Twoja rola\n\n" + body.strip()
              + "\n\n---\n\n# Kontrakt wyjścia\n\nOstatnia wiadomość to wyłącznie JSON zgodny ze schematem `" + role["output_schema"] + "`.")
    cfg = res["cfg"]
    doc = {"_generated": GENERATED, "role": role["name"], "model_profile": res["profile"], "hosting": res["hosting"],
           "provider": cfg.get("opencode_provider"), "api_base_env": cfg.get("api_base_env"), "api_key_env": cfg.get("api_key_env"),
           "model": res["model"], "variant": res.get("variant"), "tier": res["tier"], "reasoning": role["reasoning"],
           "tools": [t for t in tools if t["name"] in role["tools"]], "runtime_policy": "agents/runtime-policy.yaml",
           "system": system, "response_schema": schema, "escalation": cfg.get("escalation", [])}
    return json.dumps(doc, ensure_ascii=False, indent=2) + "\n"


def render_role_block(rows: list[tuple]) -> str:
    table = "\n".join(f"| `{n}` | {scope} | {tier} | `{model}`{(' · ' + variant) if variant else ''} | {hosting} | {dc} |"
                      for n, scope, tier, model, variant, hosting, dc in rows)
    return (f"{ROLE_BEGIN} — sekcję generuje tools/agents/render_agents.py; nie edytuj ręcznie -->\n"
            "## Agenci (OpenCode)\n\n"
            "| Agent | Zakres zapisu | Poziom | Model · wariant | Hosting | Klasa danych |\n| --- | --- | --- | --- | --- | --- |\n"
            + table + "\n\nPoziom wybiera wysiłek rozumowania tego samego modelu; eskalacja: wyższy wariant, potem człowiek. "
            "Wszystkie role używają modelu w infrastrukturze banku (ADR-016); klasa danych decyduje o przeglądzie bezpieczeństwa.\n" + ROLE_END)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=None, help="profil modeli z config/models.yaml")
    ap.add_argument("--targets", default=None, help="opencode,agents-md,json")
    ap.add_argument("--check", action="store_true", help="nie zapisuj; kod 1, jeśli pliki są nieaktualne")
    args = ap.parse_args()

    registry, models, tools, agents_md, project_rules, profiles = load()
    model_profile = args.profile or os.environ.get("PH_MODEL_PROFILE") or models["default_profile"]
    targets = args.targets.split(",") if args.targets else models["profiles"][model_profile].get("targets", ["opencode", "agents-md"])
    roles = {r["name"]: r for r in registry["roles"]}
    outputs: dict[Path, str] = {}
    warnings: list[str] = []
    resolved_all, rows = [], []

    agents = []  # (nazwa, rola, res, opis, edit, treść, primary, zakres)
    for r in registry["roles"]:
        res = resolve(r, model_profile, models)
        agents.append((r["name"], r, res, r["description"], platform_edit(r), prompt_for(r), r["name"] == "orchestrator", "platforma"))
    for prof in profiles:
        pid = prof["id"]
        prof_class = prof.get("dev", {}).get("dataClass", prof["data"]["classification"])
        for role_name in prof.get("dev", {}).get("agents", []):
            r = roles[role_name]
            dc = max(r["data_class"], prof_class, key=lambda c: CLASS_RANK[c])
            res = resolve(r, model_profile, models, dc)
            edit = {"*": "deny", f"profiles/{pid}/**": "allow", RFC_GLOB: "allow"} if WRITE_TOOLS & set(r["tools"]) else "deny"
            desc = f"Profil „{pid}” ({prof['owner']['team']}): {r['description']} Zapis wyłącznie w profiles/{pid}/**."
            agents.append((f"{pid}-{role_name}", r, res, desc, edit, prompt_for(r) + profile_addendum(prof), False, f"`profiles/{pid}/**`"))

    for name, r, res, desc, edit, body, primary, scope in agents:
        resolved_all.append(res)
        own = ", ".join(f"`{w}`" for w in r.get("writes", []))
        rows.append((name, scope if scope != "platforma" else ("brak (tylko odczyt)" if edit == "deny" else (own or "platforma (bez `profiles/<id>/**`)")),
                     res["tier"], res["model"], res.get("variant"), res["hosting"], res["data_class"]))
        if not opencode_model(res):
            warnings.append(f"{name}: model {res['model']} nieustalony — ustaw zmienne profilu modeli {res['profile']}")
        limit, need = res["cfg"].get("context_limit_tokens"), r["requires"]["min_context_tokens"]
        if limit and limit < need:
            warnings.append(f"{name}: kontekst {limit} < wymagane {need} — orkiestrator dzieli pakiety rozmiaru L")
        if "opencode" in targets:
            outputs[ROOT / f".opencode/agent/{name}.md"] = render_opencode_agent(name, r, res, desc, edit, body, primary)
        if "json" in targets:
            outputs[ROOT / f"agents/dist/{model_profile}/{name}.json"] = render_json(r, res, tools, project_rules, body)

    if "opencode" in targets:
        arch = next(a for a in agents if a[0] == "architect")[2]
        small = next(a for a in agents if a[0] == "ci-triage")[2]
        outputs[ROOT / "opencode.json"] = render_opencode_config(models, resolved_all, arch, small)
        stale_agents = {p.name for p in (ROOT / ".opencode/agent").glob("*.md")} - {f"{a[0]}.md" for a in agents} \
            if (ROOT / ".opencode/agent").exists() else set()
        for orphan in sorted(stale_agents):
            warnings.append(f"plik .opencode/agent/{orphan} nie odpowiada żadnej roli — usuń go")
    if "agents-md" in targets:
        block = render_role_block(rows)
        if ROLE_BEGIN not in agents_md or ROLE_END not in agents_md:
            raise ConfigError("AGENTS.md nie zawiera znaczników bloku ról")
        head, rest = agents_md.split(ROLE_BEGIN, 1)
        tail = rest.split(ROLE_END, 1)[1]
        outputs[ROOT / "AGENTS.md"] = head + block + tail

    stale = []
    for path, content in sorted(outputs.items()):
        current = path.read_text(encoding="utf-8") if path.exists() else None
        if current != content:
            stale.append(path.relative_to(ROOT))
            if not args.check:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
    for w in sorted(set(warnings)):
        print(f"OSTRZEŻENIE: {w}", file=sys.stderr)
    if args.check:
        for s in stale:
            print(f"NIEAKTUALNE: {s}", file=sys.stderr)
        return 1 if stale else 0
    print(f"profil modeli: {model_profile} · agentów: {len(agents)} · zapisano {len(stale)} plików, bez zmian {len(outputs) - len(stale)}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ConfigError as e:
        print(f"BŁĄD KONFIGURACJI: {e}", file=sys.stderr)
        sys.exit(2)
````

## Plik: tools/agents/steplib.py

````python
"""Wspólne funkcje skryptów prowadzenia kroków: plan (platformy albo profilu), postęp, bramki."""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
PLATFORM_BACKLOG = ROOT / "plan/backlog.yaml"


class Plan:
    """Plan kroków: platformy (plan/backlog.yaml) albo zespołu profilu (profiles/<id>/backlog.yaml).

    Postęp planu platformy: plan/progress/; planu profilu: profiles/<id>/progress/.
    Zależność spoza planu (np. krok profilu zależny od S38) sprawdzana jest w postępie planu platformy.
    """

    def __init__(self, backlog: str | Path | None = None):
        self.path = (ROOT / backlog) if backlog else PLATFORM_BACKLOG
        self.data = yaml.safe_load(self.path.read_text(encoding="utf-8"))
        self.profile = self.data.get("profile")
        self.progress_dir = (self.path.parent / "progress") if self.profile else ROOT / "plan/progress"
        self.steps = {s["id"]: s for s in self.data["steps"]}
        self._platform = None if not self.profile else Plan(None)

    @property
    def gates_file(self) -> Path:
        return self.progress_dir / "gates.json"

    def progress(self, step_id: str) -> dict:
        if step_id not in self.steps and self._platform:
            return self._platform.progress(step_id)
        f = self.progress_dir / f"{step_id}.json"
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}

    def origin(self, step_id: str) -> "Plan":
        """Plan, do którego należy krok: ten albo — dla zależności kroku profilu — plan platformy."""
        return self._platform if step_id not in self.steps and self._platform else self

    def is_merged(self, step_id: str) -> bool:
        p = self.progress(step_id)
        return p.get("status") == "done" and bool(p.get("merged"))

    def gates(self) -> dict:
        return json.loads(self.gates_file.read_text(encoding="utf-8")) if self.gates_file.exists() else {}

    def readiness(self, step: dict) -> tuple[bool, list[str]]:
        reasons = [f"{d} nie jest scalony" for d in step.get("depends_on", []) if not self.is_merged(d)]
        gate = step.get("gate_before")
        if gate and gate not in self.gates():
            reasons.append(f"bramka {gate} niezatwierdzona")
        return (not reasons, reasons)

    def agent_name(self, agent: str) -> str:
        return f"{self.profile}-{agent}" if self.profile and agent != "human" else agent


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def today() -> str:
    return date.today().isoformat()
````

## Plik: tools/agents/prepare_step.py

````python
#!/usr/bin/env python3
"""Przygotowuje krok planu do pracy agenta: worktree, .agent-scope i pakiet roboczy.

Deterministyczna część pracy orkiestratora — bez modelu, więc bez kosztu tokenów.

  python3 tools/agents/prepare_step.py S10                                        # plan platformy
  python3 tools/agents/prepare_step.py KRE-02 --backlog profiles/kredyty/backlog.yaml   # plan zespołu profilu
  python3 tools/agents/prepare_step.py S10 --no-worktree   # pakiet i .agent-scope w bieżącym katalogu
  python3 tools/agents/prepare_step.py S10 --force         # pomiń kontrolę zależności i bramki (decyzja człowieka)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from steplib import ROOT, Plan

HUMAN = "human"


def git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True)


def ensure_worktree(step_id: str, branch: str, root: Path) -> Path:
    path = (root / f"wt-{step_id}").resolve()
    if path.exists():
        return path
    if git("rev-parse", "--is-inside-work-tree").returncode != 0:
        sys.exit("Repozytorium nie jest repozytorium git — użyj --no-worktree albo wykonaj git init.")
    has_branch = git("rev-parse", "--verify", branch).returncode == 0
    res = git("worktree", "add", str(path), branch) if has_branch else git("worktree", "add", "-b", branch, str(path), "HEAD")
    if res.returncode != 0:
        sys.exit(f"git worktree add nie powiódł się: {res.stderr.strip()}")
    return path


def contracts_of(step: dict) -> list[str]:
    return [r for r in step.get("reads", []) if r.rstrip("/").endswith("Contracts")]


# Podział pracy w parze, gdy krok nie podaje własnego (`pair_task`).
PAIR_DEFAULT = {
    "bdd-tester": "pisze kroki Reqnroll i drivery w projektach testów, zanim powstanie implementacja; wykonawca nie edytuje `tests/*.Specs/**`",
    "security-reviewer": "obowiązkowy przegląd bezpieczeństwa po zielonych bramkach (tylko odczyt)",
    "ui-reviewer": "obowiązkowy przegląd warstwy wizualnej po zielonych bramkach (tylko odczyt)",
}
PAIR_OTHER = "współwykonawca w tym samym worktree i zakresie — wykonuje część wskazaną przez wykonawcę"


def section(title: str, items: list[str]) -> list[str]:
    """Sekcja pakietu z listą punktów; pusta lista = brak sekcji (pakiet ma być krótki)."""
    return ["", f"## {title}"] + [f"- {i}" for i in items] if items else []


def packet(step: dict, plan: Plan) -> str:
    dod = step.get("dod") or plan.data.get("common_dod", [])
    reads = [r for r in step.get("reads", []) if r not in contracts_of(step)]
    if "AGENTS.md" not in reads:
        reads.insert(0, "AGENTS.md")
    if plan.profile and f"profiles/{plan.profile}/AGENTS.md" not in reads:
        reads.insert(1, f"profiles/{plan.profile}/AGENTS.md")
    human = step["agent"] == HUMAN
    agent = plan.agent_name(step["agent"])
    pair = plan.agent_name(step["pair"]) if step.get("pair") else None
    inputs = []
    for dep in step.get("depends_on", []):
        owner = plan.origin(dep)
        title = owner.steps[dep]["title"] if dep in owner.steps else "krok spoza planu"
        inputs.append(f"`{dep}` {title} — przekazanie: `{owner.progress_dir.relative_to(ROOT)}/{dep}.json`")
    lines = [f"# Pakiet roboczy — {step['id']}: {step['title']}", "",
             "> Wygenerowany przez tools/agents/prepare_step.py. Czytaj tylko ten plik i pliki z sekcji „Czytaj”.", "",
             "## Cel", step["title"] + ".", "",
             (f"Profil projektu: `{plan.profile}` — zapis wyłącznie w `profiles/{plan.profile}/**`.\n" if plan.profile else "")
             + f"Wykonawca: `{agent}`" + (f" · para: `{pair}`" if pair else "")
             + f" · rozmiar: {step.get('size', '—')} · ścieżka krytyczna: {'tak' if step.get('critical') else 'nie'}"]
    lines += section("Wynik (co ma powstać)", step.get("outcome", []))
    lines += section("Wskazówki startowe", step.get("notes", []))
    lines += ["", "## Czytaj (w tej kolejności)"] + [f"{i}. `{r}`" for i, r in enumerate(reads, 1)]
    lines += section("Sięgaj punktowo (wyszukuj fragment, nie czytaj w całości)", step.get("refs", []))
    lines += section("Wejście od poprzedników (czytaj pytania otwarte i listę zmienionych plików)", inputs)
    lines += ["", "## Wolno zapisywać (`.agent-scope`)"] + [f"- `{w}`" for w in step.get("writes", [])]
    lines += [f"- `docs/rfc/RFC-{step['id']}-<temat>.md` — wniosek o zmianę poza zakresem (dozwolony zawsze)"]
    if pair:
        lines += section("Para", [f"`{pair}`: " + (step.get("pair_task") or PAIR_DEFAULT.get(step["pair"], PAIR_OTHER))])
    lines += ["", "## Scenariusze do zaliczenia"] + ([f"- `{s}`" for s in step.get("specs", [])] or ["- brak (krok techniczny)"])
    lines += ["", "## Kontrakty zależności (tylko do odczytu)"] + ([f"- `{c}`" for c in contracts_of(step)] or ["- brak"])
    lines += ["", "## Definition of Done"] + [f"- [ ] `{c}` kończy się kodem 0" for c in dod]
    lines += ["- [ ] brak nowych ostrzeżeń analizatorów",
              "- [ ] każda nowa komenda lub operacja ma deskryptor audytu; każdy endpoint — politykę autoryzacji",
              "- [ ] `AGENTS.md` modułu lub profilu zaktualizowany (cel, inwarianty, komendy)"]
    lines += section("Kryteria akceptacji człowieka (poza bramkami)", step.get("acceptance", []))
    lines += ["", "## Budżet", "Próby: 2 · potem jedna sesja od zera z diagnozą recenzenta (albo wyższy wariant rozumowania, jeśli rola go ma) "
              "· potem człowiek · zakaz zmian poza `.agent-scope` (zmiana kontraktu, scenariusza platformy lub SDK → RFC w docs/rfc/)", "",
              "## Przekazanie"]
    if not human:
        lines += [f"Przed przekazaniem zatwierdź zmiany na gałęzi kroku: `git add -A`, potem `git commit -m \"{step['id']}: <opis>\"` (bez `push`)."]
    lines += [f"Ostatnia wiadomość: JSON wg `AGENTS.md` → `{plan.progress_dir.relative_to(ROOT)}/{step['id']}.json`", ""]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("step")
    ap.add_argument("--backlog", default=None, help="plan zespołu profilu, np. profiles/kredyty/backlog.yaml")
    ap.add_argument("--worktree-root", default=str(ROOT.parent), help="katalog, w którym powstaje wt-<krok>")
    ap.add_argument("--no-worktree", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    plan = Plan(args.backlog)
    step = plan.steps.get(args.step)
    if not step:
        sys.exit(f"Nie ma kroku {args.step} w {plan.path.relative_to(ROOT)}")
    ok, reasons = plan.readiness(step)
    if not ok and not args.force:
        print(f"Krok {step['id']} nie jest gotowy: " + "; ".join(reasons))
        print("Uzupełnij postęp (scalenie poprzedników, zatwierdzenie bramki) albo uruchom z --force decyzją człowieka.")
        return 1

    if step["agent"] == HUMAN:
        target = ROOT
        print(f"Krok {step['id']} wykonuje człowiek — powstaje tylko pakiet (bez worktree i .agent-scope).")
    else:
        branch = f"profile/{plan.profile}/{step['id']}" if plan.profile else f"step/{step['id']}"
        target = ROOT if args.no_worktree else ensure_worktree(step["id"], branch, Path(args.worktree_root))
        scope = [f"# Wygenerowane przez prepare_step.py — zakres zapisu kroku {step['id']}"]
        if plan.profile:
            scope.append(f"@profile {plan.profile}")
        scope += step.get("writes", [])
        (target / ".agent-scope").write_text("\n".join(scope) + "\n", encoding="utf-8")

    out = target / "plan/packets" / f"{step['id']}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(packet(step, plan), encoding="utf-8")
    print(f"worktree: {target}")
    print(f"pakiet:   {out}")
    if step["agent"] != HUMAN:
        agent = plan.agent_name(step["agent"])
        print(f"zakres:   {target / '.agent-scope'}" + (f"  (profil: {plan.profile})" if plan.profile else ""))
        print(f"agent:    {agent}" + (f" + {plan.agent_name(step['pair'])}" if step.get("pair") else ""))
        print(f"start:    opencode run --dir {target} --agent {agent} \"Wykonaj pakiet plan/packets/{step['id']}.md\"")
        print(f"          (interaktywnie: cd {target} && opencode, potem: @{agent} Wykonaj pakiet plan/packets/{step['id']}.md)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/agents/run_dod.py

````python
#!/usr/bin/env python3
"""Uruchamia bramki deterministyczne (Definition of Done) kroku i zapisuje wynik <postęp>/<krok>.gates.json.

  python3 tools/agents/run_dod.py S10 --dir ../wt-S10
  python3 tools/agents/run_dod.py KRE-02 --backlog profiles/kredyty/backlog.yaml --dir ../wt-KRE-02
Kod wyjścia 1, gdy którakolwiek komenda się nie powiedzie. Pełne logi: <postęp>/logs/ (poza repozytorium git).
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

from steplib import ROOT, Plan, today, write_json

TAIL = 40


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("step")
    ap.add_argument("--backlog", default=None)
    ap.add_argument("--dir", default=".", help="katalog roboczy kroku (worktree)")
    ap.add_argument("--timeout", type=int, default=1800)
    args = ap.parse_args()

    plan = Plan(args.backlog)
    step = plan.steps.get(args.step)
    if not step:
        sys.exit(f"Nie ma kroku {args.step}")
    commands = step.get("dod") or plan.data.get("common_dod", [])
    workdir = Path(args.dir).resolve()
    logs = plan.progress_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)

    results = []
    for i, cmd in enumerate(commands, 1):
        t0 = time.time()
        try:
            res = subprocess.run(cmd, shell=True, cwd=workdir, capture_output=True, text=True, timeout=args.timeout)
            code, output = res.returncode, (res.stdout or "") + (res.stderr or "")
        except subprocess.TimeoutExpired:
            code, output = 124, f"przekroczono limit czasu {args.timeout} s"
        log = logs / f"{args.step}-{i}.log"
        log.write_text(output, encoding="utf-8")
        results.append({"command": cmd, "exit_code": code, "passed": code == 0, "seconds": round(time.time() - t0, 1),
                        "log": str(log.relative_to(ROOT)),
                        "tail": "" if code == 0 else "\n".join(output.strip().splitlines()[-TAIL:])})
        print(f"[{'OK ' if code == 0 else 'BŁĄD'}] {cmd}  ({results[-1]['seconds']} s)")
        if code != 0:
            break  # kolejne bramki zwykle zależą od poprzednich; oszczędza czas i tokeny triage

    passed = all(r["passed"] for r in results) and len(results) == len(commands)
    out = plan.progress_dir / f"{args.step}.gates.json"
    write_json(out, {"step": args.step, "date": today(), "workdir": str(workdir), "passed": passed, "results": results})
    print(f"wynik: {'zielone' if passed else 'czerwone'} → {out.relative_to(ROOT)}")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/agents/plan_status.py

````python
#!/usr/bin/env python3
"""Stan planu: scalone kroki, kroki gotowe do startu, blokady; zatwierdzanie bramek i oznaczanie scaleń.

  python3 tools/agents/plan_status.py                                     # plan platformy
  python3 tools/agents/plan_status.py --backlog profiles/kredyty/backlog.yaml
  python3 tools/agents/plan_status.py --merged S10                        # człowiek scalił krok S10
  python3 tools/agents/plan_status.py --approve-gate G0 --by "Jan Kowalski" --evidence "ADR-003, ADR-004 przyjęte"
Bramkę można zatwierdzić dopiero po scaleniu kroków z jej pola `after` (inaczej: --force, decyzja człowieka).
"""
from __future__ import annotations

import argparse
import sys

from steplib import Plan, today, write_json


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backlog", default=None)
    ap.add_argument("--merged")
    ap.add_argument("--approve-gate")
    ap.add_argument("--by")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--force", action="store_true", help="zatwierdź bramkę mimo niescalonych kroków z pola after")
    args = ap.parse_args()
    plan = Plan(args.backlog)

    if args.merged:
        if args.merged not in plan.steps:
            sys.exit(f"Nie ma kroku {args.merged} w {plan.path.name}")
        p = plan.progress(args.merged) or {"step": args.merged}
        p.update({"status": "done", "merged": True, "merged_on": today()})
        write_json(plan.progress_dir / f"{args.merged}.json", p)
        print(f"{args.merged}: oznaczono jako scalony")
        return 0
    if args.approve_gate:
        if not args.by:
            sys.exit("Podaj --by (kto zatwierdza bramkę).")
        gate = plan.data.get("gates", {}).get(args.approve_gate)
        if gate is None:
            sys.exit(f"Nie ma bramki {args.approve_gate} w {plan.path.name}")
        missing = [s for s in gate.get("after", []) if not plan.is_merged(s)]
        if missing and not args.force:
            print(f"{args.approve_gate}: nie można zatwierdzić — niescalone kroki: {', '.join(missing)}")
            return 1
        g = plan.gates()
        g[args.approve_gate] = {"approved_by": args.by, "date": today(), "evidence": args.evidence}
        write_json(plan.gates_file, g)
        print(f"{args.approve_gate}: zatwierdzona przez {args.by}")
        return 0

    merged, in_progress, ready, blocked = [], [], [], []
    for s in plan.data["steps"]:
        p = plan.progress(s["id"])
        if plan.is_merged(s["id"]):
            merged.append(s)
        elif p:
            in_progress.append((s, p.get("status", "w toku")))
        else:
            ok, reasons = plan.readiness(s)
            (ready if ok else blocked).append((s, reasons))
    ready.sort(key=lambda x: (not x[0].get("critical"), {"L": 0, "M": 1, "S": 2}.get(x[0].get("size"), 3)))

    title = f"Plan profilu „{plan.profile}”" if plan.profile else "Plan platformy"
    print(f"{title} — scalone: {len(merged)}/{len(plan.steps)} · w toku: {len(in_progress)} · gotowe: {len(ready)} · zablokowane: {len(blocked)}")
    print(f"Bramki zatwierdzone: {', '.join(plan.gates()) or 'brak'}")
    if in_progress:
        print("\nW toku:")
        for s, st in in_progress:
            print(f"  {s['id']:7} {st:10} {s['title']}")
    print("\nGotowe do startu (krytyczne najpierw):")
    for s, _ in ready:
        print(f"  {s['id']:7} {'K' if s.get('critical') else ' '} {s.get('size', '-')} {plan.agent_name(s['agent']):28} {s['title']}")
    print(f"\nRównolegle wolno prowadzić: {plan.data.get('parallelism', 1)} kroki")
    external = sorted({r.split()[0] for _, rs in blocked for r in rs if r.endswith("nie jest scalony") and r.split()[0] not in plan.steps})
    if external:
        print("Czekają na kroki platformy: " + ", ".join(external))
    waiting_gates = sorted({r.split()[1] for _, rs in blocked for r in rs if r.startswith("bramka")})
    if waiting_gates:
        print("Czekają na bramki: " + ", ".join(waiting_gates))
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/agents/validate_output.py

````python
#!/usr/bin/env python3
"""Waliduje wynik agenta (JSON) względem schematu roli. Użycie: validate_output.py <schemat> <plik.json|->"""
import json
import sys

try:
    import jsonschema
except ImportError:  # pragma: no cover
    sys.exit("Zainstaluj pakiet jsonschema: pip install jsonschema")

schema = json.load(open(sys.argv[1], encoding="utf-8"))
raw = sys.stdin.read() if sys.argv[2] == "-" else open(sys.argv[2], encoding="utf-8").read()
try:
    jsonschema.validate(json.loads(raw), schema)
except (json.JSONDecodeError, jsonschema.ValidationError) as e:
    print(f"NIEZGODNE: {e.__class__.__name__}: {str(e).splitlines()[0]}", file=sys.stderr)
    sys.exit(1)
print("ZGODNE")
````

## Plik: tools/guard/enforce_write_scope.py

````python
#!/usr/bin/env python3
"""Strażnik zakresu zapisu dla agentów Process Hub (OpenCode i CI).

Tryby:
  (domyślny)                 stdin: {"tool": "write", "path": "<plik>"} — kod 0 = dozwolone, 2 = blokada (powód na stderr).
                             Wywołuje go plugin OpenCode `.opencode/plugin/write-scope.js` przed każdym zapisem.
  --check <ścieżka>...       sprawdza podane ścieżki względem `.agent-scope` (skrypty, ręczna weryfikacja).
  --verify-diff <base>       bramka CI i DoD: wszystkie pliki zmienione względem <base> — zatwierdzone, niezatwierdzone
                             i nieśledzone — muszą mieścić się w zakresie (łapie też zmiany zrobione komendą, nie edytorem).
      [--profile <id>]       bramka CI dla PR zespołu profilu: zmiany wyłącznie w profiles/<id>/** (bez .agent-scope).
  --self-test                test reguł.

`.agent-scope` (katalog główny worktree) tworzy `tools/agents/prepare_step.py` z pola `writes` kroku:
  - jeden glob w linii; `#` — komentarz;
  - `@profile <id>` — krok zespołu profilu: każdy zapis musi leżeć w profiles/<id>/, niezależnie od globów.
Brak pliku = sesja człowieka: zapis dozwolony (z PH_STRICT=1 — bez ścieżek chronionych).
Wniosek RFC (`docs/rfc/RFC-*.md`) wolno złożyć zawsze — także w kroku profilu; to jedyna droga zmiany poza zakresem.
"""
from __future__ import annotations

import fnmatch
import json
import os
import subprocess
import sys

# Ścieżki chronione: zmiana tylko, gdy glob w .agent-scope wprost je wymienia (marker); inaczej — RFC w docs/rfc/.
PROTECTED = {
    "specs/**": "specs/",
    "**/Contracts/**": "/Contracts",
    "docs/adr/**": "docs/adr",
    "config/authorization/**": "config/authorization",
    "plan/backlog.yaml": "plan/backlog.yaml",
    "AGENTS.md": "AGENTS.md",                                   # tylko plik główny; AGENTS.md modułów i profili są wolne
    "CODEOWNERS": "CODEOWNERS",
    "src/Platform/ProcessHub.Extensibility/**": "ProcessHub.Extensibility",   # SDK rozszerzeń = kontrakt z profilami
    "frontend/libs/platform/extension-sdk/**": "extension-sdk",
    "profiles/*/profile.yaml": "profile.yaml",                 # kontrakt profilu z platformą
    "profiles/*/authorization.yaml": "authorization.yaml",
}

# Wniosek o zmianę poza zakresem kroku: dozwolony w każdym kroku (AGENTS.md, zasada 8).
RFC_GLOB = "docs/rfc/RFC-*.md"


def project_root() -> str:
    return os.environ.get("PH_PROJECT_DIR") or os.getcwd()


def load_scope(root: str):
    """Zwraca (globy, profil) albo (None, None), gdy brak .agent-scope."""
    path = os.path.join(root, ".agent-scope")
    if not os.path.exists(path):
        return None, None
    globs, profile = [], None
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("@profile "):
                profile = line.split(None, 1)[1].strip()
            else:
                globs.append(line)
    return globs, profile


def matches(rel: str, globs) -> bool:
    return any(fnmatch.fnmatchcase(rel, g) or fnmatch.fnmatchcase(rel, g.rstrip("/*")) for g in globs)


def normalize(rel: str) -> str:
    rel = rel.replace("\\", "/")
    while rel.startswith("./"):
        rel = rel[2:]
    return rel


def decide(rel: str, scope, profile: str | None = None):
    rel = normalize(rel)
    if rel.startswith("../") or rel == ".." or os.path.isabs(rel):
        return False, f"zapis poza repozytorium: {rel}"
    if fnmatch.fnmatchcase(rel, RFC_GLOB) and "/" not in rel[len("docs/rfc/"):]:
        return True, ""
    if profile:
        own = f"profiles/{profile}/"
        if rel.startswith("profiles/") and not rel.startswith(own):
            other = rel.split("/")[1]
            return False, f"{rel} należy do profilu „{other}” — krok profilu „{profile}” zmienia tylko {own}**"
        if not rel.startswith(own):
            return False, f"{rel} to część platformy — krok profilu „{profile}” zmienia tylko {own}** (zmiana platformy: RFC w docs/rfc/)"
    if scope is None:
        if os.environ.get("PH_STRICT") == "1" and matches(rel, list(PROTECTED)):
            return False, f"ścieżka chroniona bez .agent-scope: {rel}"
        return True, ""
    for pattern, marker in PROTECTED.items():
        if fnmatch.fnmatchcase(rel, pattern):
            explicit = any(marker in g and matches(rel, [g]) for g in scope) or scope == ["**"]
            if not explicit:
                return False, f"ścieżka chroniona ({rel}) — złóż RFC w docs/rfc/ zamiast edytować"
    if not matches(rel, scope):
        return False, f"{rel} jest poza zakresem kroku; dozwolone: {', '.join(scope)}"
    return True, ""


def relative(target: str, root: str) -> str:
    return os.path.relpath(os.path.abspath(os.path.join(root, target)), root)


def stdin_mode() -> int:
    data = json.load(sys.stdin)
    target = data.get("path")
    if not target:
        return 0
    root = project_root()
    scope, profile = load_scope(root)
    ok, why = decide(relative(target, root), scope, profile)
    if ok:
        return 0
    print(f"BLOCKED: {why}", file=sys.stderr)
    return 2


def check_paths(paths) -> int:
    root = project_root()
    scope, profile = load_scope(root)
    bad = 0
    for p in paths:
        ok, why = decide(relative(p, root), scope, profile)
        print(("OK       " if ok else "BLOCKED  ") + (p if ok else why))
        bad += 0 if ok else 1
    return 1 if bad else 0


def verify_diff(base: str, profile_arg: str | None) -> int:
    root = project_root()
    scope, profile = load_scope(root)
    profile = profile_arg or profile
    if profile and scope is None:
        scope = [f"profiles/{profile}/**"]
    res = subprocess.run(["git", "diff", "--name-only", f"{base}...HEAD"], capture_output=True, text=True, cwd=root)
    if res.returncode != 0:
        print(f"BŁĄD: nie udało się porównać z {base}: {res.stderr.strip()}", file=sys.stderr)
        return 2
    files = res.stdout.split()
    # Zmiany jeszcze niezatwierdzone i pliki nieśledzone (np. powstałe z komendy) — ten sam zakres.
    for extra in (["diff", "--name-only", "HEAD"], ["ls-files", "--others", "--exclude-standard"]):
        more = subprocess.run(["git", *extra], capture_output=True, text=True, cwd=root)
        if more.returncode == 0:
            files += [f for f in more.stdout.split() if f not in files]
    bad = [(f, why) for f in files for ok, why in [decide(f, scope, profile)] if not ok]
    for f, why in bad:
        print(f"SCOPE VIOLATION: {why}", file=sys.stderr)
    return 1 if bad else 0


def self_test() -> int:
    module = ["src/Modules/TaskWork/**", "tests/TaskWork.*/**"]
    prof = ["profiles/kredyty/**"]
    cases = [
        # (ścieżka, globy, profil, oczekiwany wynik)
        ("src/Modules/TaskWork/Domain/WorkItem.cs", module, None, True),
        ("src/Modules/TaskWork/Contracts/ITaskWork.cs", module, None, False),
        ("src/Modules/Audit/Domain/JournalEntry.cs", module, None, False),
        ("tests/TaskWork.Specs/Steps/ClaimSteps.cs", module, None, True),
        ("specs/tasks/claim-and-complete.feature", module, None, False),
        ("../outside.txt", module, None, False),
        ("src/Modules/TaskWork/AGENTS.md", module, None, True),
        ("src/Modules/TaskWork/Contracts/X.cs", ["src/Modules/*/Contracts/**"], None, True),
        ("profiles/kredyty/backend/Kredyty.Extension/Scoring/RecalculateScoring.cs", prof, "kredyty", True),
        ("profiles/kredyty/specs/scoring.feature", prof, "kredyty", True),
        ("profiles/kredyty/AGENTS.md", prof, "kredyty", True),
        ("profiles/kredyty/profile.yaml", prof, "kredyty", False),
        ("profiles/aml/backend/Aml.Extension/Sanctions.cs", prof, "kredyty", False),
        ("profiles/aml/backend/Aml.Extension/Sanctions.cs", ["profiles/**"], "kredyty", False),
        ("src/Modules/TaskWork/Domain/WorkItem.cs", ["**"], "kredyty", False),
        ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", ["src/Platform/**"], None, False),
        ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", ["src/Platform/ProcessHub.Extensibility/**"], None, True),
        ("docs/rfc/RFC-S30-kontrakt.md", module, None, True),
        ("docs/rfc/RFC-KRE-02-sdk.md", prof, "kredyty", True),
        ("docs/rfc/notatki.md", module, None, False),
        ("docs/rfc/RFC-S30/zalacznik.md", module, None, False),
    ]
    failed = [(p, exp) for p, g, pr, exp in cases if decide(p, g, pr)[0] != exp]
    for p, exp in failed:
        print(f"self-test FAIL: {p} oczekiwano {'dozwolone' if exp else 'blokada'}", file=sys.stderr)
    print("self-test OK" if not failed else "self-test FAILED")
    return 1 if failed else 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if args[:1] == ["--self-test"]:
        sys.exit(self_test())
    if args[:1] == ["--check"]:
        sys.exit(check_paths(args[1:]))
    if args[:1] == ["--verify-diff"] and len(args) >= 2:
        prof = args[args.index("--profile") + 1] if "--profile" in args else None
        sys.exit(verify_diff(args[1], prof))
    sys.exit(stdin_mode())
````

## Plik: tools/profiles/validate_profiles.py

````python
#!/usr/bin/env python3
"""Walidacja profili projektów i generowanie CODEOWNERS.

  python3 tools/profiles/validate_profiles.py                     # raport
  python3 tools/profiles/validate_profiles.py --check             # bramka CI: błędy lub nieaktualny CODEOWNERS → kod 1
  python3 tools/profiles/validate_profiles.py --write-codeowners  # zapisuje CODEOWNERS

Sprawdza schemat (profiles/profile.schema.json) i reguły międzyprofilowe: przestrzenie nazw (R10), wyłączną własność
procesów i grup kandydujących, spójność ról, operacji, slotów UI, klas danych i zakresów zapisu w planie zespołu.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
PROFILES = ROOT / "profiles"
CLASS_RANK = {"internal": 0, "confidential": 1, "restricted": 2}
WRITE_KINDS = {"task-action", "case-action", "profile-action"}
GENERATED = "# WYGENEROWANE przez tools/profiles/validate_profiles.py --write-codeowners — źródła: config/ownership.yaml, profiles/*/profile.yaml"


def platform_permissions() -> set[str]:
    roles = yaml.safe_load((ROOT / "config/authorization/roles.example.yaml").read_text(encoding="utf-8"))["roles"]
    return {p for r in roles for p in r.get("permissions", [])}


def load_profiles():
    out = []
    for d in sorted(p for p in PROFILES.iterdir() if p.is_dir() and not p.name.startswith("_")):
        manifest = d / "profile.yaml"
        if not manifest.exists():
            out.append((d.name, None, None, [f"{d.name}: brak profile.yaml"]))
            continue
        prof = yaml.safe_load(manifest.read_text(encoding="utf-8"))
        authz_path = d / "authorization.yaml"
        authz = yaml.safe_load(authz_path.read_text(encoding="utf-8")) if authz_path.exists() else None
        out.append((d.name, prof, authz, []))
    return out


def validate(profiles) -> list[str]:
    schema = json.loads((PROFILES / "profile.schema.json").read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    platform_perms = platform_permissions()
    errors: list[str] = []
    process_owner: dict[str, str] = {}
    candidate_owner: dict[str, str] = {}
    group_owner: dict[str, str] = {}

    for name, prof, authz, errs in profiles:
        errors += errs
        if prof is None:
            continue
        for e in validator.iter_errors(prof):
            errors.append(f"{name}: schemat — {'/'.join(map(str, e.path)) or '(korzeń)'}: {e.message}")
        pid = prof.get("id")
        if pid != name:
            errors.append(f"{name}: id „{pid}” musi być równe nazwie katalogu")
        ns = f"{pid}."
        if prof.get("data", {}).get("schema") != f"prj_{pid}":
            errors.append(f"{name}: schemat danych musi nazywać się prj_{pid}")
        own_processes = {p["bpmnProcessId"] for p in prof.get("processes", [])}
        for proc in own_processes:
            if proc in process_owner:
                errors.append(f"{name}: proces {proc} należy już do profilu {process_owner[proc]} (proces ma jednego właściciela)")
            process_owner[proc] = name
        perms = {p["id"]: p for p in prof.get("permissions", [])}
        for pid_ in perms:
            if not pid_.startswith(ns):
                errors.append(f"{name}: uprawnienie {pid_} spoza przestrzeni nazw {ns} (R10)")
        roles = {r["id"]: r for r in prof.get("roles", [])}
        for r in roles.values():
            for p in r.get("permissions", []):
                if p not in perms:
                    errors.append(f"{name}: rola {r['id']} używa nieznanego uprawnienia {p}")
            for proc in r.get("processes", []):
                if proc not in own_processes:
                    errors.append(f"{name}: rola {r['id']} obejmuje proces {proc} spoza profilu (R9)")
        for op in prof.get("operations", []):
            if not op["id"].startswith(ns):
                errors.append(f"{name}: operacja {op['id']} spoza przestrzeni nazw {ns} (R10)")
            if op["permission"] not in perms and op["permission"] not in platform_perms:
                errors.append(f"{name}: operacja {op['id']} — nieznane uprawnienie {op['permission']}")
            proc = op.get("appliesTo", {}).get("process")
            if proc and proc not in own_processes:
                errors.append(f"{name}: operacja {op['id']} na procesie {proc} spoza profilu (R9)")
            if op["kind"] in WRITE_KINDS and "requiresAssignee" not in op:
                errors.append(f"{name}: operacja zapisu {op['id']} musi jawnie deklarować requiresAssignee")
            if op["kind"] == "task-action" and op.get("requiresAssignee") is False:
                errors.append(f"{name}: task-action {op['id']} bez wymogu assignee łamie R1")
            if op["kind"] == "profile-action":          # zapis danych profilu bez zadania i sprawy (ADR-017)
                if op.get("requiresAssignee"):
                    errors.append(f"{name}: profile-action {op['id']} nie dotyczy zadania — requiresAssignee musi być false")
                if op.get("appliesTo"):
                    errors.append(f"{name}: profile-action {op['id']} działa na danych profilu — bez appliesTo (R9)")
                if perms.get(op["permission"], {}).get("kind") != "write":
                    errors.append(f"{name}: profile-action {op['id']} wymaga uprawnienia projektu rodzaju write")
            kind = perms.get(op["permission"], {}).get("kind")
            if kind == "sensitive-read" and not op.get("sensitive"):
                errors.append(f"{name}: operacja {op['id']} z uprawnieniem odczytu wrażliwego musi mieć sensitive: true")
        ui = prof.get("ui", {})
        for route in ui.get("routes", []):
            if not route["path"].startswith(f"/p/{pid}/"):
                errors.append(f"{name}: trasa {route['path']} musi zaczynać się od /p/{pid}/")
        for slot in ui.get("slots", []):
            if slot.get("permission") and slot["permission"] not in perms and slot["permission"] not in platform_perms:
                errors.append(f"{name}: slot {slot['component']} — nieznane uprawnienie {slot['permission']}")
            proc = slot.get("appliesTo", {}).get("process")
            if proc and proc not in own_processes:
                errors.append(f"{name}: slot {slot['component']} na procesie {proc} spoza profilu (R9)")
        for jt in prof.get("integrations", {}).get("jobTypes", []):
            if not jt.startswith(ns):
                errors.append(f"{name}: typ zadania {jt} musi zaczynać się od {ns}")
        dev = prof.get("dev", {})
        data_class = prof.get("data", {}).get("classification", "internal")
        if CLASS_RANK.get(dev.get("dataClass", data_class), 0) < CLASS_RANK.get(data_class, 0):
            errors.append(f"{name}: dev.dataClass słabsza niż klasyfikacja danych profilu ({data_class})")
        backlog = dev.get("backlog")
        if backlog:
            bpath = ROOT / backlog
            if not bpath.exists():
                errors.append(f"{name}: brak planu zespołu {backlog}")
            else:
                b = yaml.safe_load(bpath.read_text(encoding="utf-8"))
                if b.get("profile") != pid:
                    errors.append(f"{name}: {backlog} musi mieć profile: {pid}")
                for step in b.get("steps", []):
                    for w in step.get("writes", []):
                        if not w.startswith(f"profiles/{pid}/"):
                            errors.append(f"{name}: krok {step['id']} zapisuje poza profiles/{pid}/ ({w})")
        if authz is None:
            errors.append(f"{name}: brak authorization.yaml")
            continue
        if authz.get("profile") != pid:
            errors.append(f"{name}: authorization.yaml musi mieć profile: {pid}")
        for a in authz.get("assignments", []):
            for r in a.get("roles", []):
                if r not in roles:
                    errors.append(f"{name}: grupa {a['group']} dostaje nieznaną rolę {r}")
            if a["group"] in group_owner and group_owner[a["group"]] != name:
                errors.append(f"{name}: grupa {a['group']} jest już przypisana w profilu {group_owner[a['group']]} — użyj osobnej grupy AD per profil")
            group_owner[a["group"]] = name
        for cg in (authz.get("candidateGroups") or {}):
            if cg in candidate_owner:
                errors.append(f"{name}: grupa kandydująca {cg} należy już do profilu {candidate_owner[cg]}")
            candidate_owner[cg] = name
    return errors


def codeowners(profiles) -> str:
    own = yaml.safe_load((ROOT / "config/ownership.yaml").read_text(encoding="utf-8"))
    handle = {k: own[k] for k in ("platform", "architects", "security", "design")}
    lines = [GENERATED, "", f"*  {own['platform']}"]
    for entry in own["paths"]:
        lines.append(f"{entry['path']}  " + " ".join(handle[o] for o in entry["owners"]))
    lines.append("")
    for name, prof, _, _ in profiles:
        if prof is None:
            continue
        team = prof["owner"]["team"]
        lines.append(f"/profiles/{name}/  {team}")
        lines.append(f"/profiles/{name}/profile.yaml  {team} {handle['architects']}")
        lines.append(f"/profiles/{name}/authorization.yaml  {team} {handle['architects']} {handle['security']}")
    return "\n".join(lines) + "\n"


def self_test() -> int:
    """Złe manifesty muszą zostać odrzucone — test reguł bez plików na dysku."""
    import copy
    base = {name: (prof, authz) for name, prof, authz, _ in load_profiles() if prof}
    k, ka = base["kredyty"]
    a, aa = base["aml"]

    def run(mut):
        kk, kka, am, ama = copy.deepcopy(k), copy.deepcopy(ka), copy.deepcopy(a), copy.deepcopy(aa)
        mut(kk, kka, am, ama)
        return validate([("kredyty", kk, kka, []), ("aml", am, ama, [])])

    cases = {
        "proces w dwóch profilach": lambda kk, kka, am, ama: am["processes"].append({"bpmnProcessId": "wniosek-kredytowy"}),
        "uprawnienie w cudzej przestrzeni": lambda kk, kka, am, ama: am["permissions"].append({"id": "kredyty.Case.Export", "kind": "read", "description": "x"}),
        "operacja na cudzym procesie": lambda kk, kka, am, ama: am["operations"][0]["appliesTo"].update({"process": "wniosek-kredytowy"}),
        "task-action bez assignee": lambda kk, kka, am, ama: kk["operations"][0].update({"requiresAssignee": False}),
        "odczyt wrażliwy bez oznaczenia": lambda kk, kka, am, ama: kk["operations"][2].pop("sensitive"),
        "grupa kandydująca w dwóch profilach": lambda kk, kka, am, ama: ama["candidateGroups"].update({"kre-analitycy": "PH-AML-ANALITYCY"}),
        "rola z nieznanym uprawnieniem": lambda kk, kka, am, ama: kk["roles"][0]["permissions"].append("aml.Party.View"),
        "trasa poza /p/<id>/": lambda kk, kka, am, ama: kk["ui"]["routes"][0].update({"path": "/portfel"}),
        "słabsza klasa danych agentów": lambda kk, kka, am, ama: am["dev"].update({"dataClass": "confidential"}),
        "profile-action z uprawnieniem platformy": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "Task.ViewOwn", "requiresAssignee": False}),
        "profile-action przypięta do procesu": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "kredyty.Limit.Override", "requiresAssignee": False,
             "appliesTo": {"process": "wniosek-kredytowy"}}),
        "profile-action z wymogiem assignee": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "kredyty.Limit.Override", "requiresAssignee": True}),
    }
    failed = [name for name, mut in cases.items() if not run(mut)]
    ok_errors = validate([("kredyty", k, ka, []), ("aml", a, aa, [])])
    for name in failed:
        print(f"self-test FAIL: nie wykryto „{name}”", file=sys.stderr)
    if ok_errors:
        print("self-test FAIL: poprawne profile zgłaszają błędy", file=sys.stderr)
    print("self-test OK" if not failed and not ok_errors else "self-test FAILED")
    return 1 if failed or ok_errors else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--write-codeowners", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    profiles = load_profiles()
    errors = validate(profiles)
    for name, prof, authz, _ in profiles:
        if prof:
            print(f"{name:10} procesy: {', '.join(p['bpmnProcessId'] for p in prof['processes'])} · role: {len(prof['roles'])} · "
                  f"operacje: {len(prof.get('operations', []))} · dane: {prof['data']['schema']} ({prof['data']['classification']}) · "
                  f"integracja: {prof.get('integration', 'in-process')} · zespół: {prof['owner']['team']}")
    for e in errors:
        print(f"BŁĄD: {e}", file=sys.stderr)
    content = codeowners(profiles)
    path = ROOT / "CODEOWNERS"
    if args.write_codeowners and not errors:
        path.write_text(content, encoding="utf-8")
        print("zapisano CODEOWNERS")
    stale = not path.exists() or path.read_text(encoding="utf-8") != content
    if args.check and stale:
        print("NIEAKTUALNE: CODEOWNERS — uruchom --write-codeowners", file=sys.stderr)
    return 1 if errors or (args.check and stale) else 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: tools/profiles/new_profile.py

````python
#!/usr/bin/env python3
"""Zakłada nowy profil projektu z szablonu profiles/_template.

  python3 tools/profiles/new_profile.py lizing --name "Lizing" --team "@bank/zespol-lizing" --process umowa-lizingowa
Potem: uzupełnij profile.yaml i authorization.yaml, uruchom validate_profiles.py --write-codeowners i render_agents.py.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEMPLATE = ROOT / "profiles/_template"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("id")
    ap.add_argument("--name", required=True)
    ap.add_argument("--team", required=True, help="grupa w systemie kontroli wersji, np. @bank/zespol-lizing")
    ap.add_argument("--process", required=True, help="bpmnProcessId pierwszego procesu profilu")
    ap.add_argument("--po", default="Właściciel produktu")
    ap.add_argument("--description", default="Opis projektu do uzupełnienia.")
    args = ap.parse_args()

    if not re.fullmatch(r"[a-z][a-z0-9]{1,23}", args.id):
        sys.exit("id: małe litery i cyfry, 2–24 znaki, bez myślników (przestrzeń nazw i schemat prj_<id>)")
    target = ROOT / "profiles" / args.id
    if target.exists():
        sys.exit(f"profil {args.id} już istnieje")
    shutil.copytree(TEMPLATE, target)
    values = {"__ID__": args.id, "__NAME__": args.name, "__TEAM__": args.team, "__PROCESS__": args.process,
              "__PO__": args.po, "__OPIS__": args.description, "__GROUP__": args.id.upper(),
              "__PREFIX__": args.id[:3].upper()}
    for f in target.rglob("*"):
        if f.is_file() and f.suffix in {".yaml", ".md"}:
            text = f.read_text(encoding="utf-8")
            for k, v in values.items():
                text = text.replace(k, v)
            f.write_text(text, encoding="utf-8")
    print(f"utworzono profiles/{args.id}/ — uzupełnij profile.yaml i authorization.yaml, potem:")
    print("  python3 tools/profiles/validate_profiles.py --write-codeowners")
    print("  python3 tools/agents/render_agents.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

## Plik: .opencode/plugin/write-scope.js

````javascript
// Plugin OpenCode: blokuje zapis poza .agent-scope, edycję ścieżek chronionych (specyfikacje, kontrakty, ADR,
// uprawnienia, SDK rozszerzeń, kontrakty profili) oraz zapis do cudzego profilu projektu.
// Logika: tools/guard/enforce_write_scope.py albo narzędzie .NET `ph guard` (tools/dotnet) — ta sama w CI.
import { check, targetsOf } from "../lib/write-scope-core.js"

export default async ({ directory, worktree }) => {
  const root = worktree || directory
  return {
    "tool.execute.before": async (input, output) => {
      for (const file of targetsOf(input?.tool, output?.args)) {
        const result = check(root, file, input?.tool)
        if (!result.ok) throw new Error(result.reason)
      }
    },
  }
}
````

## Plik: .opencode/lib/write-scope-core.js

````javascript
// Logika strażnika zakresu zapisu dla OpenCode (bez rejestracji pluginu — testowalna osobno).
// Decyzję podejmuje strażnik repozytorium — ta sama logika w CI (--verify-diff). Kolejność wyboru implementacji:
//   1. zmienna PH_GUARD (np. "ph guard" albo pełna ścieżka do ph z argumentem guard),
//   2. zbudowane narzędzie .NET: tools/dotnet/publish/ph (Windows: ph.exe) — gdy Python jest zablokowany,
//   3. Python: tools/guard/enforce_write_scope.py.
import { spawnSync } from "node:child_process"
import fs from "node:fs"
import path from "node:path"

const WRITE_TOOLS = new Set(["write", "edit", "multiedit", "patch", "apply_patch"])
const PATCH_RE = /^\*\*\* (?:Add File|Update File|Delete File|Move to):\s*(.+)$/gm

/** Ścieżki, które narzędzie zamierza zmienić (filePath albo pliki z tekstu łatki). */
export function targetsOf(tool, args = {}) {
  if (!WRITE_TOOLS.has(tool) && typeof args?.patchText !== "string") return []
  const out = new Set()
  for (const key of ["filePath", "file_path", "path"]) if (typeof args?.[key] === "string") out.add(args[key])
  for (const value of Object.values(args ?? {})) {
    if (typeof value !== "string") continue
    for (const m of value.matchAll(PATCH_RE)) out.add(m[1].trim())
  }
  return [...out]
}

/** Polecenie strażnika: {cmd, args} wg kolejności opisanej wyżej. */
export function guardCommand(root, env = process.env) {
  if (env.PH_GUARD && env.PH_GUARD.trim()) {
    const parts = env.PH_GUARD.trim().split(/\s+/)
    return { cmd: parts[0], args: parts.slice(1) }
  }
  const published = path.join(root, "tools", "dotnet", "publish", process.platform === "win32" ? "ph.exe" : "ph")
  if (fs.existsSync(published)) return { cmd: published, args: ["guard"] }
  return { cmd: "python3", args: [path.join(root, "tools", "guard", "enforce_write_scope.py")] }
}

/** Zwraca {ok, reason}. Brak strażnika (np. zablokowany Python bez narzędzia .NET) = blokada (fail-closed). */
export function check(root, file, tool = "write", env = process.env) {
  const abs = path.isAbsolute(file) ? file : path.join(root, file)
  const { cmd, args } = guardCommand(root, env)
  const res = spawnSync(cmd, args, {
    input: JSON.stringify({ tool, path: abs }),
    encoding: "utf8",
    cwd: root,
    env: { ...env, PH_PROJECT_DIR: root },
  })
  if (res.error) {
    return { ok: false, reason: `Strażnik zakresu nie uruchomił się (${cmd}): ${res.error.message} — zbuduj narzędzia .NET (tools/dotnet/README.md) albo ustaw PH_GUARD` }
  }
  if (res.status === 0) return { ok: true }
  if (res.status === 2) return { ok: false, reason: (res.stderr || "").trim() }
  return { ok: false, reason: `Strażnik zakresu zakończył się kodem ${res.status}: ${(res.stderr || "").trim()}` }
}
````

