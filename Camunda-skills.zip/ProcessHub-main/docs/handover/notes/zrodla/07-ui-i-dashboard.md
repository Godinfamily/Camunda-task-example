# 07-ui-i-dashboard — Propozycja UI, tokeny, formatki (założenia wizualne i katalog pól), dashboard harmonogramu: rejestr ryzyk i decyzji oraz dane

Pakiet zawiera 13 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: plan/dashboard/data/steps.json (skrót tabelaryczny)

Liczba rekordów w pełnym zbiorze: 57 (każdy z kilkudziesięcioma polami); poniżej najważniejsze kolumny.

| Krok | Nazwa | Faza | Krytyczny | Tydz. start–koniec | Zapas (dni) | Złożoność | Udział AI | Bez AI (od) | Z AI (od) | Zakres | Rola wiodąca | Ryzyko | Bloker zewnętrzny |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S00 | Repozytorium i harness | 0 Przygotowanie i PoC | tak | 0.0–0.5 | 0.0 | niska (1.85) | 30% | 3.2 | 2.7 | Infrastruktura | Architekt / tech lead | niskie |  |
| S01 | PoC SDK Camunda | 0 Przygotowanie i PoC | tak | 0.5–1.9 | 0.0 | wysoka (3.5) | 40% | 8.5 | 6.8 | Camunda, Backend | Backend .NET | wysokie |  |
| S05 | Scenariusze z biznesem | 0 Przygotowanie i PoC |  | 0.5–2.0 | 6.7 | niska (2.2) | 40% | 8.7 | 7.3 | Biznes, Testy | PO / analityk | wysokie | dostępność biznesu na warsztatach |
| S06 | Środowisko dev w banku | 0 Przygotowanie i PoC |  | 0.5–2.5 | 67.6 | wysoka (3.7) | 30% | 16.7 | 14.7 | Infrastruktura, Camunda, Dane, Bezpieczeństwo | DevOps | wysokie | dostępy i procedury IT banku |
| S07 | PoC formatek w UI | 0 Przygotowanie i PoC |  | 0.5–1.7 | 49.5 | wysoka (3.3) | 50% | 8.3 | 6.0 | Frontend, Camunda | Frontend Angular | wysokie |  |
| S09 | Warstwa wizualna i Figma | 0 Przygotowanie i PoC |  | 0.5–2.2 | 39.8 | średnia (2.4) | 30% | 9.5 | 8.4 | Frontend, Biznes | Projektant UX | wysokie | dostępność projektanta UX i księgi znaku banku |
| S02 | PoC autoryzacji | 0 Przygotowanie i PoC | tak | 1.9–3.3 | 0.0 | bardzo wysoka (4.15) | 35% | 8.7 | 7.1 | Bezpieczeństwo, Camunda | Backend .NET | wysokie | decyzja zespołu bezpieczeństwa |
| S03 | PoC task listenera | 0 Przygotowanie i PoC |  | 1.9–2.5 | 4.2 | średnia (3.0) | 50% | 4.2 | 2.9 | Camunda | Backend .NET | wysokie |  |
| S04 | PoC zasilania read modelu | 0 Przygotowanie i PoC |  | 1.9–2.6 | 3.4 | średnia (3.0) | 50% | 5.3 | 3.7 | Camunda, Dane | Backend .NET | wysokie |  |
| S08 | PoC walidacji i FEEL | 0 Przygotowanie i PoC |  | 1.9–2.7 | 43.7 | wysoka (3.15) | 50% | 5.3 | 3.9 | Camunda, Backend | Backend .NET | wysokie |  |
| S17 | bpmnlint i modele BPMN | 1 Fundament |  | 2.0–3.4 | 36.1 | niska (1.65) | 75% | 3.2 | 1.5 | Camunda | Backend .NET | niskie |  |
| S10 | Szkielet rozwiązania | 1 Fundament | tak | 3.3–4.8 | 0.0 | niska (1.55) | 80% | 4.2 | 1.7 | Backend | Backend .NET | niskie |  |
| S11 | Testy architektury i CI | 1 Fundament |  | 4.8–5.1 | 112.5 | niska (1.85) | 75% | 3.2 | 1.5 | Testy, Infrastruktura | Backend .NET | niskie |  |
| S12 | Building Blocks | 1 Fundament | tak | 4.8–5.8 | 0.0 | średnia (2.7) | 65% | 12.3 | 7.5 | Backend, Bezpieczeństwo | Backend .NET | średnie |  |
| S13 | Baza MSSQL | 1 Fundament |  | 4.8–5.7 | 13.3 | średnia (2.65) | 60% | 7.3 | 4.7 | Dane, Bezpieczeństwo | Backend .NET | średnie |  |
| S14 | Harness BDD | 1 Fundament |  | 4.8–5.4 | 110.9 | niska (2.2) | 70% | 6.2 | 3.1 | Testy | QA / BDD | niskie |  |
| S15 | Kontrakty v1 i OpenAPI | 1 Fundament | tak | 5.8–6.7 | 0.0 | wysoka (3.35) | 55% | 9.3 | 6.8 | Backend, Frontend | Architekt / tech lead | wysokie |  |
| S18 | BFF i logowanie RHBK | 1 Fundament |  | 5.8–7.0 | 102.9 | wysoka (3.55) | 50% | 8.2 | 6.1 | Bezpieczeństwo, Backend | Backend .NET | wysokie |  |
| S16 | Frontend: shell i ui-kit | 1 Fundament |  | 6.7–8.2 | 17.5 | niska (2.2) | 70% | 10.3 | 5.3 | Frontend | Frontend Angular | niskie | licencja Kendo UI i dostęp do rejestru npm |
| S19 | SDK rozszerzeń i rejestr profili | 1 Fundament |  | 6.7–8.0 | 25.2 | wysoka (3.2) | 45% | 12.3 | 10.1 | Backend, Frontend | Backend .NET | wysokie |  |
| S20 | Party i zastępstwa | 2 Dostęp, Camunda, audyt, formatki |  | 6.7–7.9 | 11.0 | średnia (2.5) | 70% | 7.2 | 3.9 | Backend | Backend .NET | niskie |  |
| S21 | Autoryzacje jako kod | 2 Dostęp, Camunda, audyt, formatki |  | 6.7–8.8 | 6.3 | bardzo wysoka (3.85) | 55% | 12.3 | 8.6 | Bezpieczeństwo, Camunda | Backend .NET | wysokie |  |
| S22 | Adaptery SDK | 2 Dostęp, Camunda, audyt, formatki | tak | 6.7–8.4 | 0.0 | wysoka (3.55) | 60% | 14.7 | 9.4 | Camunda, Backend | Backend .NET | wysokie |  |
| S25 | Audyt | 2 Dostęp, Camunda, audyt, formatki |  | 6.7–8.5 | 15.4 | średnia (3.0) | 60% | 10.3 | 6.9 | Bezpieczeństwo, Dane | Backend .NET | średnie |  |
| S26 | Formatki: cykl życia | 2 Dostęp, Camunda, audyt, formatki |  | 6.7–8.3 | 11.7 | średnia (3.0) | 65% | 14.3 | 8.7 | Backend, Biznes | Backend .NET | średnie |  |
| S28 | Formatki: schemat bazy | 2 Dostęp, Camunda, audyt, formatki |  | 6.7–7.4 | 38.9 | niska (1.8) | 70% | 3.2 | 1.7 | Dane | Backend .NET | niskie |  |
| S49 | UI: komponenty pól | 4 Frontend funkcjonalny |  | 8.2–9.7 | 17.5 | średnia (2.3) | 65% | 12.3 | 7.5 | Frontend | Frontend Angular | niskie |  |
| S23 | Projekcja read modelu | 2 Dostęp, Camunda, audyt, formatki | tak | 8.4–10.1 | 0.0 | bardzo wysoka (3.85) | 55% | 18.7 | 13.0 | Camunda, Dane | Backend .NET | wysokie |  |
| S33 | Zastępstwa (listener) | 3 Funkcje rdzenia |  | 8.5–9.6 | 28.8 | wysoka (3.5) | 55% | 8.2 | 5.7 | Camunda | Backend .NET | wysokie |  |
| S46 | UI: audytor | 4 Frontend funkcjonalny |  | 8.5–8.8 | 36.0 | niska (1.5) | 80% | 4.2 | 1.7 | Frontend | Frontend Angular | niskie |  |
| S27 | Izolacja profili | 2 Dostęp, Camunda, audyt, formatki |  | 8.8–10.5 | 21.2 | wysoka (3.65) | 40% | 9.5 | 8.2 | Bezpieczeństwo, Dane | Backend .NET | wysokie |  |
| S24 | Polityka dostępu R1–R11 | 2 Dostęp, Camunda, audyt, formatki | tak | 10.1–11.6 | 0.0 | wysoka (3.65) | 55% | 15.3 | 11.1 | Bezpieczeństwo, Backend, Dane | Backend .NET | wysokie |  |
| S29 | Formatki: powiązania z BPMN | 2 Dostęp, Camunda, audyt, formatki |  | 10.1–10.9 | 2.6 | średnia (2.85) | 60% | 6.2 | 3.9 | Camunda, Backend | Backend .NET | średnie |  |
| S37 | Form Runtime | 3 Funkcje rdzenia |  | 10.9–12.6 | 2.6 | wysoka (3.35) | 60% | 10.3 | 6.6 | Backend, Frontend | Backend .NET | wysokie |  |
| S30 | Praca na zadaniach | 3 Funkcje rdzenia | tak | 11.6–12.6 | 0.0 | wysoka (3.35) | 60% | 12.3 | 7.9 | Backend, Camunda | Backend .NET | wysokie |  |
| S32 | Przekazywanie zadań | 3 Funkcje rdzenia |  | 12.6–14.1 | 6.5 | wysoka (3.15) | 60% | 9.3 | 6.0 | Backend | Backend .NET | wysokie |  |
| S34 | Mapa etapów | 3 Funkcje rdzenia | tak | 12.6–14.2 | 0.0 | wysoka (3.65) | 60% | 15.3 | 9.8 | Backend, Biznes | Backend .NET | wysokie |  |
| S38 | Operacje profili | 3 Funkcje rdzenia |  | 12.6–14.0 | 10.3 | średnia (2.85) | 55% | 9.2 | 6.6 | Backend, Testy | Backend .NET | średnie |  |
| S31 | Start procesu | 3 Funkcje rdzenia |  | 12.6–13.6 | 10.1 | średnia (2.35) | 70% | 6.2 | 3.4 | Backend, Camunda | Backend .NET | niskie |  |
| S39 | Formatki: wycofanie i przepięcie | 3 Funkcje rdzenia |  | 12.6–13.4 | 13.0 | średnia (2.85) | 60% | 6.2 | 3.9 | Backend | Backend .NET | średnie |  |
| S40 | UI: zadania i renderer formatek | 4 Frontend funkcjonalny |  | 12.6–14.1 | 2.6 | wysoka (3.5) | 65% | 18.5 | 10.7 | Frontend | Frontend Angular | wysokie |  |
| S41 | UI: start i moje procesy | 4 Frontend funkcjonalny |  | 13.6–14.0 | 10.1 | niska (1.5) | 80% | 5.3 | 2.1 | Frontend | Frontend Angular | niskie |  |
| S48 | Onboarding zespołów profili | 4 Frontend funkcjonalny |  | 14.0–14.5 | 38.9 | niska (1.6) | 50% | 4.0 | 2.8 | Biznes | Architekt / tech lead | niskie | dostępność zespołów profili projektów |
| S45 | UI: projektant formatek | 4 Frontend funkcjonalny |  | 14.1–15.5 | 2.6 | wysoka (3.35) | 60% | 17.7 | 10.8 | Frontend | Frontend Angular | wysokie |  |
| S47 | UI: sloty profili | 4 Frontend funkcjonalny |  | 14.1–15.0 | 5.1 | średnia (2.35) | 65% | 7.3 | 4.7 | Frontend | Frontend Angular | niskie |  |
| S43 | UI: przekazywanie | 4 Frontend funkcjonalny |  | 14.1–14.7 | 6.5 | niska (1.85) | 75% | 7.2 | 3.1 | Frontend | Frontend Angular | niskie |  |
| S35 | Eskalacje | 3 Funkcje rdzenia |  | 14.2–14.9 | 1.7 | średnia (2.8) | 65% | 6.2 | 3.6 | Backend | Backend .NET | średnie |  |
| S36 | Dashboard menadżera | 3 Funkcje rdzenia | tak | 14.2–15.3 | 0.0 | wysoka (3.3) | 60% | 12.3 | 7.9 | Dane, Biznes | Backend .NET | wysokie |  |
| S44 | UI: edytor mapy etapów | 4 Frontend funkcjonalny |  | 14.2–15.6 | 2.2 | wysoka (3.15) | 60% | 11.3 | 6.9 | Frontend, Camunda | Frontend Angular | wysokie |  |
| S42 | UI: dashboard i etapy | 4 Frontend funkcjonalny | tak | 15.3–16.0 | 0.0 | średnia (2.3) | 70% | 11.3 | 5.8 | Frontend | Frontend Angular | niskie |  |
| S50 | Testy end-to-end | 5 Integracja i hardening | tak | 16.0–17.6 | 0.0 | bardzo wysoka (3.9) | 50% | 15.8 | 11.9 | Testy, Infrastruktura | QA / BDD | wysokie |  |
| S51 | Testy bezpieczeństwa | 5 Integracja i hardening | tak | 17.6–19.1 | 0.0 | wysoka (3.5) | 45% | 9.3 | 7.7 | Bezpieczeństwo, Testy | Bezpieczeństwo | wysokie |  |
| S52 | Wydajność | 5 Integracja i hardening |  | 17.6–19.0 | 0.9 | wysoka (3.5) | 45% | 8.5 | 6.8 | Dane, Testy | Backend .NET | wysokie |  |
| S53 | Dostępność i UX | 5 Integracja i hardening |  | 17.6–18.7 | 2.3 | niska (1.95) | 40% | 6.3 | 5.3 | Frontend, Testy | Frontend Angular | niskie |  |
| S55 | Zgodność i spójność formatek | 5 Integracja i hardening |  | 17.6–18.3 | 4.3 | średnia (2.65) | 60% | 5.2 | 3.3 | Frontend, Testy | Frontend Angular | średnie |  |
| S54 | Pentest i compliance | 5 Integracja i hardening | tak | 19.1–22.3 | 0.0 | wysoka (3.4) | 10% | 15.8 | 15.8 | Bezpieczeństwo, Biznes | Bezpieczeństwo | wysokie | termin zewnętrznego pentestu i akceptacje compliance |
| S60 | Pilotaż | 6 Pilotaż | tak | 22.3–27.6 | 0.0 | bardzo wysoka (3.8) | 10% | 20.8 | 20.8 | Biznes, Infrastruktura | PO / analityk | wysokie | gotowość obszaru biznesowego, szkolenia i profilu pilotażowego (zespół projektu) |

## Plik: design/README.md

# Makieta UI Process Hub — propozycja projektowa

Makieta to jeden plik `mockups/index.html`: klikalna aplikacja z przełącznikiem „Podgląd jako”, który pokazuje ten sam system oczami dziewięciu osób — sześciu z ról platformy i trzech z przykładowego profilu projektu „Flota samochodowa” (`profiles/flota/`). Wszystkie akcje działają na danych w pamięci i od razu pojawiają się w dzienniku audytu (widok audytora), więc na pokazie widać zasadę „każda akcja jest audytowana”. Otwórz plik w przeglądarce — bez serwera i bez instalacji.

Zaczynasz pracę nad interfejsem? Najpierw `docs/artifacts/04-wytyczne-ui.md` (wytyczne i założenia w jednym miejscu), potem ten dokument, `forms/README.md` (formatki) i makieta.

## Kierunek wizualny

Biel i czerwień jak barwy Polski, ale użyte oszczędnie, bo to narzędzie pracy na cały dzień, nie plakat.

- **Biel nad czerwienią:** biały pasek aplikacji kończy się 4-pikselowym pasem flagowej czerwieni. To jedyne miejsce, gdzie czerwień działa jako znak.
- **Wstęga etapów** jest jedynym mocnym elementem wizualnym: etapy procesu jako segmenty biało-czerwonej wstęgi, bieżący etap w pełnej czerwieni. Ten sam komponent wraca w zadaniu, sprawie, „moich procesach”, edytorze formatki i mapie etapów, więc menadżer uczy się go raz.
- **Liczby jako pasek księgowy**, nie siedem jednakowych kafelków: jedna linia wartości oddzielonych pionowymi kreskami, czytana jak zestawienie w raporcie banku.
- **Krój Lato** — zaprojektowany przez polskiego typografa Łukasza Dziedzica, z pełnym wsparciem polskich znaków; jeden krój, hierarchia przez grubość (400/700/900).

### Paleta (sprawdzone kontrasty WCAG)

| Token | Jasny | Ciemny | Użycie | Kontrast |
| --- | --- | --- | --- | --- |
| `flag-red` | #DC143C | #DC143C | pas pod paskiem aplikacji, akcenty nietekstowe | 4,99:1 — dlatego nie dla tekstu |
| `action` | #A10F2B | #FF6B7E | przyciski główne, linki, bieżący etap | 8,02:1 na bieli (AAA) |
| `ink` / `ink-2` | #1F2328 / #4A5059 | #ECEDEF / #B5BAC1 | tekst / tekst pomocniczy | 15,8:1 / 7,45:1 |
| `ok`, `warn`, `crit`, `info` | ciemne odcienie na jasnym tle | jasne odcienie na ciemnym tle | statusy | każdy ≥ 6,5:1 |

**Konflikt czerwieni marki i czerwieni alarmu** rozwiązuje kształt i słowo: status krytyczny ma kwadratowy znacznik i etykietę („Krytyczne”, „Odmowa R2”), ostrzeżenie — trójkąt, poprawny — koło. Kolor nigdy nie jest jedynym nośnikiem informacji (WCAG 1.4.1). Wartości dla Kendo ThemeBuilder: `tokens.json` (do potwierdzenia z księgą znaku banku). Źródłem wyglądu jest biblioteka w Figma prowadzona przez projektanta UX; `tokens.json` jest jej eksportem i jedynym źródłem dla kodu — oprócz kolorów zawiera skalę odstępów, wymiary kontrolek, siatkę formatek i progi szerokości (`forms/README.md`, sekcja 9).

## Architektura informacji

Nawigacja jest liczona z uprawnień, nie z nazwy roli — dokładnie tak jak `allowedActions` w API. Osoba z kilkoma rolami (Piotr) widzi sumę sekcji.

| Sekcja | Pozycje | Kto widzi |
| --- | --- | --- |
| Praca | Pulpit, Zadania, Start procesu, Moje procesy, Zastępstwa | uczestnik, inicjator |
| Nadzór | Panel procesu, Eskalacje, Sprawy, Przekazanie masowe | menadżer procesu (audytor bez przekazywania) |
| Konfiguracja procesu | Mapa etapów, Formatki | menadżer i administrator procesu |
| Kontrola | Dziennik audytu, Uprawnienia | audytor, administrator platformy |
| Flota (sekcja profilu) | Katalog samochodów | wyłącznie role profilu „Flota samochodowa” (Tomasz, Hanna, Karol); zmiany katalogu — tylko administrator katalogu |

**Sekcje profili projektów.** Profil może dodać własną sekcję nawigacji (slot `nav.section`) z trasami `/p/<id>/…`. Sekcja stoi pod sekcjami platformy, ma znacznik „profil” i używa tych samych tokenów co reszta aplikacji. Widzą ją tylko osoby z uprawnieniem trasy; wejście z adresu kończy się stroną „Brak dostępu” z informacją, do którego profilu należy strona, i wpisem w dzienniku. Przyciski na stronie profilu (np. „Dodaj model”) przychodzą z `allowedActions`, tak jak na ekranach platformy. Jak budować takie elementy: `docs/guides/dedykowane-elementy-profilu.md`.

## Ekrany i wymagania

| Ekran (trasa) | Wymagania | Co pokazuje |
| --- | --- | --- |
| Pulpit `#/start` | FR-01, FR-08, FR-14 | sekcje zależne od ról: moje zadania, moje procesy, zdrowie procesów, zadania konfiguracyjne, ostatnie wpisy dziennika |
| Zadania `#/zadania` | FR-01–FR-03, FR-22 | zakładki Moje / Do przejęcia / Mojej grupy / Wszystkie; zapisany widok; na telefonie wiersze jako karty |
| Zadanie `#/zadanie/T-2041` | FR-04–FR-06, FR-18 | wstęga z zaznaczonym etapem zadania, formatka z pomocą przy polach, blokada edycji dla nie-assignee z wyjaśnieniem, podsumowanie błędów, potwierdzenie zakończenia |
| Start procesu `#/start-procesu` | FR-07 | katalog tylko dozwolonych procesów, formatka startowa, załącznik jako odnośnik |
| Moje procesy, Sprawy, Sprawa `#/sprawa/K-0136` | FR-08, FR-10, FR-16 | wstęga etapów, eskalacja i blokada słowami, historia biznesowa; model BPMN tylko dla administratora procesu |
| Panel procesu `#/panel` | FR-14 | liczniki wyników (sukces / negatywnie / błąd osobno), werdykt zdrowia, wąskie gardło etapów, trend, czasy etapów; każdy wykres ma tabelę danych |
| Eskalacje `#/eskalacje` | FR-13 | eskalowane vs po terminie, przekazanie z listy |
| Przekazanie (okno) i przekazanie masowe | FR-11 | osoba lub grupa, obowiązkowy powód, tylko uprawnione osoby, raport partii |
| Zastępstwa `#/zastepstwa` | FR-12 | nieobecność od–do, zastępca, walidacja nakładania się |
| Mapa etapów `#/mapa-etapow` | FR-15 | administrator: diagram tylko do odczytu, lista elementów, przypisanie, walidacja, publikacja; menadżer: nazwy i SLA etapów, bez diagramu |
| Formatki `#/formatki`, projektant `#/formatka/F-ocena` | FR-16, FR-17, FR-28–FR-31 | formatki wybranego procesu (R11), miejsce formatki na wstędze, kontrakt danych zadania, cztery oczy (R8), wersje ze stanami, wycofanie wersji z powodem i wersją zastępczą, podgląd jak u wykonawcy; w produkcie zakładka „Projekt” osadza edytor form-js z paletą z katalogu pól |
| Dziennik audytu `#/audyt` | FR-19, FR-20 | dziennik z rolą uzasadniającą, odmowy, integralność Ledger, ślad operacyjny dla wsparcia |
| Uprawnienia `#/uprawnienia` | FR-21, FR-24 | macierz ról, przypisania grup AD, role projektowe profili, zgodność z Camunda, zmiany tylko przez PR |
| Katalog samochodów `#/p/flota/katalog` (profil Flota) | FR-25, FR-27, FLO-FR-01…03 | strona profilu z sekcji „Flota”: modele z filtrami, liczba wniosków w toku; administrator katalogu: „Dodaj model”, „Zmień”, „Wycofaj”, „Przywróć” z walidacją polityki floty (CO2 do 130 g/km) i wpisem w dzienniku; wnioskodawca: „Złóż wniosek” z wybranym modelem; pozostali — tylko podgląd; spoza profilu — odmowa |
| Widżet „Katalog samochodów” na pulpicie | FR-27 | slot `dashboard.widget` profilu: liczba dostępnych modeli, ostatnia zmiana, odnośniki |
| Wniosek o samochód `#/start-procesu/rejestracja-samochodu` | FR-07, FLO-FR-03 | pole profilu „Model samochodu z katalogu” (tylko dostępne modele), błędy bez utraty danych, sprawa w „Moich procesach” |
| Opinia komórki `#/zadanie/T-2051` | FR-04–FR-06, FLO-FR-04 | wstęga sprawy nadrzędnej z etapem „Opiniowanie” (proces podrzędny), formatka opinii: pozytywna, z warunkami, negatywna; każda komórka widzi tylko swoje zadanie |

## Wzorce interakcji

- **Akcje z `allowedActions`:** przycisk, którego nie wolno użyć, nie istnieje; zamiast niego jest jedno zdanie, dlaczego („Edytować może tylko osoba, która przejęła zadanie: …”).
- **Jedna nazwa akcji w całym przepływie:** „Przekaż zadanie” → komunikat „Przekazano…”, „Opublikuj” → „Opublikowano…”.
- **Błędy:** podsumowanie na górze z odnośnikami do pól + komunikat przy polu; formularz nie gubi danych.
- **Decyzje nieodwracalne** (zakończenie zadania, przekazanie, publikacja) przez okno potwierdzenia z podsumowaniem skutku.
- **Puste stany mówią, co zrobić dalej**, a odmowa dostępu mówi, że próba trafiła do dziennika.

## Dostępność

Link „Przejdź do treści”, okruszki na każdym widoku (WCAG 2.4.8), fokus na nagłówku po zmianie widoku, widoczny fokus 3 px, cele dotykowe ≥ 44 px (2.5.5), status w regionie `aria-live`, wykresy z alternatywą tabelaryczną, `prefers-reduced-motion`, motyw jasny/ciemny/systemowy, układ bez przewijania w poziomie od 390 px szerokości. Makieta przeszła automatyczny test wszystkich ról i ścieżek w przeglądarce bezgłowej; audyt axe-core i z czytnikiem ekranu to krok S53.

## Odwzorowanie w Kendo UI for Angular

| Element makiety | Komponent docelowy |
| --- | --- |
| pasek aplikacji, szuflada nawigacji | `kendo-appbar`, `kendo-drawer` |
| listy zadań i spraw | `kendo-grid` (tryb kart na wąskich ekranach, stan zapisywany w `SavedListView`) |
| zakładki, okruszki | `kendo-tabstrip`, `kendo-breadcrumb` |
| wstęga etapów | komponent własny w `core/ui-kit` (Kendo nie ma chevronowej wstęgi z flagami) |
| wykresy | `kendo-chart` (słupki poziome, linia) z tabelą danych |
| okna potwierdzeń, powiadomienia | `kendo-dialog`, `kendo-notification` |
| formatki | komponenty pól `ph-*` w `core/ui-kit` na kontrolkach Kendo — jeden na każdy typ Camunda Forms z katalogu pól (`forms/field-catalog.yaml`, tabela w `forms/README.md`) |
| projektant formatek | osadzony edytor `@bpmn-io/form-js-editor` (jak w Camunda Modelerze) z paletą ograniczoną katalogiem pól; podgląd w rendererze platformy (ADR-019) |
| diagram techniczny | bpmn-js NavigatedViewer (tylko z uprawnieniem `Bpmn.ViewTechnical`) |

## Jak dalej projektować

1. **Pokaz z rolami:** 30 minut na rolę, scenariusze z listy niżej; notujemy, gdzie ktoś się zawahał.
2. **Testy z użytkownikami:** po 5 osób na rolę (uczestnik, menadżer procesu, administrator procesu, audytor) na makiecie, zanim powstanie kod Angulara.
3. **Warsztat mapy etapów z menadżerami** dwóch procesów: czy 4–6 etapów wystarcza, które kroki techniczne muszą być widoczne jako „w toku”.
4. **Księga znaku banku i Figma:** projektant UX zakłada bibliotekę w Figma (zmienne = tokeny, komponenty pól, wzorce); eksport podmienia `tokens.json`, ponowny pomiar kontrastu (krok S09).
5. **Przeniesienie do kodu:** tokeny → Kendo ThemeBuilder → `core/theming`; komponenty pól → `core/ui-kit` z regresją wizualną (S49); ekrany → biblioteki z `docs/architecture/11-frontend.md` (kroki S40–S46).

## Scenariusze do kliknięcia

1. **Anna (uczestnik):** Zadania → Do przejęcia → Przejmij → Otwórz → Zakończ bez uzasadnienia (błędy) → uzupełnij → Zakończ.
2. **Anna:** Start procesu → Wniosek kredytowy → Moje procesy → wstęga sprawy.
3. **Marta (menadżer procesu):** Panel procesu → wąskie gardło „Ocena” → Eskalacje → Przekaż (bez powodu, potem z powodem).
4. **Marta:** Przekazanie masowe zadań osoby na urlopie → raport partii → Zastępstwa (spróbuj nakładających się dat).
5. **Marta:** Formatki → wybierz proces (lista pokazuje tylko jej procesy) → Ocena wniosku → Przekaż do przeglądu → „Zatwierdź” jest zablokowane (cztery oczy).
6. **Adam (administrator procesu):** zatwierdź i opublikuj tę formatkę → Mapa etapów → przypisz „Akceptacja klienta” → Opublikuj → Sprawa → Pokaż model BPMN.
7. **Olga (audytor):** wszystko tylko do odczytu → Dziennik audytu z akcjami z poprzednich kroków, łącznie z odmowami.
8. **Zenon (administrator platformy):** Uprawnienia → Sprawdź zgodność z Camunda; spróbuj wejść w `#/panel` — odmowa trafia do dziennika.
9. **Karol (administrator katalogu, profil Flota):** sekcja „Flota” → Katalog samochodów → Dodaj model z emisją 220 g/km (odmowa polityki floty) → popraw na 0 → Wycofaj „Toyota Corolla Touring Sports” (okno mówi, że wniosek w toku zachowa model) → filtr „Wycofane” → Przywróć.
10. **Tomasz (wnioskodawca, profil Flota):** Katalog — bez przycisków zmian → „Złóż wniosek” przy modelu → formatka z wybranym modelem → złóż bez uzasadnienia (błąd, dane zostają) → złóż → nowa sprawa w etapie „Wniosek” → Moje procesy → sprawa F-0012: etap „Opiniowanie”, zadania komórek nie są widoczne.
11. **Hanna (opiniująca z HR, profil Flota):** Zadania → T-2051 → „Pozytywna z warunkami” bez warunków (błąd) → uzupełnij → Zakończ → Do przejęcia: T-2056; zadanie Prawnego `#/zadanie/T-2053` — odmowa.
12. **Anna (kredyty):** nie ma sekcji „Flota”; wejście na `#/p/flota/katalog` — odmowa z informacją o profilu. **Olga:** dziennik pokazuje operacje `flota.*` z rolami `flota/administrator-katalogu` i `flota/opiniujacy`. **Zenon:** Uprawnienia → Role projektowe profili.
13. **Marta (wycofanie wersji):** Formatki → Ocena wniosku → zakładka „Wersje” → „Wycofaj wersję” przy v3 → bez powodu (błąd) → powód „Wada formatki”, wersja zastępcza v2, „Przepnij na wersję obowiązującą” → obowiązuje v2, v3 ma stan „Wycofana”; **Olga:** dziennik pokazuje `Form.Withdraw` i `Form.Repin`, a w formatkach ma tylko wgląd; **Piotr:** w Formatkach widzi wyłącznie proces „Weryfikacja AML”, wejście na `#/formatka/F-ocena` kończy się odmową.

## Plik: design/tokens.json

````json
{
  "comment": "Tokeny wizualne Process Hub (v2: dodane odstępy, kontrolki, siatka formatek i progi szerokości). Źródło wyglądu: biblioteka w Figma prowadzona przez projektanta UX; ten plik jest jej eksportem i jedynym źródłem dla Kendo ThemeBuilder i core/theming. Wartości do potwierdzenia z księgą znaku banku.",
  "font": { "family": "Lato, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif", "scale_px": { "h1": 28, "h2": 19, "body": 16, "small": 14, "kpi": 34 } },
  "light": {
    "flag-red": "#DC143C", "action": "#A10F2B", "action-ink": "#FFFFFF", "action-hover": "#86081F",
    "ink": "#1F2328", "ink-2": "#4A5059", "bg": "#F4F5F7", "surface": "#FFFFFF", "surface-2": "#F9FAFB", "line": "#D9DCE1", "line-strong": "#AEB3BB",
    "ok": "#17552E", "ok-bg": "#E7F3EB", "warn": "#6B4100", "warn-bg": "#FFF3D1", "crit": "#6E0F1E", "crit-bg": "#FBE9EC", "info": "#1F4E8C", "info-bg": "#E8EFF8"
  },
  "dark": {
    "flag-red": "#DC143C", "action": "#FF6B7E", "action-ink": "#16181B", "action-hover": "#FF8A99",
    "ink": "#ECEDEF", "ink-2": "#B5BAC1", "bg": "#16181B", "surface": "#1F2226", "surface-2": "#24282D", "line": "#353A41", "line-strong": "#4E555E",
    "ok": "#6FD08F", "ok-bg": "#1B2E22", "warn": "#F2C14E", "warn-bg": "#33290F", "crit": "#FF8A99", "crit-bg": "#3A1A20", "info": "#8FB8F2", "info-bg": "#1A2636"
  },
  "contrast_checked": {
    "action on surface (light)": 8.02, "ink on surface (light)": 15.8, "ink-2 on bg (light)": 7.45,
    "flag-red on surface (light, tylko elementy nietekstowe)": 4.99, "action on surface-2 (dark)": 7.11, "ink on bg (dark)": 15.18
  },
  "touch_target_px": 44,
  "radius_px": { "control": 6, "panel": 8, "pill": 999 },
  "space_px": { "1": 4, "2": 8, "3": 12, "4": 16, "6": 24, "8": 32, "12": 48 },
  "control_px": { "height": 44, "padding_x": 10, "padding_y": 8, "border": 1, "focus_ring": 3, "focus_offset": 2, "textarea_min_height": 96 },
  "form": { "grid_columns": 16, "column_gap_px": 16, "field_gap_px": 16, "label_gap_px": 6, "help_gap_px": 4, "group_padding_px": 16, "max_width_px": 880, "stack_below_px": 600 },
  "breakpoints_px": { "phone": 600, "tablet": 860, "desktop": 1100 }
}
````

## Plik: design/forms/README.md

# Formatki — założenia wizualne i kontrakt materializacji

Formatka jest opisana schematem Camunda Forms, ale wygląda jak reszta Process Hub. Ten dokument mówi, jak to osiągamy: co ustala biznes, co design system, jak każdy typ pola zamienia się w komponent i jak zmiany z Figma trafiają do kodu. Opis działania modułu: `docs/architecture/14-form-management.md`; decyzja: ADR-019; maszynowa wersja kontraktu: `field-catalog.yaml`.

## 1. Koncepcja: trzy warstwy

```mermaid
flowchart LR
    S["Struktura<br/>schemat Camunda Forms<br/>pola · typy · teksty · walidacje · warunki · wiersze"] --> M["Materializacja<br/>katalog pól<br/>typ → komponent ui-kit"]
    T["Wygląd<br/>tokeny z Figma<br/>kolory · typografia · odstępy · kontrolki"] --> M
    M --> UI["Formatka na zadaniu<br/>spójna z całym systemem"]
```

| Warstwa | Kto decyduje | Gdzie żyje | Jak się zmienia |
| --- | --- | --- | --- |
| Struktura | menadżer i administrator procesu | wersja formatki (schemat) | szkic → przegląd → zatwierdzenie → publikacja |
| Materializacja | zespół design systemu z architektem | `field-catalog.yaml`, `core/ui-kit` | pull request, regresja wizualna |
| Wygląd | projektant UX | Figma → `design/tokens.json` → `core/theming` | eksport z Figma jako pull request |

Skutek: zmiana tokenów albo komponentu poprawia wygląd wszystkich formatek naraz, bez nowych wersji; zmiana formatki nigdy nie zmienia wyglądu systemu.

## 2. Co ustala biznes, a czego nie

| Biznes ustawia w projektancie | Design system ustala raz dla całej aplikacji |
| --- | --- |
| typ pola z katalogu, etykietę, podpowiedź, wartość domyślną | krój, rozmiary i grubości tekstu |
| wymagalność, długości, zakresy, wzorzec, format daty | kolory, obramowania, promienie, cienie |
| warunek widoczności, tylko do odczytu, wyłączenie (także wyrażeniem FEEL) | wysokość i wypełnienie kontrolek, fokus |
| opcje wyboru (stałe, ze zmiennej, z wyrażenia) | odstępy między polami, sekcjami i wierszami |
| kolejność pól, wiersze i szerokości (2–16 z 16 kolumn) | wygląd błędu, podpowiedzi, znacznika „wymagane” |
| sekcje i listy powtarzane, teksty objaśniające, linie podziału | zachowanie na telefonie, motyw jasny i ciemny |
| przedrostek i przyrostek pola (np. „PLN”) | teksty systemowe: komunikaty walidacji, „Dodaj pozycję”, „Usuń” |

Projektant nie pokazuje własności, których katalog nie dopuszcza. Schemat Camunda Forms nie ma pól na kolor czy krój — jedyne własności bliskie wyglądowi to układ w siatce, przedrostki, wysokość odstępu i obrys sekcji, a te design system zamienia na własne wartości.

## 3. Anatomia pola

```
Etykieta (wymagane)            ← 700; słowo „(wymagane)”, nie sama gwiazdka
[ kontrolka 44 px            ] ← obramowanie line-strong, promień 6, fokus 3 px
Podpowiedź                     ← 14 px, ink-2
■ Komunikat błędu              ← 14 px, 700, crit, z kwadratowym znacznikiem
```

- Odstępy z `design/tokens.json`: etykieta–kontrolka 6 px, kontrolka–podpowiedź 4 px, pole–pole 16 px.
- Podpowiedź i błąd są powiązane z kontrolką przez `aria-describedby`; błąd ustawia `aria-invalid`.
- Grupy opcji (`radio`, `checklist`) to `fieldset` z `legend`; każda opcja ma cel dotykowy 44 px.
- Pole tylko do odczytu pokazuje wartość jako tekst na tle `surface-2`, bez obramowania kontrolki; pole wyłączone ma obniżony kontrast i nie przyjmuje fokusu.
- Stany każdego komponentu w Figma i w katalogu komponentów: domyślny, najechany, fokus, wypełniony, błąd, tylko do odczytu, wyłączony — w obu motywach.

## 4. Układ

- Schemat układa pola w wierszach (`layout.row`) w siatce 16 kolumn (`layout.columns` 2–16; brak wartości = równy podział wiersza). Design system odwzorowuje to w siatce CSS z odstępem kolumn 16 px.
- Formatka ma szerokość do 880 px i jest wyrównana do lewej krawędzi panelu zadania; nie rozciąga pól na całą szerokość szerokiego ekranu.
- Poniżej 600 px każde pole zajmuje pełną szerokość, w kolejności ze schematu; nic nie przewija się w poziomie (od 390 px).
- Sekcja (`group`) to `fieldset` z nagłówkiem; `showOutline` rysuje obramowanie panelu (promień 8, wypełnienie 16 px). Sekcje można zagnieżdżać najwyżej do dwóch poziomów — głębsze zagnieżdżenie zgłasza ostrzeżenie w projektancie.
- Lista powtarzana (`dynamiclist`) pokazuje pozycje jako kolejne sekcje z numerem; przyciski „Dodaj pozycję” i „Usuń” pochodzą z design systemu i mają opisy dla czytników ekranu.
- `spacer` zaokrągla wysokość do skali odstępów (4, 8, 12, 16, 24, 32, 48 px); `separator` to linia `line` z odstępem 16 px.

## 5. Walidacja i komunikaty

- Walidacja przy opuszczeniu pola i przy „Zakończ zadanie”; „Zapisz szkic” nie wymaga poprawności.
- Po nieudanej próbie zakończenia nad formatką pojawia się podsumowanie błędów z odnośnikami do pól, a fokus przechodzi na podsumowanie. Formatka nie gubi wpisanych danych.
- Komunikaty walidacji pochodzą z plików i18n aplikacji („Podaj wartość”, „Najwyżej 5000 znaków”), nie z formatki — wyjątkiem jest `patternErrorMessage` pola tekstowego.
- Błąd z serwera (np. pole wymagane warunkowo) pokazuje się tak samo jak błąd z przeglądarki.
- Kolor nigdy nie jest jedynym nośnikiem: błąd ma znacznik i tekst, pole wymagane ma słowo.

## 6. Tryby formatki

| Tryb | Kiedy | Wygląd |
| --- | --- | --- |
| Edycja | zadanie przejęte przez bieżącą osobę | kontrolki aktywne; akcje „Zapisz szkic”, „Zakończ zadanie” z `allowedActions` pod formatką |
| Odczyt | każda inna osoba z wglądem | wartości jako tekst; nad formatką jedno zdanie, kto może edytować |
| Podgląd | zakładka „Podgląd jak u wykonawcy” w projektancie | jak edycja, z danymi przykładowymi; przełącznik motywu i szerokości |
| Niedostępna | brak wersji obowiązującej (wycofanie bez zastępczej) | komunikat w miejscu formatki; zakończenie zablokowane |

Przyciski akcji nie należą do formatki — renderuje je powłoka. Dlatego typ `button` jest zablokowany w katalogu.

## 7. Mapowanie typów na komponenty

Pełne dane (własności, ograniczenia, nazwy w Figma): `field-catalog.yaml`.

| Typ Camunda Forms | Nazwa w palecie | Komponent `ui-kit` | Podstawa Kendo | Status |
| --- | --- | --- | --- | --- |
| `textfield` | Pole tekstowe | `ph-text-field` | `kendo-textbox` | wspierany |
| `textarea` | Tekst długi | `ph-textarea` | `kendo-textarea` | wspierany |
| `number` | Liczba | `ph-number-field` | `kendo-numerictextbox` | wspierany |
| `datetime` | Data i czas | `ph-date-field` | `kendo-datepicker`, `-timepicker`, `-datetimepicker` | wspierany |
| `checkbox` | Pole wyboru | `ph-checkbox` | `kendo-checkbox` | wspierany |
| `checklist` | Lista pól wyboru | `ph-checklist` | `fieldset` + `kendo-checkbox` | wspierany |
| `radio` | Wybór jednej opcji | `ph-radio-group` | `fieldset` + `kendo-radiobutton` | wspierany |
| `select` | Lista rozwijana | `ph-select` | `kendo-dropdownlist` / `kendo-combobox` | wspierany |
| `taglist` | Wybór wielu wartości | `ph-taglist` | `kendo-multiselect` | wspierany |
| `group` | Sekcja | `ph-group` | `fieldset` | wspierany |
| `dynamiclist` | Lista powtarzana | `ph-repeater` | własny na `ui-kit` | wspierany |
| `table` | Tabela | `ph-data-table` | `kendo-grid` (odczyt) | wspierany |
| `expression` | Pole wyliczane | — (bez interfejsu) | — | wspierany |
| `separator` | Linia podziału | `ph-separator` | — | wspierany |
| `text` | Tekst | `ph-text-block` | — | z ograniczeniami: Markdown bez HTML |
| `spacer` | Odstęp | `ph-spacer` | — | z ograniczeniami: skala odstępów |
| `image` | Obraz | `ph-image` | — | z ograniczeniami: zasób osadzony, tekst alternatywny |
| `filepicker`, `documentPreview` | Załącznik, Podgląd dokumentu | `ph-file-field`, `ph-document-preview` | `kendo-upload` | planowane (decyzja D-15) |
| `html`, `iframe`, `button` | — | — | — | zablokowane |

Pole profilu (slot `form.field`) to typ bazowy z własnością `ph:field`; w palecie ma nazwę z manifestu profilu i znacznik „profil”, a wygląda jak każde inne pole, bo komponent profilu buduje się z `ui-kit` i tokenów.

## 8. Projektant formatek

- **Układ ekranu:** nagłówek ze stanem i akcjami → „Miejsce w procesie” (wstęga etapów, powiązania, kontrakt danych) → zakładki „Projekt”, „Podgląd jak u wykonawcy”, „Wersje”, „Historia”.
- **Zakładka „Projekt”** osadza edytor form-js: paleta, kanwa, panel właściwości. Otoczenie edytora (nagłówki paneli, tło, obramowania) używa tokenów; sama kanwa zachowuje wygląd biblioteki, a znak bpmn.io pozostaje widoczny i niczym nieprzysłonięty.
- **Znaczniki stanu wersji** (kształt + słowo, jak w całym systemie): Szkic — neutralny; W przeglądzie — ostrzeżenie; Zatwierdzona — informacja; Opublikowana — poprawny; Zastąpiona — neutralny; Wycofana — krytyczny.
- **Nazwy akcji** są takie same na przycisku, w oknie potwierdzenia i w komunikacie: „Zapisz szkic”, „Przekaż do przeglądu”, „Cofnij z przeglądu”, „Odrzuć do poprawy”, „Zatwierdź”, „Opublikuj”, „Utwórz nową wersję”, „Wycofaj wersję”, „Wycofaj formatkę”, „Importuj”, „Eksportuj”.
- **Przegląd** pokazuje różnicę względem wersji obowiązującej: pola dodane, usunięte i zmienione z listą własności; zablokowany przycisk „Zatwierdź” ma obok jedno zdanie o regule czterech oczu.
- **Wycofanie** to okno potwierdzenia z powodem (lista + opis), wyborem wersji zastępczej, wyborem skutku dla zadań w toku i liczbami: ile zadań jest na tej wersji, ile zadań procesu wskazuje formatkę.

## 9. Z Figma do kodu

```mermaid
flowchart LR
    F["Figma: biblioteka Process Hub<br/>zmienne · komponenty pól · wzorce"] -->|eksport: zmienne JSON, specyfikacje| PR["Pull request w design/**<br/>ux-designer + projektant UX"]
    PR --> TOK["design/tokens.json<br/>design/forms/field-catalog.yaml"]
    TOK --> TH["core/theming<br/>zmienne CSS, motyw Kendo"]
    TOK --> KIT["core/ui-kit<br/>komponenty pól"]
    KIT --> CAT["apps/ui-catalog<br/>wszystkie stany"]
    CAT -->|zrzuty Playwright, axe| REV["ui-reviewer + projektant UX<br/>zatwierdzenie wzorców"]
```

1. Projektant UX prowadzi w Figma jedną bibliotekę: zmienne (kolory, typografia, odstępy, promienie, wymiary kontrolek), komponenty pól z kompletem stanów i wzorce formularza. Nazwy komponentów pól są zapisane w katalogu (`figma`).
2. Zmiana wyglądu to eksport zmiennych i specyfikacji do pull requestu w `design/**`. Agenci nie mają dostępu do Figma — pracują na plikach w repozytorium (ADR-016).
3. Każda zmiana kolorów przechodzi ponowny pomiar kontrastu (`contrast_checked` w `design/tokens.json`): tekst podstawowy, pomocniczy i akcje ≥ 7:1 (cel AAA), tekst statusów ≥ 6,5:1, żaden tekst poniżej 4,5:1 (wymóg AA), elementy nietekstowe ≥ 3:1.
4. `core/theming` generuje z tokenów zmienne CSS i motyw Kendo; komponenty nie zawierają wartości „na sztywno” (lint).
5. Katalog komponentów pokazuje każdy komponent w każdym stanie; zrzuty w motywie jasnym i ciemnym przy 390, 768 i 1280 px są porównywane ze wzorcami. Wzorce zmienia się tylko za zgodą projektanta UX.

## 10. Jak dodać albo zmienić typ pola

1. Wpis w `field-catalog.yaml` (status, komponent, własności, ograniczenie) — przegląd architekta i projektanta UX.
2. Komponent w Figma ze stanami; specyfikacja w tym dokumencie (tabela w sekcji 7).
3. Komponent w `core/ui-kit` i wpis w rejestrze `form-runtime`; `IFieldType` w `FormRuntime` (walidacja na serwerze).
4. Formatka wzorcowa w zestawie zgodności i wzorce regresji wizualnej.
5. Testy parytetu (katalog ↔ rejestr ↔ `IFieldType`) i axe zielone.

## 11. Lista kontrolna przeglądu formatki i komponentu

- Każde pole wprowadzania ma etykietę; podpowiedź mówi, co wpisać, a nie powtarza etykietę.
- Kolejność fokusu = kolejność czytania; nic nie wymaga myszy.
- Błąd wskazuje pole i mówi, jak go poprawić.
- Formatka mieści się na telefonie bez przewijania w poziomie i działa przy powiększeniu 200%.
- Żadnych wartości kolorów, rozmiarów ani odstępów poza tokenami.
- Wygląd w obu motywach sprawdzony w katalogu komponentów.

## Plik: design/forms/field-catalog.yaml

````yaml
# Katalog pól formatek — kontrakt materializacji Camunda Forms w design systemie Process Hub (ADR-019).
# Czytają go: projektant formatek (paleta i panel właściwości), backend (walidacja importu, przeglądu i publikacji),
# renderer form-runtime (rejestr typ → komponent), testy parytetu oraz dokumentacja (design/forms/README.md).
# Zmiana statusu albo dodanie typu = pull request z przeglądem architekta platformy i projektanta UX.
version: 1
profile: ph-forms-8.9                      # profil zgodności zapisywany przy każdej opublikowanej wersji formatki
library:
  package: "@bpmn-io/form-js"
  version: "2.2.0"                          # wersja przypięta; do potwierdzenia z Modelerem dla Camunda 8.9 w S07
  schema_version_max: 19
  execution_platform: "Camunda Cloud"
  execution_platform_version: "8.9.0"
  json_schema: "@bpmn-io/form-json-schema"  # oficjalny schemat formatu — każda opublikowana wersja musi go przejść

statuses:
  supported:  "Wspierany — w palecie projektanta, renderowany i walidowany"
  restricted: "Wspierany z ograniczeniami — publikacja sprawdza ograniczenie z pola `restriction`"
  planned:    "Planowany — poza paletą; import i publikacja odrzucane do czasu decyzji"
  blocked:    "Zablokowany — poza paletą; import i publikacja odrzucane"

# Własności wspólne dopuszczone dla pól wiążących dane (w nawiasie: kto je materializuje).
common_properties:
  - { name: label,             owner: struktura, note: "etykieta nad polem; wymagana dla każdego pola wprowadzania danych" }
  - { name: description,       owner: struktura, note: "podpowiedź pod polem; powiązana z kontrolką przez aria-describedby" }
  - { name: key,               owner: struktura, note: "zmienna procesu; zgodna z kontraktem ph:inputs / ph:outputs" }
  - { name: defaultValue,      owner: struktura }
  - { name: validate.required, owner: struktura, note: "komponent dopisuje słowo „(wymagane)” — nie sama gwiazdka" }
  - { name: readonly,          owner: struktura, note: "wartość stała albo wyrażenie FEEL" }
  - { name: disabled,          owner: struktura, note: "wartość stała albo wyrażenie FEEL; pole nie trafia do danych wyjściowych" }
  - { name: conditional.hide,  owner: struktura, note: "wyrażenie FEEL; pole ukryte nie jest walidowane ani przyjmowane" }
  - { name: layout.row,        owner: struktura, note: "wiersz siatki" }
  - { name: layout.columns,    owner: struktura, note: "szerokość 2–16 z 16 kolumn; brak = równy podział wiersza" }
  - { name: properties,        owner: struktura, note: "tylko klucze z przestrzeni ph: (np. ph:field dla pól profili)" }

# Czego schemat nie może ustawić (i czego projektant nie pokazuje): kolory, kroje, rozmiary czcionek, marginesy, obramowania, CSS, HTML.

types:
  - type: textfield
    name: Pole tekstowe
    status: supported
    component: ph-text-field
    kendo: kendo-textbox
    figma: "Form / Text field"
    data: string
    properties: [validate.minLength, validate.maxLength, validate.pattern, validate.patternErrorMessage, validate.validationType, appearance.prefixAdorner, appearance.suffixAdorner]
  - type: textarea
    name: Tekst długi
    status: supported
    component: ph-textarea
    kendo: kendo-textarea
    figma: "Form / Text area"
    data: string
    properties: [validate.minLength, validate.maxLength]
    note: "licznik znaków, gdy ustawiono maxLength"
  - type: number
    name: Liczba
    status: supported
    component: ph-number-field
    kendo: kendo-numerictextbox
    figma: "Form / Number field"
    data: number
    properties: [validate.min, validate.max, decimalDigits, increment, serializeToString, appearance.prefixAdorner, appearance.suffixAdorner]
    note: "kwoty: sufiks waluty przez suffixAdorner; separator dziesiętny wg ustawień regionalnych (pl-PL)"
  - type: datetime
    name: Data i czas
    status: supported
    component: ph-date-field
    kendo: "kendo-datepicker, kendo-timepicker, kendo-datetimepicker (wg subtype)"
    figma: "Form / Date field"
    data: date
    properties: [subtype, dateLabel, timeLabel, use24h, timeSerializingFormat, timeInterval, disallowPassedDates]
  - type: checkbox
    name: Pole wyboru (tak/nie)
    status: supported
    component: ph-checkbox
    kendo: kendo-checkbox
    figma: "Form / Checkbox"
    data: boolean
    properties: []
  - type: checklist
    name: Lista pól wyboru
    status: supported
    component: ph-checklist
    kendo: "fieldset + kendo-checkbox"
    figma: "Form / Checklist"
    data: list
    properties: [values, valuesKey, valuesExpression]
  - type: radio
    name: Wybór jednej opcji
    status: supported
    component: ph-radio-group
    kendo: "fieldset + kendo-radiobutton"
    figma: "Form / Radio group"
    data: string
    properties: [values, valuesKey, valuesExpression]
  - type: select
    name: Lista rozwijana
    status: supported
    component: ph-select
    kendo: "kendo-dropdownlist; kendo-combobox, gdy searchable"
    figma: "Form / Select"
    data: string
    properties: [values, valuesKey, valuesExpression, searchable]
    note: "typ bazowy pól profili (properties.ph:field)"
  - type: taglist
    name: Wybór wielu wartości
    status: supported
    component: ph-taglist
    kendo: kendo-multiselect
    figma: "Form / Tag list"
    data: list
    properties: [values, valuesKey, valuesExpression]
  - type: group
    name: Sekcja
    status: supported
    component: ph-group
    kendo: "fieldset + legend"
    figma: "Form / Group"
    data: context
    properties: [path, showOutline, verticalAlignment, components]
  - type: dynamiclist
    name: Lista powtarzana
    status: supported
    component: ph-repeater
    kendo: "własny na ui-kit (przyciski „Dodaj pozycję” i „Usuń”)"
    figma: "Form / Repeater"
    data: list
    properties: [path, isRepeating, allowAddRemove, defaultRepetitions, disableCollapse, nonCollapsedItems, showOutline, verticalAlignment, components]
  - type: table
    name: Tabela (tylko odczyt)
    status: supported
    component: ph-data-table
    kendo: "kendo-grid w trybie odczytu; karty poniżej progu szerokości"
    figma: "Form / Data table"
    data: none
    properties: [dataSource, columns, columnsExpression, rowCount]
  - type: expression
    name: Pole wyliczane
    status: supported
    component: none
    kendo: "—"
    figma: "—"
    data: any
    properties: [expression, computeOn]
    note: "bez interfejsu; wartość liczona wyrażeniem FEEL"
  - type: separator
    name: Linia podziału
    status: supported
    component: ph-separator
    kendo: "—"
    figma: "Form / Separator"
    data: none
    properties: []
  - type: text
    name: Tekst
    status: restricted
    component: ph-text-block
    kendo: "—"
    figma: "Form / Text block"
    data: none
    properties: [text]
    restriction: "Markdown (nagłówki, akapity, listy, pogrubienie, odnośniki do tej samej domeny) i szablony FEEL; surowy HTML jest usuwany; typografię nadaje design system"
  - type: spacer
    name: Odstęp
    status: restricted
    component: ph-spacer
    kendo: "—"
    figma: "Form / Spacer"
    data: none
    properties: [height]
    restriction: "wysokość zaokrąglana do najbliższej wartości ze skali odstępów (space_px w design/tokens.json)"
  - type: image
    name: Obraz
    status: restricted
    component: ph-image
    kendo: "—"
    figma: "Form / Image"
    data: none
    properties: [source, alt]
    restriction: "źródło wyłącznie jako data URI do 200 KB; alt wymagany; adresy zewnętrzne odrzucane (CSP)"
  - type: filepicker
    name: Załącznik
    status: planned
    component: ph-file-field
    kendo: kendo-upload
    figma: "Form / File field"
    data: document-reference
    properties: [accept, multiple]
    note: "czeka na decyzję D-15 o magazynie dokumentów (praktyka C9: załączniki jako referencje, nie zmienne)"
  - type: documentPreview
    name: Podgląd dokumentu
    status: planned
    component: ph-document-preview
    kendo: "—"
    figma: "Form / Document preview"
    data: none
    properties: [dataSource, maxHeight]
    note: "jak filepicker — decyzja D-15"
  - type: html
    name: HTML
    status: blocked
    component: none
    kendo: "—"
    figma: "—"
    data: none
    properties: []
    note: "brak dowolnego HTML w formatkach (docs/architecture/10-audit-and-security.md); zamiast niego typ text"
  - type: iframe
    name: Ramka
    status: blocked
    component: none
    kendo: "—"
    figma: "—"
    data: none
    properties: []
    note: "brak treści zewnętrznych; dane projektu dostarcza panel zadania profilu (slot task.panel)"
  - type: button
    name: Przycisk
    status: blocked
    component: none
    kendo: "—"
    figma: "—"
    data: none
    properties: []
    note: "akcje zadania renderuje powłoka z allowedActions (Zapisz szkic, Zakończ zadanie)"

# Zgodność typów pól z typami kontraktu danych zadania (ph:inputs / ph:outputs).
contract_types:
  string:  [textfield, textarea, radio, select, datetime, expression]
  number:  [number, expression]
  boolean: [checkbox, expression]
  date:    [datetime]
  list:    [checklist, taglist, dynamiclist]
  context: [group]
````

## Plik: plan/dashboard/README.md

# Dashboard harmonogramu i wyceny

Interaktywny widok planu wykonawczego dla zespołu i decydentów: harmonogram kroków na osi tygodni ze ścieżką krytyczną, bramkami i warstwami (wycena, ryzyko, zakres, role, udział AI, blokery, zapas), obciążenie ról w tygodniach, złożoność a oszczędność, rejestr ryzyk i decyzji. Każda liczba na stronie wskazuje swoje źródło (zbiór danych poniżej).

| Plik | Rola |
| --- | --- |
| `index.html` | samodzielna strona (otwierana z dysku, bez serwera); jasny i ciemny motyw |
| `data.js` | wszystkie zbiory danych dla strony (`window.PH_DATA`) — generowany |
| `data/*.json` | te same zbiory osobno: `steps`, `gates`, `summary`, `phases`, `roles`, `role_weekly`, `scenarios`, `risks`, `decisions` |
| `register.yaml` | ręcznie utrzymywany rejestr ryzyk, decyzji i warunków bramek |
| `vendor/d3.v7.9.0.min.js` | biblioteka wykresów d3 (licencja ISC, `vendor/d3-LICENSE.txt`) dołączona lokalnie — strona nie pobiera nic z internetu |

## Odświeżenie po zmianie planu

```bash
python3 tools/plan/estimate.py                  # przelicza model (plan/estimation-report.md)
python3 tools/plan/export_dashboard_data.py     # zapisuje plan/dashboard/data/*.json i plan/dashboard/data.js
```

Potem wystarczy odświeżyć `index.html` w przeglądarce.

## Obserwowanie wykonania

- Status i postęp kroku: pola `status` (`Planowany`, `W toku`, `Zakończony`, `Zablokowany`) i `progress` w `steps.json` — eksporter ustawia je dziś na wartości startowe; po włączeniu śledzenia czyta je z `plan/progress/*.json`.
- Rzeczywista praca ludzi: `plan/progress/<krok>.effort.json` → kalibracja prognozy (`plan/estimation.md`, sekcja 7) → nowe tygodnie i wyceny na wykresie.
- Warstwa „Status” na harmonogramie i filtr ról pokazują, co jest w toku i kto jest potrzebny w danym tygodniu.
- Plany zespołów profili (`profiles/<id>/backlog.yaml`) nie są częścią tej wyceny — dashboard pokazuje plan platformy, a kroki profili są blokerem zewnętrznym pilotażu (S60).

## Plik: plan/dashboard/register.yaml

````yaml
# Rejestr ryzyk, decyzji i warunków bramek — źródło dla dashboardu (tools/plan/export_dashboard_data.py).
# Prawdopodobieństwo i wpływ w skali 1–5; wynik = prawdopodobieństwo × wpływ.
gate_conditions:
  G0: "ADR-003, ADR-004, ADR-007 i ADR-010 przyjęte na podstawie PoC; scenariusze zatwierdzone przez PO"
  G1: "Kontrakty v1 i OpenAPI zamrożone; szkielet, baza i harness BDD zielone w CI; ADR-019 i ADR-020 przyjęte na podstawie PoC formatek, warstwa wizualna zatwierdzona przez projektanta UX"
  G2: "Przejęcie i zakończenie zadania działają end-to-end na prawdziwej Camunda przez oficjalne SDK"
  G3: "Wszystkie scenariusze zielone; pentest, kompletność audytu i compliance zaakceptowane"
risks:
  - {id: R01, title: "Luki w oficjalnym SDK Camunda dla 8.9", probability: 3, impact: 4, owner: "Architekt", steps: "S01, S22", signal: "operacja z listy kontrolnej niedostępna w SDK podczas S01", mitigation: "klient z OpenAPI Camunda wewnątrz ACL (ADR-003)", status: "otwarte"}
  - {id: R02, title: "Autoryzacje Camunda działają inaczej niż założono", probability: 3, impact: 5, owner: "Bezpieczeństwo", steps: "S02, S21, S24", signal: "PoC S02 nie potwierdza zakresu per bpmnProcessId lub tokenu delegowanego", mitigation: "PoC przed G0; reguły L2 w aplikacji jako siatka bezpieczeństwa", status: "otwarte"}
  - {id: R03, title: "Procedury IT banku opóźniają środowisko", probability: 4, impact: 4, owner: "DevOps", steps: "S06, S50", signal: "brak dostępów do AD, RHBK lub K8s po 2 tygodniach", mitigation: "start S06 w tygodniu 1, wnioski o dostępy przed startem projektu", status: "otwarte"}
  - {id: R04, title: "Opóźnione decyzje biznesu przy G0", probability: 3, impact: 4, owner: "Product Owner", steps: "S05, S10", signal: "warsztaty przesunięte lub decyzje D-01..D-07 otwarte w tygodniu 3", mitigation: "terminy warsztatów ustalone przed startem; scenariusze w `specs/` gotowe do akceptacji", status: "otwarte"}
  - {id: R05, title: "Spójność i opóźnienie read modelu", probability: 3, impact: 4, owner: "Architekt", steps: "S04, S23", signal: "opóźnienie P95 powyżej celu w pomiarze S04", mitigation: "inbox i upsert po kluczu; przejście na eksporter (ADR-010)", status: "otwarte"}
  - {id: R06, title: "Brak terminu zewnętrznego pentestu", probability: 3, impact: 3, owner: "Bezpieczeństwo", steps: "S54", signal: "brak potwierdzonego terminu do tygodnia 12", mitigation: "rezerwacja w pierwszym miesiącu projektu", status: "otwarte"}
  - {id: R07, title: "Niska dostępność PO i bezpieczeństwa", probability: 3, impact: 4, owner: "Sponsor", steps: "S05, S18, S24, S51, S54", signal: "decyzje czekają dłużej niż tydzień", mitigation: "rezerwacja 0,5–0,75 etatu PO i 0,2–0,3 etatu bezpieczeństwa", status: "otwarte"}
  - {id: R08, title: "Agenci AI słabsi niż założono", probability: 2, impact: 3, owner: "Tech lead", steps: "S10, S12, S22, S40", signal: "współczynnik kalibracji k powyżej 1,3 po S10–S12", mitigation: "kwalifikacja GLM 5.3 Flash (E01–E08), wyższy wariant rozumowania, kalibracja prognozy", status: "otwarte"}
  - {id: R09, title: "Opóźniony zakup licencji Kendo UI", probability: 2, impact: 2, owner: "Zakupy", steps: "S16", signal: "brak tokenu rejestru npm w tygodniu 6", mitigation: "zakup równolegle z PoC", status: "otwarte"}
  - {id: R10, title: "Obejście reguł przez natywny Tasklist w pilotażu", probability: 2, impact: 4, owner: "Architekt", steps: "S60", signal: "użytkownicy pilotażu mają dostęp do webapp Tasklist", mitigation: "odcięcie dostępu do Tasklist od pierwszego dnia pilotażu (C16)", status: "otwarte"}
  - {id: R11, title: "Mapa etapów nie oddaje pracy menadżerów", probability: 2, impact: 3, owner: "Product Owner", steps: "S34, S36, S42", signal: "menadżerowie w teście makiety nie rozpoznają etapów", mitigation: "warsztat na makiecie przed S34", status: "otwarte"}
  - {id: R12, title: "Wolumen audytu obciąża bazę", probability: 2, impact: 3, owner: "Inżynier danych", steps: "S25, S52", signal: "przyrost OperationTrace ponad plan w testach wydajności", mitigation: "partycje i retencja przez TRUNCATE, indeks kolumnowy", status: "otwarte"}
  - {id: R13, title: "SDK rozszerzeń nie pokrywa potrzeb zespołów profili", probability: 3, impact: 3, owner: "Architekt", steps: "S19, S38, S47", signal: "więcej niż 2 RFC o nowe punkty rozszerzeń przed G2", mitigation: "warsztat z zespołami kredytów i AML przed S19; profil przykładowy i testy zgodności", status: "otwarte"}
  - {id: R14, title: "Izolacja danych profili w bazie trudniejsza niż założono", probability: 2, impact: 4, owner: "Inżynier danych", steps: "S27", signal: "EXECUTE AS USER niezgodne z pulą połączeń lub zbyt kosztowne w teście S27", mitigation: "wariant zapasowy: osobne połączenie i login per profil z outboxem (ADR-014)", status: "otwarte"}
  - {id: R15, title: "Bramka modelu GLM w banku niewystarczająca (wydajność, dostępność, kolejki)", probability: 3, impact: 3, owner: "DevOps", steps: "S00, S06, S10", signal: "czas odpowiedzi agenta powyżej 2 min albo przerwy w dostępności bramki w pierwszych krokach", mitigation: "rezerwacja GPU przed startem, limity równoległości roju, kolejka zadań, monitoring bramki", status: "otwarte"}
  - {id: R16, title: "Renderer platformy zachowuje się inaczej niż biblioteka Camunda Forms", probability: 3, impact: 3, owner: "Architekt", steps: "S07, S40, S55", signal: "rozbieżności w zestawie zgodności dla formatek wzorcowych w S07", mitigation: "katalog pól ogranicza zakres typów; zestaw zgodności w CI; wariant zapasowy z ADR-019", status: "otwarte"}
  - {id: R17, title: "FEEL w przeglądarce i w silniku daje różne wyniki albo ewaluacja w silniku jest za wolna", probability: 3, impact: 3, owner: "Architekt", steps: "S08, S37", signal: "różnice semantyki w raporcie S08 lub czas ewaluacji formatki powyżej celu", mitigation: "podzbiór FEEL dozwolony w formatkach; warianty zapasowe z ADR-020; walidacja poziomu A niezależna od FEEL", status: "otwarte"}
  - {id: R18, title: "Biblioteka w Figma i księga znaku banku gotowe za późno", probability: 3, impact: 3, owner: "Projektant UX", steps: "S09, S16, S49", signal: "brak eksportu zmiennych i komponentów pól przed startem S16", mitigation: "start na tokenach makiety; podmiana tokenów nie wymaga zmian w komponentach ani formatkach", status: "otwarte"}
  - {id: R19, title: "Biznes oczekuje stylowania pojedynczych formatek", probability: 2, impact: 2, owner: "Product Owner", steps: "S45, S60", signal: "prośby o kolory lub własny wygląd pól w testach z użytkownikami", mitigation: "podgląd jak u wykonawcy w projektancie; wytyczne UI; zmiany wyglądu wyłącznie przez design system", status: "otwarte"}
decisions:
  - {id: S-1, type: "start", decision: "Zatwierdzenie zespołu 6,2 etatu (w tym 0,5 etatu projektanta UX) i budżetu na agentów AI", recommendation: "zespół referencyjny z planu, budżet tokenów zmierzony na S10–S12", owner: "Sponsor projektu", before_steps: "S00"}
  - {id: S-2, type: "start", decision: "Bramka modelu GLM w infrastrukturze banku: sprzęt, serwer, dostęp", recommendation: "serwer zgodny z API OpenAI z wagami GLM 5.3 Flash, rezerwacja GPU na czas projektu, klucz w magazynie sekretów", owner: "DevOps i bezpieczeństwo", before_steps: "S00"}
  - {id: S-3, type: "start", decision: "Dostępy: namespace K8s, realm RHBK, grupy AD, baza MSSQL", recommendation: "wnioski złożone przed startem projektu", owner: "IT / infrastruktura", before_steps: "S06"}
  - {id: S-4, type: "start", decision: "Licencja Kendo UI for Angular", recommendation: "zakup równolegle z PoC", owner: "Zakupy", before_steps: "S16"}
  - {id: S-5, type: "start", decision: "Rezerwacja terminu zewnętrznego pentestu", recommendation: "rezerwacja w pierwszym miesiącu", owner: "Bezpieczeństwo", before_steps: "S54"}
  - {id: S-6, type: "start", decision: "Projektant UX w zespole i dostęp do Figma oraz księgi znaku banku", recommendation: "0,5 etatu od pierwszego tygodnia; biblioteka w Figma jako źródło wyglądu", owner: "Sponsor projektu", before_steps: "S09"}
  - {id: ADR, type: "techniczna", decision: "Rozstrzygnięcia PoC: SDK, autoryzacje, zastępstwa, zasilanie read modelu", recommendation: "ADR-003, ADR-004, ADR-007, ADR-010 przyjęte na podstawie raportów PoC", owner: "Architekt", before_steps: "S10"}
  - {id: D-01, type: "biznes", decision: "Co znaczy „ta sama grupa uprawnień” dla widoczności", recommendation: "grupy kandydujące zadania i grupy inicjatora", owner: "Product Owner", before_steps: "S24"}
  - {id: D-02, type: "biznes", decision: "Czy menadżer może przekazać zadanie osobie spoza grup kandydujących", recommendation: "tak, jeśli ma rolę uczestnika w procesie", owner: "Product Owner", before_steps: "S32"}
  - {id: D-03, type: "biznes", decision: "Kto przypisuje elementy BPMN do etapów", recommendation: "administrator procesu; menadżer po nadaniu uprawnienia", owner: "Product Owner", before_steps: "S34"}
  - {id: D-04, type: "biznes", decision: "Zastępstwa: tylko nowe zadania czy też istniejące", recommendation: "nowe automatycznie, istniejące przez przekazanie masowe", owner: "Product Owner", before_steps: "S33"}
  - {id: D-05, type: "biznes", decision: "Czy szkic przechodzi z zadaniem przy przekazaniu", recommendation: "tak, z adnotacją i audytem", owner: "Product Owner", before_steps: "S32"}
  - {id: D-06, type: "biznes", decision: "Czy anulowanie liczyć jako błąd na dashboardzie", recommendation: "osobny licznik „anulowane”", owner: "Product Owner", before_steps: "S36"}
  - {id: D-07, type: "biznes", decision: "Czy audytor widzi techniczny model BPMN", recommendation: "nie domyślnie; osobna rola, jeśli potrzebna", owner: "Compliance", before_steps: "S24"}
  - {id: D-08, type: "techniczna", decision: "Domyślny model integracji profili", recommendation: "in-process; remote na wniosek zespołu (inna technologia, osobne wydania)", owner: "Architekt", before_steps: "S19"}
  - {id: D-09, type: "techniczna", decision: "Monorepo z CODEOWNERS czy osobne repozytoria profili", recommendation: "monorepo na start — walidacja międzyprofilowa i testy architektury w jednym miejscu", owner: "Architekt", before_steps: "S19"}
  - {id: D-10, type: "biznes", decision: "Rytm pociągu wydań dla profili in-process", recommendation: "co dwa tygodnie, wspólnie z wydaniem platformy", owner: "Sponsor projektu", before_steps: "S48"}
  - {id: D-11, type: "biznes", decision: "Zakres danych platformy w widokach platform_api", recommendation: "zadania, instancje i stany etapów procesów profilu; bez danych innych profili", owner: "Product Owner", before_steps: "S27"}
  - {id: ADR-F, type: "techniczna", decision: "Rozstrzygnięcia PoC formatek: renderer i walidacja FEEL", recommendation: "ADR-019 (własny renderer na design systemie) i ADR-020 (FEEL przez silnik) przyjęte na podstawie raportów S07 i S08", owner: "Architekt", before_steps: "S26, S37"}
  - {id: D-12, type: "biznes", decision: "Cztery oczy przy formatkach: autor ostatniej zmiany czy każdy współautor szkicu", recommendation: "autor ostatniej zmiany (R8); lista współautorów widoczna dla zatwierdzającego i zapisana w dzienniku", owner: "Compliance", before_steps: "S26"}
  - {id: D-13, type: "biznes", decision: "Czy wycofanie wersji formatki wymaga drugiej osoby", recommendation: "nie — operacja awaryjna jednej osoby z powodem, powiadomieniem pozostałych i wpisem w dzienniku", owner: "Product Owner", before_steps: "S26"}
  - {id: D-14, type: "biznes", decision: "Domyślny skutek wycofania dla zadań w toku", recommendation: "zadania pozostają na wycofanej wersji; przepięcie na wersję zastępczą jako świadomy wybór", owner: "Product Owner", before_steps: "S39"}
  - {id: D-15, type: "techniczna", decision: "Załączniki w formatkach: magazyn dokumentów dla pól plikowych", recommendation: "obsługa dokumentów Camunda albo magazyn banku; do decyzji typy filepicker i documentPreview pozostają poza katalogiem", owner: "Architekt", before_steps: "S40"}
  - {id: D-16, type: "biznes", decision: "Właściciel biblioteki w Figma i tryb przenoszenia zmian wyglądu do repozytorium", recommendation: "projektant UX banku; eksport jako pull request w design/** z przeglądem, najwyżej raz na wydanie", owner: "Projektant UX", before_steps: "S09"}
````

## Plik: plan/dashboard/data/summary.json

````json
[
 {
  "cal_hyb_weeks": 27.6,
  "cal_hyb_p80_weeks": 30.8,
  "cal_trad_weeks": 38.3,
  "cal_trad_p80_weeks": 42.9,
  "cal_saving_weeks": 10.7,
  "effort_hyb_pd": 459,
  "effort_hyb_p80_pd": 515,
  "effort_trad_pd": 597,
  "effort_trad_p80_pd": 669,
  "effort_saving": 0.23,
  "cp_days": 138,
  "team_fte": 6.2,
  "steps_total": 57,
  "steps_critical": 17,
  "gates_total": 4,
  "bottleneck_role": "Backend .NET",
  "calibration_k": 1.0,
  "steps_with_actuals": 0
 }
]
````

## Plik: plan/dashboard/data/phases.json

````json
[
 {
  "phase": 0,
  "name": "Przygotowanie i PoC",
  "trad_pd": 78.3,
  "hyb_pd": 63.5,
  "saving": 0.19,
  "start_week": 0.0,
  "end_week": 3.3,
  "steps": 10
 },
 {
  "phase": 1,
  "name": "Fundament",
  "trad_pd": 76.5,
  "hyb_pd": 48.3,
  "saving": 0.37,
  "start_week": 2.0,
  "end_week": 8.2,
  "steps": 10
 },
 {
  "phase": 2,
  "name": "Dostęp, Camunda, audyt, formatki",
  "trad_pd": 111.7,
  "hyb_pd": 75.5,
  "saving": 0.32,
  "start_week": 6.7,
  "end_week": 11.6,
  "steps": 10
 },
 {
  "phase": 3,
  "name": "Funkcje rdzenia",
  "trad_pd": 95.5,
  "hyb_pd": 61.4,
  "saving": 0.36,
  "start_week": 8.5,
  "end_week": 15.3,
  "steps": 10
 },
 {
  "phase": 4,
  "name": "Frontend funkcjonalny",
  "trad_pd": 99.2,
  "hyb_pd": 56.1,
  "saving": 0.43,
  "start_week": 8.2,
  "end_week": 16.0,
  "steps": 10
 },
 {
  "phase": 5,
  "name": "Integracja i hardening",
  "trad_pd": 61.0,
  "hyb_pd": 50.8,
  "saving": 0.17,
  "start_week": 16.0,
  "end_week": 22.3,
  "steps": 6
 },
 {
  "phase": 6,
  "name": "Pilotaż",
  "trad_pd": 20.8,
  "hyb_pd": 20.8,
  "saving": 0.0,
  "start_week": 22.3,
  "end_week": 27.6,
  "steps": 1
 }
]
````

## Plik: plan/dashboard/data/gates.json

````json
[
 {
  "gate": "G0",
  "week": 3.3,
  "wait_days": 5.5,
  "after": "S01, S02, S03, S04, S05",
  "approver": "Architekt, Product Owner",
  "condition": "ADR-003, ADR-004, ADR-007 i ADR-010 przyjęte na podstawie PoC; scenariusze zatwierdzone przez PO"
 },
 {
  "gate": "G1",
  "week": 7.0,
  "wait_days": 2.2,
  "after": "S07, S08, S09, S11, S13, S14, S15, S18",
  "approver": "Architekt, Tech lead",
  "condition": "Kontrakty v1 i OpenAPI zamrożone; szkielet, baza i harness BDD zielone w CI; ADR-019 i ADR-020 przyjęte na podstawie PoC formatek, warstwa wizualna zatwierdzona przez projektanta UX"
 },
 {
  "gate": "G2",
  "week": 12.6,
  "wait_days": 1.3,
  "after": "S30",
  "approver": "Tech lead",
  "condition": "Przejęcie i zakończenie zadania działają end-to-end na prawdziwej Camunda przez oficjalne SDK"
 },
 {
  "gate": "G3",
  "week": 22.3,
  "wait_days": 5.5,
  "after": "S54",
  "approver": "Bezpieczeństwo, Compliance",
  "condition": "Wszystkie scenariusze zielone; pentest, kompletność audytu i compliance zaakceptowane"
 }
]
````

## Plik: plan/dashboard/data/roles.json

````json
[
 {
  "role": "architekt_tech_lead",
  "role_label": "Architekt / tech lead",
  "fte": 1.0,
  "load_pd": 92.9,
  "days_needed": 124,
  "cp_days": 138,
  "load_vs_cp": 0.9
 },
 {
  "role": "backend_dotnet",
  "role_label": "Backend .NET",
  "fte": 2.0,
  "load_pd": 191.9,
  "days_needed": 128,
  "cp_days": 138,
  "load_vs_cp": 0.93
 },
 {
  "role": "frontend_angular",
  "role_label": "Frontend Angular",
  "fte": 1.0,
  "load_pd": 66.2,
  "days_needed": 88,
  "cp_days": 138,
  "load_vs_cp": 0.64
 },
 {
  "role": "ux_designer",
  "role_label": "Projektant UX",
  "fte": 0.5,
  "load_pd": 14.0,
  "days_needed": 37,
  "cp_days": 138,
  "load_vs_cp": 0.27
 },
 {
  "role": "devops",
  "role_label": "DevOps",
  "fte": 0.5,
  "load_pd": 22.1,
  "days_needed": 59,
  "cp_days": 138,
  "load_vs_cp": 0.43
 },
 {
  "role": "qa_bdd",
  "role_label": "QA / BDD",
  "fte": 0.5,
  "load_pd": 12.8,
  "days_needed": 34,
  "cp_days": 138,
  "load_vs_cp": 0.25
 },
 {
  "role": "product_owner_analityk",
  "role_label": "PO / analityk",
  "fte": 0.5,
  "load_pd": 43.5,
  "days_needed": 116,
  "cp_days": 138,
  "load_vs_cp": 0.84
 },
 {
  "role": "bezpieczenstwo",
  "role_label": "Bezpieczeństwo",
  "fte": 0.2,
  "load_pd": 15.9,
  "days_needed": 106,
  "cp_days": 138,
  "load_vs_cp": 0.77
 }
]
````

## Plik: plan/dashboard/data/scenarios.json

````json
[
 {
  "effort_pd": 459.3,
  "cal_weeks": 27.6,
  "cal_p80_weeks": 30.8,
  "id": "bazowy",
  "name": "Bazowy",
  "description": "plan i szacunki bez zmian",
  "delta_weeks": 0.0,
  "delta_effort_pd": 0.0
 },
 {
  "effort_pd": 529.2,
  "cal_weeks": 30.3,
  "cal_p80_weeks": 33.9,
  "id": "slabsi_agenci",
  "name": "Słabsi agenci",
  "description": "udział AI niższy o 20 pkt, np. słabsze wyniki kwalifikacji modelu",
  "delta_weeks": 2.7,
  "delta_effort_pd": 69.9
 },
 {
  "effort_pd": 511.6,
  "cal_weeks": 29.6,
  "cal_p80_weeks": 33.1,
  "id": "drozszy_przeglad",
  "name": "Droższy przegląd",
  "description": "przegląd pracy agentów droższy o 15 pkt",
  "delta_weeks": 2.0,
  "delta_effort_pd": 52.3
 },
 {
  "effort_pd": 474.5,
  "cal_weeks": 32.5,
  "cal_p80_weeks": 36.3,
  "id": "wolne_procedury",
  "name": "Wolne procedury banku",
  "description": "oczekiwanie na bramki ×2, środowisko i pentest pesymistycznie",
  "delta_weeks": 4.9,
  "delta_effort_pd": 15.2
 },
 {
  "effort_pd": 459.3,
  "cal_weeks": 27.6,
  "cal_p80_weeks": 30.8,
  "id": "wiekszy_zespol",
  "name": "Większy zespół",
  "description": "+1 backend, PO 0,75 etatu, bezpieczeństwo 0,3 etatu",
  "delta_weeks": 0.0,
  "delta_effort_pd": 0.0
 },
 {
  "effort_pd": 459.3,
  "cal_weeks": 25.6,
  "cal_p80_weeks": 28.7,
  "id": "podzial_krytycznych",
  "name": "Podział kroków krytycznych",
  "description": "dwie osoby z agentami na krokach ścieżki krytycznej",
  "delta_weeks": -2.0,
  "delta_effort_pd": 0.0
 }
]
````

## Plik: plan/dashboard/data/risks.json

````json
[
 {
  "id": "R01",
  "title": "Luki w oficjalnym SDK Camunda dla 8.9",
  "probability": 3,
  "impact": 4,
  "owner": "Architekt",
  "steps": "S01, S22",
  "signal": "operacja z listy kontrolnej niedostępna w SDK podczas S01",
  "mitigation": "klient z OpenAPI Camunda wewnątrz ACL (ADR-003)",
  "status": "otwarte",
  "score": 12
 },
 {
  "id": "R02",
  "title": "Autoryzacje Camunda działają inaczej niż założono",
  "probability": 3,
  "impact": 5,
  "owner": "Bezpieczeństwo",
  "steps": "S02, S21, S24",
  "signal": "PoC S02 nie potwierdza zakresu per bpmnProcessId lub tokenu delegowanego",
  "mitigation": "PoC przed G0; reguły L2 w aplikacji jako siatka bezpieczeństwa",
  "status": "otwarte",
  "score": 15
 },
 {
  "id": "R03",
  "title": "Procedury IT banku opóźniają środowisko",
  "probability": 4,
  "impact": 4,
  "owner": "DevOps",
  "steps": "S06, S50",
  "signal": "brak dostępów do AD, RHBK lub K8s po 2 tygodniach",
  "mitigation": "start S06 w tygodniu 1, wnioski o dostępy przed startem projektu",
  "status": "otwarte",
  "score": 16
 },
 {
  "id": "R04",
  "title": "Opóźnione decyzje biznesu przy G0",
  "probability": 3,
  "impact": 4,
  "owner": "Product Owner",
  "steps": "S05, S10",
  "signal": "warsztaty przesunięte lub decyzje D-01..D-07 otwarte w tygodniu 3",
  "mitigation": "terminy warsztatów ustalone przed startem; scenariusze w `specs/` gotowe do akceptacji",
  "status": "otwarte",
  "score": 12
 },
 {
  "id": "R05",
  "title": "Spójność i opóźnienie read modelu",
  "probability": 3,
  "impact": 4,
  "owner": "Architekt",
  "steps": "S04, S23",
  "signal": "opóźnienie P95 powyżej celu w pomiarze S04",
  "mitigation": "inbox i upsert po kluczu; przejście na eksporter (ADR-010)",
  "status": "otwarte",
  "score": 12
 },
 {
  "id": "R06",
  "title": "Brak terminu zewnętrznego pentestu",
  "probability": 3,
  "impact": 3,
  "owner": "Bezpieczeństwo",
  "steps": "S54",
  "signal": "brak potwierdzonego terminu do tygodnia 12",
  "mitigation": "rezerwacja w pierwszym miesiącu projektu",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R07",
  "title": "Niska dostępność PO i bezpieczeństwa",
  "probability": 3,
  "impact": 4,
  "owner": "Sponsor",
  "steps": "S05, S18, S24, S51, S54",
  "signal": "decyzje czekają dłużej niż tydzień",
  "mitigation": "rezerwacja 0,5–0,75 etatu PO i 0,2–0,3 etatu bezpieczeństwa",
  "status": "otwarte",
  "score": 12
 },
 {
  "id": "R08",
  "title": "Agenci AI słabsi niż założono",
  "probability": 2,
  "impact": 3,
  "owner": "Tech lead",
  "steps": "S10, S12, S22, S40",
  "signal": "współczynnik kalibracji k powyżej 1,3 po S10–S12",
  "mitigation": "kwalifikacja GLM 5.3 Flash (E01–E08), wyższy wariant rozumowania, kalibracja prognozy",
  "status": "otwarte",
  "score": 6
 },
 {
  "id": "R09",
  "title": "Opóźniony zakup licencji Kendo UI",
  "probability": 2,
  "impact": 2,
  "owner": "Zakupy",
  "steps": "S16",
  "signal": "brak tokenu rejestru npm w tygodniu 6",
  "mitigation": "zakup równolegle z PoC",
  "status": "otwarte",
  "score": 4
 },
 {
  "id": "R10",
  "title": "Obejście reguł przez natywny Tasklist w pilotażu",
  "probability": 2,
  "impact": 4,
  "owner": "Architekt",
  "steps": "S60",
  "signal": "użytkownicy pilotażu mają dostęp do webapp Tasklist",
  "mitigation": "odcięcie dostępu do Tasklist od pierwszego dnia pilotażu (C16)",
  "status": "otwarte",
  "score": 8
 },
 {
  "id": "R11",
  "title": "Mapa etapów nie oddaje pracy menadżerów",
  "probability": 2,
  "impact": 3,
  "owner": "Product Owner",
  "steps": "S34, S36, S42",
  "signal": "menadżerowie w teście makiety nie rozpoznają etapów",
  "mitigation": "warsztat na makiecie przed S34",
  "status": "otwarte",
  "score": 6
 },
 {
  "id": "R12",
  "title": "Wolumen audytu obciąża bazę",
  "probability": 2,
  "impact": 3,
  "owner": "Inżynier danych",
  "steps": "S25, S52",
  "signal": "przyrost OperationTrace ponad plan w testach wydajności",
  "mitigation": "partycje i retencja przez TRUNCATE, indeks kolumnowy",
  "status": "otwarte",
  "score": 6
 },
 {
  "id": "R13",
  "title": "SDK rozszerzeń nie pokrywa potrzeb zespołów profili",
  "probability": 3,
  "impact": 3,
  "owner": "Architekt",
  "steps": "S19, S38, S47",
  "signal": "więcej niż 2 RFC o nowe punkty rozszerzeń przed G2",
  "mitigation": "warsztat z zespołami kredytów i AML przed S19; profil przykładowy i testy zgodności",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R14",
  "title": "Izolacja danych profili w bazie trudniejsza niż założono",
  "probability": 2,
  "impact": 4,
  "owner": "Inżynier danych",
  "steps": "S27",
  "signal": "EXECUTE AS USER niezgodne z pulą połączeń lub zbyt kosztowne w teście S27",
  "mitigation": "wariant zapasowy: osobne połączenie i login per profil z outboxem (ADR-014)",
  "status": "otwarte",
  "score": 8
 },
 {
  "id": "R15",
  "title": "Bramka modelu GLM w banku niewystarczająca (wydajność, dostępność, kolejki)",
  "probability": 3,
  "impact": 3,
  "owner": "DevOps",
  "steps": "S00, S06, S10",
  "signal": "czas odpowiedzi agenta powyżej 2 min albo przerwy w dostępności bramki w pierwszych krokach",
  "mitigation": "rezerwacja GPU przed startem, limity równoległości roju, kolejka zadań, monitoring bramki",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R16",
  "title": "Renderer platformy zachowuje się inaczej niż biblioteka Camunda Forms",
  "probability": 3,
  "impact": 3,
  "owner": "Architekt",
  "steps": "S07, S40, S55",
  "signal": "rozbieżności w zestawie zgodności dla formatek wzorcowych w S07",
  "mitigation": "katalog pól ogranicza zakres typów; zestaw zgodności w CI; wariant zapasowy z ADR-019",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R17",
  "title": "FEEL w przeglądarce i w silniku daje różne wyniki albo ewaluacja w silniku jest za wolna",
  "probability": 3,
  "impact": 3,
  "owner": "Architekt",
  "steps": "S08, S37",
  "signal": "różnice semantyki w raporcie S08 lub czas ewaluacji formatki powyżej celu",
  "mitigation": "podzbiór FEEL dozwolony w formatkach; warianty zapasowe z ADR-020; walidacja poziomu A niezależna od FEEL",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R18",
  "title": "Biblioteka w Figma i księga znaku banku gotowe za późno",
  "probability": 3,
  "impact": 3,
  "owner": "Projektant UX",
  "steps": "S09, S16, S49",
  "signal": "brak eksportu zmiennych i komponentów pól przed startem S16",
  "mitigation": "start na tokenach makiety; podmiana tokenów nie wymaga zmian w komponentach ani formatkach",
  "status": "otwarte",
  "score": 9
 },
 {
  "id": "R19",
  "title": "Biznes oczekuje stylowania pojedynczych formatek",
  "probability": 2,
  "impact": 2,
  "owner": "Product Owner",
  "steps": "S45, S60",
  "signal": "prośby o kolory lub własny wygląd pól w testach z użytkownikami",
  "mitigation": "podgląd jak u wykonawcy w projektancie; wytyczne UI; zmiany wyglądu wyłącznie przez design system",
  "status": "otwarte",
  "score": 4
 }
]
````

## Plik: plan/dashboard/data/decisions.json

````json
[
 {
  "id": "S-1",
  "type": "start",
  "decision": "Zatwierdzenie zespołu 6,2 etatu (w tym 0,5 etatu projektanta UX) i budżetu na agentów AI",
  "recommendation": "zespół referencyjny z planu, budżet tokenów zmierzony na S10–S12",
  "owner": "Sponsor projektu",
  "before_steps": "S00",
  "needed_by_week": 0.0
 },
 {
  "id": "S-2",
  "type": "start",
  "decision": "Bramka modelu GLM w infrastrukturze banku: sprzęt, serwer, dostęp",
  "recommendation": "serwer zgodny z API OpenAI z wagami GLM 5.3 Flash, rezerwacja GPU na czas projektu, klucz w magazynie sekretów",
  "owner": "DevOps i bezpieczeństwo",
  "before_steps": "S00",
  "needed_by_week": 0.0
 },
 {
  "id": "S-3",
  "type": "start",
  "decision": "Dostępy: namespace K8s, realm RHBK, grupy AD, baza MSSQL",
  "recommendation": "wnioski złożone przed startem projektu",
  "owner": "IT / infrastruktura",
  "before_steps": "S06",
  "needed_by_week": 0.5
 },
 {
  "id": "S-4",
  "type": "start",
  "decision": "Licencja Kendo UI for Angular",
  "recommendation": "zakup równolegle z PoC",
  "owner": "Zakupy",
  "before_steps": "S16",
  "needed_by_week": 6.7
 },
 {
  "id": "S-5",
  "type": "start",
  "decision": "Rezerwacja terminu zewnętrznego pentestu",
  "recommendation": "rezerwacja w pierwszym miesiącu",
  "owner": "Bezpieczeństwo",
  "before_steps": "S54",
  "needed_by_week": 19.1
 },
 {
  "id": "S-6",
  "type": "start",
  "decision": "Projektant UX w zespole i dostęp do Figma oraz księgi znaku banku",
  "recommendation": "0,5 etatu od pierwszego tygodnia; biblioteka w Figma jako źródło wyglądu",
  "owner": "Sponsor projektu",
  "before_steps": "S09",
  "needed_by_week": 0.5
 },
 {
  "id": "ADR",
  "type": "techniczna",
  "decision": "Rozstrzygnięcia PoC: SDK, autoryzacje, zastępstwa, zasilanie read modelu",
  "recommendation": "ADR-003, ADR-004, ADR-007, ADR-010 przyjęte na podstawie raportów PoC",
  "owner": "Architekt",
  "before_steps": "S10",
  "needed_by_week": 3.3
 },
 {
  "id": "D-01",
  "type": "biznes",
  "decision": "Co znaczy „ta sama grupa uprawnień” dla widoczności",
  "recommendation": "grupy kandydujące zadania i grupy inicjatora",
  "owner": "Product Owner",
  "before_steps": "S24",
  "needed_by_week": 10.1
 },
 {
  "id": "D-02",
  "type": "biznes",
  "decision": "Czy menadżer może przekazać zadanie osobie spoza grup kandydujących",
  "recommendation": "tak, jeśli ma rolę uczestnika w procesie",
  "owner": "Product Owner",
  "before_steps": "S32",
  "needed_by_week": 12.6
 },
 {
  "id": "D-03",
  "type": "biznes",
  "decision": "Kto przypisuje elementy BPMN do etapów",
  "recommendation": "administrator procesu; menadżer po nadaniu uprawnienia",
  "owner": "Product Owner",
  "before_steps": "S34",
  "needed_by_week": 12.6
 },
 {
  "id": "D-04",
  "type": "biznes",
  "decision": "Zastępstwa: tylko nowe zadania czy też istniejące",
  "recommendation": "nowe automatycznie, istniejące przez przekazanie masowe",
  "owner": "Product Owner",
  "before_steps": "S33",
  "needed_by_week": 8.5
 },
 {
  "id": "D-05",
  "type": "biznes",
  "decision": "Czy szkic przechodzi z zadaniem przy przekazaniu",
  "recommendation": "tak, z adnotacją i audytem",
  "owner": "Product Owner",
  "before_steps": "S32",
  "needed_by_week": 12.6
 },
 {
  "id": "D-06",
  "type": "biznes",
  "decision": "Czy anulowanie liczyć jako błąd na dashboardzie",
  "recommendation": "osobny licznik „anulowane”",
  "owner": "Product Owner",
  "before_steps": "S36",
  "needed_by_week": 14.2
 },
 {
  "id": "D-07",
  "type": "biznes",
  "decision": "Czy audytor widzi techniczny model BPMN",
  "recommendation": "nie domyślnie; osobna rola, jeśli potrzebna",
  "owner": "Compliance",
  "before_steps": "S24",
  "needed_by_week": 10.1
 },
 {
  "id": "D-08",
  "type": "techniczna",
  "decision": "Domyślny model integracji profili",
  "recommendation": "in-process; remote na wniosek zespołu (inna technologia, osobne wydania)",
  "owner": "Architekt",
  "before_steps": "S19",
  "needed_by_week": 6.7
 },
 {
  "id": "D-09",
  "type": "techniczna",
  "decision": "Monorepo z CODEOWNERS czy osobne repozytoria profili",
  "recommendation": "monorepo na start — walidacja międzyprofilowa i testy architektury w jednym miejscu",
  "owner": "Architekt",
  "before_steps": "S19",
  "needed_by_week": 6.7
 },
 {
  "id": "D-10",
  "type": "biznes",
  "decision": "Rytm pociągu wydań dla profili in-process",
  "recommendation": "co dwa tygodnie, wspólnie z wydaniem platformy",
  "owner": "Sponsor projektu",
  "before_steps": "S48",
  "needed_by_week": 14.0
 },
 {
  "id": "D-11",
  "type": "biznes",
  "decision": "Zakres danych platformy w widokach platform_api",
  "recommendation": "zadania, instancje i stany etapów procesów profilu; bez danych innych profili",
  "owner": "Product Owner",
  "before_steps": "S27",
  "needed_by_week": 8.8
 },
 {
  "id": "ADR-F",
  "type": "techniczna",
  "decision": "Rozstrzygnięcia PoC formatek: renderer i walidacja FEEL",
  "recommendation": "ADR-019 (własny renderer na design systemie) i ADR-020 (FEEL przez silnik) przyjęte na podstawie raportów S07 i S08",
  "owner": "Architekt",
  "before_steps": "S26, S37",
  "needed_by_week": 6.7
 },
 {
  "id": "D-12",
  "type": "biznes",
  "decision": "Cztery oczy przy formatkach: autor ostatniej zmiany czy każdy współautor szkicu",
  "recommendation": "autor ostatniej zmiany (R8); lista współautorów widoczna dla zatwierdzającego i zapisana w dzienniku",
  "owner": "Compliance",
  "before_steps": "S26",
  "needed_by_week": 6.7
 },
 {
  "id": "D-13",
  "type": "biznes",
  "decision": "Czy wycofanie wersji formatki wymaga drugiej osoby",
  "recommendation": "nie — operacja awaryjna jednej osoby z powodem, powiadomieniem pozostałych i wpisem w dzienniku",
  "owner": "Product Owner",
  "before_steps": "S26",
  "needed_by_week": 6.7
 },
 {
  "id": "D-14",
  "type": "biznes",
  "decision": "Domyślny skutek wycofania dla zadań w toku",
  "recommendation": "zadania pozostają na wycofanej wersji; przepięcie na wersję zastępczą jako świadomy wybór",
  "owner": "Product Owner",
  "before_steps": "S39",
  "needed_by_week": 12.6
 },
 {
  "id": "D-15",
  "type": "techniczna",
  "decision": "Załączniki w formatkach: magazyn dokumentów dla pól plikowych",
  "recommendation": "obsługa dokumentów Camunda albo magazyn banku; do decyzji typy filepicker i documentPreview pozostają poza katalogiem",
  "owner": "Architekt",
  "before_steps": "S40",
  "needed_by_week": 12.6
 },
 {
  "id": "D-16",
  "type": "biznes",
  "decision": "Właściciel biblioteki w Figma i tryb przenoszenia zmian wyglądu do repozytorium",
  "recommendation": "projektant UX banku; eksport jako pull request w design/** z przeglądem, najwyżej raz na wydanie",
  "owner": "Projektant UX",
  "before_steps": "S09",
  "needed_by_week": 0.5
 }
]
````

