# 08-artefakty-i-podsumowanie — Artefakty projektowe (plan systemu, aktorzy, założenia, wytyczne UI) i podsumowanie projektu z rejestrem wymagań W-01…W-48

Pakiet zawiera 6 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: docs/artifacts/01-plan-systemu.md

<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Plan systemu Process Hub

Process Hub to własny TaskList dla Camunda 8.9 w banku: jedna platforma wspólna dla wszystkich projektów i profile projektów z częścią specyficzną realizowaną przez zespoły projektów. Według modelu wyceny pierwszy projekt kończy pilotaż po 27,6 tyg. z rojem agentów AI (ostrożnie 30,8 tyg.), wobec 38,3 tyg. bez AI, przy 459 osobodniach pracy ludzi zamiast 597.

## 1. System w kontekście

```mermaid
flowchart LR
  subgraph U["Użytkownicy"]
    U1["Uczestnik · Inicjator"]
    U2["Menadżer i Administrator procesu"]
    U3["Audytor · Administrator platformy"]
  end
  subgraph PH["Process Hub"]
    SPA["Aplikacja Angular<br/>sloty UI profili"]
    HOST["Host .NET 10 — platforma<br/>api · projector · jobs · worker"]
    EXT["Extension Host<br/>SDK rozszerzeń"]
    PK["Profil kredyty<br/>in-process"]
    PF["Profil flota<br/>in-process"]
    SPA --> HOST
    HOST --- EXT
    EXT --- PK
    EXT --- PF
  end
  PA["Usługa profilu AML<br/>remote"]
  CAM[("Camunda 8.9")]
  IDP[("RHBK + AD")]
  DB[("MS SQL Server<br/>platforma + prj_*")]
  SYS["Systemy projektów<br/>scoring, rejestry, listy sankcyjne, zakupy floty"]
  U --> SPA
  HOST -->|oficjalne SDK| CAM
  HOST -->|OIDC| IDP
  HOST --> DB
  EXT -->|mTLS + token platformy| PA
  PK --> SYS
  PF --> SYS
  PA --> SYS
```

Camunda pozostaje jedynym źródłem prawdy o stanie procesów i zadań; platforma decyduje, kto co widzi i co może zrobić, i audytuje każdą akcję. Użytkownicy nie korzystają z natywnych aplikacji Camunda.

## 2. Część wspólna i część specyficzna

| Platforma — tak samo dla każdego profilu | Profil projektu — decyduje zespół projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4) | Role projektowe z ról platformy i uprawnień projektu |
| Start procesu, moje procesy, przekazywanie, zastępstwa | Operacje dedykowane na zadaniach i sprawach |
| Eskalacje, dashboard menadżera, mapa etapów, formatki | Dane projektu w schemacie `prj_<id>` |
| Audyt każdej akcji, autoryzacje jako kod | Sloty UI (panel zadania i sprawy, widżet, pole formatki, trasy) |
| Integracja z Camunda (wyłącznie platforma) | Workery typów zadań `<id>.*`, integracje z systemami projektu |
| SDK rozszerzeń i jego zgodność wsteczna | Model integracji (in-process albo remote), własny plan i rytm wydań |

Separację wymuszają osobno: repozytorium (`CODEOWNERS`), kompilacja (zależność tylko od SDK), uprawnienia (przestrzeń nazw, R10), wykonanie (R9), baza danych (schemat i użytkownik per profil), wdrożenie, CI i agenci AI (zapis tylko we własnym profilu). Szczegóły: `docs/architecture/13-project-profiles.md`.

## 3. Główne przepływy

- **Praca na zadaniu.** Uczestnik przejmuje zadanie swojej grupy, zapisuje szkic i kończy je; wyścig o przejęcie rozstrzyga Camunda; każda akcja trafia do dziennika bezpieczeństwa z rolą uzasadniającą.
- **Wgląd menadżera.** Dashboard, eskalacje i stan spraw na etapach biznesowych (mapa etapów nad BPMN); przekazywanie pojedyncze i masowe z powodem; zastępstwa na czas nieobecności.
- **Operacja profilu.** Akcja projektu (np. „Przelicz scoring”) pojawia się w akcjach zadania tylko dla uprawnionego assignee; potok platformy sprawdza uprawnienie, R1 i R9, audytuje i wywołuje kod profilu w jego kontekście danych.
- **Dedykowane miejsce profilu.** Profil może mieć własną sekcję nawigacji i strony (np. „Flota” → „Katalog samochodów”), które widzą tylko jego role; dane referencyjne profilu zmienia wskazana rola operacją na danych profilu (ADR-017), a każda zmiana trafia do dziennika.
- **Formatki.** Menadżer albo administrator procesu projektuje formatkę w formacie Camunda Forms (edytor jak w Modelerze), inna osoba ją zatwierdza, publikacja nadaje wersję; wersję można wycofać z powodem. Każda formatka należy do jednego procesu (R11), a na zadaniu renderują ją komponenty design systemu — biznes decyduje o polach i układzie, wygląd jest wspólny (`docs/architecture/14-form-management.md`).
- **Uprawnienia jako kod.** Role platformy, role projektowe i grupy AD w YAML; reconciler uzgadnia je z Camunda, odrzucając naruszenia rozdziału obowiązków (R7) i przestrzeni nazw (R10).

## 4. Plan realizacji

| Faza | Tygodnie (najwcześniej) | Kroki | Praca ludzi bez AI | Z AI | Oszczędność |
| --- | --- | --- | --- | --- | --- |
| 0 — Przygotowanie i PoC | 0,0–3,3 | 10 | 78,3 | 63,5 | 19% |
| 1 — Fundament | 2,0–8,2 | 10 | 76,5 | 48,3 | 37% |
| 2 — Dostęp, Camunda, audyt, formatki | 6,7–11,6 | 10 | 111,7 | 75,5 | 32% |
| 3 — Funkcje rdzenia | 8,5–15,3 | 10 | 95,5 | 61,4 | 36% |
| 4 — Frontend funkcjonalny | 8,2–16,0 | 10 | 99,2 | 56,1 | 43% |
| 5 — Integracja i hardening | 16,0–22,3 | 6 | 61,0 | 50,8 | 17% |
| 6 — Pilotaż | 22,3–27,6 | 1 | 20,8 | 20,8 | 0% |

| Bramka | Tydzień | Warunek | Kto decyduje |
| --- | --- | --- | --- |
| G0 | 3,3 | ADR-003, ADR-004, ADR-007 i ADR-010 przyjęte na podstawie PoC; scenariusze zatwierdzone przez PO | Architekt, Product Owner |
| G1 | 7,0 | Kontrakty v1 i OpenAPI zamrożone; szkielet, baza i harness BDD zielone w CI; ADR-019 i ADR-020 przyjęte na podstawie PoC formatek, warstwa wizualna zatwierdzona przez projektanta UX | Architekt, Tech lead |
| G2 | 12,6 | Przejęcie i zakończenie zadania działają end-to-end na prawdziwej Camunda przez oficjalne SDK | Tech lead |
| G3 | 22,3 | Wszystkie scenariusze zielone; pentest, kompletność audytu i compliance zaakceptowane | Bezpieczeństwo, Compliance |

Liczby pochodzą z modelu wyceny (`plan/estimation-report.md`) i zmieniają się po kalibracji rzeczywistymi danymi. Część specyficzną profili planują zespoły projektów (`profiles/<id>/backlog.yaml`); pilotaż (S60) wymaga gotowości profilu `kredyty`.

## 5. Wytwarzanie

- Zespół platformy realizuje plan platformy (`plan/backlog.yaml`); zespoły profili — własne plany, zależne od kroków S27, S38 i S47.
- Rój agentów AI działa w OpenCode z modelem `glm-5.3-flash` uruchomionym wyłącznie w infrastrukturze banku: agenci platformy nie zapisują w profilach, agenci profilu zapisują tylko we własnym profilu.
- Interfejs powstaje z design systemu: tokeny z Figma w `design/tokens.json`, komponenty w `core/ui-kit`, agenci warstwy wizualnej `ux-designer`, `design-system-engineer` i `ui-reviewer`. Wytyczne dla osób zaczynających pracę nad UI: `04-wytyczne-ui.md`.
- Ludzie zatwierdzają bramki G0–G3 i scalają każdą zmianę; bramki deterministyczne (build, testy, testy architektury, strażnik zakresu) działają przed recenzją modelu.

## Plik: docs/artifacts/02-aktorzy.md

<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Aktorzy Process Hub

Kto korzysta z systemu, kto go wytwarza i z jakimi systemami współpracuje. Osoby w kolumnie „Kto” to świat testowy ze scenariuszy BDD (`specs/README.md`). Źródło: `actors.yaml`.

```mermaid
flowchart LR
  subgraph B["Użytkownicy biznesowi"]
    UB["Uczestnik · Inicjator · Menadżer procesu<br/>Administrator procesu · Audytor · Administrator platformy"]
    UP["Role projektowe z profili<br/>np. Analityk kredytowy, Underwriter, Analityk AML"]
  end
  subgraph W["Wytwarzanie"]
    TP["Zespół platformy"]
    TPR["Zespoły profili projektów"]
    AI["Rój agentów AI<br/>OpenCode + GLM 5.3 Flash"]
  end
  PH["Process Hub<br/>platforma + profile"]
  CAM[("Camunda 8.9")]
  IDP[("RHBK + AD")]
  DB[("MS SQL Server")]
  SYS["Systemy i usługi projektów"]
  UB --> PH
  UP --> PH
  TP -->|platforma, SDK| PH
  TPR -->|profiles/&lt;id&gt;| PH
  AI -.->|pakiety robocze, człowiek scala| PH
  PH --> CAM
  PH --> IDP
  PH --> DB
  PH --> SYS
```

## Użytkownicy biznesowi — role platformy

Role wspólne dla wszystkich projektów; jedna osoba może mieć wiele ról naraz, w zakresie wybranych procesów.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-01 | Uczestnik | anna, bartek, celina, ewa, darek | Realizuje zadania swoich grup | moje zadania, przejęcie z grupy, szkic, zakończenie, własne zastępstwa; widzi stan zadań grupy tylko do odczytu | R1, R2, R3 | FR-01…FR-06, FR-12 |
| AK-02 | Inicjator procesu | anna | Uruchamia sprawy i śledzi ich postęp | start procesu z formatką startową, moje procesy z bieżącym etapem | R3 | FR-07, FR-08 |
| AK-03 | Menadżer procesu | marta, piotr | Pilnuje przepływu pracy w swoich procesach | wszystkie zadania i sprawy w zakresie, dashboard, eskalacje, przekazywanie pojedyncze i masowe, zastępstwa zespołu, nazwy i SLA etapów; formatki swoich procesów: projektowanie, przegląd, publikacja, wycofanie | R1 (nie edytuje), R6, R8, R11 | FR-10, FR-11, FR-13…FR-17, FR-28…FR-31 |
| AK-04 | Administrator procesu | adam | Utrzymuje konfigurację procesu | mapowanie elementów BPMN na etapy, widok techniczny; formatki swoich procesów: projektowanie, zatwierdzanie, publikacja, wycofanie, import i eksport | R4, R8, R11 | FR-15, FR-17, FR-28…FR-31 |
| AK-05 | Audytor | olga | Kontroluje zgodność i rozliczalność | odczyt wszystkich procesów, zadań, formatek z ich historią i dziennika audytu; żadnych akcji zapisu | R5, R7 | FR-19, FR-20 |
| AK-06 | Administrator platformy | zenon | Utrzymuje uprawnienia i rejestr profili | autoryzacje jako kod, rejestr profili, ślad operacyjny do analizy problemów | R7, R10 | FR-21, FR-23 |

## Role projektowe — przykłady z profili

Każdy profil składa własne role z ról platformy i uprawnień projektu; działają tylko w procesach profilu.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-07 | Analityk kredytowy (kredyty) | anna, bartek | Ocenia wnioski kredytowe | rola Uczestnika i Inicjatora w procesie wniosek-kredytowy + przeliczenie scoringu, dane wnioskodawcy | R1, R9 | FR-24, FR-25, KRE-FR-01 |
| AK-08 | Underwriter (kredyty) | celina, ewa | Akceptuje wnioski i odstępstwa | rola Uczestnika + odstępstwo od limitu, dane wnioskodawcy | R1, R9 | FR-24, FR-25 |
| AK-09 | Kierownik zespołu kredytowego (kredyty) | marta | Zarządza portfelem wniosków | rola Menadżera procesu + raport portfela | R9 | FR-24, FR-27 |
| AK-10 | Analityk i kierownik AML (aml) | darek, piotr | Weryfikuje klientów i transakcje | ponowna weryfikacja sankcji, profil ryzyka, eksport sprawy dla nadzoru (usługa zespołu AML) | R1, R9 | FR-24, FR-25, AML-FR-01 |
| AK-17 | Wnioskodawca (flota) | tomasz | Dostaje samochód służbowy zgodny z polityką floty | rola Inicjatora w procesie rejestracja-samochodu; przegląda katalog samochodów w sekcji „Flota” i wybiera model w formatce wniosku | R3, R9 | FR-07, FR-27, FLO-FR-01, FLO-FR-03 |
| AK-18 | Opiniujący — komórki IT, HR, Prawny, Finanse, Ryzyko (flota) | igor, hanna, lena, filip, rafal | Wydaje opinię komórki o wniosku | rola Uczestnika w procesie opiniowanie-rejestracji; każda komórka widzi i przejmuje tylko swoje zadanie opinii | R1, R2, R3, R9 | FR-24, FLO-FR-04 |
| AK-19 | Administrator katalogu samochodów (flota) | karol | Prowadzi katalog samochodów dostępnych do zakupu | bez ról platformy; dodaje, zmienia, wycofuje i przywraca modele operacjami na danych profilu (profile-action); każda zmiana w dzienniku | R9, R10 | FR-25, FR-27, FLO-FR-02 |

## Zespoły i osoby wytwarzające oraz decydujące

Platformę i profile realizują różne zespoły; ludzie zatwierdzają bramki i scalają zmiany.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-11 | Zespół platformy | architekt, backend .NET, frontend Angular, QA | Buduje i utrzymuje część wspólną | moduły platformy, SDK rozszerzeń i jego zgodność, CI, integracja z Camunda | ADR-012, ADR-013 | plan/backlog.yaml |
| AK-12 | Zespół profilu projektu | PO projektu, programiści projektu | Realizuje część specyficzną projektu | manifest profilu, operacje, dane prj_<id>, sloty UI, workery i scenariusze profilu; własny plan i rytm wydań | R9, R10 | profiles/<id>/backlog.yaml |
| AK-13 | Product Owner platformy i analityk | — | Prowadzi wymagania i decyzje biznesowe | akceptacja scenariuszy, decyzje D-01…D-07, D-10, D-11, D-13, D-14, priorytety | — | G0 |
| AK-14 | Bezpieczeństwo i compliance | — | Chroni bank i klientów | zatwierdzenie bramki modelu w banku (S-2), przegląd danych restricted, pentest, retencja audytu | R7 | G3, S-2, S-5 |
| AK-15 | DevOps | — | Zapewnia środowiska i dostarczanie | Camunda 8.9 na Kubernetes, RHBK, MSSQL, bramka modelu GLM w banku, pipeline CI/CD | — | S06, S-3 |
| AK-16 | Sponsor projektu | — | Zatwierdza zakres, zespół i budżet | decyzje startowe S-1 i S-6, rytm wydań profili (D-10) | — | S-1, S-6 |
| AK-26 | Projektant UX | — | Zapewnia spójny wygląd i użyteczność całego systemu | biblioteka w Figma (tokeny, komponenty pól, wzorce), eksport do design/**, zatwierdzanie wzorców regresji wizualnej, testy z użytkownikami; nie decyduje o treści formatek | ADR-019 | S09, D-16, NFR-08, NFR-15 |

## Systemy i aktorzy techniczni

Systemy, z którymi Process Hub współpracuje w czasie działania i wytwarzania.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-20 | Camunda 8.9 | Zeebe, Operate, Tasklist, Identity | Orkiestruje procesy | jedyne źródło prawdy o stanie procesu i zadań; autoryzacje zasobów (L1); dostęp wyłącznie przez platformę | C1–C23 | ADR-003, ADR-004, ADR-018 |
| AK-21 | RHBK i Active Directory | — | Tożsamość i grupy | SSO jednego realmu, grupy AD jako podstawa ról platformy i projektowych | — | ADR-008 |
| AK-22 | MS SQL Server 2022+ | — | Dane platformy i profili | read model, audyt (Ledger), schematy modułów i prj_<id> profili z izolacją | — | ADR-005, ADR-014 |
| AK-23 | Systemy projektów | np. system scoringowy, rejestr kredytowy, listy sankcyjne | Dane i usługi projektów | wywoływane z operacji profili i workerów typów zadań <id>.* | R9 | profile.yaml: integrations |
| AK-24 | Usługi profili remote | np. usługa AML | Część specyficzna w osobnej usłudze | kontrakt profile-operations v1, wywołania z podpisanym kontekstem; własne wydania zespołu | R9 | ADR-012 |
| AK-25 | Rój agentów AI | OpenCode + GLM 5.3 Flash w infrastrukturze banku | Przyspiesza wytwarzanie pod nadzorem ludzi | kroki planu w pakietach roboczych; agenci platformy (w tym warstwy wizualnej: ux-designer, design-system-engineer, ui-reviewer) i agenci profili z rozdzielonym zakresem zapisu; człowiek scala | ADR-015 | AGENTS.md |

## Plik: docs/artifacts/03-zalozenia.md

<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Założenia Process Hub

Rejestr 38 założeń: 19 przyjętych, 10 do weryfikacji w PoC lub w trakcie prac, 9 czekających na decyzję. Każde ma źródło, punkt sprawdzenia i skutek, jeśli okaże się nieprawdą. Źródło: `assumptions.yaml`.

## Biznes

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-01 | Process Hub zastępuje natywny Tasklist; użytkownicy końcowi nie mają dostępu do webapp Tasklist ani Operate. | W-01, C16 | przyjęte | S60 | Użytkownicy mogliby obejść reguły widoczności i audyt (R10 w rejestrze ryzyk). |
| Z-02 | „Ta sama grupa uprawnień” to grupy kandydujące zadania i grupy inicjatora sprawy. | W-03, D-01 | decyzja otwarta | S05 / G0 | Zmiana reguły widoczności R3 i scenariuszy access/visibility. |
| Z-03 | Edytuje i kończy zadanie tylko osoba, która je przejęła; menadżer przekazuje zadania, ale ich nie edytuje. | W-04, R1 | przyjęte | S30 | — |
| Z-04 | Jedna osoba może mieć wiele ról naraz; uprawnienia sumują się w zakresach, a audyt zapisuje rolę uzasadniającą. | W-19 | przyjęte | S24 | — |
| Z-05 | Menadżer widzi etapy biznesowe zamiast BPMN; elementy na etapy mapuje administrator procesu. | W-26, D-03, ADR-006 | decyzja otwarta | warsztat przed S34 | Zmiana uprawnień StageMap.* i ekranu edytora mapy etapów. |
| Z-06 | Wynik biznesowy (sukces, odmowa, błąd) jest oznaczany na zdarzeniach końcowych BPMN. | W-25, ADR-011 | przyjęte | S17, S36 | Dashboard nie odróżni odmowy od błędu. |
| Z-31 | Biznes decyduje o polach formatki i ich układzie; wygląd jest wspólny dla całego systemu i nie da się go zmienić w pojedynczej formatce. | W-45, ADR-019 | przyjęte | S45, testy z użytkownikami | Prośby o stylowanie formatek oznaczają rozszerzenie design systemu, nie schematu (ryzyko R19). |
| Z-32 | Każdy proces ma formatki wyłącznie dla siebie; treść przenosi się między procesami tylko przez jawny eksport i import pliku. | W-46, R11, ADR-018 | przyjęte | S26, specs/forms/form-isolation.feature | — |
| Z-33 | Wycofanie wersji formatki wykonuje jedna uprawniona osoba z powodem; zadania w toku domyślnie zostają na wycofanej wersji. | W-44, D-13, D-14 | decyzja otwarta | S05 / przed S26 | Dodatkowa akceptacja wycofania albo inny domyślny tryb przepięcia zadań. |

## Architektura

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-07 | Modularny monolit .NET 10 w czterech rolach jednego obrazu wystarczy na skalę banku. | ADR-001 | przyjęte | S52 | Wydzielenie modułów do usług — kontrakty to umożliwiają. |
| Z-08 | Jeden tenant <default>; architektura gotowa na wielu bez zmian w kodzie domeny. | W-14, ADR-002 | przyjęte | scenariusze @multi-tenant | — |
| Z-09 | Tokeny trzyma BFF; przeglądarka ma tylko ciasteczko sesji. | ADR-008 | przyjęte | S18 | — |
| Z-36 | Własny renderer w Angularze odwzoruje zachowanie biblioteki form-js dla typów z katalogu pól. | ADR-019 | do weryfikacji | S07, S55 | Wariant zapasowy dla typów złożonych albo węższy katalog pól (ryzyko R16). |
| Z-38 | Licencja biblioteki form-js (bpmn.io) pozwala osadzić edytor w aplikacji banku przy widocznym znaku bpmn.io. | ADR-019 | do weryfikacji | S07 (przegląd prawny) | Bez zgody projektant formatek wymaga innego edytora. |

## Camunda

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-10 | Oficjalne SDK Camunda pokrywa potrzebne operacje (braki uzupełnia klient z OpenAPI wewnątrz ACL). | W-16, ADR-003 | do weryfikacji | S01 | Więcej kodu w module integracyjnym (ryzyko R01). |
| Z-11 | Autoryzacje zasobów Camunda zawężają dostęp per bpmnProcessId; token delegowany jest możliwy. | W-15, ADR-004 | do weryfikacji | S02 | Większy ciężar reguł L2 w aplikacji (ryzyko R02). |
| Z-12 | Task listener nadaje się do zastępstw w trybie fail-open. | W-23, ADR-007 | do weryfikacji | S03 | Zastępstwa realizowane przez projektor z opóźnieniem. |
| Z-13 | Read model zasilany wyszukiwaniem przyrostowym przez SDK mieści się w celu opóźnienia (propozycja P95 ≤ 5 s). | ADR-010, NFR-04 | do weryfikacji | S04 | Eksporter do Kafka (ryzyko R05). |
| Z-34 | Formatki w formacie Camunda Forms prowadzi aplikacja; zadania wskazują je referencją zewnętrzną, bez wdrażania formularzy do silnika. | W-43, C6, C22, ADR-018 | przyjęte | S29 | Wdrażanie do silnika wymagałoby szerszych uprawnień klienta platformy i drugiego cyklu życia. |
| Z-35 | Camunda 8.9 udostępnia ewaluację wyrażeń FEEL przez API klastra, wystarczającą do walidacji formatek na serwerze. | ADR-020 | do weryfikacji | S08 | Wariant zapasowy z ADR-020; do tego czasu walidacja bez wyrażeń (ryzyko R17). |

## Dane i bezpieczeństwo

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-14 | MS SQL Server 2022+ z RLS, tabelami Ledger i partycjonowaniem jest dostępny w banku. | ADR-005 | przyjęte | S06, S13 | Inny mechanizm niezmienności audytu. |
| Z-15 | Każde żądanie trafia do śladu operacyjnego; komendy i odczyty wrażliwe — do dziennika bezpieczeństwa, bez wartości PII. | W-08, W-18, NFR-02, NFR-09 | przyjęte | S25, S51 | — |

## Profile projektów

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-16 | Każdy proces ma dokładnie jeden profil-właściciela. | ADR-012 | przyjęte | validate_profiles.py | Procesy wspólne wielu projektów wymagają decyzji o właścicielu. |
| Z-17 | Punkty rozszerzeń SDK (operacje, wzbogacenia, źródła danych, zapytania, zdarzenia, sloty UI) pokrywają potrzeby projektów. | ADR-012, ADR-017, R13 | do weryfikacji | warsztat z zespołami przed S19; S38 (profil flota ujawnił brak operacji na danych profilu → RFC-FLO-03, ADR-017) | Kolejne RFC i wersje SDK. |
| Z-18 | Izolację danych profilu zapewni schemat i użytkownik bazy per profil z przełączaniem kontekstu w transakcji. | ADR-014 | do weryfikacji | S27 | Wariant zapasowy: osobne połączenie i login per profil (ryzyko R14). |
| Z-19 | Profile działają domyślnie in-process w pociągu wydań; model remote na wniosek zespołu. | D-08, D-10 | decyzja otwarta | przed S19 | Inny model wydań i koszt utrzymania po stronie zespołów. |
| Z-20 | Na start jedno repozytorium z CODEOWNERS dla platformy i profili. | D-09, ADR-013 | decyzja otwarta | przed S19 | Osobne repozytoria wymagają publikacji SDK i manifestów jako paczek. |
| Z-21 | Zespoły profili planują i wyceniają swoją część same; plan platformy obejmuje SDK, izolację, sloty UI i onboarding. | W-38 | przyjęte | S48 | — |

## Organizacja

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-22 | Zespół referencyjny 6,2 etatu (w tym 0,5 etatu projektanta UX) przy wykorzystaniu 75%. | plan/estimation-params.yaml | decyzja otwarta | S-1 | Inny kalendarz — przeliczenie modelu. |
| Z-23 | Dostępy (AD, RHBK, Kubernetes, MSSQL) i licencja Kendo UI są dostępne w pierwszych tygodniach. | S-3, S-4 | decyzja otwarta | S06, S16 | Około +5 tygodni w scenariuszu wolnych procedur (ryzyko R03). |
| Z-24 | Termin zewnętrznego pentestu jest zarezerwowany z wyprzedzeniem. | S-5 | decyzja otwarta | do tygodnia 12 | Przesunięcie G3 i pilotażu (ryzyko R06). |
| Z-37 | Projektant UX (0,5 etatu) prowadzi bibliotekę w Figma; do repozytorium trafiają eksporty, a agenci nie mają dostępu do Figma. | W-45, D-16, S-6, ADR-016 | decyzja otwarta | S09 | Bez projektanta wygląd zostaje na tokenach makiety; opóźnienie S16 i S49 (ryzyko R18). |

## AI i narzędzia

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-25 | Agentów uruchamia OpenCode z modelem glm-5.3-flash; poziomy ról to warianty rozumowania tego samego modelu. | ADR-015 | przyjęte | kwalifikacja E01–E08 | Zmiana modelu = ponowna kwalifikacja ról. |
| Z-26 | Wszystkie dane (kod, dokumentacja, dane testowe) przetwarza wyłącznie model GLM w infrastrukturze banku; zewnętrzne API są wykluczone. | W-40, ADR-016 | przyjęte | S06 (bramka), kwalifikacja E01–E08 | Bez bramki rój nie pracuje — prace prowadzą ludzie (ryzyko R15). |
| Z-30 | Narzędzia repozytorium działają bez Pythona — w wersji .NET (ph) z kodem źródłowym i bez zewnętrznych paczek. | W-41 | przyjęte | S00 (zgodność wyników z wersją Python) | Przy zablokowanym Pythonie i bez .NET zostaje praca ręczna. |
| Z-27 | Człowiek scala każdą zmianę i zatwierdza bramki; agenci pracują w osobnych worktree z zakresem zapisu. | AGENTS.md | przyjęte | S00 | — |

## Wycena

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-28 | Udział AI i koszt przeglądu per krok jak w plan/estimates.yaml; kalibracja po S10–S12. | plan/estimation.md | do weryfikacji | S10–S12 | Inne tygodnie i osobodni — model przelicza się automatycznie. |
| Z-29 | Dodatkowi ludzie nie skracają projektu; skraca go podział kroków ścieżki krytycznej. | scenariusze D i E | przyjęte | kalibracja | — |

## Plik: docs/artifacts/04-wytyczne-ui.md

# Wytyczne UI Process Hub — start dla nowej osoby

Wszystko, czego potrzebujesz, żeby zacząć pracę nad interfejsem Process Hub: czym jest system, dla kogo projektujemy, jakie zasady są nienaruszalne, skąd bierze się wygląd, jak zbudowany jest frontend, jak działają formatki i kto za co odpowiada. Dokument jest pisany ręcznie; wartości i listy pochodzą z plików źródłowych wskazanych przy każdej sekcji — przy rozbieżności rozstrzyga źródło. Wersja do przeglądania: `wytyczne-ui.html`.

## 1. System w pięciu zdaniach

1. Process Hub zastępuje natywny Tasklist Camunda 8.9 własnym interfejsem; Camunda pozostaje jedynym źródłem prawdy o stanie procesów i zadań.
2. Platforma decyduje, kto co widzi i co może zrobić, i zapisuje każdą akcję w dzienniku audytu.
3. Menadżer procesu nie ogląda BPMN — widzi etapy biznesowe (wstęgę etapów), dashboard, eskalacje i przekazuje zadania.
4. Formatki zadań projektuje biznes w formacie Camunda Forms; wygląd nadaje im design system wspólny dla całej aplikacji.
5. Projekty biznesowe (profile: kredyty, AML, flota) dokładają własne elementy w wyznaczonych miejscach interfejsu, w tym samym wyglądzie.

## 2. Dla kogo projektujesz

| Rola | Po co przychodzi | Główne ekrany |
| --- | --- | --- |
| Uczestnik | wykonać swoje zadania | Pulpit, Zadania, Zadanie z formatką, Start procesu, Moje procesy, Zastępstwa |
| Menadżer procesu | pilnować przepływu pracy | Panel procesu, Eskalacje, Sprawy, Przekazanie, Formatki, Mapa etapów (nazwy i SLA) |
| Administrator procesu | utrzymać konfigurację procesu | Mapa etapów (z diagramem), Formatki |
| Audytor | sprawdzić zgodność | wszystko tylko do odczytu, Dziennik audytu |
| Administrator platformy | utrzymać uprawnienia | Uprawnienia, ślad operacyjny |
| Role profili (np. flota) | praca w procesach projektu | sekcja profilu w nawigacji, strony `/p/<id>/…` |

Jedna osoba może mieć kilka ról naraz — nawigacja pokazuje sumę. Persony do testów i makiety: `specs/README.md`; pełna lista aktorów: `02-aktorzy.md`.

## 3. Dziesięć zasad nienaruszalnych

1. **UI nie liczy uprawnień.** Każdy zasób z API przychodzi z listą `allowedActions`; przycisk istnieje tylko wtedy, gdy akcja jest na liście.
2. **Akcji, której nie wolno wykonać, nie ma** — zamiast wyszarzonego przycisku jest jedno zdanie, dlaczego („Edytować może tylko osoba, która przejęła zadanie: …”).
3. **Kolor nigdy nie jest jedynym nośnikiem informacji.** Status ma kształt i słowo: krytyczny — kwadrat, ostrzeżenie — trójkąt, poprawny — koło.
4. **Jedna nazwa akcji w całym przepływie:** „Opublikuj” na przycisku → „Opublikować wersję 4?” w potwierdzeniu → „Opublikowano wersję 4” w komunikacie.
5. **Decyzje nieodwracalne** (zakończenie zadania, przekazanie, publikacja, wycofanie) przechodzą przez okno potwierdzenia z podsumowaniem skutku.
6. **Formularz nie gubi danych.** Błędy: podsumowanie na górze z odnośnikami do pól i komunikat przy polu.
7. **Puste stany mówią, co zrobić dalej;** odmowa dostępu mówi, że próba trafiła do dziennika.
8. **Wartości wizualne wyłącznie z tokenów** (`design/tokens.json`); widoki składasz z komponentów `core/ui-kit`, nie z kontrolek Kendo wprost.
9. **Menadżer nie widzi technikaliów BPMN** — identyfikatory i diagram tylko dla uprawnienia `Bpmn.ViewTechnical`.
10. **Teksty po polsku, w plikach i18n;** kod i identyfikatory po angielsku.

## 4. Kierunek wizualny i tokeny

Biel i czerwień jak barwy Polski, użyte oszczędnie — to narzędzie pracy na cały dzień. Biały pasek aplikacji kończy się 4-pikselowym pasem flagowej czerwieni; jedynym mocnym elementem jest wstęga etapów; liczby czytamy jak pasek księgowy; jeden krój — Lato, hierarchia przez grubość (400/700/900). Źródło: `design/README.md`, `design/tokens.json`.

| Token | Jasny | Ciemny | Użycie |
| --- | --- | --- | --- |
| `flag-red` | #DC143C | #DC143C | pas pod paskiem aplikacji, akcenty nietekstowe — nigdy tekst |
| `action` / `action-hover` | #A10F2B / #86081F | #FF6B7E / #FF8A99 | przyciski główne, odnośniki, bieżący etap (8,02:1 na bieli) |
| `action-ink` | #FFFFFF | #16181B | tekst na `action` |
| `ink` / `ink-2` | #1F2328 / #4A5059 | #ECEDEF / #B5BAC1 | tekst / tekst pomocniczy |
| `bg` / `surface` / `surface-2` | #F4F5F7 / #FFFFFF / #F9FAFB | #16181B / #1F2226 / #24282D | tło strony / panele / tło wtórne |
| `line` / `line-strong` | #D9DCE1 / #AEB3BB | #353A41 / #4E555E | linie / obramowania kontrolek |
| `ok`, `warn`, `crit`, `info` (+ `-bg`) | ciemne odcienie na jasnym tle | jasne odcienie na ciemnym tle | statusy, każdy ≥ 6,5:1 |

| Skala | Wartości |
| --- | --- |
| Typografia (px) | h1 28 · h2 19 · tekst 16 · mały 14 · liczba kluczowa 34; interlinia tekstu 1,5 |
| Odstępy (px) | 4 · 8 · 12 · 16 · 24 · 32 · 48 |
| Promienie (px) | kontrolka 6 · panel 8 · pigułka 999 |
| Kontrolka (px) | wysokość 44 · obramowanie 1 · wypełnienie 8 × 10 · fokus 3 z odstępem 2 |
| Progi szerokości (px) | telefon 600 · tablet 860 · pulpit 1100; układ bez przewijania w poziomie od 390 |

**Skąd się bierze wygląd.** Projektant UX prowadzi bibliotekę w Figma (zmienne, komponenty, wzorce). Zmiana wyglądu to eksport do pull requestu w `design/**`; kod czyta wyłącznie pliki z repozytorium. Brakuje tokenu? Nie wpisujesz wartości „na chwilę” — zgłaszasz to projektantowi UX (agent `ux-designer` przenosi eksport). Wartości są do potwierdzenia z księgą znaku banku (krok S09).

## 5. Architektura informacji

Nawigacja jest liczona z uprawnień, nie z nazwy roli.

| Sekcja | Pozycje | Kto widzi |
| --- | --- | --- |
| Praca | Pulpit, Zadania, Start procesu, Moje procesy, Zastępstwa | uczestnik, inicjator |
| Nadzór | Panel procesu, Eskalacje, Sprawy, Przekazanie masowe | menadżer procesu (audytor bez przekazywania) |
| Konfiguracja procesu | Mapa etapów, Formatki | menadżer i administrator procesu |
| Kontrola | Dziennik audytu, Uprawnienia | audytor, administrator platformy |
| Sekcja profilu (np. Flota) | strony profilu `/p/<id>/…` | wyłącznie role profilu |

Każdy widok ma okruszki, nagłówek z fokusem po zmianie widoku i odnośnik „Przejdź do treści”. Ekrany, trasy i wymagania: tabela w `design/README.md`; zachowanie zobaczysz w makiecie `design/mockups/index.html` (przełącznik „Podgląd jako”).

## 6. Stos i układ frontendu

Angular, Nx, Kendo UI for Angular (przez `core/ui-kit`), Signals z `OnPush`, RxJS na brzegu, SignalR dla aktualizacji, klient API generowany z OpenAPI. Źródło: `docs/architecture/11-frontend.md`.

| Biblioteka (Nx) | Zawartość |
| --- | --- |
| `core/theming` | tokeny → zmienne CSS i motyw Kendo; motywy jasny, ciemny, systemowy |
| `core/ui-kit` | komponenty aplikacji (opakowania Kendo), w tym komponenty pól formatek `ph-*` i wstęga etapów |
| `core/auth`, `core/access`, `core/i18n` | sesja, `allowedActions`, teksty |
| `apps/ui-catalog` | każdy komponent w każdym stanie — do przeglądu i regresji wizualnej |
| `task-workspace` | listy zadań, szczegóły zadania z formatką |
| `process-lifecycle` | start procesu, moje procesy |
| `process-insight` | dashboard, eskalacje, sprawy |
| `reassignment` | przekazania, zastępstwa |
| `stage-map-editor` | mapa etapów; jedyne miejsce bpmn-js |
| `form-designer` | projektant formatek; jedyne miejsce edytora form-js |
| `form-runtime` | renderer formatek: interpretacja schematu + rejestr typ → komponent |
| `audit-viewer` | dziennik i ślad |
| `platform/extension-sdk`, `profiles/<id>/frontend` | sloty i biblioteki profili projektów |

Granice Nx: widok nie importuje Kendo wprost; biblioteki profili zależą tylko od SDK rozszerzeń; `form-runtime` nie zawiera stylów.

## 7. Komponenty — wzorce wspólne

| Wzorzec | Zasada |
| --- | --- |
| Przycisk | 44 px, tekst 15 px/700; główny na `action`, zwykły z obramowaniem, cichy bez tła; najwyżej jeden główny w grupie |
| Pole | etykieta nad polem (700), „(wymagane)” słowem, podpowiedź 14 px pod polem, błąd 14 px/700 ze znacznikiem |
| Wstęga etapów | etapy jako segmenty biało-czerwonej wstęgi; bieżący w pełnej czerwieni akcji; eskalacja i blokada słowem |
| Pasek księgowy | liczby w jednej linii oddzielone kreskami zamiast jednakowych kafelków |
| Listy | tabela na szerokim ekranie, karty na telefonie; stan widoku zapisywany |
| Znacznik stanu | kształt + słowo + kolor statusu |
| Okno potwierdzenia | tytuł = nazwa akcji, podsumowanie skutku, przycisk o tej samej nazwie |
| Komunikat | region `aria-live`; mówi, co się stało, tymi samymi słowami co akcja |
| Wykres | zawsze z tabelą danych jako alternatywą |

## 8. Formatki — jak to działa

Źródła: `docs/architecture/14-form-management.md` (działanie), `design/forms/README.md` (wygląd), `design/forms/field-catalog.yaml` (kontrakt).

**Trzy warstwy.** Struktura (schemat Camunda Forms: pola, typy, teksty, walidacje, warunki, wiersze) należy do biznesu. Materializacja (typ pola → komponent) należy do design systemu. Wygląd (tokeny) należy do projektanta UX. Schemat nie ma jak nieść kolorów ani krojów; renderer nie ma własnych stylów.

**Cykl życia wersji:** Szkic → W przeglądzie → Zatwierdzona → Opublikowana → Zastąpiona albo Wycofana. Zatwierdza inna osoba niż autor ostatniej zmiany (R8). Opublikowana wersja jest niezmienna; zadanie renderuje wersję przypiętą przy jego utworzeniu. Wycofanie wymaga powodu, wersji zastępczej (albo świadomego jej braku) i decyzji o zadaniach w toku.

**Separacja.** Formatka należy do jednego procesu (R11): ekran „Formatki” działa zawsze w kontekście wybranego procesu, a przełącznik pokazuje tylko procesy z zakresu roli.

**Katalog pól** (typy Camunda Forms → komponenty):

| Status | Typy |
| --- | --- |
| Wspierane (14) | `textfield`, `textarea`, `number`, `datetime`, `checkbox`, `checklist`, `radio`, `select`, `taglist`, `group`, `dynamiclist`, `table`, `expression`, `separator` |
| Z ograniczeniami (3) | `text` (Markdown bez HTML), `spacer` (skala odstępów), `image` (zasób osadzony, tekst alternatywny) |
| Planowane (2) | `filepicker`, `documentPreview` — po decyzji o magazynie dokumentów |
| Zablokowane (3) | `html`, `iframe`, `button` — akcje renderuje powłoka z `allowedActions` |

**Układ.** Siatka 16 kolumn ze schematu, odstęp 16 px, szerokość formatki do 880 px, jedna kolumna poniżej 600 px.

**Tryby:** edycja (assignee), odczyt (pozostali, z jednym zdaniem wyjaśnienia), podgląd (projektant), niedostępna (brak wersji obowiązującej).

**Projektant.** Zakładka „Projekt” osadza edytor form-js — ten sam co w Camunda Modelerze — z paletą ograniczoną do katalogu pól. Kanwa wygląda jak w Modelerze; o wyglądzie u wykonawcy rozstrzyga zakładka „Podgląd jak u wykonawcy”, oparta o renderer platformy. Znak bpmn.io musi pozostać widoczny (licencja).

**Czego nie robimy:** żadnych stylów per formatka, żadnego HTML w treści, żadnych przycisków w formatce, żadnych wartości wyglądu w schemacie.

## 9. Dostępność — lista kontrolna (WCAG 2.2 AA, wybrane cele AAA)

- Kontrast: tekst podstawowy, pomocniczy i akcje ≥ 7:1 (cel AAA), tekst statusów ≥ 6,5:1, żaden tekst poniżej 4,5:1 (wymóg AA), elementy nietekstowe ≥ 3:1; pomiary w `design/tokens.json`.
- Widoczny fokus 3 px; kolejność fokusu = kolejność czytania; wszystko działa z klawiatury.
- Cele dotykowe ≥ 44 px.
- Etykieta dla każdej kontrolki; podpowiedź i błąd przez `aria-describedby`; `aria-invalid` przy błędzie; grupy opcji w `fieldset` z `legend`.
- Zmiany stanu w regionie `aria-live`; fokus na nagłówku po zmianie widoku; okruszki na każdym widoku.
- Wykres ma tabelę danych; kolor nie jest jedynym nośnikiem.
- `prefers-reduced-motion`; motyw jasny, ciemny i systemowy; powiększenie 200% bez utraty treści; brak przewijania w poziomie od 390 px.

## 10. Jak pracujemy

| Etap | Kto | Wynik |
| --- | --- | --- |
| Projekt w Figma | projektant UX | zmienne, komponenty ze stanami, wzorce |
| Eksport do repozytorium | agent `ux-designer` + projektant UX | pull request w `design/**` (tokeny, specyfikacje, katalog pól, makieta) |
| Komponenty | agent `design-system-engineer` | `core/theming`, `core/ui-kit`, strona w katalogu komponentów, zrzuty wzorcowe |
| Widoki i logika | agent `frontend-developer` | biblioteki funkcjonalne na `ui-kit` i `allowedActions` |
| Przegląd | agent `ui-reviewer` + człowiek | zgodność z tokenami, katalogiem pól, wzorcami i WCAG |
| Scalenie | człowiek | każda zmiana; wzorce regresji wizualnej tylko za zgodą projektanta UX |

Praca agenta zaczyna się od pakietu kroku (`plan/packets/<krok>.md`) i kończy bramkami Definition of Done. Dla UI: `npx nx affected -t lint test build`, test axe-core widoku lub komponentu, zrzuty regresji wizualnej (motyw jasny i ciemny; 390, 768, 1280 px), scenariusz Playwright dla widoku. Kroki dotyczące UI: S09 (warstwa wizualna), S16 (shell, motyw, ui-kit), S49 (komponenty pól), S40–S47 (widoki), S53 (dostępność), S55 (zgodność i spójność formatek) — `plan/execution-plan.md`.

## 11. Kto za co odpowiada

| Obszar | Decyduje | Wykonuje | Sprawdza |
| --- | --- | --- | --- |
| Tokeny, wygląd komponentów, wzorce | projektant UX | `ux-designer` (eksport), `design-system-engineer` (kod) | `ui-reviewer`, projektant UX (zrzuty) |
| Katalog pól formatek | architekt platformy z projektantem UX | `ux-designer`, `design-system-engineer` | testy parytetu |
| Treść i układ formatki | menadżer, administrator procesu | oni sami, w projektancie | druga osoba (R8) |
| Zachowanie widoków, `allowedActions` | architekt (kontrakty API) | `frontend-developer` | `reviewer`, testy |
| Dostępność | — (wymóg NFR-08) | wszyscy | axe w CI, przegląd z czytnikiem ekranu (S53) |
| Elementy profili w UI | zespół profilu | agenci profilu | granice Nx, `ui-reviewer` |

## 12. Pierwszy dzień — co zrobić

1. Otwórz makietę `design/mockups/index.html` i przejdź scenariusze 1, 3, 5, 6 i 13 z `design/README.md` (uczestnik, menadżer, formatki, wycofanie wersji).
2. Przeczytaj `design/README.md`, potem `design/forms/README.md`.
3. Przejrzyj `design/tokens.json` i `design/forms/field-catalog.yaml` — to dwa pliki, z których czyta kod.
4. Przeczytaj `docs/architecture/11-frontend.md` i sekcje 1–3 oraz 11–13 w `docs/architecture/14-form-management.md`.
5. Zajrzyj do `AGENTS.md` (zasady repozytorium) i skilli `.opencode/skills/design-system` oraz `.opencode/skills/camunda-forms`.
6. Sprawdź swój krok w `plan/execution-plan.md` i otwarte decyzje D-12…D-16.

## 13. Słownik

| Pojęcie | Znaczenie |
| --- | --- |
| Formatka | formularz zadania albo startu procesu w formacie Camunda Forms; należy do jednego procesu |
| Katalog pól | lista typów pól ze statusem i komponentem design systemu |
| Materializacja | zamiana schematu formatki na interfejs z komponentów |
| Token | nazwana wartość wizualna (kolor, odstęp, wymiar) w `design/tokens.json` |
| Wstęga etapów | komponent pokazujący etapy biznesowe procesu i bieżący etap |
| `allowedActions` | lista akcji, które bieżąca osoba może wykonać na zasobie — jedyne źródło przycisków |
| Slot | miejsce w interfejsie na komponent profilu projektu |
| Wersja obowiązująca | opublikowana wersja formatki przypinana nowym zadaniom |
| Przypięcie | wersja formatki zapisana przy zadaniu w chwili jego utworzenia |

## 14. Otwarte sprawy, które dotyczą UI

| Sprawa | Gdzie |
| --- | --- |
| Potwierdzenie kolorów z księgą znaku banku i założenie biblioteki w Figma | S09, D-16 |
| Wariant renderera formatek (własny na design systemie — rekomendacja) | ADR-019, PoC S07 |
| Załączniki w formatkach | D-15 |
| Testy z użytkownikami na makiecie (po 5 osób na rolę) | `design/README.md`, „Jak dalej projektować” |

## Plik: docs/artifacts/05-agenci.md

# Agenci AI w Process Hub — konfiguracja, zależności i harness

Dokument dla ludzi: tech leada, architekta, zespołów profili i bezpieczeństwa. Wyjaśnia, kim są agenci, co każdy z nich może, jak przebiega krok planu i co pilnuje, żeby agent nie wyszedł poza swoje zadanie. Źródłem prawdy pozostają pliki konfiguracji — każda sekcja wskazuje, gdzie je znaleźć.

## 1. W skrócie

- Pracę wykonuje **27 agentów** w OpenCode: 15 ról platformy i 12 agentów zespołów profili (`kredyty-…`, `flota-…`, `aml-…`). Wszyscy używają jednego modelu, `glm-5.3-flash`, uruchomionego w infrastrukturze banku (ADR-016).
- Agent dostaje **jeden krok planu** w postaci pakietu roboczego: cel, oczekiwany wynik, pliki do przeczytania, zakres zapisu, bramki. Pracuje w osobnym katalogu (`git worktree`) na własnej gałęzi.
- **Harness** — czyli wszystko dookoła modelu — decyduje, co agentowi wolno: które pliki zmieni, jakie komendy uruchomi, czego nie przeczyta. Te ograniczenia egzekwuje kod, nie polecenie w prompcie.
- O jakości decydują **bramki deterministyczne** (build, testy, zakres zapisu), potem **recenzja** innego agenta, na końcu **człowiek**: tylko człowiek scala, wypycha, zatwierdza bramki G0–G3 i zmienia plan.

## 2. Z czego składa się konfiguracja

```mermaid
flowchart LR
  subgraph Źródła["Źródła — edytuje człowiek"]
    REG["agents/registry.yaml<br/>role, narzędzia, zapis, zestaw komend"]
    PR["agents/prompts/*.md<br/>instrukcje ról"]
    POL["agents/runtime-policy.yaml<br/>komendy, zakazy, odczyt"]
    MOD["config/models.yaml<br/>model, warianty, klasy danych"]
    PROF["profiles/*/profile.yaml<br/>agenci zespołu profilu"]
    SCH["agents/schemas/*.json<br/>format wyniku roli"]
  end
  GEN["tools/agents/render_agents.py<br/>(albo: ph agents render)"]
  subgraph Wynik["Wynik — generowany, nie edytuj"]
    AG[".opencode/agent/*.md"]
    CFG["opencode.json"]
    AMD["tabela ról w AGENTS.md"]
  end
  subgraph Ręczne["Pisane ręcznie"]
    PLG[".opencode/plugin/write-scope.js<br/>strażnik zapisu"]
    CMD[".opencode/command/<br/>/status /krok /profil /bramki"]
    SK[".opencode/skills/<br/>6 skilli"]
  end
  REG --> GEN
  PR --> GEN
  POL --> GEN
  MOD --> GEN
  PROF --> GEN
  GEN --> AG
  GEN --> CFG
  GEN --> AMD
  AG --> OC["OpenCode"]
  CFG --> OC
  PLG --> OC
  CMD --> OC
  SK --> OC
  PLG --> GUARD["tools/guard/enforce_write_scope.py"]
```

| Chcę zmienić… | Edytuję | Potem |
| --- | --- | --- |
| co rola robi i jak pracuje | `agents/prompts/<rola>.md` | `render_agents.py`, ponowna kwalifikacja roli (`evals/agents/`) |
| narzędzia, ścieżki zapisu albo zestaw komend roli | `agents/registry.yaml` (`tools`, `writes`, `commands`) | `render_agents.py` |
| dozwolone i zakazane komendy, zakazy odczytu | `agents/runtime-policy.yaml` | `render_agents.py`; przegląd bezpieczeństwa |
| model, wariant rozumowania, limity kontekstu | `config/models.yaml` | `render_agents.py`, kwalifikacja |
| agentów zespołu profilu | `profiles/<id>/profile.yaml` (`dev.agents`, `dev.dataClass`) | `render_agents.py`; przegląd architekta |
| co krok ma zrobić i gdzie może pisać | `plan/backlog.yaml` | `validate_plan.py --check` |

Bramka CI `render_agents.py --check` nie przepuści zmiany, po której pliki wygenerowane różnią się od źródeł.

## 3. Role

„Zapis” to granica roli; w konkretnym kroku agent dostaje jeszcze węższy zakres z pola `writes` kroku. „Wariant” to tryb rozumowania modelu: `high` — z trybem myślenia, `low` — bez.

| Rola | Do czego służy | Poziom · wariant | Zapis | Komendy | Wynik |
| --- | --- | --- | --- | --- | --- |
| `orchestrator` | prowadzi plan: wybiera kroki, przygotowuje pakiety, uruchamia wykonawców, bramki i recenzje | T1 · high | tylko `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | skrypty kroków, `opencode run --dir ../wt-*`, odczyt git | przekazanie |
| `architect` | kontrakty modułów, OpenAPI, ADR, rozstrzyganie RFC | T1 · high | platforma | domyślne | przekazanie |
| `module-implementer` | moduł backendu .NET (DDD, heksagonalnie) | T2 · high | platforma | domyślne | przekazanie |
| `camunda-integrator` | PoC, moduł `CamundaIntegration`, bpmnlint, modele BPMN | T2 · high | platforma | domyślne | przekazanie |
| `data-engineer` | schematy MSSQL, RLS, Ledger, wydajność | T2 · high | platforma | domyślne | przekazanie |
| `frontend-developer` | biblioteki Angular, renderer i projektant formatek | T2 · high | platforma | domyślne | przekazanie |
| `design-system-engineer` | `core/theming`, `core/ui-kit`, komponenty pól | T2 · high | platforma | domyślne | przekazanie |
| `bdd-tester` | kroki Reqnroll, drivery, testy integracyjne i E2E | T2 · high | platforma | domyślne | przekazanie |
| `bdd-analyst` | scenariusze Gherkin i pytania do biznesu | T2 · high | tylko `specs/**` i wnioski RFC | brak | przekazanie |
| `ux-designer` | przenosi eksporty z Figma do `design/**` | T1 · high | tylko `design/**`, `poc/forms-ui/**` i wnioski RFC | domyślne | przekazanie |
| `docs-writer` | przewodniki i changelog po scaleniu kroków | T3 · low | tylko `docs/guides/**`, `CHANGELOG.md` i wnioski RFC | brak | przekazanie |
| `reviewer` | recenzja diffu kroku | T1 · high | brak | tylko `git diff`, `git status`, `git log` | werdykt + ustalenia |
| `ui-reviewer` | recenzja warstwy wizualnej i dostępności | T1 · high | brak | tylko odczyt git | werdykt + ustalenia |
| `security-reviewer` | szuka obejść autoryzacji, izolacji i audytu | T0 · high | brak | tylko odczyt git | `approve` / `block` |
| `ci-triage` | streszcza czerwoną bramkę dla wykonawcy | T3 · low | brak | brak | raport triage |

**Agenci profili** (`<profil>-<rola>`, np. `kredyty-module-implementer`) to te same role z dopisanym kontekstem profilu i zapisem ograniczonym do `profiles/<id>/**` oraz wniosków `docs/rfc/RFC-*.md`. Klasa danych agenta profilu to wyższa z klas roli i profilu — profil `aml` ma `restricted`, więc jego kroki zawsze przechodzą recenzję bezpieczeństwa.

Formaty wyników (`agents/schemas/`): przekazanie kroku (`handoff`), recenzja (`review`), recenzja bezpieczeństwa (`security-review`), triage. Ostatnia wiadomość agenta to wyłącznie JSON w formacie swojej roli; sprawdza go `tools/agents/validate_output.py`.

## 4. Przebieg kroku

```mermaid
sequenceDiagram
  autonumber
  participant H as Człowiek
  participant O as Orkiestrator
  participant S as Skrypty (bez modelu)
  participant W as Wykonawca (sesja w worktree)
  participant R as Recenzenci
  H->>O: /krok S30
  O->>S: prepare_step.py S30
  S-->>O: worktree ../wt-S30, .agent-scope, pakiet
  O->>W: opencode run --dir ../wt-S30 --agent module-implementer
  W-->>O: commit na gałęzi step/S30 + przekazanie JSON
  O->>S: validate_output.py, run_dod.py S30
  alt bramka czerwona
    S-->>O: S30.gates.json
    O->>W: skrót od ci-triage, kolejna próba (maks. 2)
  else bramki zielone
    O->>R: reviewer (+ security-reviewer, ui-reviewer)
    R-->>O: werdykt
  end
  O-->>H: podsumowanie, plan/progress/S30.json
  H->>H: PR, CI, scalenie, plan_status.py --merged S30
```

1. **Gotowość.** Krok może ruszyć, gdy wszystkie kroki z `depends_on` są scalone, a bramka `gate_before` zatwierdzona. Sprawdza to `plan_status.py` i ponownie `prepare_step.py`.
2. **Przygotowanie** (`prepare_step.py`, bez modelu): osobny worktree `../wt-<krok>` na gałęzi `step/<krok>`, plik `.agent-scope` z zakresem zapisu, pakiet roboczy `plan/packets/<krok>.md`.
3. **Wykonanie.** Wykonawca działa jako osobna sesja OpenCode uruchomiona **w worktree kroku**. To ważne: strażnik zapisu czyta `.agent-scope` z katalogu sesji. Krok z parą `bdd-tester` zaczyna Tester (testy mają być czerwone), potem implementer.
4. **Bramki** (`run_dod.py`, bez modelu): komendy z pola `dod` po kolei; pierwsza zawsze sprawdza zakres zapisu. Wynik w `plan/progress/<krok>.gates.json`.
5. **Naprawa.** Czerwona bramka → `ci-triage` streszcza log → wykonawca poprawia. Dwie próby; potem jedna sesja od zera z diagnozą recenzenta; potem człowiek.
6. **Recenzja.** `reviewer` zawsze; `security-reviewer`, gdy diff dotyka ścieżek `security_sensitive`, krok ma taką parę albo profil ma dane `restricted`; `ui-reviewer` dla `frontend/**` i `design/**`.
7. **Człowiek.** PR, CI, przegląd właścicieli kodu (CODEOWNERS), scalenie, oznaczenie `--merged`, kryteria z pola `acceptance`.

Krok zespołu profilu przebiega tak samo (`/profil kredyty KRE-02`), na planie `profiles/<id>/backlog.yaml`, gałęzi `profile/<id>/<krok>` i z postępem w `profiles/<id>/progress/`.

## 5. Skąd agent wie, co robić — pakiet roboczy

Pakiet powstaje z jednego wpisu w `plan/backlog.yaml`. Agent czyta tylko pakiet i pliki w nim wskazane — mniej tokenów, mniej pomyłek.

| Sekcja pakietu | Pole w backlogu | Po co |
| --- | --- | --- |
| Cel | `title` | jedno zdanie, co robimy |
| Wynik | `outcome` | pliki, moduły i dowody, po których poznać, że krok jest zrobiony |
| Wskazówki startowe | `notes` | granice z sąsiednimi krokami, decyzje biznesowe, pułapki |
| Czytaj | `reads` | pliki do przeczytania w całości — pilnowany budżet kontekstu |
| Sięgaj punktowo | `refs` | duże pliki (np. makieta, 145 kB), w których szuka się fragmentu |
| Wejście od poprzedników | `depends_on` | przekazania kroków, od których zależymy (pytania otwarte, zmienione pliki) |
| Wolno zapisywać | `writes` | zakres zapisu → `.agent-scope`; wniosek RFC wolno złożyć zawsze |
| Para | `pair`, `pair_task` | kto współpracuje i co robi |
| Scenariusze | `specs` | pliki `.feature` i tagi do zaliczenia |
| Definition of Done | `dod` | komendy bramek |
| Kryteria akceptacji człowieka | `acceptance` | to, czego komenda nie sprawdzi (zatwierdzenie PO, projektanta UX, bezpieczeństwa) |

Spójność planu z repozytorium sprawdza `python3 tools/plan/validate_plan.py`: nieznane zależności i cykle, role bez prawa zapisu, pliki z `reads`, które nie istnieją i których nie tworzy żaden poprzednik, scenariusze i tagi, bramkę zakresu w `dod`, budżet kontekstu oraz kroki, które mogą być gotowe jednocześnie, a piszą w tym samym miejscu.

## 6. Zabezpieczenia — warstwy i ich granice

Żadna warstwa nie jest szczelna sama. Razem działają tak, że błąd agenta kończy się najwyżej odrzuconą gałęzią.

| # | Warstwa | Co zatrzymuje | Gdzie skonfigurowana | Czego nie zatrzymuje |
| --- | --- | --- | --- | --- |
| 1 | Uprawnienia `edit` agenta | zapis poza granicą roli (profil, recenzent, orkiestrator) | `.opencode/agent/*.md` z `agents/registry.yaml` | zapisu wykonanego komendą powłoki |
| 2 | Strażnik zapisu (plugin) | każdy `write`/`edit`/`patch` poza `.agent-scope`; ścieżki chronione (specyfikacje, kontrakty, ADR, uprawnienia, SDK, manifesty profili, `backlog.yaml`, `AGENTS.md`); cudzy profil | `.opencode/plugin/write-scope.js` → `tools/guard/enforce_write_scope.py` | sesji bez `.agent-scope` (traktowana jak sesja człowieka); zapisu komendą |
| 3 | Uprawnienia komend | sieć (`curl`, `wget`, `ssh`), `git push`, `git merge`, `--force`, `--merged`, `--approve-gate`, `--amend`, przekierowanie poza worktree, odczyt zmiennych środowiska | `agents/runtime-policy.yaml` → `opencode.json` i pliki agentów | wszystkiego — to dopasowanie wzorców tekstu, a `dotnet test` z natury uruchamia kod napisany przez agenta |
| 4 | Zakazy odczytu | `.env`, `secrets/**`, klucze i certyfikaty | `agents/runtime-policy.yaml` (`read_guard`) | odczytu przez dozwoloną komendę |
| 5 | Bramka zakresu w DoD | wszystko, co zmieniło się w worktree poza `writes` — także zmiany niezatwierdzone i powstałe z komendy | pole `dod` kroku: `enforce_write_scope.py --verify-diff main` | zmian poza repozytorium |
| 6 | Recenzja agentów | błędy logiki, naruszenia zasad, obejścia bezpieczeństwa | prompty recenzentów, `security_sensitive` w backlogu | tego, czego recenzent nie zauważy |
| 7 | Człowiek i CI | scalenie bez przeglądu; zmiana chronionych ścieżek bez właściciela | ochrona `main`, `CODEOWNERS`, potok CI | — |

Stałe ustawienia: brak dostępu do internetu (`webfetch`, `websearch` wyłączone), `share: disabled` (rozmowy nie trafiają do publicznych linków), model wyłącznie w banku.

Gdy strażnik nie może się uruchomić (brak Pythona i narzędzia `ph`), zapis jest blokowany — zachowanie celowe.

### Zestawy komend

| Zestaw | Kto | Dozwolone bez pytania | Reszta |
| --- | --- | --- | --- |
| domyślny | role wykonawcze | `dotnet build/test/format/new/sln`, `npx nx`, `npx bpmnlint`, `npx gherkin-lint`, `npx @redocly/cli lint`, `npm test`, `git diff/status/log/add/commit`, `python3 tools/…`, `ph …` | pytanie do człowieka |
| `read-only` | recenzenci | `git diff`, `git status`, `git log` | zakaz |
| `orchestrator` | orkiestrator | skrypty `tools/agents/`, `validate_plan.py`, `ph step …`, odczyt git, `opencode run --dir ../wt-*` | pytanie do człowieka |
| brak | `ci-triage`, `bdd-analyst`, `docs-writer` | — | zakaz |

Zakazy wspólne obowiązują w każdym zestawie i wygrywają z listą dozwolonych.

## 7. Model, poziomy i eskalacja

| Poziom | Role | Wariant | Znaczenie |
| --- | --- | --- | --- |
| T0 | `security-reviewer` | high | recenzja bezpieczeństwa, dane `restricted` |
| T1 | orkiestrator, architekt, recenzenci, `ux-designer` | high | planowanie, decyzje, recenzja |
| T2 | role wykonawcze | high | implementacja |
| T3 | `ci-triage`, `docs-writer` | low | streszczenia, dokumentacja |

Model jest jeden, więc poziom wybiera tylko wariant rozumowania. Stąd ważna konsekwencja: **dla ról T0–T2 nie ma „mocniejszego modelu”, na który można eskalować**. Po dwóch nieudanych próbach orkiestrator uruchamia jedną sesję od zera — z diagnozą recenzenta zamiast historii prób — a potem oddaje krok człowiekowi. Prawdziwa eskalacja wariantu (`low` → `high`) dotyczy tylko ról T3.

Limit kontekstu modelu to 131 072 tokeny. `validate_plan.py` ostrzega, gdy same pliki z `reads` zajęłyby ponad 35% — dlatego makieta (ok. 45 tys. tokenów) jest w `refs`, nie w `reads`.

## 8. Zależności między agentami i ludźmi

```mermaid
flowchart TD
  PO["Product Owner"] -->|zatwierdza specs| BA["bdd-analyst"]
  BA -->|scenariusze .feature| BT["bdd-tester"]
  AR["architect"] -->|kontrakty, OpenAPI, decyzje RFC| IMPL["role wykonawcze"]
  BT -->|czerwone testy| IMPL
  UX["projektant UX (człowiek)"] -->|eksport z Figma| UXD["ux-designer"]
  UXD -->|tokeny, katalog pól| DSE["design-system-engineer"]
  DSE -->|ui-kit| FE["frontend-developer"]
  IMPL -->|commit + przekazanie| GATES["bramki DoD (skrypt)"]
  FE --> GATES
  GATES -->|czerwone| TRI["ci-triage"]
  TRI --> IMPL
  GATES -->|zielone| REV["reviewer / security-reviewer / ui-reviewer"]
  REV -->|approve| HUM["Człowiek: PR, scalenie, bramki G0–G3"]
  REV -->|changes| IMPL
  ORC["orchestrator"] -.prowadzi.-> IMPL
  ORC -.prowadzi.-> GATES
  ORC -.prowadzi.-> REV
```

- **Kontrakty przed implementacją.** Implementer nie zmienia `*/Contracts/**` ani `specs/**`; brak w kontrakcie zgłasza plikiem `docs/rfc/RFC-<krok>-<temat>.md` i statusem `needs-rfc`. RFC rozstrzyga architekt z człowiekiem.
- **Platforma i profile.** Agenci platformy nie piszą w `profiles/<id>/**`; agenci profilu — nigdzie poza swoim profilem. Kroki profili czekają na kroki platformy S27, S38 i S47.
- **Kolejność w czasie** wynika z `depends_on` i bramek w `plan/backlog.yaml`, nie z ról. Aktualny stan: `/status`.

## 9. Co robi wyłącznie człowiek

| Czynność | Jak | Dlaczego nie agent |
| --- | --- | --- |
| scalenie i wypchnięcie | PR w systemie kontroli wersji | `git push` i `git merge` są zakazane dla agentów |
| oznaczenie scalenia | `plan_status.py --merged <krok>` | odblokowuje kolejne kroki |
| zatwierdzenie bramki G0–G3 | `plan_status.py --approve-gate G1 --by "…" --evidence "…"` | decyzja biznesowa lub architektoniczna; narzędzie wymaga scalenia kroków z pola `after` |
| pominięcie kontroli | `--force` | świadome odstępstwo |
| zmiana planu, ról, polityki komend | edycja źródeł + PR | ścieżki chronione i `security_sensitive` |
| nowy profil projektu | `new_profile.py` | zmienia własność kodu (CODEOWNERS) |
| kryteria `acceptance` | podpis, przegląd, test z czytnikiem ekranu | nie da się ich sprawdzić komendą |

## 10. Co zmienił przegląd konfiguracji (listopad 2026)

| Obszar | Było | Jest |
| --- | --- | --- |
| Orkiestrator | mógł edytować całą platformę (zakaz tylko w prompcie); miał wszystkie komendy, w tym `--merged` i `--approve-gate` | zapis tylko w postępie i pakietach; własny zestaw komend; zakazy egzekwuje harness |
| Recenzenci i triage | pełny zestaw komend (w tym `dotnet format`, generatory) | recenzenci: tylko odczyt git; `ci-triage`: bez komend |
| Role wąskie | `bdd-analyst`, `docs-writer`, `ux-designer` mogli pisać w całej platformie | zapis tylko we własnych katalogach |
| Zapis komendą | `git diff --output`, przekierowania i `dotnet format` omijały strażnika bez śladu | zakazy wzorców + bramka zakresu w każdym DoD (obejmuje pliki niezatwierdzone i nieśledzone) |
| Wniosek RFC | zasada kazała złożyć RFC, a strażnik blokował zapis w `docs/rfc/` (dla agentów profili zawsze) | `docs/rfc/RFC-*.md` dozwolony w każdym kroku |
| Uruchamianie wykonawcy | `/krok` zlecał pracę podagentowi w głównym katalogu — bez `.agent-scope`, więc bez strażnika | wykonawca jako sesja w worktree (`opencode run --dir`) |
| Przekazanie do recenzji | recenzja `git diff main...HEAD`, ale nikt nie zatwierdzał zmian | agent zatwierdza na gałęzi kroku (`git add`, `git commit`) |
| Bramki G0–G3 | zatwierdzenie bez sprawdzenia kroków | wymaga scalenia kroków z pola `after` |
| Zakazy odczytu | `*.pfx` i `*.key` były w polityce, ale nie w `opencode.json` | generowane z polityki |
| Eskalacja | „wyższy poziom” przy tym samym wariancie nic nie zmieniał | jawna reguła: sesja od zera z diagnozą, potem człowiek |
| Schematy | identyfikator kroku profilu (`KRE-02`) nie przechodził walidacji przekazania; triage nie miał kategorii `scope`, `integration`, `e2e` | poprawione |
| Backlog | krok S51 prowadzony przez rolę bez prawa zapisu; opisowe „komendy” w DoD kroków S06, S09, S54, S60; S13 bez dostępu do testowanego projektu; makieta 145 kB w `reads` siedmiu kroków | poprawione; każdy krok ma `outcome` i `notes`, kryteria dla ludzi w `acceptance` |

## 11. Znane ograniczenia i rzeczy do sprawdzenia

- **Narzędzia .NET (`ph`).** Zmiany w `render_agents.py`, `prepare_step.py`, `plan_status.py` i strażniku zostały przeniesione do bliźniaczych plików C# (`tools/dotnet`), ale nie były kompilowane w środowisku, w którym powstały. Przed użyciem uruchom `dotnet build tools/dotnet/ProcessHub.Tools.sln -c Release` i `tools/dotnet/parity.sh`.
- **`validate_plan.py`** istnieje tylko w Pythonie.
- **OpenCode.** Reguły `bash` w plikach agentów, uruchamianie `opencode run --dir` przez orkiestratora i zachowanie komend wymagających zgody w sesji bez interfejsu sprawdź na przypiętej wersji (instrukcja: `docs/opencode/start.md`, krok 4): `opencode debug agent orchestrator`, `opencode debug agent reviewer`.
- **Warianty rozumowania.** Parametr `chat_template_kwargs.enable_thinking` jest oznaczony w `config/models.yaml` jako do weryfikacji z serwerem bramki (krok S06).
- **Komendy to najsłabsza warstwa.** Wzorce tekstu da się obejść; realną ochroną są worktree, brak sieci, brak `push`, bramka zakresu i przegląd człowieka. Agent uruchamiający testy uruchamia kod, który sam napisał — środowisko agentów nie powinno mieć dostępu do sekretów ani systemów produkcyjnych.
- **Podział pracy w parze** (kto pisze testy, kto kod) wynika z promptów, nie z uprawnień: obie role dostają ten sam `.agent-scope`.
- **Sesja człowieka.** Bez `.agent-scope` strażnik niczego nie blokuje (z `PH_STRICT=1` — chroni ścieżki chronione). Wbudowany agent `build` w głównym katalogu ma więc pełny zapis; używaj go świadomie.
- **Kwalifikacja.** Zmieniły się prompty ról `orchestrator`, `reviewer`, `ui-reviewer`, `security-reviewer`, `ci-triage`, `module-implementer`, `bdd-tester`, `docs-writer`, `architect` — zgodnie z `evals/agents/README.md` wymagają ponownej kwalifikacji.

## 12. Słowniczek

| Pojęcie | Znaczenie |
| --- | --- |
| harness | kod i konfiguracja wokół modelu: narzędzia, uprawnienia, strażnik, skrypty kroków |
| krok | jednostka planu (`S30`, `KRE-02`) z zależnościami, zakresem zapisu i bramkami |
| pakiet roboczy | instrukcja kroku dla agenta, generowana z backlogu |
| worktree | osobny katalog roboczy tej samej historii git, jeden na krok |
| `.agent-scope` | plik z zakresem zapisu kroku, czytany przez strażnika |
| bramka deterministyczna (DoD) | komenda, która musi zakończyć się kodem 0 |
| bramka G0–G3 | decyzja człowieka rozdzielająca fazy planu |
| przekazanie | końcowy JSON agenta: status, zmienione pliki, bramki, pytania |
| RFC | wniosek o zmianę poza zakresem kroku (`docs/rfc/`) |
| para | druga rola w kroku: tester, współwykonawca albo recenzent |

## Plik: docs/handover/podsumowanie.md

# Podsumowanie: dane wejściowe, wymagania i rezultaty projektu Process Hub (v4)

Dokument zbiera wszystko, co powstało w projekcie: materiały wejściowe, wymagania zgłaszane w kolejnych krokach, podjęte decyzje, wytworzone artefakty i kluczowe liczby. Jest rejestrem wymagań W-xx, do którego odwołują się inne dokumenty (np. `docs/artifacts/assumptions.yaml`).

## 1. Materiały wejściowe (wersja v1)

| Plik | Zawartość |
| --- | --- |
| `architektura-platforma-bpm-camunda.md` | Platforma „Process Hub” zastępująca natywny Tasklist Camunda 8.9: Camunda jako jedyne źródło prawdy, CQRS z read modelem, ACL do Camunda, SSO Keycloak RHBK (jeden realm, federacja AD), dwupoziomowa autoryzacja, etapy biznesowe w BPMN, audyt append-only, fazy wdrożenia |
| `backend-architektura-szczegolowa.md` | Aktorzy, funkcje, konteksty, konfiguracja klienta Camunda, outbox, idempotencja, układ rozwiązania .NET, testy behawioralne |
| `frontend-architektura-ui.md` | Angular i Telerik Kendo UI, Nx, UI Kit, motywy na tokenach (kolory marki banku do potwierdzenia), WCAG AAA z wyjątkami, i18n, Signals, zapis widoków list |
| `camunda-devops-przygotowanie-srodowiska.md` | Camunda 8.9 Self-Managed na Kubernetes, realm RHBK, klienci OIDC, Identity, multi-tenancy, sieć, observability, hosting BFF i SPA, licencja Kendo |

## 2. Zasady pracy

Zwięźle i precyzyjnie; wzorce architektoniczne i archetypy; jakość kodu, testowalność i reużywalność; testy behawioralne (Gherkin, dziś Reqnroll); przy BPMN/Camunda uzasadnienie „dlaczego”; persystencja w MS SQL Server.

## 3. Wymagania

| Id | Wymaganie |
| --- | --- |
| W-01 | Plan architektury własnego TaskList dla Camunda 8.9: własny interfejs użytkownika |
| W-02 | Moduł generowania formatek przez administratora |
| W-03 | Użytkownik widzi swoje zadania oraz stan zadań tej samej grupy uprawnień |
| W-04 | Edytować i kończyć zadanie może tylko osoba, która je przyjęła |
| W-05 | Warstwa menadżera: stan wszystkich zadań zespołu |
| W-06 | DDD, SOLID i archetypy (np. Party) |
| W-07 | Separacja widoczności między grupami operacyjnymi i biznesami |
| W-08 | Audytowalność wszystkich operacji |
| W-09 | Testy BDD |
| W-10 | Plan prac, ścieżka krytyczna, harness modeli AI oszczędzający tokeny przy rzetelnej weryfikacji |
| W-11 | Implementacja przez rój agentów AI — konfiguracja roju |
| W-12 | Frontend w Angularze, SSO w RHBK |
| W-13 | Diagramy modułów, kontekstów i architektury |
| W-14 | Domyślnie jeden tenant, architektura gotowa na wielu |
| W-15 | Widoczność w tenancie przez autoryzacje zasobów Camunda |
| W-16 | Backend korzysta z oficjalnego SDK Camunda |
| W-17 | Wszystkie artefakty w repozytorium, czytelne dla agentów |
| W-18 | Każda akcja audytowana i zapisywana w bazie (bezpieczeństwo, analiza problemów) |
| W-19 | Jedna osoba może mieć wiele ról |
| W-20 | Start procesów z aplikacji |
| W-21 | Formatki edytuje menadżer procesu lub administrator |
| W-22 | Rola audytora: odczyt wszystkich procesów |
| W-23 | Menadżer zmienia osobę lub grupę w trakcie procesu (urlopy) |
| W-24 | Eskalacje i widok procesów eskalowanych |
| W-25 | Dashboard menadżera: wystartowane, sukces, błąd, metryki zdrowia |
| W-26 | Workflow i stan procesu dla formatki bez technikaliów BPMN — warstwa etapów |
| W-27 | Harmonogram bez dat — wykonywalny plan kroków dla agentów |
| W-28 | Instrukcja dostosowania agentów do różnych dostawców modeli i modeli self-hosted (w v3 zastąpiona przez W-36) |
| W-29 | Klikalna makieta UI w barwach zbliżonych do barw Polski |
| W-30 | Złożoność i pracochłonność kroków w hybrydzie AI + ludzie |
| W-31 | Interaktywny dashboard harmonogramu z warstwami dla planowania i decydentów |
| W-32 | Podsumowanie i prompt do odtworzenia artefaktów w innym modelu |
| W-33 | Prompty odtwarzające repozytorium od zera, bez przekazywania plików |
| W-34 | Prompt kontekstowy do notesu w innym modelu |
| W-35 | Instrukcja startu projektu z OpenCode krok po kroku |
| W-36 | Agenci orkiestrowani przez OpenCode z modelem z rodziny GLM 5.3 Flash; repozytorium bez odniesień do poprzedniego narzędzia agentowego |
| W-37 | Repozytorium neutralne: zamiast nazwy konkretnego banku — „bank” |
| W-38 | Profile określające role w ramach projektów korzystających z TaskList; wydzielona część specyficzna (dane, operacje dedykowane) realizowana niezależnie przez zespoły projektów; część platformowa wspólna; separacja kodu |
| W-39 | Artefakty projektowe: plan systemu, aktorzy i główne założenia |
| W-40 | Model zawsze uruchomiony w infrastrukturze banku (self-hosted) — żadnych zewnętrznych API |
| W-41 | Narzędzia repozytorium także w C# (.NET 10, język C# 10) z kodem źródłowym, bez instalacji przez `pip` i bez zależności od Pythona; pliki Pythona zostają, wersja .NET jest opcją |
| W-42 | Przykładowe procesy: opiniowanie rejestracji samochodu udostępnione komórkom banku (IT, HR, Prawny, Finanse, Ryzyko) z diagramem; dedykowane menu z katalogiem samochodów widocznym tylko dla profilu procesu i uzupełnianym przez jedną z ról administracyjnych; instrukcja dla zespołów o możliwościach i ograniczeniach platformy, konfiguracji i podpięciu; makieta z tą opcją; prompty od zera zgodne z repozytorium |
| W-43 | Moduł zarządzania formatkami Camunda Forms z poziomu systemu: menadżer lub administrator procesu tworzy formatki zgodne z biblioteką używaną przez Camunda 8.9, analogicznie jak w Modelerze |
| W-44 | Pełne zarządzanie wersjami formatek, akceptacja i wycofywanie |
| W-45 | Formatki renderowane na zadaniu w wyglądzie spójnym z resztą systemu: definicja zgodna z możliwościami biblioteki Camunda, materializacja zgodna z warstwą wizualną przygotowaną przez projektanta UX w Figma; biznes decyduje o polach i układzie, wygląd jest wspólny |
| W-46 | Separacja widoczności formatek: każdy proces ma formatki wyłącznie dla siebie |
| W-47 | Szczegółowy opis działania modułu dla osób rozwijających system (założenia wizualne, koncepcje, odpowiedzialności), plan wykonywalny modułu i agenci odpowiadający za warstwę wizualną |
| W-48 | Artefakt z wytycznymi i założeniami systemu dla osoby zaczynającej pracę nad interfejsem użytkownika |

## 4. Kluczowe decyzje

- **Architektura.** Modularny monolit .NET 10 w rolach `api`, `projector`, `jobs`, `worker`; moduły heksagonalne; potok komend: ślad → walidacja → autoryzacja → audyt Intent/Outcome → idempotencja → transakcja z outboxem.
- **Konteksty DDD.** Rdzeń: Task Work, Process Lifecycle, Process Insight, Form Management; wspierające: Form Runtime, Party & Accountability, Access Policy, Audit, Extension Host; generyczne: Camunda Integration (ACL z oficjalnym SDK), Platform Administration, User Preferences, Notification. Profile projektów to osobne konteksty poza platformą.
- **Uprawnienia.** Role platformy (Uczestnik, Inicjator, Menadżer procesu, Administrator procesu) i globalne (Audytor, Administrator platformy); role projektowe w profilach. L1 autoryzacje Camunda, L2 polityka aplikacji; uprawnienia jako kod z reconcilerem; reguły R1–R11 (R9 zasoby profilu, R10 przestrzeń nazw profilu, R11 formatka należy do procesu).
- **Profile projektów (ADR-012…014, ADR-017).** Manifest profilu (procesy, role projektowe, uprawnienia, dane, operacje na zadaniu, sprawie i danych profilu, sloty UI z sekcją nawigacji, integracje); SDK rozszerzeń jako jedyna zależność; potok operacji platformy; przykład kompletu dedykowanych elementów: profil `flota` (katalog samochodów, opinie komórek banku); modele in-process i remote; separacja w ośmiu warstwach (repozytorium, kompilacja, uprawnienia, wykonanie, dane, wdrożenie, CI, agenci AI); schemat i użytkownik bazy per profil; własne plany zespołów.
- **Formatki (ADR-018…020).** Format Camunda Forms (schemat form-js, FEEL) z importem i eksportem `.form`; aplikacja jest systemem zapisu — formatek nie wdraża się do silnika, zadanie wskazuje je referencją zewnętrzną. Wersje w cyklu szkic → przegląd → zatwierdzenie (R8) → publikacja → zastąpienie albo wycofanie (`Form.Withdraw`, z wersją zastępczą i opcjonalnym przepięciem zadań). Formatka należy do jednego procesu (R11). Projektant osadza edytor form-js z paletą ograniczoną katalogiem pól; na zadaniu formatkę materializuje własny renderer komponentami design systemu; dane waliduje serwer (reguły schematu, FEEL przez silnik).
- **Warstwa wizualna.** Trzy warstwy: struktura (biznes, schemat formatki), materializacja (katalog pól: typ → komponent `ui-kit`), wygląd (projektant UX: Figma → `design/tokens.json`). Agenci `ux-designer`, `design-system-engineer`, `ui-reviewer`; regresja wizualna i axe w CI; wytyczne dla nowych osób w `docs/artifacts/04-wytyczne-ui.md`.
- **Dane.** MS SQL Server 2022+: schematy per moduł i `prj_<id>` per profil, RLS, Ledger, partycjonowany ślad operacyjny, tabele temporalne.
- **Wgląd menadżera.** Mapa etapów nad BPMN, dashboard z wynikiem biznesowym na zdarzeniach końcowych, eskalacje, przekazywanie i zastępstwa.
- **Agenci (ADR-015, ADR-016).** OpenCode z `glm-5.3-flash` wyłącznie na bramce w infrastrukturze banku (jeden profil modeli `glm-self-hosted`, polityka danych tylko on-prem); poziomy ról jako warianty rozumowania wysyłane bramce (`low`, `high`); agenci profili z zapisem tylko we własnym profilu; strażnik zapisu w OpenCode i CI.
- **Narzędzia.** Dwie równoważne implementacje: Python (`tools/*.py`) i .NET (`tools/dotnet`, polecenie `ph`, C# 10, zero paczek NuGet). Wyniki identyczne co do bajtu (zaokrąglanie, `repr`, sumy i JSON jak w Pythonie 3.12+, YAML jak PyYAML); obie przechodzą te same bramki `--check`; plugin strażnika i `ph step dod` same przełączają się na .NET, gdy Pythona brak.

## 5. Rezultaty (repozytorium `process-hub`, v4)

| Obszar | Pliki | Zawartość |
| --- | --- | --- |
| Wejście | `README.md`, `AGENTS.md`, `CODEOWNERS` | mapa, zasady dla agentów i ludzi, tabela agentów, własność kodu |
| Architektura | `docs/architecture/00–14`, `docs/glossary.md` | 15 dokumentów, w tym profile projektów i moduł zarządzania formatkami; słownik PL ↔ kod |
| Decyzje | `docs/adr/ADR-001…020`, `docs/rfc/` | 20 ADR (ADR-018…020: formatki), wnioski RFC |
| Artefakty projektowe | `docs/artifacts/` | plan systemu, aktorzy, założenia, wytyczne UI (Markdown i strony HTML), rejestry YAML |
| Profile projektów | `profiles/`, `docs/guides/` | schemat manifestu, szablon, przewodnik, instrukcja dedykowanych elementów, profile `kredyty` (in-process), `aml` (remote) i `flota` (in-process: katalog samochodów, opinie komórek banku, modele BPMN) z planami i scenariuszami |
| Uprawnienia | `config/authorization/`, `profiles/*/authorization.yaml` | role platformy, role globalne, role projektowe |
| Specyfikacje | `specs/**`, `profiles/*/specs/` | scenariusze platformy (w tym profile) i scenariusze zespołów profili |
| Plan i wycena | `plan/` | 57 kroków (w tym 8 kroków modułu formatek i warstwy wizualnej), bramki G0–G3, model wyceny, raport, dashboard (strona działa z dysku) |
| Agenci | `.opencode/`, `opencode.json`, `agents/`, `config/models.yaml`, `evals/agents/` | agenci platformy i profili, skille, komendy, plugin strażnika, profile modeli GLM, kwalifikacja E01–E11; role warstwy wizualnej i skille `camunda-forms`, `design-system` |
| Narzędzia | `tools/` | generator agentów, prowadzenie kroków, strażnik zapisu, walidacja profili, wycena, eksport dashboardu, artefakty, źródła notesu — w Pythonie |
| Narzędzia .NET | `tools/dotnet/` | te same narzędzia w C# (`ph`), testy bez zewnętrznych paczek, skrypt zgodności w obie strony |
| UI | `design/` | propozycja projektowa, tokeny, klikalna makieta, `forms/`: założenia wizualne formatek, katalog pól, formatka wzorcowa |
| Przekazanie | `docs/handover/` | to podsumowanie, prompty od zera, prompt i źródła notesu |

## 6. Kluczowe liczby (model, do kalibracji)

| Wielkość | Z AI | Bez AI |
| --- | --- | --- |
| Czas do końca pilotażu | 27,6 tyg. (P80: 30,8) | 38,3 tyg. (P80: 42,9) |
| Praca ludzi z narzutami | 459 osobodni | 597 osobodni |
| Ścieżka krytyczna | 138 dni roboczych | 177 dni roboczych |

Zespół referencyjny 6,2 etatu (w tym 0,5 etatu projektanta UX), wykorzystanie 75%. Moduł formatek z warstwą wizualną dodał ok. 59 osobodni bez zmiany kalendarza; jego łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma ok. 2,6 dnia zapasu. Najtrudniejsze kroki: S02, S50, S23, S21, S60, S06, S24, S27, S34. Kroki profili (S19, S27, S38, S47, S48) dodają ok. 39 osobodni, ale mają zapas i nie wydłużają kalendarza. Wrażliwość: wolne procedury banku +4,9 tyg.; podział kroków krytycznych −2,0 tyg.; słabsi agenci +2,7 tyg.; większy zespół 0 tyg.

## 7. Do weryfikacji

Pokrycie oficjalnego SDK Camunda dla .NET w 8.9; nazwy uprawnień autoryzacji Camunda; korekty w task listenerach; token delegowany w RHBK; `EXECUTE AS USER` z pulą połączeń EF Core (izolacja profili); ograniczenie workerów profili do ich procesów; parametry wariantów rozumowania i limity modelu GLM na bramce banku; bramka i sprzęt GPU (S-2); kolory z księgi znaku banku i biblioteka w Figma (S09); zgodność własnego renderera z form-js (S07); endpoint ewaluacji FEEL w 8.9 (S08); licencja bpmn.io dla osadzonego edytora; decyzje D-01…D-16; właściciele i oceny ryzyk.

