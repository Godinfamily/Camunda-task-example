# 05-profile-projektow — Profile projektów: przewodnik i instrukcja dedykowanych elementów, schemat manifestu, szablon, profile kredyty, aml i flota (manifesty, plany, scenariusze)

Pakiet zawiera 24 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: profiles/README.md

# Profile projektów

Profil projektu to sposób, w jaki projekt biznesowy (np. kredyty, AML) korzysta z Process Hub: deklaruje swoje procesy, role projektowe, dane i operacje dedykowane, a resztę dostaje od platformy. Część platformowa działa tak samo dla każdego profilu; część specyficzna należy do zespołu projektu i jest od platformy oraz od innych profili oddzielona — w repozytorium, w kodzie, w bazie, w uprawnieniach i w pracy agentów AI.

Architektura: `docs/architecture/13-project-profiles.md` · decyzje: ADR-012 (profile i punkty rozszerzeń), ADR-013 (separacja kodu), ADR-014 (dane profilu), ADR-017 (operacje na danych profilu) · jak budować dedykowane menu, strony, dane i operacje: `docs/guides/dedykowane-elementy-profilu.md`.

## Profile w repozytorium

| Profil | Model | Co pokazuje |
| --- | --- | --- |
| `kredyty` | in-process | operacje na zadaniu („Przelicz scoring”), wzbogacenie zadania, źródło danych formatki, raport portfela na trasie `/p/kredyty/portfel` |
| `aml` | remote | usługa zespołu (kontrakt `profile-operations v1`), operacja na sprawie, dane klasy `restricted` |
| `flota` | in-process | **przykład dedykowanych elementów**: sekcja nawigacji „Flota” z katalogiem samochodów widocznym tylko dla ról profilu, operacje na danych profilu (`profile-action`) dla roli „Administrator katalogu samochodów”, pole formatki z katalogu, opinie pięciu komórek banku w procesie podrzędnym, modele BPMN (`profiles/flota/README.md`) |

## Platforma a profil

| Platforma — tak samo dla wszystkich | Profil — decyzja zespołu projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4) | Role projektowe złożone z ról platformy i uprawnień projektu |
| Start procesu, moje procesy, przekazywanie, zastępstwa | Operacje dedykowane na zadaniach, sprawach i danych profilu (np. „Przelicz scoring”, „Zapisz model w katalogu”) |
| Eskalacje, dashboard, mapa etapów, formatki | Dane projektu we własnym schemacie `prj_<id>` |
| Audyt każdej akcji, autoryzacje jako kod | Rozszerzenia UI w slotach: panel zadania, panel sprawy, widżet, pole formatki, sekcja nawigacji, trasy `/p/<id>/` |
| Integracja z Camunda (wyłącznie platforma) | Workery typów zadań `<id>.*` i integracje z systemami projektu |
| SDK rozszerzeń i jego zgodność wsteczna | Model integracji: `in-process` (moduł w hoście) albo `remote` (usługa zespołu) |

## Założenie nowego profilu

```bash
python3 tools/profiles/new_profile.py lizing --name "Lizing" --team "@bank/zespol-lizing" --process umowa-lizingowa
python3 tools/profiles/validate_profiles.py --write-codeowners   # sprawdza manifesty, aktualizuje CODEOWNERS
python3 tools/agents/render_agents.py                            # agenci lizing-* z zapisem tylko w profiles/lizing/**
# bez Pythona: ph profiles new …, ph profiles validate --write-codeowners, ph agents render
```

1. Zespół uzupełnia `profile.yaml` (procesy, uprawnienia, role, dane, operacje, UI) i `authorization.yaml` (grupy AD → role projektowe).
2. Pull request przeglądają zespół profilu i architekt platformy (`CODEOWNERS`); CI uruchamia walidację manifestów.
3. Po scaleniu reconciler nadaje autoryzacje w Camunda, a platforma rejestruje profil przy starcie.
4. Zespół prowadzi własny plan (`backlog.yaml`) tymi samymi narzędziami co platforma.

## Co wolno, a czego nie

| Wolno | Nie wolno |
| --- | --- |
| Zależeć od `ProcessHub.Extensibility` i `@process-hub/extension-sdk` | Odwoływać się do modułów platformy lub innych profili |
| Czytać dane platformy przez widoki `platform_api` | Czytać lub zapisywać tabele platformy i innych profili |
| Definiować uprawnienia, operacje i typy zadań z prefiksem `<id>.` | Używać cudzej przestrzeni nazw albo nadawać rolę audytora |
| Wywoływać systemy projektu z operacji lub workerów | Łączyć się z Camunda poza workerami typów zadań profilu |
| Wydawać profil w rytmie zespołu (remote) lub w pociągu wydań (in-process) | Omijać potok platformy: autoryzację, audyt, idempotencję |

## Praca z agentami

Generator tworzy agentów profilu (`kredyty-module-implementer`, `kredyty-frontend-developer`…), którzy mogą zapisywać wyłącznie w `profiles/<id>/**`; wszyscy agenci pracują na modelu GLM w infrastrukturze banku, a klasa danych profilu decyduje o przeglądzie bezpieczeństwa. W OpenCode: `/profil kredyty KRE-02`.

## Lista kontrolna przed pierwszym wydaniem profilu

- [ ] `validate_profiles.py --check` zielone; zespół w `CODEOWNERS`
- [ ] testy zgodności SDK i testy architektury profilu zielone
- [ ] każda operacja zapisu ma `requiresAssignee` i scenariusz odmowy
- [ ] odczyty wrażliwe oznaczone `sensitive: true`
- [ ] migracje schematu `prj_<id>` przechodzą tożsamością migracji profilu
- [ ] przegląd bezpieczeństwa dla klasy danych `restricted`

## Plik: docs/guides/dedykowane-elementy-profilu.md

# Dedykowane elementy procesów w profilu projektu — przewodnik dla zespołów

Dla zespołu projektu, który chce dodać do Process Hub coś, czego potrzebują tylko jego procesy: własne menu i strony, dane projektu (np. katalog, słownik), operacje, pola formatek, panele w zadaniach. Przewodnik mówi, co platforma pozwala zbudować, czego nie pozwala i dlaczego, jak to zadeklarować w manifeście i jak podpiąć kod do platformy.

Przykład przewija się przez cały tekst: profil **`flota`** (`profiles/flota/`) — rejestracja samochodu służbowego z opiniami komórek banku (IT, HR, Prawny, Finanse, Ryzyko) i **katalogiem samochodów**, który widzą tylko role tego profilu, a uzupełnia jedna z jego ról administracyjnych. W klikalnej makiecie (`design/mockups/index.html`) zobaczysz go jako Tomasz (wnioskodawca), Hanna (opiniująca z HR) i Karol (administrator katalogu); Anna z profilu `kredyty` nie widzi niczego z tego.

Podstawy: `docs/architecture/13-project-profiles.md` (profile i punkty rozszerzeń), `profiles/README.md` (założenie profilu), skill `profile-extension` (kod), ADR-012, ADR-013, ADR-014, ADR-017.

## 1. W skrócie

- **Dedykowany element = deklaracja w manifeście + kod na SDK.** Platforma rejestruje tylko to, co jest w `profiles/<id>/profile.yaml`. Kod bez wpisu w manifeście nie zostanie uruchomiony, a wpis bez kodu nie przejdzie testów zgodności.
- **Platforma pilnuje dostępu, profil dostarcza logikę.** Uprawnienia, odmowy, audyt, idempotencja, kontekst bazy i decyzja, czy przycisk w ogóle się pojawi (`allowedActions`), są po stronie platformy. Zespół pisze logikę biznesową, zapytania i komponenty.
- **Wszystko jest ograniczone do profilu.** Elementy profilu działają tylko w jego procesach (R9), mają jego przestrzeń nazw (R10) i widzą je tylko osoby z jego rolami projektowymi. Inne profile, ich procesy i formatki nie mają do nich dostępu.
- **Brakuje punktu rozszerzenia? RFC, nie obejście.** Tak powstał `profile-action` dla katalogu floty: `docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md` → ADR-017.

```mermaid
flowchart LR
  M["profile.yaml<br/>authorization.yaml"] --> V["Walidator profili<br/>bramka CI"]
  V --> PR["PR: zespół profilu<br/>+ architekt platformy<br/>(+ bezpieczeństwo)"]
  PR --> R["Reconciler<br/>role i autoryzacje Camunda"]
  PR --> H["Rejestr profili<br/>Extension Host"]
  K["Kod profilu na SDK<br/>backend · frontend · workery"] --> H
  H --> API["API platformy<br/>uprawnienia · audyt · allowedActions"]
  R --> API
  API --> UI["Powłoka Angular<br/>sekcja nawigacji · strony · sloty"]
  UI --> U["Tylko role profilu"]
```

## 2. Co możesz zbudować

| Potrzeba biznesowa | Punkt rozszerzenia | Przykład | Platforma zapewnia | Ty piszesz |
| --- | --- | --- | --- | --- |
| Własne menu i miejsce w aplikacji | `ui.slots: nav.section` + `ui.routes` (`/p/<id>/…`) | sekcja „Flota” → „Katalog samochodów” (`/p/flota/katalog`) | widoczność sekcji i trasy z uprawnienia, odmowa z wpisem w dzienniku, układ, okruszki, motyw | komponent sekcji i strony |
| Lista lub raport danych projektu | `query` | `flota.CarCatalog`, `kredyty.PortfolioReport` | endpoint `/p/<id>/queries/…`, autoryzacja, ślad, `allowedActions` w wyniku | zapytanie (`IProfileQuery`) |
| Edycja danych projektu bez zadania (katalog, słownik, progi) | `profile-action` (SDK 1.1, ADR-017) | „Dodaj model”, „Wycofaj model” w katalogu floty | uprawnienie, odmowy, audyt Intent/Outcome, idempotencja, kontekst bazy `prj_<id>`, przyciski z `allowedActions` | logika i walidacja (`IProfileAction`) |
| Akcja na zadaniu | `task-action` | „Sprawdź cenę i termin dostawy” (flota), „Przelicz scoring” (kredyty) | to samo + R1 (tylko assignee) i R9 | `ITaskOperation`, zapis szkicu przez `ctx.Tasks` |
| Akcja na sprawie | `case-action` | „Eksport sprawy dla nadzoru” (aml) | to samo w kontekście instancji procesu | `ICaseOperation` |
| Dodatkowe informacje w zadaniu | `task-enricher` + `ui.slots: task.panel` | panel „Opinie komórek” w zadaniu decyzji | sekcja `extensions.<id>`, limit czasu, audyt odczytu wrażliwego | `ITaskEnricher` i komponent panelu |
| Informacje w sprawie | `ui.slots: case.panel` | „Eksport dla nadzoru” (aml) | jak wyżej, dla instancji | komponent panelu |
| Pole formatki z danymi projektu | `ui.slots: form.field` + `form-data-source` | „Model samochodu z katalogu” w formatce startowej | pole w palecie projektanta i w rendererze formatek jako wariant typu bazowego Camunda Forms (zwykle `select`) z własnością `ph:field`; wywołanie tylko z formatek procesów profilu, pamięć podręczna | `IFormDataSource` i komponent pola z `core/ui-kit` |
| Widżet na pulpicie | `ui.slots: dashboard.widget` | „Katalog samochodów” | miejsce na pulpicie, widoczność z uprawnienia | komponent widżetu |
| Dane projektu ze zdarzeń procesów | `event-handler` | rejestr opinii `flota.OpinionRegister` | zdarzenia platformy tylko z procesów profilu, outbox, ponowienia | `IPlatformEventHandler` |
| Krok systemowy w procesie | service task z typem `<id>.*` + worker | `flota.zamowienie.zloz`, `flota.ewidencja.dodaj` | wdrożenie BPMN z pipeline'u, lint, minimalne uprawnienia klienta workera | worker w `profiles/<id>/workers/` |
| Zadanie dla kilku komórek banku | grupy kandydujące w `authorization.yaml` + zadanie wielokrotne w BPMN | opiniowanie IT, HR, Prawny, Finanse, Ryzyko | widoczność per grupa (R3), przejęcie tylko przez członka grupy (R2), audyt z rolą | konfiguracja i model BPMN (sekcja 6) |
| Role projektu | `roles` + `authorization.yaml` | „Administrator katalogu samochodów” bez ról platformy | reconciler, role w audycie (`<profil>/<rola>`), suma uprawnień w zakresach | deklaracja |

## 3. Czego nie możesz — i co zrobić zamiast

| Ograniczenie | Dlaczego | Zamiast tego |
| --- | --- | --- |
| Nie dodasz pozycji do sekcji platformy (Praca, Nadzór, Konfiguracja procesu, Kontrola) ani nie zmienisz jej ekranów | powłoka jest wspólna dla wszystkich profili; zmiana jednego projektu zmieniłaby wszystkim | własna sekcja `nav.section` i sloty; brak potrzebnego slotu → RFC |
| Nie decydujesz w komponencie, czy przycisk akcji ma się pojawić, i nie sprawdzasz ról | UI nie liczy uprawnień; reguły żyją w backendzie, a przyciski renderuje powłoka z `allowedActions` | zadeklaruj operację z uprawnieniem; w kodzie sprawdzasz uprawnienie (`flota.Catalog.Manage`), nigdy nazwę roli |
| Nie piszesz własnych kontrolerów ani endpointów | każde wywołanie musi przejść potok: uprawnienie, deny by default, audyt, idempotencja | operacja albo zapytanie w manifeście |
| Nie łączysz się z Camunda poza workerami typów `<id>.*` i nie zmieniasz zmiennych procesu bezpośrednio | Camunda tylko przez moduł `CamundaIntegration` (ADR-003) | zapis szkicu lub zakończenie zadania przez `ctx.Tasks`; krok systemowy jako service task z workerem |
| Nie czytasz tabel platformy ani innych profili | izolacja danych: schemat i użytkownik bazy per profil (ADR-014) | widoki `platform_api` (filtrowane do procesów profilu) albo `IPlatformQueries` |
| Nie udostępnisz elementów profilu innym profilom ani procesom innych profili | R9; proces ma jednego właściciela (Z-16) | wspólny proces wymaga decyzji o właścicielu; raport przekrojowy — osobny, zatwierdzony mechanizm (ADR-014) |
| Nie używasz cudzej przestrzeni nazw i nie nadajesz ról audytora ani administratora platformy | R10, rozdział obowiązków (R7) | uprawnienia, operacje i typy zadań z prefiksem `<id>.`; grupy AD i grupy kandydujące tylko własne (jedna grupa należy do jednego profilu) |
| Operacja na danych profilu nie ma akceptacji drugiej osoby | `profile-action` to pojedyncza, audytowana zmiana | gdy biznes wymaga czterech oczu — proces z zadaniem zatwierdzenia (R1) |
| Menadżer procesu nie edytuje treści zadań | R1: edytuje i kończy tylko assignee | `task-action` zawsze z `requiresAssignee: true` |
| Operacja ma limit czasu (propozycja: 5 s; wzbogacenie: 1 s) | awaria profilu nie może blokować pracy na zadaniu (NFR-13) | długie obliczenia w workerze albo asynchronicznie ze zdarzenia |
| Nie zapisujesz w audycie ani w logach wartości danych osobowych | RODO, NFR-09 | identyfikatory i listy pól; odczyty wrażliwe oznacz `sensitive: true` |
| Nie wprowadzasz własnych kolorów, krojów ani komponentów spoza Kendo i SDK | rozszerzenia mają wyglądać jak platforma, WCAG 2.2 AA | tokeny z `design/tokens.json`, komponenty `core/ui-kit`, teksty w `profiles/<id>/frontend/i18n/pl.json` |
| Nie dodajesz paczek npm ani NuGet bez zgody | zasada 9 w `AGENTS.md` | wniosek do architekta platformy |
| Nie zmieniasz SDK, kontraktów platformy ani `specs/**` | zasada 8 w `AGENTS.md` | RFC w `docs/rfc/` (wzór: `RFC-FLO-03`) |
| Pole profilu nie zmienia formatu formatki | formatka pozostaje poprawnym dokumentem Camunda Forms, który otworzy Modeler (ADR-018) | pole to typ bazowy z katalogu pól (`design/forms/field-catalog.yaml`) z własnością `ph:field = <profil>.<nazwa>`; bez własnych typów komponentów i bez stylów |
| Profil nie prowadzi formatek poza platformą | wersje, akceptację (R8) i wycofanie prowadzi platforma; formatka należy do jednego procesu (R11) | formatki projektują menadżer i administrator procesu z ról projektowych — `docs/architecture/14-form-management.md` |
| Zdarzenie startowe BPMN nie wskazuje formatki przez `externalReference` | Zeebe 8.9 przyjmuje tam tylko `formId` albo `formKey` | formatkę startową przypisuje do procesu Form Management; kontrakt danych w `ph:outputs` zdarzenia startowego |

## 4. Jak element trafia na ekran

1. **Manifest.** Zespół deklaruje uprawnienia, role, operacje, trasy i sloty w `profile.yaml`, a przypisania grup AD w `authorization.yaml`.
2. **Walidacja.** `python3 tools/profiles/validate_profiles.py --check` (albo `ph profiles validate --check`) sprawdza schemat i reguły międzyprofilowe; bez zielonej walidacji PR nie przejdzie CI.
3. **Przegląd.** `CODEOWNERS`: zespół profilu, a dla `profile.yaml` także architekt platformy, dla `authorization.yaml` także bezpieczeństwo.
4. **Uzgodnienie autoryzacji.** Reconciler łączy role platformy i role projektowe, nadaje w Camunda autoryzacje na procesach profilu i odrzuca naruszenia R7 i R10.
5. **Rejestracja.** Przy starcie host platformy rejestruje moduł profilu (backend) i bibliotekę `profile-<id>-ui` (frontend, ładowanie leniwe).
6. **Wywołanie.** Użytkownik dostaje sekcję nawigacji i strony tylko z uprawnieniem trasy. Wynik zapytania przychodzi z `allowedActions`, a przyciski renderuje powłoka. Kliknięcie idzie przez potok platformy do kodu profilu w kontekście bazy `prj_<id>`.

```mermaid
sequenceDiagram
  participant U as Osoba z rolą profilu
  participant UI as Powłoka + profile-flota-ui
  participant API as Potok platformy
  participant EX as Extension Host
  participant Q as flota.CarCatalog
  U->>UI: otwiera aplikację
  UI->>API: nawigacja i sloty dla aktora
  API-->>UI: sekcja „Flota” (uprawnienie flota.Catalog.View)
  U->>UI: Flota → Katalog samochodów
  UI->>API: GET /p/flota/queries/flota.CarCatalog
  API->>API: uprawnienie trasy i zapytania, ślad
  API->>EX: wykonaj w kontekście profilu
  EX->>Q: ExecuteAsync
  Q-->>EX: modele, liczba wniosków w toku (platform_api)
  EX-->>API: wynik
  API-->>UI: wynik + allowedActions (np. flota.SaveCatalogItem dla administratora katalogu)
  UI-->>U: lista, przyciski tylko z allowedActions
```

Osoba bez uprawnienia nie widzi sekcji. Gdy wpisze adres ręcznie, dostaje stronę „Brak dostępu”, a próba trafia do dziennika bezpieczeństwa z wynikiem `Denied` (R5) — kod profilu nie jest wywoływany.

## 5. Krok po kroku: katalog samochodów w profilu `flota`

### 5.1. Załóż profil (albo pracuj w istniejącym)

```bash
python3 tools/profiles/new_profile.py flota --name "Flota samochodowa" --team "@bank/zespol-flota" --process rejestracja-samochodu
python3 tools/profiles/validate_profiles.py --write-codeowners   # CODEOWNERS dla profiles/flota/
python3 tools/agents/render_agents.py                            # agenci flota-* z zapisem tylko w profiles/flota/**
# bez Pythona: ph profiles new …, ph profiles validate --write-codeowners, ph agents render
```

### 5.2. Uprawnienia i role

Najpierw uprawnienia projektu (zawsze w przestrzeni nazw profilu), potem role projektowe złożone z ról platformy i tych uprawnień:

```yaml
permissions:
  - { id: flota.Catalog.View, kind: read, description: Podgląd katalogu samochodów dostępnych do zakupu }
  - { id: flota.Catalog.Manage, kind: write, description: Dodawanie i zmiana modeli w katalogu oraz ich wycofywanie }

roles:
  - id: wnioskodawca
    name: Wnioskodawca
    platformRoles: [process-starter]
    permissions: [flota.Catalog.View]
    processes: [rejestracja-samochodu]
  - id: administrator-procesow-floty     # formatki, mapa etapów — bez prawa zmiany katalogu
    name: Administrator procesów floty
    platformRoles: [process-administrator]
    permissions: [flota.Catalog.View]
  - id: administrator-katalogu           # tylko opcja dedykowana, bez ról platformy
    name: Administrator katalogu samochodów
    platformRoles: []
    permissions: [flota.Catalog.View, flota.Catalog.Manage]
```

Wskazówki:
- Daj uprawnienie podglądu wszystkim rolom, które mają widzieć element, a uprawnienie zapisu — jednej, wąskiej roli. „Jedna z ról administratora” to rola projektowa z uprawnieniem `…Manage`; druga rola administracyjna (procesów) go nie ma.
- Rola może nie mieć żadnej roli platformy (`platformRoles: []`) — wtedy dostaje wyłącznie opcje dedykowane, bez zadań, formatek i dashboardu.
- Przypisania do grup AD w `authorization.yaml` (jedna grupa AD należy do jednego profilu):

```yaml
assignments:
  - { group: PH-FLOTA-KATALOG, roles: [administrator-katalogu] }
```

### 5.3. Operacje

```yaml
operations:
  - id: flota.CarCatalog                 # lista na stronie i w widżecie
    kind: query
    permission: flota.Catalog.View
  - id: flota.SaveCatalogItem            # dodanie albo zmiana modelu
    kind: profile-action
    title: Zapisz model w katalogu
    permission: flota.Catalog.Manage     # uprawnienie projektu rodzaju write
    requiresAssignee: false              # jawnie: nie ma zadania
    idempotent: true                     # bez appliesTo
  - id: flota.WithdrawCatalogItem
    kind: profile-action
    title: Wycofaj model z katalogu
    permission: flota.Catalog.Manage
    requiresAssignee: false
    idempotent: true
  - id: flota.CarModels                  # pole formatki w procesach profilu
    kind: form-data-source
    permission: flota.Catalog.View
```

`profile-action` wymaga `sdk: "^1.1"` w manifeście.

### 5.4. Interfejs: sekcja nawigacji, strona, widżet, pole formatki

```yaml
ui:
  routes:
    - { path: /p/flota/katalog, title: Katalog samochodów, permission: flota.Catalog.View }
  slots:
    - { slot: nav.section, component: FleetNavSectionComponent, title: Flota, permission: flota.Catalog.View }
    - { slot: dashboard.widget, component: CatalogWidgetComponent, title: Katalog samochodów, permission: flota.Catalog.View }
    - { slot: form.field, component: CarModelSelectComponent, title: Model samochodu z katalogu, permission: flota.Catalog.View, appliesTo: { process: rejestracja-samochodu } }
```

Trasa musi zaczynać się od `/p/<id>/`. Sekcja nawigacji pojawia się w szufladzie pod sekcjami platformy i zawiera tylko trasy, do których aktor ma uprawnienie.

### 5.5. Walidacja manifestu

```bash
python3 tools/profiles/validate_profiles.py --check     # albo: ph profiles validate --check
```

Typowe błędy i ich przyczyny:

| Komunikat walidatora | Co poprawić |
| --- | --- |
| `uprawnienie … spoza przestrzeni nazw flota. (R10)` | prefiks profilu w identyfikatorze |
| `trasa … musi zaczynać się od /p/flota/` | ścieżka trasy |
| `profile-action … wymaga uprawnienia projektu rodzaju write` | uprawnienie zapisu z manifestu, nie platformy |
| `profile-action … działa na danych profilu — bez appliesTo (R9)` | usuń `appliesTo` |
| `profile-action … nie dotyczy zadania — requiresAssignee musi być false` | `requiresAssignee: false` |
| `operacja zapisu … musi jawnie deklarować requiresAssignee` | dodaj pole |
| `task-action … bez wymogu assignee łamie R1` | `requiresAssignee: true` |
| `operacja … z uprawnieniem odczytu wrażliwego musi mieć sensitive: true` | oznacz odczyt wrażliwy |
| `slot … na procesie … spoza profilu (R9)` | `appliesTo` tylko z procesami profilu |
| `grupa … jest już przypisana w profilu …` | osobna grupa AD dla każdego profilu |
| `NIEAKTUALNE: CODEOWNERS` | `--write-codeowners` |

### 5.6. Dane profilu

Migracje w `profiles/flota/db/` tworzą tabele w schemacie `prj_flota` (uruchamia je tożsamość migracji profilu). Dane platformy, np. liczbę wniosków w toku dla modelu, czytasz wyłącznie z widoków `platform_api`, które pokazują tylko procesy profilu.

### 5.7. Backend (C#, `profiles/flota/backend/Flota.Extension`)

```csharp
public sealed class FlotaProfile : IProfileModule
{
    public ProfileId Id => new("flota");
    public void Register(IProfileBuilder p) => p
        .UseDatabase<FlotaDb>()                                              // schemat prj_flota
        .AddQuery<CarCatalog, CarCatalog.Result, CarCatalogHandler>()          // flota.CarCatalog
        .AddProfileAction<SaveCatalogItem, SaveCatalogItem.Input>()            // flota.SaveCatalogItem (SDK 1.1)
        .AddProfileAction<WithdrawCatalogItem, WithdrawCatalogItem.Input>()
        .AddFormDataSource<CarModels>("flota.CarModels");
}

[ProfileOperation("flota.SaveCatalogItem")]                                    // = operations[].id
internal sealed class SaveCatalogItem(FlotaDb db) : IProfileAction<SaveCatalogItem.Input>
{
    public sealed record Input(string? ItemId, string Brand, string Model, string Version, string Category, decimal NetPrice, int Co2);

    public async ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, Input input, CancellationToken ct)
    {
        if (input.Co2 > CarCatalogPolicy.MaxCo2)                               // reguła biznesowa, nie uprawnienie
            return OperationResult.Invalid("co2", $"Emisja CO2 przekracza limit polityki floty ({CarCatalogPolicy.MaxCo2} g/km).");
        var item = await db.CatalogItems.FindOrNewAsync(input.ItemId, ct);
        item.Apply(input, ctx.Actor.PartyId, ctx.Clock.UtcNow);                // historia zmian w prj_flota
        return OperationResult.Ok(new { itemId = item.Id });
    }
}
```

Kod nie sprawdza uprawnień, nie pisze audytu i nie obsługuje ponowień — robi to potok. Szczegóły interfejsów: `docs/architecture/13-project-profiles.md` §5, skill `profile-extension`.

### 5.8. Frontend (Angular, biblioteka `profile-flota-ui`)

Szkic — ostateczny kształt SDK UI ustalają kroki S19 i S47:

```ts
export const flotaUi: ProfileUiModule = {
  id: "flota",
  routes: [{ path: "katalog", loadComponent: () => import("./catalog.page").then(m => m.CatalogPage) }],   // /p/flota/katalog
  slots: [
    { slot: "nav.section", component: FleetNavSectionComponent },
    { slot: "dashboard.widget", component: CatalogWidgetComponent },
    { slot: "form.field", component: CarModelSelectComponent, when: { process: "rejestracja-samochodu" } },
  ],
  actions: [                                                         // formularz parametrów operacji; przycisk i potwierdzenie — powłoka
    { operation: "flota.SaveCatalogItem", form: CatalogItemFormComponent },
    { operation: "flota.WithdrawCatalogItem", confirm: "Wycofać model z katalogu? Wnioski w toku zachowają wybrany model." },
  ],
}
```

- Komponent strony pobiera dane zapytaniem profilu; przyciski „Dodaj model”, „Zmień”, „Wycofaj” pojawiają się tylko wtedy, gdy `allowedActions` wyniku je zawiera.
- Biblioteka ma tag Nx `scope:profile-flota` i zależy wyłącznie od `scope:extension-sdk`; platforma jej nie importuje.
- Kolory, odstępy i krój — wyłącznie z `design/tokens.json` przez `core/ui-kit`; teksty w `profiles/flota/frontend/i18n/pl.json`.
- Wzór wyglądu i zachowania: makieta, persona Karol → „Flota” → „Katalog samochodów”.

### 5.9. Scenariusze i testy

- Scenariusze w `profiles/flota/specs/` (`# language: pl`, tagi `@FLO-FR-xx`): kto widzi stronę i sekcję (także odmowy dla innych profili), kto zmienia katalog, walidacja polityki, idempotencja, R9 dla źródła danych formatki, izolacja bazy (`@integration`).
- Testy w CI profilu: `dotnet test profiles/flota/backend`, testy architektury profili, `npx nx run-many … --projects=tag:scope:profile-flota`, strażnik `enforce_write_scope.py --verify-diff origin/main --profile flota`.

### 5.10. PR, wdrożenie i eksploatacja

- PR przeglądają `CODEOWNERS` profilu; `profile.yaml` także architekt platformy, `authorization.yaml` także bezpieczeństwo. Klasa danych `restricted` wymaga przeglądu bezpieczeństwa.
- Po scaleniu reconciler nadaje autoryzacje, a profil rejestruje się przy starcie platformy (in-process: pociąg wydań; remote: wydania zespołu).
- Zmiany w katalogu po wdrożeniu nie wymagają wydania — to dane profilu zmieniane operacją `profile-action`, każda zmiana z wpisem w dzienniku.

## 6. Wzorzec: zadanie udostępnione kilku komórkom banku

Opiniowanie w profilu `flota` trafia jednocześnie do IT, HR, Prawnego, Finansów i Ryzyka. Każda komórka widzi i przejmuje tylko swoje zadanie, a nowa komórka nie wymaga zmiany modelu.

1. **Jedna rola, wiele grup.** Rola `opiniujacy` (Uczestnik w `opiniowanie-rejestracji`) przypisana do pięciu grup AD; każda komórka ma też własną grupę kandydującą:

   ```yaml
   assignments:
     - { group: PH-FLOTA-OPINIA-IT, roles: [opiniujacy] }
     - { group: PH-FLOTA-OPINIA-HR, roles: [opiniujacy] }
     # … Prawny, Finanse, Ryzyko
   candidateGroups:
     flota-opinia-it: PH-FLOTA-OPINIA-IT
     flota-opinia-hr: PH-FLOTA-OPINIA-HR
   ```

2. **Jedno zadanie wielokrotne w BPMN.** Lista komórek pochodzi ze zmiennej `routing.komorkiOpiniujace`, a grupa kandydująca każdej instancji — z elementu listy (praktyka C4):

   ```xml
   <bpmn:userTask id="OpiniaKomorki" name="Opinia komórki">
     <bpmn:extensionElements>
       <zeebe:userTask />
       <zeebe:assignmentDefinition candidateGroups="=[komorka.grupa]" />
       <zeebe:ioMapping>
         <zeebe:input source="=null" target="opinia" />      <!-- zmienne lokalne instancji: brak wyścigu między komórkami -->
         <zeebe:input source="=null" target="warunki" />
       </zeebe:ioMapping>
     </bpmn:extensionElements>
     <bpmn:multiInstanceLoopCharacteristics>
       <bpmn:extensionElements>
         <zeebe:loopCharacteristics inputCollection="=komorkiOpiniujace" inputElement="komorka"
           outputCollection="opinie" outputElement="={komorka: komorka.kod, opinia: opinia, warunki: warunki}" />
       </bpmn:extensionElements>
     </bpmn:multiInstanceLoopCharacteristics>
   </bpmn:userTask>
   ```

3. **Minimalne dane w procesie.** Do procesu wraca tylko komórka, opinia i warunki (C8). Uzasadnienie, które może zawierać dane osobowe, zapisuje rejestr opinii profilu (`event-handler`) w `prj_flota`; decydent widzi je w panelu `task.panel` z wzbogaceniem oznaczonym `sensitive: true` (każdy odczyt w dzienniku).
4. **Nowa komórka** = grupa AD i grupa kandydująca w `authorization.yaml` + wpis w `routing.komorkiOpiniujace`. Bez zmiany BPMN i bez wdrożenia modelu.

Pełny model: `profiles/flota/bpmn/opiniowanie-rejestracji.bpmn`; diagramy i mapa etapów: `profiles/flota/README.md`.

## 7. Ściąga: rodzaje operacji w manifeście

| `kind` | Kontekst | `appliesTo` | `requiresAssignee` | Uprawnienie | Uwagi |
| --- | --- | --- | --- | --- | --- |
| `task-action` | zadanie | proces (i zadania) profilu | zawsze `true` (R1) | projektu albo platformy | zapis szkicu przez `ctx.Tasks` |
| `case-action` | instancja procesu | proces profilu | jawnie `true` albo `false` | projektu albo platformy | |
| `profile-action` | dane profilu | **brak** | jawnie `false` | projektu, rodzaju `write` | SDK 1.1, ADR-017 |
| `task-enricher` | widok zadania | proces (i zadania) profilu | — | projektu albo platformy | `sensitive: true` przy odczycie wrażliwym |
| `form-data-source` | formatka procesu profilu | — | — | projektu albo platformy | |
| `query` | trasa, widżet | — | — | projektu albo platformy | wynik z `allowedActions` |
| `event-handler` | zdarzenia platformy | — | — | wymagane przez schemat | tylko procesy profilu |

Każda operacja: identyfikator `<id>.NazwaOperacji` (R10), uprawnienie istniejące w manifeście albo w katalogu platformy, odczyt wrażliwy z `sensitive: true`.

## 8. Lista kontrolna przed PR

- [ ] Każdy dedykowany element ma wpis w `profile.yaml`; identyfikatory w kodzie = identyfikatory w manifeście.
- [ ] Uprawnienie podglądu mają wszystkie role, które mają widzieć element; uprawnienie zapisu — tylko wąska rola.
- [ ] Trasy pod `/p/<id>/`; sekcja `nav.section` i trasy z uprawnieniem.
- [ ] Operacje zapisu: `requiresAssignee` zadeklarowane (`task-action`: `true`, `profile-action`: `false`); odczyty wrażliwe `sensitive: true`.
- [ ] Scenariusze: dostęp dla ról profilu, odmowa (z wpisem w dzienniku) dla innych profili i ról, audyt z rolą `<profil>/<rola>`, idempotencja, R9.
- [ ] Brak wartości danych osobowych w audycie i logach.
- [ ] Wygląd z `design/tokens.json`; teksty w i18n profilu; tekst odmowy mówi, dlaczego i że próba trafiła do dziennika.
- [ ] `validate_profiles.py --check`, testy profilu, testy architektury, Nx i strażnik zakresu zapisu — zielone.
- [ ] Potrzeba spoza punktów rozszerzeń → RFC w `docs/rfc/`, nie kod platformy.

## 9. Gdzie szukać

| Temat | Plik |
| --- | --- |
| Profile i punkty rozszerzeń | `docs/architecture/13-project-profiles.md`, ADR-012, ADR-017 |
| Role, uprawnienia, reguły R1–R11 | `docs/architecture/02-roles-and-authorization.md` |
| Praktyki Camunda (C1–C21), lint BPMN | `docs/architecture/06-camunda-integration.md` |
| Frontend, sloty, `allowedActions` | `docs/architecture/11-frontend.md`, `design/README.md` |
| Izolacja danych profilu | ADR-014 |
| Przykład kompletnego profilu | `profiles/flota/` (README, manifest, BPMN, scenariusze, plan) |
| Założenie profilu, lista kontrolna wydania | `profiles/README.md` |
| Kod na SDK | skill `.opencode/skills/profile-extension/SKILL.md` |

## Plik: profiles/profile.schema.json

````json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://process-hub.bank.local/schemas/profile.schema.json",
  "title": "Profil projektu Process Hub",
  "description": "Kontrakt profilu projektu z platformą: procesy, role projektowe, uprawnienia, dane, operacje dedykowane, rozszerzenia UI i integracje. Reguły międzyprofilowe sprawdza tools/profiles/validate_profiles.py.",
  "type": "object",
  "additionalProperties": false,
  "required": ["apiVersion", "kind", "id", "name", "owner", "tenant", "sdk", "processes", "roles", "data"],
  "properties": {
    "apiVersion": {"const": "processhub/v1"},
    "kind": {"const": "ProjectProfile"},
    "id": {"type": "string", "pattern": "^[a-z][a-z0-9]{1,23}$", "description": "Przestrzeń nazw profilu: uprawnienia, operacje, typy zadań, schemat danych."},
    "name": {"type": "string", "minLength": 2},
    "description": {"type": "string"},
    "owner": {
      "type": "object", "additionalProperties": false, "required": ["team", "productOwner"],
      "properties": {
        "team": {"type": "string", "pattern": "^@[A-Za-z0-9._/-]+$", "description": "Grupa w systemie kontroli wersji (CODEOWNERS)."},
        "productOwner": {"type": "string"},
        "contact": {"type": "string"}
      }
    },
    "tenant": {"type": "string"},
    "sdk": {"type": "string", "pattern": "^\\^?[0-9]+\\.[0-9]+$", "description": "Wymagana wersja SDK rozszerzeń (semver, np. ^1.0)."},
    "integration": {"enum": ["in-process", "remote"], "default": "in-process", "description": "in-process: moduł w hoście platformy; remote: usługa zespołu wywoływana przez platformę (ADR-012)."},
    "processes": {
      "type": "array", "minItems": 1,
      "items": {"type": "object", "additionalProperties": false, "required": ["bpmnProcessId"],
                "properties": {"bpmnProcessId": {"type": "string", "pattern": "^[a-z][a-z0-9-]+$"}, "name": {"type": "string"}}}
    },
    "permissions": {
      "type": "array",
      "items": {"type": "object", "additionalProperties": false, "required": ["id", "kind", "description"],
                "properties": {"id": {"type": "string", "pattern": "^[a-z][a-z0-9]+\\.[A-Z][A-Za-z]+\\.[A-Z][A-Za-z]+$"},
                               "kind": {"enum": ["read", "write", "sensitive-read"]},
                               "description": {"type": "string"}}}
    },
    "roles": {
      "type": "array", "minItems": 1,
      "items": {"type": "object", "additionalProperties": false, "required": ["id", "name", "platformRoles"],
                "properties": {"id": {"type": "string", "pattern": "^[a-z][a-z0-9-]+$"},
                               "name": {"type": "string"},
                               "platformRoles": {"type": "array", "items": {"enum": ["participant", "process-starter", "process-manager", "process-administrator"]}},
                               "permissions": {"type": "array", "items": {"type": "string"}},
                               "processes": {"type": "array", "items": {"type": "string"}, "description": "Podzbiór procesów profilu; brak = wszystkie."}}}
    },
    "data": {
      "type": "object", "additionalProperties": false, "required": ["schema", "classification"],
      "properties": {"schema": {"type": "string", "pattern": "^prj_[a-z][a-z0-9]+$"},
                     "classification": {"enum": ["internal", "confidential", "restricted"]},
                     "retentionMonths": {"type": "integer", "minimum": 1},
                     "entities": {"type": "array", "items": {"type": "string"}}}
    },
    "operations": {
      "type": "array",
      "items": {"type": "object", "additionalProperties": false, "required": ["id", "kind", "permission"],
                "properties": {"id": {"type": "string", "pattern": "^[a-z][a-z0-9]+\\.[A-Z][A-Za-z]+$"},
                               "kind": {"enum": ["task-action", "case-action", "profile-action", "task-enricher", "form-data-source", "query", "event-handler"],
                                        "description": "profile-action: zapis danych profilu (prj_<id>) bez zadania i sprawy — od SDK 1.1 (ADR-017)."},
                               "title": {"type": "string"},
                               "permission": {"type": "string"},
                               "appliesTo": {"type": "object", "additionalProperties": false,
                                      "properties": {"process": {"type": "string"}, "tasks": {"type": "array", "items": {"type": "string"}}}},
                               "requiresAssignee": {"type": "boolean"},
                               "sensitive": {"type": "boolean"},
                               "idempotent": {"type": "boolean"},
                               "description": {"type": "string"}}}
    },
    "ui": {
      "type": "object", "additionalProperties": false,
      "properties": {
        "routes": {"type": "array", "items": {"type": "object", "additionalProperties": false, "required": ["path", "title", "permission"],
                   "properties": {"path": {"type": "string"}, "title": {"type": "string"}, "permission": {"type": "string"}}}},
        "slots": {"type": "array", "items": {"type": "object", "additionalProperties": false, "required": ["slot", "component"],
                  "properties": {"slot": {"enum": ["task.panel", "case.panel", "dashboard.widget", "form.field", "nav.section"]},
                                 "component": {"type": "string"}, "title": {"type": "string"}, "permission": {"type": "string"},
                                 "appliesTo": {"type": "object", "additionalProperties": false,
                                        "properties": {"process": {"type": "string"}, "tasks": {"type": "array", "items": {"type": "string"}}}}}}}
      }
    },
    "integrations": {
      "type": "object", "additionalProperties": false,
      "properties": {"jobTypes": {"type": "array", "items": {"type": "string"}},
                     "externalSystems": {"type": "array", "items": {"type": "object", "additionalProperties": false, "required": ["name", "via"],
                                         "properties": {"name": {"type": "string"}, "via": {"enum": ["job-worker", "operation", "remote"]}, "notes": {"type": "string"}}}}}
    },
    "dev": {
      "type": "object", "additionalProperties": false,
      "properties": {"agents": {"type": "array", "items": {"enum": ["module-implementer", "bdd-tester", "bdd-analyst", "frontend-developer", "data-engineer", "docs-writer"]}},
                     "dataClass": {"enum": ["internal", "confidential", "restricted"]},
                     "backlog": {"type": "string"}}
    }
  }
}
````

## Plik: profiles/_template/authorization.yaml

````yaml
profile: __ID__
assignments:
  - { group: PH-__GROUP__-UCZESTNICY, roles: [uczestnik-__ID__] }
  - { group: PH-__GROUP__-MGR, roles: [kierownik-__ID__] }
candidateGroups: {}
````

## Plik: profiles/_template/backlog.yaml

````yaml
version: 1
profile: __ID__
parallelism: 2
retries_per_tier: 2
escalation: [T3, T2, T1, human]
gates: {}
steps:
  - id: __PREFIX__-01
    title: Moduł profilu i schemat prj___ID__ z szablonu, testy zgodności SDK
    agent: module-implementer
    tier: T2
    size: M
    depends_on: [S27]
    reads: [profiles/__ID__/AGENTS.md, profiles/__ID__/profile.yaml, docs/architecture/13-project-profiles.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/__ID__/backend/**", "profiles/__ID__/db/**"]
    specs: []
    dod: ["python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile __ID__"]
````

## Plik: profiles/_template/profile.yaml

````yaml
# Profil projektu „__NAME__” — kontrakt z platformą Process Hub (schemat: profiles/profile.schema.json).
apiVersion: processhub/v1
kind: ProjectProfile
id: __ID__
name: __NAME__
description: __OPIS__
owner:
  team: "__TEAM__"
  productOwner: __PO__
tenant: "<default>"
sdk: "^1.0"
integration: in-process            # albo remote (usługa zespołu, ADR-012)

processes:
  - { bpmnProcessId: __PROCESS__ }

permissions: []                    # { id: __ID__.Obszar.Akcja, kind: read | write | sensitive-read, description: … }

roles:
  - id: uczestnik-__ID__
    name: Uczestnik procesów __NAME__
    platformRoles: [participant]
    permissions: []
  - id: kierownik-__ID__
    name: Kierownik __NAME__
    platformRoles: [process-manager]
    permissions: []

data:
  schema: prj___ID__
  classification: confidential
  retentionMonths: 60

operations: []                     # { id: __ID__.NazwaOperacji, kind: task-action | case-action | profile-action | task-enricher | form-data-source | query | event-handler, permission: … }

ui:
  slots: []

integrations:
  jobTypes: ["__ID__.*"]

dev:
  agents: [module-implementer, bdd-tester, frontend-developer]
  dataClass: confidential
  backlog: profiles/__ID__/backlog.yaml
````

## Plik: profiles/_template/AGENTS.md

# AGENTS.md — profil „__ID__”

Pracujesz dla zespołu „__NAME__”. Część specyficzną profilu realizujesz wyłącznie w `profiles/__ID__/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości.

## Granice

- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`).
- Działasz tylko na procesach z `profile.yaml` (R9); uprawnienia, operacje i typy zadań mają prefiks `__ID__.` (R10).
- Dane: schemat `prj___ID__`; dane platformy tylko przez widoki `platform_api`.
- Zmiana kontraktu (`profile.yaml`, `authorization.yaml`) — zatwierdza też architekt platformy. Brak punktu rozszerzenia → RFC w `docs/rfc/`.

## Komendy

```bash
dotnet test profiles/__ID__/backend --filter "Category!=integration"
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile __ID__
```

## Plik: profiles/aml/profile.yaml

````yaml
# Profil projektu „AML” — kontrakt z platformą Process Hub (schemat: profiles/profile.schema.json).
# Zespół AML realizuje część specyficzną jako osobną usługę (integration: remote) — własne wdrożenia i technologia.
apiVersion: processhub/v1
kind: ProjectProfile
id: aml
name: Przeciwdziałanie praniu pieniędzy (AML)
description: Weryfikacja klientów i transakcji — analiza, ponowna weryfikacja sankcji, eksport sprawy dla nadzoru.
owner:
  team: "@bank/zespol-aml"
  productOwner: Właściciel procesów AML
  contact: aml-dev@bank.example
tenant: "<default>"
sdk: "^1.0"
integration: remote

processes:
  - { bpmnProcessId: weryfikacja-aml, name: Weryfikacja AML }

permissions:
  - { id: aml.Sanctions.Recheck, kind: write, description: Ponowne sprawdzenie list sankcyjnych w zadaniu analizy }
  - { id: aml.Party.View, kind: sensitive-read, description: Profil ryzyka klienta }
  - { id: aml.Case.Export, kind: sensitive-read, description: Eksport sprawy dla organu nadzoru }

roles:
  - id: analityk-aml
    name: Analityk AML
    platformRoles: [participant]
    permissions: [aml.Sanctions.Recheck, aml.Party.View]
  - id: kierownik-aml
    name: Kierownik zespołu AML
    platformRoles: [process-manager]
    permissions: [aml.Party.View, aml.Case.Export]

data:
  schema: prj_aml
  classification: restricted
  retentionMonths: 60
  entities: [ProfilRyzykaKlienta, WynikSankcji, PaczkaEksportu]

operations:
  - id: aml.RecheckSanctions
    kind: task-action
    title: Sprawdź sankcje ponownie
    permission: aml.Sanctions.Recheck
    appliesTo: { process: weryfikacja-aml, tasks: [AnalizaAml] }
    requiresAssignee: true
    idempotent: true
  - id: aml.PartyRiskProfile
    kind: task-enricher
    permission: aml.Party.View
    appliesTo: { process: weryfikacja-aml }
    sensitive: true
  - id: aml.CaseExport
    kind: case-action
    title: Eksport sprawy dla nadzoru
    permission: aml.Case.Export
    appliesTo: { process: weryfikacja-aml }
    requiresAssignee: false
    sensitive: true
    description: Paczka dokumentów sprawy dla organu nadzoru — odczyt wrażliwy, zawsze w dzienniku bezpieczeństwa.

ui:
  slots:
    - { slot: task.panel, component: PartyRiskPanelComponent, title: Profil ryzyka, permission: aml.Party.View, appliesTo: { process: weryfikacja-aml } }
    - { slot: case.panel, component: CaseExportPanelComponent, title: Eksport dla nadzoru, permission: aml.Case.Export, appliesTo: { process: weryfikacja-aml } }

integrations:
  jobTypes: ["aml.*"]
  externalSystems:
    - { name: Usługa AML zespołu, via: remote, notes: operacje profilu wywoływane przez platformę (kontrakt profile-operations v1) }
    - { name: Listy sankcyjne, via: job-worker }

dev:
  agents: [module-implementer, bdd-tester, frontend-developer]
  dataClass: restricted
  backlog: profiles/aml/backlog.yaml
````

## Plik: profiles/flota/profile.yaml

````yaml
# Profil projektu „Flota samochodowa” — kontrakt z platformą Process Hub (schemat: profiles/profile.schema.json).
# Przykład dedykowanych elementów jednego projektu: sekcja nawigacji „Flota” z katalogiem samochodów widocznym tylko
# dla ról tego profilu, operacje na danych profilu (ADR-017), pole formatki z katalogu i panel opinii komórek banku.
# Opis i diagramy: profiles/flota/README.md · przewodnik dla zespołów: docs/guides/dedykowane-elementy-profilu.md.
# Właściciel: zespół floty; zmiany tego pliku zatwierdza też architekt platformy (CODEOWNERS).
apiVersion: processhub/v1
kind: ProjectProfile
id: flota
name: Flota samochodowa
description: Samochody służbowe — wniosek z katalogu floty, opinie komórek banku (IT, HR, Prawny, Finanse, Ryzyko), decyzja, zakup i rejestracja pojazdu.
owner:
  team: "@bank/zespol-flota"
  productOwner: Kierownik Działu Floty Samochodowej
  contact: flota-dev@bank.example
tenant: "<default>"
sdk: "^1.1"                              # operacje na danych profilu (profile-action) — od SDK 1.1 (ADR-017)
integration: in-process

processes:
  - { bpmnProcessId: rejestracja-samochodu, name: Rejestracja samochodu służbowego }
  - { bpmnProcessId: opiniowanie-rejestracji, name: Opiniowanie rejestracji samochodu }   # proces podrzędny (call activity)

permissions:
  - { id: flota.Catalog.View, kind: read, description: Podgląd katalogu samochodów dostępnych do zakupu }
  - { id: flota.Catalog.Manage, kind: write, description: Dodawanie i zmiana modeli w katalogu oraz ich wycofywanie }
  - { id: flota.Opinion.ViewAll, kind: sensitive-read, description: Zestawienie opinii wszystkich komórek w zadaniu decyzji (opinia HR może zawierać dane osobowe) }
  - { id: flota.Delivery.Check, kind: write, description: Sprawdzenie ceny i terminu dostawy w systemie zakupowym z zapisem w szkicu zadania }

roles:                                   # rola projektowa = role platformy + uprawnienia projektu, w procesach profilu
  - id: wnioskodawca
    name: Wnioskodawca
    platformRoles: [process-starter]
    permissions: [flota.Catalog.View]
    processes: [rejestracja-samochodu]
  - id: koordynator-floty
    name: Koordynator floty
    platformRoles: [participant]
    permissions: [flota.Catalog.View]
    processes: [rejestracja-samochodu]
  - id: opiniujacy                       # jedna rola dla pięciu komórek; komórkę wyznacza grupa AD i grupa kandydująca
    name: Opiniujący (komórka banku)
    platformRoles: [participant]
    permissions: [flota.Catalog.View]
    processes: [opiniowanie-rejestracji]
  - id: decydent-floty
    name: Decydent floty
    platformRoles: [participant]
    permissions: [flota.Catalog.View, flota.Opinion.ViewAll, flota.Delivery.Check]
    processes: [rejestracja-samochodu]
  - id: kierownik-floty
    name: Kierownik floty
    platformRoles: [process-manager]
    permissions: [flota.Catalog.View, flota.Opinion.ViewAll]
  - id: administrator-procesow-floty     # konfiguruje procesy (formatki, mapa etapów) — bez prawa zmiany katalogu
    name: Administrator procesów floty
    platformRoles: [process-administrator]
    permissions: [flota.Catalog.View]
  - id: administrator-katalogu           # druga rola administracyjna: tylko opcja dedykowana, bez ról platformy
    name: Administrator katalogu samochodów
    platformRoles: []
    permissions: [flota.Catalog.View, flota.Catalog.Manage]

data:
  schema: prj_flota
  classification: confidential           # opinie komórek mogą zawierać dane osobowe pracownika
  retentionMonths: 84
  entities: [ModelSamochodu, ZmianaKatalogu, OpiniaKomorki]

operations:
  - id: flota.CarCatalog
    kind: query
    title: Katalog samochodów
    permission: flota.Catalog.View
    description: Modele z katalogu z liczbą wniosków w toku (widoki platform_api); wynik z allowedActions operacji katalogu dla strony /p/flota/katalog i widżetu pulpitu.
  - id: flota.SaveCatalogItem
    kind: profile-action
    title: Zapisz model w katalogu
    permission: flota.Catalog.Manage
    requiresAssignee: false
    idempotent: true
    description: Dodanie nowego modelu albo zmiana istniejącego z walidacją polityki floty (np. limit emisji CO2); historia zmian w prj_flota.
  - id: flota.WithdrawCatalogItem
    kind: profile-action
    title: Wycofaj model z katalogu
    permission: flota.Catalog.Manage
    requiresAssignee: false
    idempotent: true
    description: Model znika z formatek nowych wniosków; wnioski w toku zachowują wybrany model.
  - id: flota.CarModels
    kind: form-data-source
    permission: flota.Catalog.View
    description: Dostępne modele dla pola „Model samochodu” w formatkach procesów profilu — formatki innych procesów nie mogą go wywołać (R9).
  - id: flota.CheckDeliveryTerms
    kind: task-action
    title: Sprawdź cenę i termin dostawy
    permission: flota.Delivery.Check
    appliesTo: { process: rejestracja-samochodu, tasks: [DecyzjaOPrzydziale] }
    requiresAssignee: true
    idempotent: true
    description: Pobiera z systemu zakupowego aktualną cenę i termin dostawy wybranego modelu i zapisuje je w szkicu zadania decyzji.
  - id: flota.OpinionsSummary
    kind: task-enricher
    permission: flota.Opinion.ViewAll
    appliesTo: { process: rejestracja-samochodu, tasks: [DecyzjaOPrzydziale] }
    sensitive: true
    description: Sekcja „Opinie komórek” w widoku zadania decyzji — komórka, opinia, warunki, uzasadnienie i autor (odczyt wrażliwy — audytowany).
  - id: flota.OpinionRegister
    kind: event-handler
    permission: Task.ViewOwn
    description: Zapisuje w prj_flota opinie z zakończonych zadań OpiniaKomorki (zdarzenia platformy tylko z procesów profilu).

ui:
  routes:
    - { path: /p/flota/katalog, title: Katalog samochodów, permission: flota.Catalog.View }
  slots:
    - { slot: nav.section, component: FleetNavSectionComponent, title: Flota, permission: flota.Catalog.View }
    - { slot: dashboard.widget, component: CatalogWidgetComponent, title: Katalog samochodów, permission: flota.Catalog.View }
    - { slot: form.field, component: CarModelSelectComponent, title: Model samochodu z katalogu, permission: flota.Catalog.View, appliesTo: { process: rejestracja-samochodu } }
    - { slot: task.panel, component: OpinionsPanelComponent, title: Opinie komórek, permission: flota.Opinion.ViewAll, appliesTo: { process: rejestracja-samochodu, tasks: [DecyzjaOPrzydziale] } }

integrations:
  jobTypes: ["flota.*"]
  externalSystems:
    - { name: System zakupowy — cennik i terminy, via: operation, notes: wywołanie synchroniczne z operacji CheckDeliveryTerms }
    - { name: System zakupowy — zamówienia, via: job-worker, notes: service task flota.zamowienie.zloz }
    - { name: Ewidencja floty, via: job-worker, notes: service task flota.ewidencja.dodaj }

dev:
  agents: [module-implementer, bdd-tester, frontend-developer, data-engineer]
  dataClass: confidential
  backlog: profiles/flota/backlog.yaml
````

## Plik: profiles/kredyty/profile.yaml

````yaml
# Profil projektu „Kredyty” — kontrakt z platformą Process Hub (schemat: profiles/profile.schema.json).
# Właściciel: zespół kredytów; zmiany tego pliku zatwierdza też architekt platformy (CODEOWNERS).
apiVersion: processhub/v1
kind: ProjectProfile
id: kredyty
name: Kredyty
description: Wnioski i aneksy kredytowe — ocena, akceptacja underwritera, oferta.
owner:
  team: "@bank/zespol-kredyty"
  productOwner: Właściciel produktu kredytowego
  contact: kredyty-dev@bank.example
tenant: "<default>"
sdk: "^1.0"
integration: in-process

processes:
  - { bpmnProcessId: wniosek-kredytowy, name: Wniosek kredytowy }
  - { bpmnProcessId: aneks-kredytowy, name: Aneks kredytowy }

permissions:
  - { id: kredyty.Scoring.Recalculate, kind: write, description: Ponowne przeliczenie scoringu w zadaniu oceny }
  - { id: kredyty.Applicant.View, kind: sensitive-read, description: Podgląd danych wnioskodawcy z systemów kredytowych }
  - { id: kredyty.Limit.Override, kind: write, description: Odstępstwo od limitu z uzasadnieniem (underwriter) }
  - { id: kredyty.Portfolio.Report, kind: read, description: Raport portfela wniosków dla kierownika }

roles:                                   # rola projektowa = role platformy + uprawnienia projektu, w procesach profilu
  - id: analityk-kredytowy
    name: Analityk kredytowy
    platformRoles: [participant, process-starter]
    permissions: [kredyty.Scoring.Recalculate, kredyty.Applicant.View]
    processes: [wniosek-kredytowy]
  - id: underwriter
    name: Underwriter
    platformRoles: [participant]
    permissions: [kredyty.Applicant.View, kredyty.Limit.Override]
    processes: [wniosek-kredytowy]
  - id: kierownik-kredytow
    name: Kierownik zespołu kredytowego
    platformRoles: [process-manager]
    permissions: [kredyty.Applicant.View, kredyty.Portfolio.Report]
  - id: administrator-procesow-kredytowych
    name: Administrator procesów kredytowych
    platformRoles: [process-administrator]

data:
  schema: prj_kredyty
  classification: confidential
  retentionMonths: 120
  entities: [Wnioskodawca, WynikScoringu, OdstepstwoOdLimitu]

operations:
  - id: kredyty.RecalculateScoring
    kind: task-action
    title: Przelicz scoring
    permission: kredyty.Scoring.Recalculate
    appliesTo: { process: wniosek-kredytowy, tasks: [OcenaWniosku] }
    requiresAssignee: true
    idempotent: true
    description: Pobiera aktualny scoring z systemu scoringowego, zapisuje wynik w prj_kredyty i w szkicu zadania.
  - id: kredyty.OverrideLimit
    kind: task-action
    title: Odstępstwo od limitu
    permission: kredyty.Limit.Override
    appliesTo: { process: wniosek-kredytowy, tasks: [AkceptacjaUnderwritera] }
    requiresAssignee: true
    sensitive: true
  - id: kredyty.ApplicantSummary
    kind: task-enricher
    permission: kredyty.Applicant.View
    appliesTo: { process: wniosek-kredytowy }
    sensitive: true
    description: Sekcja „Wnioskodawca” w widoku zadania (odczyt wrażliwy — audytowany).
  - id: kredyty.ProductCatalog
    kind: form-data-source
    permission: Task.ViewOwn
    description: Słownik produktów kredytowych dla pól formatek.
  - id: kredyty.PortfolioReport
    kind: query
    permission: kredyty.Portfolio.Report
  - id: kredyty.ScoringResultProjection
    kind: event-handler
    permission: Task.ViewOwn
    description: Buduje read model profilu ze zdarzeń platformy (TaskCompleted, ProcessEnded) dla procesów profilu.

ui:
  routes:
    - { path: /p/kredyty/portfel, title: Portfel wniosków, permission: kredyty.Portfolio.Report }
  slots:
    - { slot: task.panel, component: ApplicantPanelComponent, title: Wnioskodawca, permission: kredyty.Applicant.View, appliesTo: { process: wniosek-kredytowy } }
    - { slot: dashboard.widget, component: PortfolioWidgetComponent, title: Portfel wniosków, permission: kredyty.Portfolio.Report }
    - { slot: form.field, component: ProductSelectComponent, title: Produkt kredytowy }

integrations:
  jobTypes: ["kredyty.*"]
  externalSystems:
    - { name: System scoringowy, via: operation, notes: wywołanie synchroniczne z operacji RecalculateScoring }
    - { name: Rejestr kredytowy, via: job-worker, notes: service task kredyty.rejestr.sprawdz }

dev:
  agents: [module-implementer, bdd-tester, bdd-analyst, frontend-developer, data-engineer]
  dataClass: confidential
  backlog: profiles/kredyty/backlog.yaml
````

## Plik: profiles/aml/authorization.yaml

````yaml
profile: aml
assignments:
  - { group: PH-AML-ANALITYCY, roles: [analityk-aml] }
  - { group: PH-AML-MGR, roles: [kierownik-aml] }
candidateGroups:
  aml-analitycy: PH-AML-ANALITYCY
````

## Plik: profiles/flota/authorization.yaml

````yaml
# Przypisania ról projektowych profilu „flota” do grup AD. Reconciler łączy ten plik z config/authorization/
# i sprawdza: role istnieją w profile.yaml, grupy AD i grupy kandydujące nie kolidują z innymi profilami (R10).
# Opiniowanie jest udostępnione pięciu komórkom banku: ta sama rola „opiniujacy”, osobna grupa AD i osobna grupa
# kandydująca dla każdej komórki — każda komórka widzi i przejmuje tylko swoje zadanie opinii (R2, R3).
profile: flota
assignments:
  - { group: PH-FLOTA-WNIOSKODAWCY, roles: [wnioskodawca] }
  - { group: PH-FLOTA-KOORDYNATORZY, roles: [koordynator-floty] }
  - { group: PH-FLOTA-OPINIA-IT, roles: [opiniujacy] }
  - { group: PH-FLOTA-OPINIA-HR, roles: [opiniujacy] }
  - { group: PH-FLOTA-OPINIA-PRAWNY, roles: [opiniujacy] }
  - { group: PH-FLOTA-OPINIA-FINANSE, roles: [opiniujacy] }
  - { group: PH-FLOTA-OPINIA-RYZYKO, roles: [opiniujacy] }
  - { group: PH-FLOTA-DECYDENCI, roles: [decydent-floty] }
  - { group: PH-FLOTA-MGR, roles: [kierownik-floty] }
  - { group: PH-FLOTA-ADM, roles: [administrator-procesow-floty] }
  - { group: PH-FLOTA-KATALOG, roles: [administrator-katalogu] }
candidateGroups:                       # identyfikatory grup kandydujących w BPMN profilu → grupy AD
  flota-koordynatorzy: PH-FLOTA-KOORDYNATORZY
  flota-decydenci: PH-FLOTA-DECYDENCI
  flota-opinia-it: PH-FLOTA-OPINIA-IT
  flota-opinia-hr: PH-FLOTA-OPINIA-HR
  flota-opinia-prawny: PH-FLOTA-OPINIA-PRAWNY
  flota-opinia-finanse: PH-FLOTA-OPINIA-FINANSE
  flota-opinia-ryzyko: PH-FLOTA-OPINIA-RYZYKO
````

## Plik: profiles/kredyty/authorization.yaml

````yaml
# Przypisania ról projektowych profilu „kredyty” do grup AD. Reconciler łączy ten plik z config/authorization/
# i sprawdza: role istnieją w profile.yaml, grupy kandydujące nie kolidują z innymi profilami (R10).
profile: kredyty
assignments:
  - { group: PH-KREDYT-ANALITYCY, roles: [analityk-kredytowy] }
  - { group: PH-KREDYT-UNDERWRITING, roles: [underwriter] }
  - { group: PH-KREDYT-MGR, roles: [kierownik-kredytow] }
  - { group: PH-KREDYT-ADM, roles: [administrator-procesow-kredytowych] }
candidateGroups:                       # identyfikatory grup kandydujących w BPMN profilu → grupy AD
  kre-analitycy: PH-KREDYT-ANALITYCY
  kre-underwriting: PH-KREDYT-UNDERWRITING
````

## Plik: profiles/flota/README.md

# Profil „flota” — rejestracja samochodu służbowego z opiniami komórek banku

Przykładowy profil projektu, który pokazuje komplet **dedykowanych elementów jednego projektu**: własną sekcję nawigacji „Flota” z katalogiem samochodów, który widzą wyłącznie role tego profilu, rolę administracyjną, która uzupełnia katalog, pole formatki korzystające z katalogu i panel z opiniami komórek w zadaniu decyzji. Żaden inny proces ani profil nie widzi katalogu i nie może z niego korzystać.

Kontrakt z platformą: `profile.yaml`, `authorization.yaml` · plan zespołu: `backlog.yaml` (FLO-01…FLO-05) · scenariusze: `specs/` · modele: `bpmn/` · przewodnik dla zespołów: `docs/guides/dedykowane-elementy-profilu.md` · klikalna makieta: `design/mockups/index.html` (persony Tomasz, Hanna, Karol).

## Procesy

| Proces | `bpmnProcessId` | Kto startuje | Etapy (mapa etapów) |
| --- | --- | --- | --- |
| Rejestracja samochodu służbowego | `rejestracja-samochodu` | Wnioskodawca, z formatki startowej z polem „Model samochodu z katalogu” | Wniosek → Opiniowanie → Decyzja → Zakup i rejestracja → Zakończenie |
| Opiniowanie rejestracji samochodu | `opiniowanie-rejestracji` | wyłącznie proces główny (call activity) | Opinie komórek → Podsumowanie |

```mermaid
flowchart LR
  S(("Wniosek złożony<br/>model z katalogu")) --> W["Weryfikacja wniosku<br/>Koordynator floty"]
  W --> K{"Wniosek<br/>kompletny?"}
  K -- nie --> Z(("Wniosek<br/>zwrócony"))
  K -- tak --> O
  subgraph O["Opiniowanie rejestracji samochodu — proces podrzędny"]
    direction TB
    OS(("start")) --> IT["Opinia: IT"] & HR["Opinia: HR"] & PR["Opinia: Prawny"] & FI["Opinia: Finanse"] & RY["Opinia: Ryzyko"]
    IT & HR & PR & FI & RY --> P["Podsumuj opinie<br/>rekomendacja"]
  end
  O --> D["Decyzja o przydziale<br/>Decydent floty<br/>panel „Opinie komórek”"]
  D --> G{"Decyzja?"}
  G -- odmowa --> R(("Wniosek<br/>odrzucony"))
  G -- przydział --> ZZ["Złóż zamówienie u dealera<br/>worker flota.zamowienie.zloz"]
  ZZ --> RP["Rejestracja pojazdu<br/>Koordynator floty"]
  RP --> E["Wpisz do ewidencji floty<br/>worker flota.ewidencja.dodaj"]
  E --> OK(("Samochód<br/>zarejestrowany"))
```

Model techniczny (Camunda 8.9): `bpmn/rejestracja-samochodu.bpmn` i `bpmn/opiniowanie-rejestracji.bpmn` — otwórz w Camunda Modeler. W modelu opinie to **jedno zadanie wielokrotne** „Opinia komórki” (`OpiniaKomorki`): Camunda tworzy tyle równoległych zadań, ile komórek jest na liście `routing.komorkiOpiniujace`, a każde dostaje grupę kandydującą swojej komórki (`candidateGroups="=[komorka.grupa]"`, praktyka C4).

### Opiniowanie przez komórki banku

| Komórka | Grupa kandydująca (BPMN) | Grupa AD | Co ocenia |
| --- | --- | --- | --- |
| IT | `flota-opinia-it` | `PH-FLOTA-OPINIA-IT` | telematyka, aplikacje mobilne i bezpieczeństwo urządzeń w samochodzie |
| HR | `flota-opinia-hr` | `PH-FLOTA-OPINIA-HR` | uprawnienie użytkownika do kategorii samochodu według regulaminu floty |
| Prawny | `flota-opinia-prawny` | `PH-FLOTA-OPINIA-PRAWNY` | forma nabycia (zakup, leasing, najem) i umowa z dealerem |
| Finanse | `flota-opinia-finanse` | `PH-FLOTA-OPINIA-FINANSE` | budżet centrum kosztów i sposób finansowania |
| Ryzyko | `flota-opinia-ryzyko` | `PH-FLOTA-OPINIA-RYZYKO` | ryzyko operacyjne, ubezpieczenie, zgodność z polityką emisji |

- Wszystkie komórki mają tę samą rolę projektową `flota/opiniujacy`; komórkę wyznacza grupa AD i grupa kandydująca. Każda komórka widzi i przejmuje wyłącznie swoje zadanie (R2, R3); opinię edytuje i kończy tylko assignee (R1).
- Opinia: **pozytywna**, **warunkowa** (z warunkami) albo **negatywna**. Skrypt „Podsumuj opinie” liczy rekomendację: negatywna, gdy choć jedna komórka jest przeciw; warunkowa, gdy któraś stawia warunki; inaczej pozytywna.
- Do procesu głównego wraca tylko lista `{komorka, opinia, warunki}` i rekomendacja (C8). Uzasadnienie opinii (może zawierać dane osobowe) zapisuje rejestr opinii profilu w `prj_flota` (`flota.OpinionRegister`); decydent widzi je w panelu „Opinie komórek” (odczyt wrażliwy, audytowany).
- Nowa komórka (np. Compliance) to konfiguracja, nie zmiana modelu: grupa AD i grupa kandydująca w `authorization.yaml` oraz wpis w `routing.komorkiOpiniujace`.

Zmienne startowe ustawia BFF z konfiguracji procesu (C4, C5):

```json
{
  "routing": {
    "koordynatorzy": ["flota-koordynatorzy"],
    "decydenci": ["flota-decydenci"],
    "komorkiOpiniujace": [
      { "kod": "it", "nazwa": "IT", "grupa": "flota-opinia-it" },
      { "kod": "hr", "nazwa": "HR", "grupa": "flota-opinia-hr" },
      { "kod": "prawny", "nazwa": "Prawny", "grupa": "flota-opinia-prawny" },
      { "kod": "finanse", "nazwa": "Finanse", "grupa": "flota-opinia-finanse" },
      { "kod": "ryzyko", "nazwa": "Ryzyko", "grupa": "flota-opinia-ryzyko" }
    ]
  },
  "sla": { "opinia": "P5D", "decyzja": "P2D" }
}
```

### Mapa etapów (zasiew `ph:stage`, ostateczną mapę ustala administrator procesu)

| Proces | Etap | Elementy BPMN | Cel SLA (propozycja) |
| --- | --- | --- | --- |
| rejestracja-samochodu | Wniosek | `WniosekZlozony`, `WeryfikacjaWniosku` | 1 dzień |
| | Opiniowanie | `OpiniowanieKomorek` (cały proces podrzędny) | 5 dni |
| | Decyzja | `DecyzjaOPrzydziale` (eskalacja `TerminDecyzjiPrzekroczony`) | 2 dni |
| | Zakup i rejestracja | `ZlozZamowienie`, `RejestracjaPojazdu`, `WpiszDoEwidencji` | 20 dni |
| | Zakończenie | `SamochodZarejestrowany` (success), `WniosekZwrocony` i `WniosekOdrzucony` (rejected) | — |
| opiniowanie-rejestracji | Opinie komórek | `OpiniowanieRozpoczete`, `OpiniaKomorki` (eskalacja `TerminOpiniiPrzekroczony`) | 5 dni |
| | Podsumowanie | `PodsumujOpinie`, `OpinieZebrane` (success) | — |

## Role projektowe

| Rola (`flota/<id>`) | Role platformy | Uprawnienia projektu | Procesy | Grupy AD | Co robi |
| --- | --- | --- | --- | --- | --- |
| `wnioskodawca` | Inicjator | `flota.Catalog.View` | rejestracja-samochodu | `PH-FLOTA-WNIOSKODAWCY` | przegląda katalog, składa wniosek, śledzi go w „Moich procesach” |
| `koordynator-floty` | Uczestnik | `flota.Catalog.View` | rejestracja-samochodu | `PH-FLOTA-KOORDYNATORZY` | weryfikuje wniosek, rejestruje pojazd |
| `opiniujacy` | Uczestnik | `flota.Catalog.View` | opiniowanie-rejestracji | `PH-FLOTA-OPINIA-IT`, `-HR`, `-PRAWNY`, `-FINANSE`, `-RYZYKO` | wydaje opinię swojej komórki |
| `decydent-floty` | Uczestnik | `flota.Catalog.View`, `flota.Opinion.ViewAll`, `flota.Delivery.Check` | rejestracja-samochodu | `PH-FLOTA-DECYDENCI` | decyduje o przydziale, sprawdza cenę i termin dostawy |
| `kierownik-floty` | Menadżer procesu | `flota.Catalog.View`, `flota.Opinion.ViewAll` | oba | `PH-FLOTA-MGR` | nadzór, przekazywanie, dashboard, eskalacje |
| `administrator-procesow-floty` | Administrator procesu | `flota.Catalog.View` | oba | `PH-FLOTA-ADM` | formatki, mapa etapów, widok techniczny — **bez** zmian katalogu |
| `administrator-katalogu` | — | `flota.Catalog.View`, `flota.Catalog.Manage` | dane profilu | `PH-FLOTA-KATALOG` | **uzupełnia katalog**: dodaje, zmienia i wycofuje modele |

Profil ma dwie role administracyjne. Konfigurację procesów prowadzi Administrator procesów floty (rola platformy Administrator procesu), a katalog — Administrator katalogu samochodów, który nie ma żadnej roli platformy, tylko uprawnienia projektu. Dzięki temu osoba prowadząca katalog nie zmienia formatek ani mapy etapów i odwrotnie (najmniejsze uprawnienia).

## Dedykowane elementy profilu

| Element | Punkt rozszerzenia (`profile.yaml`) | Uprawnienie | Gdzie w UI |
| --- | --- | --- | --- |
| Sekcja nawigacji „Flota” | `ui.slots: nav.section` → `FleetNavSectionComponent` | `flota.Catalog.View` | szuflada nawigacji, pod sekcjami platformy |
| Strona „Katalog samochodów” | `ui.routes: /p/flota/katalog` + zapytanie `flota.CarCatalog` (`query`) | `flota.Catalog.View` | `/p/flota/katalog` |
| Dodaj, zmień model | `flota.SaveCatalogItem` (`profile-action`, ADR-017) | `flota.Catalog.Manage` | przyciski na stronie katalogu z `allowedActions` |
| Wycofaj model | `flota.WithdrawCatalogItem` (`profile-action`) | `flota.Catalog.Manage` | jw., z oknem potwierdzenia |
| Widżet „Katalog samochodów” | `ui.slots: dashboard.widget` → `CatalogWidgetComponent` | `flota.Catalog.View` | pulpit |
| Pole „Model samochodu z katalogu” | `ui.slots: form.field` + źródło danych `flota.CarModels` (`form-data-source`) | `flota.Catalog.View` | formatka startowa procesu `rejestracja-samochodu` |
| Panel „Opinie komórek” | `ui.slots: task.panel` + `flota.OpinionsSummary` (`task-enricher`, `sensitive: true`) | `flota.Opinion.ViewAll` | zadanie „Decyzja o przydziale samochodu” |
| Sprawdź cenę i termin dostawy | `flota.CheckDeliveryTerms` (`task-action`, `requiresAssignee: true`) | `flota.Delivery.Check` | akcja zadania decyzji (tylko assignee, R1) |
| Rejestr opinii | `flota.OpinionRegister` (`event-handler`) | — (zdarzenia platformy z procesów profilu) | brak — dane dla panelu opinii |

### Kto co widzi

| Element | Role profilu `flota` | Administrator katalogu | Role innych profili (np. Anna — kredyty) | Audytor |
| --- | --- | --- | --- | --- |
| Sekcja „Flota”, strona i widżet katalogu | tak (podgląd) | tak (podgląd i edycja) | nie — brak sekcji; wejście z adresu = odmowa w dzienniku (R5) | nie (rola globalna bez uprawnień projektu) |
| Przyciski „Dodaj model”, „Zmień”, „Wycofaj” | nie | tak | nie | nie |
| Pole formatki z katalogu | tylko w formatkach procesów profilu | — | formatka innego procesu nie wywoła `flota.CarModels` (R9) | — |
| Zadanie opinii | komórka widzi tylko swoje zadanie | nie | nie | podgląd tylko do odczytu |
| Panel „Opinie komórek” | Decydent i Kierownik floty | nie | nie | nie |
| Wpisy dziennika (`flota.SaveCatalogItem`…) | — | — | — | tak, z rolą `flota/administrator-katalogu` |

### Uzupełnienie katalogu — przepływ

```mermaid
sequenceDiagram
  participant K as Administrator katalogu
  participant UI as Powłoka + profile-flota-ui
  participant API as Potok platformy
  participant AP as Access Policy
  participant AU as Audit
  participant EX as Extension Host
  participant OP as flota.SaveCatalogItem
  K->>UI: Flota → Katalog samochodów → „Dodaj model”
  Note over UI: przycisk istnieje, bo allowedActions wyniku flota.CarCatalog zawiera flota.SaveCatalogItem
  UI->>API: POST /p/flota/actions/flota.SaveCatalogItem (requestId)
  API->>AP: uprawnienie flota.Catalog.Manage
  AP-->>API: Allowed, GrantedBy flota/administrator-katalogu
  API->>AU: Intent
  API->>EX: wykonaj w kontekście profilu (użytkownik bazy prj_flota)
  EX->>OP: ExecuteAsync(ctx, model)
  OP-->>EX: Ok albo Invalid (np. emisja CO2 ponad limit polityki floty)
  EX-->>API: wynik
  API->>AU: Outcome
  API-->>UI: wynik i nowe allowedActions
```

## Dane profilu (`prj_flota`, klasa confidential, retencja 84 miesiące)

| Encja | Zawartość | Kto zapisuje |
| --- | --- | --- |
| `ModelSamochodu` | marka, model, wersja, napęd, kategoria floty, cena katalogowa netto, emisja CO2, umowa ramowa, status (dostępny, wycofany) | `flota.SaveCatalogItem`, `flota.WithdrawCatalogItem` |
| `ZmianaKatalogu` | historia zmian pozycji: kto, kiedy, co zmienił | jw. |
| `OpiniaKomorki` | sprawa, komórka, opinia, warunki, uzasadnienie, autor, czas | `flota.OpinionRegister` |

Liczbę wniosków w toku dla modelu zapytanie `flota.CarCatalog` liczy z widoków `platform_api` (tylko procesy profilu). Wnioski w toku zachowują wybrany model także po jego wycofaniu.

## Uwagi do modeli BPMN

- Modele przechodzą walidację projektową Zeebe 8.9 (`zeebe-bpmn-model`) i reguły zgodności Camunda 8.9 (`bpmnlint-plugin-camunda-compat`).
- Timery eskalacji (`TerminOpiniiPrzekroczony`, `TerminDecyzjiPrzekroczony`) nie mają przepływu wychodzącego — tak jak przykład C12 w `docs/architecture/06-camunda-integration.md`: zdarzenie służy tylko do oznaczenia eskalacji, zadanie zostaje u wykonawcy. Reguły `bpmnlint:recommended` `no-disconnected` i `no-implicit-end` zgłaszają takie zdarzenia — konfiguracja wtyczki `bpmnlint-plugin-ph` (S17) musi wyłączyć je dla zdarzeń z `ph:escalationLevel`.
- Formatkę startową „Wniosek o samochód” przypisuje do procesu Form Management: zdarzenie startowe w Zeebe 8.9 przyjmuje tylko `formId` albo `formKey`, nie `externalReference`. Kontrakt danych formatki startowej opisuje `ph:outputs` na zdarzeniu startowym.

## Plik: profiles/aml/AGENTS.md

# AGENTS.md — profil „aml”

Pracujesz dla zespołu AML. Część specyficzną realizujesz wyłącznie w `profiles/aml/**`. Profil działa w modelu **remote**: operacje profilu wykonuje usługa zespołu (`profiles/aml/remote/`), wywoływana przez platformę według kontraktu `profile-operations v1` (ADR-012). Zasady platformy z głównego `AGENTS.md` obowiązują w całości.

## Granice

- Dane profilu mają klasę **restricted** — każda zmiana przechodzi przegląd bezpieczeństwa (security-reviewer); jak cały rój, agenci pracują na modelu w infrastrukturze banku.
- Usługa zespołu nie łączy się z Camunda ani z bazą platformy. Dostaje od platformy kontekst operacji (zadanie, aktor, uprawnienie) w podpisanym żądaniu i zwraca wynik; audyt i autoryzację wykonuje platforma.
- Działasz tylko na procesie `weryfikacja-aml` (R9); uprawnienia i operacje mają prefiks `aml.` (R10).
- Dane trzymasz w schemacie `prj_aml` (albo w bazie usługi — decyzja zespołu, opisana w `profiles/aml/README.md`).

## Struktura

```
profiles/aml/
  profile.yaml · authorization.yaml     kontrakt z platformą
  backlog.yaml                          plan zespołu (kroki AML-xx)
  specs/                                scenariusze profilu (@AML-FR-xx)
  remote/    usługa operacji profilu (kontrakt profile-operations v1, mTLS + token platformy)
  frontend/  biblioteka Nx `profile-aml-ui`
  db/        migracje prj_aml
  bpmn/      proces weryfikacja-aml (typy zadań aml.*)
```

## Komendy

```bash
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile aml
npx nx run-many -t lint test build --projects=tag:scope:profile-aml
# testy usługi: według technologii zespołu + test kontraktowy profile-operations v1 dostarczany przez platformę
```

## Plik: profiles/flota/AGENTS.md

# AGENTS.md — profil „flota”

Pracujesz dla zespołu floty samochodowej. Część specyficzną profilu (katalog samochodów, opinie komórek banku, operacje dedykowane, rozszerzenia UI, workery) realizujesz wyłącznie w `profiles/flota/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości; poniżej to, co dodaje profil. Opis procesów i diagramy: `profiles/flota/README.md`; jak budować dedykowane elementy: `docs/guides/dedykowane-elementy-profilu.md`.

## Granice

- Zależysz tylko od SDK rozszerzeń w wersji `^1.1`: `ProcessHub.Extensibility` (backend) i `@process-hub/extension-sdk` (frontend). Nie odwołujesz się do modułów platformy ani do innych profili — testy architektury zatrzymają build.
- Działasz tylko na procesach profilu: `rejestracja-samochodu`, `opiniowanie-rejestracji` (reguła R9). Uprawnienia, operacje i typy zadań mają prefiks `flota.` (reguła R10).
- Katalog samochodów zmieniasz wyłącznie operacjami `flota.SaveCatalogItem` i `flota.WithdrawCatalogItem` (`profile-action`, ADR-017). Nie dodajesz endpointów poza potokiem platformy i nie sprawdzasz uprawnień w kodzie — robi to potok.
- Dane trzymasz w schemacie `prj_flota`; dane platformy (np. liczba wniosków w toku dla modelu) czytasz tylko przez widoki `platform_api`, filtrowane do procesów profilu.
- Opinie komórek mogą zawierać dane osobowe pracownika: w audycie i logach tylko identyfikatory, nigdy treść uzasadnienia (NFR-09).
- Komórki opiniujące to dane konfiguracyjne (grupy kandydujące w `authorization.yaml` i zmienna `routing.komorkiOpiniujace`), nie kod. Nowa komórka nie wymaga zmiany BPMN.
- Potrzebujesz nowego punktu rozszerzenia albo zmiany SDK → RFC w `docs/rfc/` do zespołu platformy (wzór: `RFC-FLO-03`). Nie obchodzisz braku przez kod platformy.

## Struktura

```
profiles/flota/
  profile.yaml · authorization.yaml     kontrakt z platformą (zmiany: zespół + architekt platformy)
  README.md                             procesy, diagramy, role, dedykowane elementy, widoczność
  backlog.yaml                          plan zespołu (kroki FLO-xx) — tools/agents/*.py --backlog
  specs/                                scenariusze profilu (# language: pl, tagi @FLO-FR-xx)
  bpmn/      rejestracja-samochodu.bpmn, opiniowanie-rejestracji.bpmn (typy zadań flota.*)
  backend/   Flota.Extension/  Flota.Extension.Tests/  Flota.Specs/
  frontend/  biblioteka Nx `profile-flota-ui` (sekcja „Flota”, strona /p/flota/katalog, widżet, pole formatki, panel opinii)
  db/        migracje schematu prj_flota (tożsamość migracji profilu)
  workers/   workery typów zadań flota.* (zamówienie u dealera, ewidencja floty)
```

## Komendy

```bash
dotnet build profiles/flota/backend -warnaserror
dotnet test profiles/flota/backend --filter "Category!=integration"
dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
npx nx run-many -t lint test build --projects=tag:scope:profile-flota
npx bpmnlint "profiles/flota/bpmn/**/*.bpmn"
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota
```

Skill do pracy z SDK: `profile-extension`.

## Plik: profiles/kredyty/AGENTS.md

# AGENTS.md — profil „kredyty”

Pracujesz dla zespołu kredytów. Część specyficzną profilu (dane, operacje dedykowane, rozszerzenia UI, workery) realizujesz wyłącznie w `profiles/kredyty/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości; poniżej to, co dodaje profil.

## Granice

- Zależysz tylko od SDK rozszerzeń: `ProcessHub.Extensibility` (backend) i `@process-hub/extension-sdk` (frontend). Nie odwołujesz się do modułów platformy ani do innych profili — testy architektury zatrzymają build.
- Działasz tylko na procesach profilu: `wniosek-kredytowy`, `aneks-kredytowy` (reguła R9). Platforma i tak odrzuci operację na zadaniu innego procesu.
- Uprawnienia, operacje i typy zadań mają prefiks `kredyty.` (reguła R10). Nowe uprawnienie lub rola = zmiana `profile.yaml`, którą zatwierdza architekt platformy.
- Dane trzymasz w schemacie `prj_kredyty`; dane platformy czytasz tylko przez widoki `platform_api` (filtrowane do procesów profilu).
- Potrzebujesz nowego punktu rozszerzenia albo zmiany SDK → RFC w `docs/rfc/` do zespołu platformy. Nie obchodzisz braku przez kod platformy.

## Struktura

```
profiles/kredyty/
  profile.yaml · authorization.yaml     kontrakt z platformą (zmiany: zespół + architekt platformy)
  backlog.yaml                          plan zespołu (kroki KRE-xx) — tools/agents/*.py --backlog
  specs/                                scenariusze profilu (# language: pl, tagi @KRE-FR-xx)
  backend/   Kredyty.Extension/  Kredyty.Extension.Tests/  Kredyty.Specs/
  frontend/  biblioteka Nx `profile-kredyty-ui` (komponenty slotów i trasy /p/kredyty/…)
  db/        migracje schematu prj_kredyty (tożsamość migracji profilu)
  bpmn/      procesy profilu (wdrożenie z pipeline'u z jawnym tenantem; typy zadań kredyty.*)
  workers/   workery typów zadań kredyty.* (np. rejestr kredytowy)
```

## Komendy

```bash
dotnet build profiles/kredyty/backend -warnaserror
dotnet test profiles/kredyty/backend --filter "Category!=integration"
dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
npx nx run-many -t lint test build --projects=tag:scope:profile-kredyty
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty
```

Skill do pracy z SDK: `profile-extension`.

## Plik: profiles/aml/backlog.yaml

````yaml
# Plan zespołu profilu „aml” (model remote). Narzędzia: tools/agents/*.py --backlog profiles/aml/backlog.yaml
version: 1
profile: aml
parallelism: 2
retries_per_tier: 2
escalation: [T3, T2, T1, human]
gates: {}
steps:
  - id: AML-01
    title: Usługa operacji profilu — kontrakt profile-operations v1, mTLS i weryfikacja tokenu platformy
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [S38]
    reads: [profiles/aml/AGENTS.md, profiles/aml/profile.yaml, docs/architecture/13-project-profiles.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/aml/remote/**"]
    specs: [profiles/aml/specs/recheck-sanctions.feature]
    dod: ["python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile aml"]
  - id: AML-02
    title: Ponowna weryfikacja sankcji i panel profilu ryzyka
    agent: frontend-developer
    tier: T2
    size: M
    depends_on: [AML-01, S47]
    reads: [profiles/aml/AGENTS.md, profiles/aml/profile.yaml, docs/architecture/11-frontend.md]
    writes: ["profiles/aml/frontend/**", "profiles/aml/remote/**"]
    specs: [profiles/aml/specs/recheck-sanctions.feature]
    dod: ["npx nx run-many -t lint test build --projects=tag:scope:profile-aml", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile aml"]
````

## Plik: profiles/flota/backlog.yaml

````yaml
# Plan zespołu profilu „flota”. Te same narzędzia co plan platformy:
#   python3 tools/agents/plan_status.py --backlog profiles/flota/backlog.yaml
#   python3 tools/agents/prepare_step.py FLO-01 --backlog profiles/flota/backlog.yaml
# Zależności S.. wskazują kroki platformy (plan/backlog.yaml) — krok profilu rusza po ich scaleniu.
# FLO-03 wymaga operacji na danych profilu (profile-action, SDK 1.1) — wniosek RFC-FLO-03, decyzja ADR-017, potok w S38.
version: 1
profile: flota
parallelism: 2
retries_per_tier: 2
escalation: [T3, T2, T1, human]
common_dod: &flo_dod
  - dotnet build profiles/flota/backend -warnaserror
  - dotnet test profiles/flota/backend --filter "Category!=integration"
  - dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
  - python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota
gates:
  FG1: { after: [FLO-03], approver: [product-owner-flota, architekt-platformy] }
steps:
  - id: FLO-01
    title: Moduł profilu i schemat prj_flota (ModelSamochodu, ZmianaKatalogu, OpiniaKomorki), testy zgodności SDK 1.1
    agent: data-engineer
    tier: T2
    size: M
    depends_on: [S27]
    reads: [profiles/flota/AGENTS.md, profiles/flota/profile.yaml, profiles/flota/README.md, docs/architecture/13-project-profiles.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/flota/backend/**", "profiles/flota/db/**"]
    specs: []
    dod: *flo_dod
  - id: FLO-02
    title: Procesy BPMN rejestracja-samochodu i opiniowanie-rejestracji — reguły bpmnlint ph, formatki, grupy kandydujące, wdrożenie z pipeline'u
    agent: module-implementer
    tier: T2
    size: S
    depends_on: [S17]
    reads: [profiles/flota/AGENTS.md, profiles/flota/README.md, profiles/flota/authorization.yaml, docs/architecture/06-camunda-integration.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/flota/bpmn/**"]
    specs: [profiles/flota/specs/opiniowanie-rejestracji.feature]
    dod: ["npx bpmnlint \"profiles/flota/bpmn/**/*.bpmn\"", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota"]
  - id: FLO-03
    title: Katalog samochodów — zapytanie CarCatalog, operacje na danych profilu SaveCatalogItem i WithdrawCatalogItem, źródło danych CarModels
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [FLO-01, S38]
    reads: [profiles/flota/AGENTS.md, profiles/flota/profile.yaml, profiles/flota/specs/katalog-samochodow.feature, docs/adr/ADR-017-profile-data-actions.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/flota/backend/**"]
    specs: [profiles/flota/specs/katalog-samochodow.feature]
    dod: *flo_dod
  - id: FLO-04
    title: UI profilu — sekcja nawigacji „Flota”, strona /p/flota/katalog z edycją, widżet pulpitu, pole formatki „Model samochodu”
    agent: frontend-developer
    tier: T2
    size: M
    gate_before: FG1
    depends_on: [FLO-03, S47]
    reads: [profiles/flota/AGENTS.md, profiles/flota/profile.yaml, docs/guides/dedykowane-elementy-profilu.md, docs/architecture/11-frontend.md, design/README.md]
    refs: ["design/mockups/index.html — makieta w jednym pliku (145 kB): wyszukaj funkcję `renderFleetCatalog`; nie wczytuj całości"]
    writes: ["profiles/flota/frontend/**"]
    specs: [profiles/flota/specs/katalog-samochodow.feature]
    dod: ["npx nx run-many -t lint test build --projects=tag:scope:profile-flota", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota"]
  - id: FLO-05
    title: Opinie komórek — rejestr opinii, panel „Opinie komórek” w zadaniu decyzji, operacja „Sprawdź cenę i termin dostawy”
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [FLO-02, FLO-03, S38, S47]
    reads: [profiles/flota/AGENTS.md, profiles/flota/profile.yaml, profiles/flota/specs/opiniowanie-rejestracji.feature, docs/architecture/10-audit-and-security.md]
    writes: ["profiles/flota/backend/**", "profiles/flota/frontend/**"]
    specs: [profiles/flota/specs/opiniowanie-rejestracji.feature]
    dod: ["dotnet test profiles/flota/backend --filter \"Category!=integration\"", "npx nx run-many -t lint test build --projects=tag:scope:profile-flota", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile flota"]
````

## Plik: profiles/kredyty/backlog.yaml

````yaml
# Plan zespołu profilu „kredyty”. Te same narzędzia co plan platformy:
#   python3 tools/agents/plan_status.py --backlog profiles/kredyty/backlog.yaml
#   python3 tools/agents/prepare_step.py KRE-01 --backlog profiles/kredyty/backlog.yaml
# Zależności S.. wskazują kroki platformy (plan/backlog.yaml) — krok profilu rusza po ich scaleniu.
version: 1
profile: kredyty
parallelism: 2
retries_per_tier: 2
escalation: [T3, T2, T1, human]
common_dod: &kre_dod
  - dotnet build profiles/kredyty/backend -warnaserror
  - dotnet test profiles/kredyty/backend --filter "Category!=integration"
  - dotnet test tests/ProcessHub.ArchitectureTests --filter "FullyQualifiedName~Profiles"
  - python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty
gates:
  KG1: { after: [KRE-02], approver: [product-owner-kredyty, architekt-platformy] }
steps:
  - id: KRE-01
    title: Moduł profilu i schemat prj_kredyty z szablonu, testy zgodności SDK
    agent: data-engineer
    tier: T2
    size: M
    depends_on: [S27]
    reads: [profiles/kredyty/AGENTS.md, profiles/kredyty/profile.yaml, docs/architecture/13-project-profiles.md, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/kredyty/backend/**", "profiles/kredyty/db/**"]
    specs: []
    dod: *kre_dod
  - id: KRE-02
    title: Operacja „Przelicz scoring” (task-action) z integracją systemu scoringowego
    agent: module-implementer
    pair: bdd-tester
    tier: T2
    size: M
    depends_on: [KRE-01, S38]
    reads: [profiles/kredyty/AGENTS.md, profiles/kredyty/profile.yaml, profiles/kredyty/specs/recalculate-scoring.feature, .opencode/skills/profile-extension/SKILL.md]
    writes: ["profiles/kredyty/backend/**"]
    specs: [profiles/kredyty/specs/recalculate-scoring.feature]
    dod: *kre_dod
  - id: KRE-03
    title: Panel „Wnioskodawca” w zadaniu (task-enricher + slot task.panel)
    agent: frontend-developer
    tier: T2
    size: M
    gate_before: KG1
    depends_on: [KRE-02, S47]
    reads: [profiles/kredyty/AGENTS.md, profiles/kredyty/profile.yaml, docs/architecture/11-frontend.md, design/README.md]
    writes: ["profiles/kredyty/frontend/**", "profiles/kredyty/backend/**"]
    specs: [profiles/kredyty/specs/recalculate-scoring.feature]
    dod: ["npx nx run-many -t lint test build --projects=tag:scope:profile-kredyty", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty"]
  - id: KRE-04
    title: Raport portfela — zapytanie, widżet pulpitu i trasa /p/kredyty/portfel
    agent: frontend-developer
    tier: T2
    size: S
    depends_on: [KRE-01, S47]
    reads: [profiles/kredyty/AGENTS.md, profiles/kredyty/profile.yaml, docs/architecture/11-frontend.md]
    writes: ["profiles/kredyty/frontend/**", "profiles/kredyty/backend/**"]
    specs: []
    dod: ["npx nx run-many -t lint test build --projects=tag:scope:profile-kredyty", "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty"]
````

## Plik: profiles/aml/specs/recheck-sanctions.feature

````gherkin
# language: pl
# Scenariusze profilu „aml” — własność zespołu AML. Świat testowy: specs/README.md.
Funkcja: Ponowna weryfikacja sankcji
  Jako analityk AML
  Chcę ponownie sprawdzić listy sankcyjne w trakcie analizy
  Aby decyzja uwzględniała najnowsze wpisy

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T3" procesu "weryfikacja-aml" typu "AnalizaAml" przypisane do "darek"

  @AML-FR-01
  Scenariusz: Assignee zleca ponowną weryfikację przez usługę zespołu
    Jeżeli "darek" wykonuje operację "aml.RecheckSanctions" na zadaniu "T3"
    Wtedy platforma wywołuje usługę profilu "aml" z kontekstem zadania "T3" i aktora "darek"
    Oraz dziennik bezpieczeństwa zawiera "aml.RecheckSanctions" z wynikiem "Succeeded" i profilem "aml"

  @AML-FR-01
  Scenariusz: Niedostępna usługa profilu nie blokuje pracy na zadaniu
    Zakładając usługa profilu "aml" nie odpowiada
    Jeżeli "darek" wykonuje operację "aml.RecheckSanctions" na zadaniu "T3"
    Wtedy operacja kończy się błędem "ProfileServiceUnavailable"
    Oraz "darek" nadal może zapisać szkic i zakończyć zadanie "T3"
````

## Plik: profiles/flota/specs/katalog-samochodow.feature

````gherkin
# language: pl
# Scenariusze profilu „flota” — własność zespołu floty. Świat testowy: specs/README.md.
# Dedykowane elementy: sekcja nawigacji „Flota”, trasa /p/flota/katalog, zapytanie flota.CarCatalog,
# operacje na danych profilu flota.SaveCatalogItem i flota.WithdrawCatalogItem (profile-action, ADR-017),
# źródło danych formatki flota.CarModels.
Funkcja: Katalog samochodów widoczny i prowadzony wyłącznie w profilu „flota”
  Jako administrator katalogu samochodów
  Chcę prowadzić w aplikacji katalog modeli dostępnych do zakupu
  Aby wnioskodawcy wybierali tylko samochody zgodne z polityką floty, a inne projekty nie widziały katalogu

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz katalog floty zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid" w kategorii "B" ze statusem "dostępny"
    Oraz katalog floty zawiera model "Skoda Octavia Combi 2.0 TDI" w kategorii "B" ze statusem "wycofany"
    Oraz limit emisji CO2 w polityce floty wynosi 130 g/km

  @FLO-FR-01
  Szablon scenariusza: Katalog i sekcję nawigacji „Flota” widzą tylko role profilu
    Jeżeli "<osoba>" otwiera trasę "/p/flota/katalog"
    Wtedy wynik to "<wynik>"
    Oraz sekcja nawigacji "Flota" jest <sekcja> dla "<osoba>"

    Przykłady:
      | osoba  | kto                                      | wynik                                 | sekcja      |
      | tomasz | wnioskodawca (flota)                     | Allowed: flota/wnioskodawca           | widoczna    |
      | hanna  | opiniująca komórki HR (flota)            | Allowed: flota/opiniujacy             | widoczna    |
      | karol  | administrator katalogu (flota)           | Allowed: flota/administrator-katalogu | widoczna    |
      | anna   | analityk kredytowy (kredyty)             | Denied: brak uprawnienia              | niewidoczna |
      | adam   | administrator procesów kredytowych       | Denied: brak uprawnienia              | niewidoczna |
      | olga   | audytor (rola globalna)                  | Denied: brak uprawnienia              | niewidoczna |

  @FLO-FR-01
  Scenariusz: Wejście na stronę katalogu spoza profilu jest odmową zapisaną w dzienniku
    Jeżeli "anna" otwiera trasę "/p/flota/katalog"
    Wtedy dziennik bezpieczeństwa zawiera "flota.CarCatalog" z wynikiem "Denied" i kodem "brak uprawnienia"
    Oraz kod profilu "flota" nie został wywołany

  @FLO-FR-01
  Scenariusz: Wnioskodawca przegląda katalog bez akcji zmiany
    Jeżeli "tomasz" pobiera zapytanie "flota.CarCatalog"
    Wtedy wynik zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid" ze statusem "dostępny"
    Oraz dozwolone akcje nie zawierają "flota.SaveCatalogItem" ani "flota.WithdrawCatalogItem"

  @FLO-FR-01
  Scenariusz: Administrator katalogu dostaje akcje katalogu razem z wynikiem zapytania
    Jeżeli "karol" pobiera zapytanie "flota.CarCatalog"
    Wtedy dozwolone akcje zawierają "flota.SaveCatalogItem" i "flota.WithdrawCatalogItem"

  @FLO-FR-01 @integration
  Scenariusz: Kod innego profilu nie czyta katalogu floty
    Zakładając kod profilu "kredyty" działa w kontekście bazy "prj_kredyty"
    Jeżeli kod profilu odczytuje tabelę "prj_flota.ModelSamochodu"
    Wtedy baza odmawia dostępu

  @FLO-FR-02
  Scenariusz: Administrator katalogu dodaje model
    Jeżeli "karol" wykonuje operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range", kategorią "A", emisją CO2 0 i ceną netto 215000
    Wtedy operacja kończy się sukcesem
    Oraz katalog floty zawiera model "Kia EV6 Long Range" ze statusem "dostępny"
    Oraz historia katalogu zawiera dodanie modelu "Kia EV6 Long Range" przez "karol"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Succeeded", rolą "flota/administrator-katalogu" i profilem "flota"

  @FLO-FR-02
  Szablon scenariusza: Katalogu nie zmienia nikt poza administratorem katalogu
    Jeżeli "<osoba>" wykonuje operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range", kategorią "A", emisją CO2 0 i ceną netto 215000
    Wtedy operacja jest odrzucona: "brak uprawnienia"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Denied"
    Oraz kod profilu "flota" nie został wywołany

    Przykłady:
      | osoba  | kto                                                        |
      | alicja | administrator procesów floty — Administrator procesu bez flota.Catalog.Manage |
      | wiktor | kierownik floty — Menadżer procesu                         |
      | tomasz | wnioskodawca                                               |
      | adam   | administrator procesów kredytowych — inny profil           |
      | zenon  | administrator platformy — rola globalna                    |

  @FLO-FR-02
  Scenariusz: Model niezgodny z polityką floty nie trafia do katalogu
    Jeżeli "karol" wykonuje operację "flota.SaveCatalogItem" z modelem "Ford Ranger 2.0 EcoBlue", kategorią "B", emisją CO2 220 i ceną netto 189000
    Wtedy operacja kończy się błędem walidacji "Emisja CO2 przekracza limit polityki floty (130 g/km)"
    Oraz katalog floty nie zawiera modelu "Ford Ranger 2.0 EcoBlue"
    Oraz dziennik bezpieczeństwa zawiera "flota.SaveCatalogItem" z wynikiem "Failed"

  @FLO-FR-02
  Scenariusz: Ponowienie z tym samym identyfikatorem żądania nie dubluje modelu
    Zakładając "karol" wykonał operację "flota.SaveCatalogItem" z modelem "Kia EV6 Long Range" i identyfikatorem żądania "k-1"
    Jeżeli "karol" ponawia operację z identyfikatorem żądania "k-1"
    Wtedy operacja kończy się sukcesem
    Oraz katalog floty zawiera dokładnie 1 model "Kia EV6 Long Range"

  @FLO-FR-02 @FLO-FR-03
  Scenariusz: Wycofany model znika z formatki, a wniosek w toku go zachowuje
    Zakładając sprawa "F-0012" procesu "rejestracja-samochodu" z modelem "Toyota Corolla Touring Sports 1.8 Hybrid" jest w etapie "Opiniowanie"
    Jeżeli "karol" wykonuje operację "flota.WithdrawCatalogItem" dla modelu "Toyota Corolla Touring Sports 1.8 Hybrid"
    Wtedy źródło danych "flota.CarModels" nie zwraca modelu "Toyota Corolla Touring Sports 1.8 Hybrid"
    Oraz sprawa "F-0012" nadal ma model "Toyota Corolla Touring Sports 1.8 Hybrid"

  @FLO-FR-03
  Scenariusz: Pole formatki startowej oferuje tylko dostępne modele z katalogu
    Jeżeli "tomasz" otwiera formatkę startową procesu "rejestracja-samochodu"
    Wtedy pole "Model samochodu z katalogu" zawiera model "Toyota Corolla Touring Sports 1.8 Hybrid"
    Ale pole "Model samochodu z katalogu" nie zawiera modelu "Skoda Octavia Combi 2.0 TDI"

  @FLO-FR-03
  Scenariusz: Formatka innego procesu nie korzysta z katalogu floty
    Jeżeli formatka procesu "wniosek-kredytowy" wywołuje źródło danych "flota.CarModels" w imieniu "anna"
    Wtedy wywołanie jest odrzucone regułą "R9"
    Oraz dziennik bezpieczeństwa zawiera "flota.CarModels" z wynikiem "Denied" i kodem "R9"
````

## Plik: profiles/flota/specs/opiniowanie-rejestracji.feature

````gherkin
# language: pl
# Scenariusze profilu „flota” — własność zespołu floty. Świat testowy: specs/README.md.
# Procesy: rejestracja-samochodu (główny) i opiniowanie-rejestracji (podrzędny, zadanie wielokrotne „Opinia komórki”).
Funkcja: Opiniowanie rejestracji samochodu przez komórki banku
  Jako komórka banku (IT, HR, Prawny, Finanse, Ryzyko)
  Chcę wydać opinię o wniosku o samochód służbowy w swoim zakresie
  Aby decydent przydzielał samochody na podstawie opinii wszystkich komórek

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz sprawa "F-0012" procesu "rejestracja-samochodu" wnioskodawcy "tomasz" z modelem "Toyota Corolla Touring Sports 1.8 Hybrid" przeszła weryfikację wniosku
    Oraz proces "opiniowanie-rejestracji" utworzył w sprawie "F-0012" zadania "Opinia komórki" dla grup:
      | grupa                |
      | flota-opinia-it      |
      | flota-opinia-hr      |
      | flota-opinia-prawny  |
      | flota-opinia-finanse |
      | flota-opinia-ryzyko  |

  @FLO-FR-04
  Szablon scenariusza: Każda komórka widzi tylko swoje zadanie opinii
    Jeżeli "<osoba>" otwiera listę "Do przejęcia"
    Wtedy lista zawiera zadanie "Opinia komórki" grupy "<grupa>" w sprawie "F-0012"
    Ale lista nie zawiera zadań "Opinia komórki" pozostałych grup

    Przykłady:
      | osoba | grupa                |
      | igor  | flota-opinia-it      |
      | hanna | flota-opinia-hr      |
      | lena  | flota-opinia-prawny  |
      | filip | flota-opinia-finanse |
      | rafal | flota-opinia-ryzyko  |

  @FLO-FR-04
  Scenariusz: Komórka nie przejmie zadania innej komórki
    Jeżeli "igor" przejmuje zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Wtedy operacja jest odrzucona regułą "R2"
    Oraz dziennik bezpieczeństwa zawiera "Task.Claim" z wynikiem "Denied" i kodem "R2"

  @FLO-FR-04
  Scenariusz: Opinię zapisuje i kończy tylko assignee
    Zakładając "hanna" przejęła zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Jeżeli "wiktor" zapisuje szkic tego zadania
    Wtedy operacja jest odrzucona regułą "R1"

  @FLO-FR-04
  Scenariusz: Opinia trafia do dziennika z rolą projektową, a sprawa czeka na pozostałe komórki
    Zakładając "hanna" przejęła zadanie "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Jeżeli "hanna" kończy to zadanie z opinią "warunkowa" i warunkiem "samochód kategorii B zamiast A"
    Wtedy dziennik bezpieczeństwa zawiera "Task.Complete" z wynikiem "Succeeded", rolą "flota/opiniujacy" i profilem "flota"
    Oraz rejestr opinii profilu "flota" zawiera opinię komórki "hr" w sprawie "F-0012"
    Oraz sprawa "F-0012" pozostaje w etapie "Opiniowanie" z 4 otwartymi zadaniami "Opinia komórki"

  @FLO-FR-04
  Szablon scenariusza: Rekomendacja wynika z opinii wszystkich komórek
    Zakładając komórki wydały w sprawie "F-0012" opinie: <opinie>
    Jeżeli proces "opiniowanie-rejestracji" kończy się
    Wtedy rekomendacja w sprawie "F-0012" to "<rekomendacja>"
    Oraz sprawa "F-0012" przechodzi do etapu "Decyzja" z zadaniem "Decyzja o przydziale samochodu" dla grupy "flota-decydenci"

    Przykłady:
      | opinie                                                                            | rekomendacja |
      | IT pozytywna, HR pozytywna, Prawny pozytywna, Finanse pozytywna, Ryzyko pozytywna | pozytywna    |
      | IT pozytywna, HR warunkowa, Prawny pozytywna, Finanse pozytywna, Ryzyko pozytywna | warunkowa    |
      | IT pozytywna, HR warunkowa, Prawny pozytywna, Finanse negatywna, Ryzyko pozytywna | negatywna    |

  @FLO-FR-04
  Scenariusz: Brak opinii w terminie eskaluje sprawę
    Zakładając zadanie "Opinia komórki" grupy "flota-opinia-prawny" w sprawie "F-0012" jest otwarte
    Jeżeli uruchamia się zdarzenie "TerminOpiniiPrzekroczony" z poziomem eskalacji 1
    Wtedy lista eskalowanych osoby "wiktor" zawiera sprawę "F-0012" z etapem "Opiniowanie" i poziomem 1

  @FLO-FR-05
  Scenariusz: Decydent widzi zestawienie opinii, a odczyt wrażliwy trafia do dziennika
    Zakładając sprawa "F-0012" jest w etapie "Decyzja" z opiniami wszystkich komórek
    Oraz zadanie "Decyzja o przydziale samochodu" w sprawie "F-0012" jest przypisane do "jan"
    Jeżeli "jan" pobiera szczegóły tego zadania
    Wtedy widok zawiera sekcję "extensions.flota" z 5 opiniami komórek
    Oraz dziennik bezpieczeństwa zawiera "flota.OpinionsSummary" z wynikiem "Succeeded", rolą "flota/decydent-floty" i profilem "flota"
    Ale wpis dziennika nie zawiera treści uzasadnień opinii

  @FLO-FR-05
  Scenariusz: Opiniujący nie widzi opinii innych komórek
    Jeżeli "hanna" pobiera szczegóły zadania "Opinia komórki" grupy "flota-opinia-hr" w sprawie "F-0012"
    Wtedy widok nie zawiera sekcji "extensions.flota"

  @FLO-FR-05
  Scenariusz: Cenę i termin dostawy sprawdza tylko assignee zadania decyzji
    Zakładając zadanie "Decyzja o przydziale samochodu" w sprawie "F-0012" jest przypisane do "jan"
    Oraz system zakupowy zwraca dla modelu "Toyota Corolla Touring Sports 1.8 Hybrid" cenę netto 116900 i termin dostawy "2026-12-15"
    Jeżeli "jan" wykonuje operację "flota.CheckDeliveryTerms" na tym zadaniu
    Wtedy szkic zadania zawiera "cenaAktualna" równe 116900 i "terminDostawy" równe "2026-12-15"
    Ale "wiktor" pobierający szczegóły tego zadania nie widzi akcji "flota.CheckDeliveryTerms"
````

## Plik: profiles/kredyty/specs/recalculate-scoring.feature

````gherkin
# language: pl
# Scenariusze profilu „kredyty” — własność zespołu kredytów. Świat testowy: specs/README.md.
Funkcja: Przeliczenie scoringu w zadaniu oceny wniosku
  Jako analityk kredytowy
  Chcę przeliczyć scoring w trakcie oceny
  Aby decyzja opierała się na aktualnych danych wnioskodawcy

  Założenia:
    Zakładając świat testowy Process Hub
    Oraz zadanie "T1" procesu "wniosek-kredytowy" typu "OcenaWniosku" przypisane do "anna"
    Oraz system scoringowy zwraca dla wniosku z zadania "T1" wynik 712

  @KRE-FR-01
  Scenariusz: Assignee przelicza scoring
    Jeżeli "anna" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja kończy się sukcesem
    Oraz szkic zadania "T1" zawiera "scoring" równe 712
    Oraz dziennik bezpieczeństwa zawiera "kredyty.RecalculateScoring" z wynikiem "Succeeded", rolą "kredyty/analityk-kredytowy" i profilem "kredyty"

  @KRE-FR-01
  Scenariusz: Osoba z grupy, która nie jest assignee, nie przelicza scoringu
    Jeżeli "bartek" wykonuje operację "kredyty.RecalculateScoring" na zadaniu "T1"
    Wtedy operacja jest odrzucona regułą "R1"
    Oraz system scoringowy nie został wywołany

  @KRE-FR-01
  Scenariusz: Ponowienie z tym samym identyfikatorem żądania nie wywołuje systemu drugi raz
    Zakładając "anna" wykonała operację "kredyty.RecalculateScoring" na zadaniu "T1" z identyfikatorem żądania "r-1"
    Jeżeli "anna" ponawia operację z identyfikatorem żądania "r-1"
    Wtedy operacja kończy się sukcesem
    Oraz system scoringowy został wywołany dokładnie 1 raz
````

