# 02-decyzje-i-uprawnienia — Decyzje architektoniczne (ADR-001…020), wnioski RFC, uprawnienia jako kod i własność kodu

Pakiet zawiera 26 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: docs/adr/README.md

# Rejestr decyzji (ADR)

| ADR | Tytuł | Status | Rozstrzyga |
| --- | --- | --- | --- |
| ADR-001 | Modularny monolit, jeden obraz w czterech rolach | Przyjęta | — |
| ADR-002 | Jeden tenant domyślnie, gotowość na wielu | Przyjęta | — |
| ADR-003 | Oficjalne SDK Camunda wyłącznie za ACL | Proponowana | S01 |
| ADR-004 | Autoryzacje dwupoziomowe i autoryzacje jako kod | Proponowana (tożsamość wywołań) | S02 |
| ADR-005 | MSSQL: RLS, Ledger, partycjonowany ślad operacyjny | Przyjęta | — |
| ADR-006 | Mapa etapów jako warstwa aplikacji | Przyjęta | — |
| ADR-007 | Zastępstwa przez task listener, fail-open | Proponowana | S03 |
| ADR-008 | BFF z ciasteczkiem zamiast publicznego klienta SPA | Przyjęta | — |
| ADR-009 | Reqnroll i biblioteki o licencjach otwartych | Przyjęta | — |
| ADR-010 | Zasilanie read modelu | Proponowana | S04 |
| ADR-011 | Wynik biznesowy na zdarzeniach końcowych | Przyjęta | — |
| ADR-012 | Profile projektów i punkty rozszerzeń | Przyjęta (model domyślny: D-08) | S19, S38 |
| ADR-013 | Separacja kodu profili i własność | Przyjęta (repozytoria: D-09) | S27 |
| ADR-014 | Izolacja danych profilu | Proponowana | S27 |
| ADR-015 | Agenci w OpenCode z modelami GLM 5.3 Flash | Przyjęta, częściowo zastąpiona przez ADR-016 | S00 |
| ADR-016 | Wyłącznie model w infrastrukturze banku | Przyjęta | S06 |
| ADR-017 | Operacje na danych profilu (`profile-action`) | Proponowana (uzupełnia ADR-012) | S38, S47 |
| ADR-018 | Formatki w formacie Camunda Forms: system zapisu, cykl życia z wycofaniem, separacja per proces | Przyjęta (decyzje D-12…D-14) | S26, S28, S29, S39 |
| ADR-019 | Projektant na edytorze form-js, materializacja komponentami design systemu | Proponowana | S07, S09 |
| ADR-020 | Walidacja formatek po stronie serwera i ewaluacja FEEL | Proponowana | S08 |

Zmiana ADR = nowy plik ze statusem „Zastępuje ADR-xxx”. Agent nie edytuje ADR — składa RFC w `docs/rfc/`.

## Plik: docs/adr/ADR-001-modular-monolith.md

# ADR-001: Modularny monolit, jeden obraz w czterech rolach

**Status:** Przyjęta

**Kontekst.** Jeden zespół, wiele kontekstów, potrzeba niezależnego skalowania obsługi żądań, projekcji zdarzeń i task listenerów.

**Decyzja.** Modularny monolit .NET 10; moduły jako pionowe wycinki z `Contracts`; jeden obraz kontenera uruchamiany w rolach `api`, `projector`, `jobs`, `worker` (zmienna `PH_ROLE`). Granice wymuszają testy architektury.

**Konsekwencje.** Jedno wdrożenie i wersja; role skalowane osobno; wydzielenie modułu do usługi możliwe bez przepisywania domeny. Koszt: dyscyplina granic musi być automatyczna (testy architektury blokują merge).

## Plik: docs/adr/ADR-002-single-tenant-multi-tenant-ready.md

# ADR-002: Jeden tenant domyślnie, gotowość na wielu

**Status:** Przyjęta

**Kontekst.** Start z jednym tenantem; separacja obszarów biznesowych wewnątrz tenanta przez autoryzacje zasobów. W przyszłości możliwe kolejne tenanty.

**Decyzja.** `TenantId` w Shared Kernel, w każdym agregacie, zapytaniu, zdarzeniu, wpisie audytu i zakresie roli. `ITenantContext` zwraca dziś `<default>`. RLS po `TenantId` działa od początku. Multi-tenancy w Camunda pozostaje wyłączone do decyzji o drugim tenancie; ta decyzja musi zapaść przed uruchomieniem środowiska docelowego z danymi (zmiana post factum wymaga ponownej inicjalizacji — dokument DevOps v1, sekcja 7).

**Konsekwencje.** Brak kosztu dziś poza dyscypliną przekazywania `TenantId`; drugi tenant = konfiguracja (Camunda, `assignments.yaml`, `ITenantContext` z claimu). Testy BDD mają scenariusz z dwoma tenantami w trybie in-memory, aby gotowość nie była deklaracją.

## Plik: docs/adr/ADR-003-official-camunda-sdk-behind-acl.md

# ADR-003: Oficjalne SDK Camunda wyłącznie za ACL

**Status:** Proponowana — potwierdza S01

**Kontekst.** Wymóg: backend korzysta z oficjalnego SDK Camunda. Chcemy izolacji od zmian API między wersjami.

**Decyzja.** Paczka SDK referowana wyłącznie przez `CamundaIntegration.Infrastructure.Sdk`; reszta systemu zna porty (`IUserTaskCommands`, `IProcessStarter`, `IProcessQueries`, `IDefinitionCatalog`, `IAuthorizationAdmin`, `ITaskListenerHost`). Wersja przypięta centralnie. Jeśli SDK nie pokrywa operacji z listy kontrolnej (`06-camunda-integration.md`), uzupełniamy ją klientem wygenerowanym z OpenAPI Camunda — wewnątrz tego samego modułu.

**Weryfikacja (S01).** Nazwa i wersja paczki zgodnej z 8.9; pokrycie listy kontrolnej; obsługa `tenantId`; job worker z korektami task listenera; poświadczenia per wywołanie (dla ADR-004).

**Konsekwencje.** Aktualizacja SDK dotyka jednego modułu, sprawdzana testami kontraktowymi na Testcontainers.

## Plik: docs/adr/ADR-004-authorization-two-levels-as-code.md

# ADR-004: Autoryzacje dwupoziomowe i autoryzacje jako kod

**Status:** Proponowana — tożsamość wywołań potwierdza S02; reszta przyjęta

**Kontekst.** W ramach tenanta widoczność ograniczają resource authorizations Camunda. Reguły wierszowe (assignee, grupa, inicjator) są drobniejsze niż autoryzacje silnika. Użytkownik może mieć wiele ról.

**Decyzja.**
1. L1 — autoryzacje Camunda na `PROCESS_DEFINITION` (`resourceId` = `bpmnProcessId` lub `*`) dla grup i ról.
2. L2 — polityka aplikacji: uprawnienia z ról w zakresach + reguły R1–R10 (R9 i R10 — profile projektów, ADR-012).
3. Jedno źródło: `config/authorization/*.yaml`; reconciler stosuje je w Camunda przez SDK (dry-run w PR, apply po scaleniu, nocne wykrywanie dryfu); aplikacja ładuje te same pliki.
4. Tożsamość wywołań: wariant A (token delegowany) dla komend użytkownika, jeśli SDK go obsługuje; wariant B (klienci techniczni z minimalnymi uprawnieniami) dla `projector`, `worker`, reconcilera — i awaryjnie dla `api`.

**Konsekwencje.** Brak drugiej tabeli ról; zmiana uprawnień przez PR z przeglądem. Generowane testy macierzy autoryzacji pilnują zgodności L2 z deklaracjami.

## Plik: docs/adr/ADR-005-mssql-rls-ledger-trace.md

# ADR-005: MSSQL — RLS, Ledger, partycjonowany ślad operacyjny

**Status:** Przyjęta

**Decyzja.** SQL Server 2022+. RLS po `TenantId` (`SESSION_CONTEXT`, `@read_only = 1`). `audit.SecurityJournal` jako tabela Ledger append-only z digestami do WORM. `audit.OperationTrace` partycjonowana miesięcznie z indeksem kolumnowym i retencją przez `TRUNCATE … WITH (PARTITIONS)`. Tabele temporalne dla danych z okresem obowiązywania.

**Konsekwencje.** Niezmienność i izolacja egzekwowane przez bazę. Wymagana wersja 2022+ (Ledger, `APPROX_PERCENTILE_CONT`). Koszt: wolumen śladu — planowanie pojemności w S52.

## Plik: docs/adr/ADR-006-stage-map-overlay.md

# ADR-006: Mapa etapów jako warstwa aplikacji

**Status:** Przyjęta

**Kontekst.** Menadżer ma wiedzieć, na jakim etapie jest proces, bez technikaliów BPMN. W v1 etykiety żyły w `zeebe:properties`, zmieniane tylko przez zespół BPMN.

**Decyzja.** `StageMap` w Process Insight, wersjonowana per wersja definicji, edytowana w aplikacji: elementy mapuje administrator procesu (`StageMap.MapElements`), nazwy/kolejność/SLA ustala menadżer (`StageMap.Edit`). `ph:stage` w BPMN jest tylko zasiewem szkicu. Stan etapów liczony z historii instancji elementów.

**Konsekwencje.** Biznes zmienia prezentację bez wdrożenia BPMN; nowa wersja definicji wymaga przeglądu raportu różnic. Ryzyko niezmapowanych elementów ograniczają walidacja i reguła bpmnlint `ph/user-task-named`.

## Plik: docs/adr/ADR-007-substitution-task-listener.md

# ADR-007: Zastępstwa przez task listener, fail-open

**Status:** Proponowana — potwierdza S03

**Kontekst.** Podczas nieobecności nowe zadania mają trafiać do zastępcy; istniejące zadania przekazuje menadżer (pojedynczo lub masowo).

**Decyzja.** Task listener (`creating`, `assigning`) typu `ph.substitution`, obsługiwany przez rolę `worker`, sprawdza rejestr `Absence` i zwraca korektę assignee lub grup. Limit czasu odpowiedzi; przy awarii platformy job kończy się bez korekty (fail-open) + audyt `SubstitutionSkipped`; job uzgadniający wykonuje przekazanie później. Wariant zapasowy (gdy 8.9 nie wspiera korekt): projektor wykrywa przypisanie do nieobecnego i wykonuje `Reassign` — z krótkim oknem widoczności u nieobecnego.

**Konsekwencje.** Korekta przed udostępnieniem zadania, bez wyścigów. Worker musi mieć ≥ 2 repliki i monitoring czasu odpowiedzi.

## Plik: docs/adr/ADR-008-bff-cookie.md

# ADR-008: BFF z ciasteczkiem zamiast publicznego klienta SPA

**Status:** Przyjęta (zmienia ustalenie z v1)

**Decyzja.** Klient poufny `process-hub-bff` w RHBK (Authorization Code + PKCE); tokeny tylko w BFF; przeglądarka dostaje ciasteczko `__Host-` (`HttpOnly`, `Secure`, `SameSite=Strict`) i chroni się przed CSRF nagłówkiem. Klient publiczny `process-hub-spa` z v1 nie jest tworzony.

**Konsekwencje.** XSS nie wykradnie tokenu; SPA prostsza. BFF musi obsłużyć odświeżanie tokenów i wylogowanie globalne.

## Plik: docs/adr/ADR-009-reqnroll-and-licensing.md

# ADR-009: Reqnroll i biblioteki o licencjach otwartych

**Status:** Przyjęta

**Decyzja.** Reqnroll zamiast SpecFlow (wycofany przez Tricentis z końcem 2024; Gherkin i bindingi przenoszą się 1:1). Dispatcher generowany źródłowo lub własny zamiast komercyjnych wersji MediatR; mapowanie ręczne lub generowane (np. Mapperly) zamiast komercyjnego AutoMappera; własne asercje domenowe zamiast komercyjnych wersji FluentAssertions.

**Konsekwencje.** Brak ryzyka licencyjnego w łańcuchu budowania; każda nowa zależność wymaga ADR.

## Plik: docs/adr/ADR-010-read-model-feed.md

# ADR-010: Zasilanie read modelu

**Status:** Proponowana — rozstrzyga S04

**Opcje.** (A) wyszukiwanie przyrostowe przez SDK ze znacznikiem i zakładką czasową; (B) eksporter rekordów silnika → Kafka → projektor.

**Rekomendacja.** Start z A (jeden tenant, prostota, oficjalne SDK); przejście na B, gdy pomiar w S04 lub produkcji przekroczy cel NFR-04 albo obciąży API wyszukiwania. Projektor za portem `IEventFeed`, więc zmiana nie dotyka rdzenia.

**Weryfikacja (S04).** Opóźnienie P95 przy obciążeniu z pilotażu; kompletność (brak zgubionych zmian przy restarcie); koszt zapytań po stronie Camunda.

## Plik: docs/adr/ADR-011-business-outcome-on-end-events.md

# ADR-011: Wynik biznesowy na zdarzeniach końcowych

**Status:** Przyjęta

**Decyzja.** Każde zdarzenie końcowe ma `ph:outcome` ∈ {`success`, `rejected`, `error`} (reguła bpmnlint). Dashboard liczy sukces/odmowę/błąd z tego tagu; incydenty to osobna kategoria techniczna; anulowanie — decyzja D-06.

**Dlaczego.** Techniczne zakończenie instancji nie mówi, czy sprawa zakończyła się sukcesem; bez tagu „wniosek odrzucony” wyglądałby jak sukces albo błąd, zależnie od interpretacji.

## Plik: docs/adr/ADR-012-project-profiles-and-extension-points.md

# ADR-012: Profile projektów i punkty rozszerzeń

**Status:** Przyjęta (model integracji domyślnej — D-08)

**Kontekst.** Z platformy korzysta wiele projektów biznesowych (kredyty, AML, kolejne). Każdy ma własne potrzeby co do danych i dedykowanych operacji, a część specyficzną mają realizować niezależne zespoły. Wbudowanie potrzeb projektów w moduły platformy uzależniłoby wydania wszystkich projektów od jednego zespołu i zatarło granice odpowiedzialności.

**Decyzja.**
1. Projekt korzysta z platformy przez **profil projektu** (`profiles/<id>/`): manifest `profile.yaml` (procesy, uprawnienia, role projektowe, dane, operacje, sloty UI, integracje) i `authorization.yaml` (grupy AD → role projektowe).
2. Część specyficzna łączy się z platformą wyłącznie przez **punkty rozszerzeń** SDK: operacje na zadaniu i sprawie, wzbogacenia widoku zadania, źródła danych formatek, zapytania, obsługa zdarzeń platformy, sloty UI.
3. Operacje profili wykonuje **potok platformy** (uprawnienie, R1, R9, audyt Intent/Outcome, idempotencja); profil implementuje tylko logikę biznesową.
4. Dwa modele integracji: **in-process** (moduł .NET w hoście, domyślny) i **remote** (usługa zespołu, kontrakt `profile-operations v1`, mTLS + krótkotrwały token platformy).
5. Nowe reguły dostępu: **R9** (zasoby tylko procesów profilu) i **R10** (przestrzeń nazw profilu).

**Konsekwencje.**
- Platforma dostaje moduł Extension Host i paczki SDK z wersjonowaniem semantycznym i testami zgodności (kroki S19, S38, S47).
- Proces ma dokładnie jednego właściciela-profil; wspólne procesy wielu projektów wymagają decyzji, który profil jest właścicielem.
- Nowa potrzeba bez punktu rozszerzenia oznacza RFC do platformy — to celowe tarcie chroniące spójność.
- Profil remote zwiększa koszt utrzymania zespołu, ale daje niezależne wydania i dowolną technologię.

**Weryfikacja.** S19 (SDK i rejestr), S38 (potok operacji i profil przykładowy), S47 (sloty UI); scenariusze `specs/profiles/project-profiles.feature`.

## Plik: docs/adr/ADR-013-profile-code-separation-and-ownership.md

# ADR-013: Separacja kodu profili i własność

**Status:** Przyjęta (monorepo czy osobne repozytoria — D-09)

**Kontekst.** Część specyficzną realizują niezależne zespoły, także z pomocą agentów AI. Trzeba zagwarantować, że zespół lub agent jednego profilu nie zrealizuje części innego projektu ani nie zmieni platformy, a jednocześnie nie blokować zespołów w ich własnym obszarze.

**Decyzja.** Separację wymusza osiem niezależnych warstw:
1. **Repozytorium:** kod profilu wyłącznie w `profiles/<id>/**`; `CODEOWNERS` generowany z manifestów (`tools/profiles/validate_profiles.py`); kontrakt profilu zatwierdza też architekt platformy.
2. **Kompilacja:** profil zależy tylko od SDK rozszerzeń; testy architektury (.NET) i granice Nx (`scope:profile-<id>` → `scope:extension-sdk`).
3. **Uprawnienia:** przestrzeń nazw profilu; walidator manifestów i reconciler odrzucają naruszenia (R10).
4. **Wykonanie:** Extension Host wywołuje profil tylko dla procesów profilu (R9).
5. **Dane:** schemat i użytkownik bazy per profil (ADR-014).
6. **Wdrożenie:** in-process w pociągu wydań, remote — niezależnie.
7. **CI:** filtry ścieżek per profil; `enforce_write_scope.py --verify-diff --profile <id>` dla PR zespołu.
8. **Agenci AI:** agenci `<id>-<rola>` z zapisem tylko w `profiles/<id>/**` (uprawnienia OpenCode + plugin strażnika); agenci platformy nie zapisują w profilach.

**Konsekwencje.**
- Monorepo (rekomendacja na start) pozwala walidować reguły międzyprofilowe w jednym miejscu; przejście na osobne repozytoria wymagałoby publikacji SDK i manifestów jako paczek.
- Generator agentów i walidator manifestów stają się częścią bramek CI.

**Weryfikacja.** S27 (testy architektury profili, CODEOWNERS, strażnik w CI); przypadek kwalifikacji agentów E08.

## Plik: docs/adr/ADR-014-profile-data-isolation.md

# ADR-014: Izolacja danych profilu

**Status:** Proponowana (mechanizm kontekstu bazy) — rozstrzyga S27

**Kontekst.** Profile przechowują dane projektu (np. wyniki scoringu, profile ryzyka AML) o różnej klasyfikacji. Błąd w kodzie jednego profilu nie może dać dostępu do danych platformy ani innych profili.

**Decyzja.**
1. Każdy profil ma schemat `prj_<id>` i użytkownika bazy `prj_<id>` bez loginu, z prawami tylko do własnego schematu i `SELECT` na widokach `platform_api`.
2. Extension Host wykonuje operację profilu w transakcji platformy pod `EXECUTE AS USER = 'prj_<id>'`, a przed zapisem audytu wraca `REVERT` — jedna transakcja, granica egzekwowana przez bazę.
3. Widoki `platform_api` udostępniają zadania, instancje i stany etapów tylko dla procesów profilu (predykat RLS po `SESSION_CONTEXT(N'ProfileId')` i tabeli `ext.ProfileProcess`).
4. Migracje profilu uruchamia osobna tożsamość z DDL tylko w `prj_<id>`; retencja i klasyfikacja z manifestu.
5. Profil remote może trzymać dane we własnej bazie — obowiązują go klasyfikacja i retencja z manifestu; platforma nie ma do niej dostępu.

**Konsekwencje.**
- Potrzebny interceptor połączeń przełączający kontekst i testy integracyjne izolacji.
- Raporty przekrojowe między profilami wymagają osobnego, jawnie zatwierdzonego mechanizmu (poza zakresem).

**Weryfikacja (S27).** Zgodność `EXECUTE AS USER` z pulą połączeń EF Core i z transakcjami rozproszonymi; test: kod profilu próbujący czytać `task.WorkItem` lub `prj_<inny>` dostaje odmowę bazy; koszt wydajnościowy przełączania kontekstu.

## Plik: docs/adr/ADR-015-opencode-and-glm-models.md

# ADR-015: Agenci w OpenCode z modelami GLM 5.3 Flash

**Status:** Przyjęta; punkty 3 i 4 (profile modeli i polityka danych) zastąpione przez ADR-016 — wyłącznie model w infrastrukturze banku

**Kontekst.** Prace wytwórcze wspiera rój agentów AI. Wybrano jedno narzędzie orkiestracji i jedną rodzinę modeli, żeby uprościć utrzymanie harnessu, kwalifikację i koszty.

**Decyzja.**
1. Agentów uruchamia **OpenCode** (zweryfikowano na 1.19.5): definicje w `.opencode/agent/` generowane z `agents/registry.yaml` i manifestów profili, zasady w `AGENTS.md`, skille w `.opencode/skills/`, strażnik zapisu jako plugin `.opencode/plugin/write-scope.js` (logika: `tools/guard/enforce_write_scope.py`, ta sama w CI).
2. Model: **`glm-5.3-flash`** (rodzina GLM 5.3 Flash). Poziomy ról różnią się wariantem rozumowania (`low`, `high`, `max`); eskalacja to wyższy wariant, potem człowiek.
3. Dwa profile modeli: `glm` — API dostawcy (`zai-coding-plan`), `glm-self-hosted` — wagi GLM uruchomione w infrastrukturze banku (bramka zgodna z API OpenAI).
4. Polityka danych: klasy `internal` i `confidential` mogą trafić do API po zatwierdzeniu umowy powierzenia i lokalizacji przetwarzania (S-2); klasa `restricted` (kod bezpieczeństwa, profil `aml`) — wyłącznie do modelu w infrastrukturze banku. Generator wymusza to automatycznie.

**Konsekwencje.**
- Jedna rodzina modeli to mniejsza różnorodność recenzji — kompensują ją bramki deterministyczne, recenzja człowieka przed scaleniem i przypadki kwalifikacyjne E01–E08.
- Zewnętrzne API oznacza przetwarzanie kodu poza bankiem — bez decyzji S-2 zespół pracuje na profilu `glm-self-hosted`.
- Zmiana modelu lub wariantu wymaga ponownej kwalifikacji ról.

**Weryfikacja.** Identyfikatory i warianty potwierdza `opencode models <dostawca> --verbose`; kwalifikacja E01–E08 na obu profilach modeli przed krokami krytycznymi.

## Plik: docs/adr/ADR-016-self-hosted-model-only.md

# ADR-016: Wyłącznie model w infrastrukturze banku

**Status:** Przyjęta — zastępuje ADR-015 w części dotyczącej profilu modeli `glm` (API dostawcy) i polityki danych

**Kontekst.** ADR-015 dopuszczał dwa profile modeli: API dostawcy GLM (po decyzji S-2) i model w infrastrukturze banku. Bank zdecydował, że agenci zawsze korzystają z modelu uruchomionego u siebie — kod, specyfikacje i dane testowe nie opuszczają infrastruktury banku.

**Decyzja.**
1. Jedyny profil modeli: `glm-self-hosted` — wagi z rodziny GLM 5.3 Flash na bramce zgodnej z API OpenAI (vLLM, SGLang, TGI albo LiteLLM), wystawione pod nazwą `glm-5.3-flash`.
2. Polityka danych: każda klasa (`internal`, `confidential`, `restricted`) — wyłącznie `on-prem`. Generator agentów odrzuci profil modeli z hostingiem zewnętrznym.
3. Poziomy ról: warianty rozumowania wysyłane bramce w treści żądania (`low` — bez trybu myślenia, `high` — z trybem myślenia), zdefiniowane w `config/models.yaml` i przekazywane do `opencode.json`.
4. OpenCode dostaje limity modelu (kontekst i wyjście) z `config/models.yaml`, żeby poprawnie zarządzać kontekstem.

**Konsekwencje.**
- Bramka modelu staje się elementem środowiska (krok S06) z wymaganiami wydajności i dostępności; jej niedostępność zatrzymuje pracę roju (ryzyko R15), ale nie platformę.
- Brak różnorodności modeli w recenzji kompensują bramki deterministyczne, recenzja człowieka i kwalifikacja E01–E08.
- Decyzja S-2 dotyczy teraz bramki w banku (sprzęt, serwer, dostęp), a nie zgody na zewnętrzne API.

**Weryfikacja.** Parametry wariantów (`chat_template_kwargs.enable_thinking`) z wersją serwera bramki [DO WERYFIKACJI w S06]; `opencode models llm-gateway --verbose` pokazuje warianty i limity; kwalifikacja E01–E08 na bramce przed krokami krytycznymi.

## Plik: docs/adr/ADR-017-profile-data-actions.md

# ADR-017: Operacje na danych profilu (`profile-action`)

**Status:** Proponowana — uzupełnia ADR-012 (punkty rozszerzeń); zatwierdza architekt platformy, rozstrzygają S38 i S47

**Kontekst.** Punkty rozszerzeń z ADR-012 pozwalają profilowi zapisywać dane tylko w kontekście zadania (`task-action`) albo sprawy (`case-action`). Profil `flota` potrzebuje katalogu samochodów dostępnych do zakupu, który w aplikacji uzupełnia wskazana rola administracyjna profilu — taki zapis nie dotyczy żadnego zadania ani instancji procesu (wniosek zespołu: `docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md`). Bez nowego punktu zespół musiałby obchodzić brak procesem BPMN „zmiana katalogu” albo kodem platformy — a to łamie zasadę, że profil nie obchodzi braku punktu rozszerzenia, i rozprasza autoryzację oraz audyt.

**Decyzja.**
1. Nowy rodzaj operacji w manifeście: `profile-action` — zapis danych profilu (`prj_<id>`), niezwiązany z zadaniem ani sprawą. Interfejs SDK: `IProfileAction<TInput>`; endpoint: `POST /p/<id>/actions/{operationId}`.
2. Operację wykonuje ten sam potok platformy co pozostałe: uprawnienie z manifestu (deny by default, odmowa audytowana z wynikiem `Denied`), audyt Intent/Outcome z zasobem `profile:<id>/<encja>/<klucz>`, idempotencja po `requestId`, limit czasu (NFR-13), kontekst bazy `prj_<id>` (ADR-014).
3. Reguły manifestu (walidator profili): uprawnienie projektu rodzaju `write` (nie uprawnienie platformy); jawne `requiresAssignee: false` (R1 nie dotyczy — nie ma zadania); brak `appliesTo` (R9: operacja działa wyłącznie na danych własnego profilu).
4. Operacja nie zmienia zmiennych procesów i nie łączy się z Camunda; dane platformy czyta wyłącznie przez widoki `platform_api`.
5. UI: przyciski renderuje powłoka z `allowedActions`, które platforma dołącza do wyniku zapytania profilu (`query`) wyświetlanego na trasie `/p/<id>/…`. Komponent profilu nie decyduje o dostępności akcji.
6. SDK rozszerzeń 1.1 (zmiana zgodna wstecz). Profil korzystający z `profile-action` deklaruje `sdk: "^1.1"`; profile na `^1.0` działają bez zmian.

**Konsekwencje.**
- Profile prowadzą dane referencyjne (katalogi, słowniki, progi) w aplikacji, bez procesu BPMN i bez zmian w platformie.
- `profile-action` nie ma wbudowanej akceptacji drugiej osoby. Zmiana danych wymagająca czterech oczu nadal powinna być procesem z zadaniem zatwierdzenia (R1).
- Walidator manifestów (Python i `ph`) zna nowy rodzaj; testy zgodności SDK obejmują `IProfileAction`.

**Weryfikacja.** S19 (interfejs w SDK, walidacja manifestu), S38 (potok: uprawnienie, audyt, idempotencja, kontekst bazy), S47 (przyciski z `allowedActions` na trasach profilu); scenariusze `profiles/flota/specs/katalog-samochodow.feature`.

## Plik: docs/adr/ADR-018-camunda-forms-format-lifecycle-isolation.md

# ADR-018: Formatki w formacie Camunda Forms — aplikacja jako system zapisu, cykl życia z wycofaniem, separacja per proces

**Status:** Przyjęta (format, system zapisu, separacja, cykl życia); otwarte decyzje biznesowe D-12, D-13, D-14 nie zmieniają modelu

**Kontekst.** Dotychczas formatka była opisana ogólnie: „wersjonowany schemat (JSON Schema)”, reguły w JSON Logic, cykl `Draft → InReview → Published → Deprecated`, bez modelu wersji, wycofania i przynależności do procesu. Wymaganie: menadżer i administrator procesu tworzą formatki zgodne z biblioteką używaną przez Camunda 8.9 (tak jak w Modelerze), z pełnym wersjonowaniem, akceptacją i wycofaniem; każdy proces ma formatki wyłącznie dla siebie. Praktyka C6 już ustala, że zadanie wskazuje formatkę referencją zewnętrzną, a jej cykl życia należy do aplikacji.

**Decyzja.**
1. **Format.** Treścią wersji formatki jest dokument Camunda Forms (schemat form-js: `type`, `schemaVersion`, `executionPlatform`, `executionPlatformVersion`, `exporter`, `components`). Wyrażenia w FEEL. JSON Schema i JSON Logic nie są używane. Zgodność definiuje profil `ph-forms-8.9`: przypięta wersja biblioteki, `schemaVersion` ≤ 19 i katalog pól (`design/forms/field-catalog.yaml`).
2. **System zapisu.** Formatki, wersje, przeglądy, wycofania i przypięcia prowadzi moduł `FormManagement` w MSSQL. Formatki nie są wdrażane do silnika jako zasoby (`formId`); user task wskazuje formatkę przez `externalReference="ph:form/<klucz>"`, formatkę startową przypisuje do procesu Form Management.
3. **Separacja (R11).** Tożsamość formatki to `(TenantId, BpmnProcessId, FormKey)`. Klucz z referencji BPMN jest rozwiązywany wyłącznie w procesie zadania. Uprawnienia `Form.*` działają w zakresie procesu formatki. Nie ma formatek współdzielonych ani kopiowania między procesami w aplikacji; przeniesienie treści możliwe tylko przez jawny eksport i import pliku `.form`.
4. **Cykl życia wersji.** `Draft → InReview → Approved → Published`, dalej `Superseded` (zastąpiona nowszą) albo `Withdrawn` (wycofana). Najwyżej jedna wersja robocza i jedna obowiązująca. Zatwierdza osoba inna niż autor ostatniej zmiany (R8), a zatwierdzenie dotyczy skrótu treści. Wersje opublikowane są niezmienne i numerowane kolejno.
5. **Wycofanie.** Nowe uprawnienie `Form.Withdraw`. Wycofanie wymaga powodu; przy wersji obowiązującej wskazuje się wersję zastępczą (wcześniej opublikowaną, zgodną z kontraktem danych) albo świadomie zostawia formatkę bez wersji obowiązującej. Zadania w toku pozostają na wycofanej wersji albo — tryb `Repin` — są przepinane na zastępczą. Przepięcie jest jedynym wyjątkiem od niezmienności przypięcia i ma własny wpis w dzienniku.
6. **Uprawnienia.** Katalog L2: `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw`. Menadżer i administrator procesu mają komplet w swoich procesach; audytor — `Form.View`.
7. **Import i eksport.** Plik `.form` z Modelera można zaimportować jako szkic; każdą wersję można wyeksportować. Import przechodzi walidację katalogu pól.
8. **Zgodność z formatem.** W czasie działania serwer waliduje schemat katalogiem pól, który jest podzbiorem formatu Camunda Forms. Zgodność z oficjalnym schematem formatu (`@bpmn-io/form-json-schema`) sprawdzają testy: w frontendzie `ajv` (ADR-019), w .NET walidator JSON Schema używany wyłącznie w projektach testowych — paczkę o otwartej licencji wybiera S26 i zatwierdza architekt (zasada 9 w `AGENTS.md`).

**Odrzucone warianty.**
- *Wdrażanie formatek do silnika (linked forms, `formId`).* Silnik sam wiązałby wersję z zadaniem, ale: prawo tworzenia wdrożeń w Camunda obejmuje także BPMN i DMN (za szerokie dla klienta technicznego platformy; nazwy uprawnień potwierdza S02), identyfikator formularza jest globalny w tenancie (łamie separację per proces), wycofanie z przepięciem zadań i tak wymaga przypięć po stronie aplikacji, a dwa cykle życia (aplikacja i silnik) mogłyby się rozjechać. Do rozważenia ponownie tylko wtedy, gdy potrzebny będzie awaryjny dostęp przez natywny Tasklist.
- *Własny format formatek.* Brak zgodności z Modelerem i konieczność utrzymywania własnego edytora — wprost sprzeczne z wymaganiem.
- *Formatki współdzielone między procesami (biblioteka).* Zmiana wspólnej formatki dotykałaby procesów, których autor nie nadzoruje; sprzeczne z wymaganiem separacji.

**Konsekwencje.**
- Opublikowana formatka jest poprawnym plikiem `.form`; narzędzia Camunda (Modeler, walidatory schematu) działają na niej bez zmian.
- Platforma musi sama rozwiązywać referencje, przypinać wersje i walidować dane — silnik tego nie zrobi (ADR-020).
- Nowa reguła wiersza R11 i dwa nowe uprawnienia zmieniają macierz autoryzacji, deklaracje ról i scenariusze.
- Model BPMN nie może używać `formId` ani formularzy osadzonych — pilnuje tego reguła `ph/form-reference` wtyczki bpmnlint.
- Formatek nie usuwa się; schemat `form` rośnie z historią. Retencję wersji wycofanych ustala compliance.

**Weryfikacja.** S26 (agregat, cykl życia, R8, R11, wycofanie), S28 (schemat `form`), S29 (referencje, przypięcie, bpmnlint), S39 (przepięcie); scenariusze `specs/forms/*.feature`. Opis działania: `docs/architecture/14-form-management.md`.

## Plik: docs/adr/ADR-019-form-designer-and-design-system-materialization.md

# ADR-019: Projektant na edytorze form-js, materializacja formatek komponentami design systemu

**Status:** Proponowana — rozstrzygają S07 (edytor i renderer) i S09 (warstwa wizualna); zatwierdza architekt platformy z projektantem UX

**Kontekst.** Formatki mają być definiowane zgodnie z możliwościami biblioteki Camunda Forms, „analogicznie jak w Modelerze”, ale wyświetlane spójnie z resztą systemu: biznes decyduje o polach i ich układzie, a wygląd ustala projektant UX w Figma dla całej aplikacji. Biblioteka form-js renderuje formularze w Preact, z własnymi kontrolkami i stylem; aplikacja jest w Angularze i używa Kendo UI przez `core/ui-kit`. Poprzednie założenie — własna kanwa projektanta na Angular CDK — wymagałoby odtworzenia edytora i nie gwarantowałoby zgodności schematu.

**Decyzja.**
1. **Projektant.** Biblioteka `form-designer` osadza edytor `@bpmn-io/form-js-editor` (ten sam silnik co w Modelerze) w komponencie Angulara. Paleta i panel właściwości są ograniczone do katalogu pól; własności zablokowane nie są wyświetlane. Pola profili (`form.field`) pojawiają się w palecie jako warianty typów bazowych z własnością `ph:field`. Znak bpmn.io pozostaje widoczny (licencja).
2. **Renderer.** Biblioteka `form-runtime` to własny renderer w Angularze, który interpretuje schemat Camunda Forms i materializuje każdy typ dokładnie jednym komponentem z `core/ui-kit`. Wyrażenia FEEL i szablony wykonują te same biblioteki co w form-js (`@bpmn-io/feelin`, `feelers`); tekst Markdown — `marked` z sanityzacją `dompurify`.
3. **Katalog pól** (`design/forms/field-catalog.yaml`) jest kontraktem materializacji: typ → status → komponent → dozwolone własności. Czytają go: projektant (paleta), backend (walidacja publikacji), renderer (rejestr), testy (parytet rejestrów) i dokumentacja.
4. **Zestaw zgodności.** Formatki wzorcowe uruchamiane w rendererze platformy i w referencyjnym `@bpmn-io/form-js-viewer` (tylko w testach) muszą dawać ten sam zbiór widocznych pól, te same błędy walidacji i te same dane wyjściowe. Wygląd nie jest porównywany.
5. **Wygląd.** Źródłem wyglądu jest biblioteka w Figma prowadzona przez projektanta UX. Do repozytorium trafia jako eksport: zmienne → `design/tokens.json`, specyfikacje komponentów → `design/forms/` i `design/README.md`. Kod czyta wyłącznie pliki z repozytorium; agenci nie mają dostępu do Figma (ADR-016). Komponent UI nie używa wartości spoza tokenów — sprawdza to lint i regresja wizualna.
6. **Regresja wizualna i dostępność.** Katalog komponentów pól (aplikacja w Nx) jest fotografowany przez Playwright w obu motywach i trzech szerokościach; wzorce zatwierdza projektant UX. axe-core dla każdego komponentu i stanu.
7. **Nowe paczki npm** (zasada 9 w `AGENTS.md`): `@bpmn-io/form-js-editor` z zależnością `@bpmn-io/form-js-viewer` (licencja bpmn.io: MIT z obowiązkiem widocznego znaku), `@bpmn-io/feelin`, `feelers`, `marked` (MIT), `dompurify` (MPL-2.0 albo Apache-2.0); tylko do testów: `@bpmn-io/form-json-schema`, `ajv` (MIT). Wersje przypięte; aktualizacja z zielonym zestawem zgodności.
8. **Agenci warstwy wizualnej:** `ux-designer` (zapis w `design/**`), `design-system-engineer` (`core/theming`, `core/ui-kit`, komponenty pól), `ui-reviewer` (przegląd, tylko odczyt). Zakres zapisu ustala krok planu.

**Rozważane warianty renderera.**

| Wariant | Za | Przeciw |
| --- | --- | --- |
| A. Viewer form-js ze stylem nadpisanym w CSS | pełna zgodność zachowania bez pracy własnej | inne kontrolki niż w reszcie aplikacji (brak Kendo), wygląd i dostępność zależne od biblioteki; znak bpmn.io na każdym zadaniu |
| B. Viewer form-js z własnymi rendererami pól (Preact) | zgodność logiki, własny wygląd | drugi framework w aplikacji; komponenty `ui-kit` nie do użycia — design system w dwóch technologiach |
| **C. Własny renderer w Angularze na `ui-kit`** (rekomendacja) | jeden design system, te same komponenty co w całej aplikacji, pełna kontrola dostępności, sloty pól profili | zgodność zachowania trzeba utrzymywać — stąd katalog pól i zestaw zgodności |

Jeżeli PoC S07 pokaże, że koszt zgodności wariantu C jest nie do przyjęcia, wariantem zapasowym jest B dla typów złożonych (`dynamiclist`, `table`) przy zachowaniu C dla pozostałych.

**Konsekwencje.**
- Zmiana tokenów albo komponentu zmienia wygląd wszystkich formatek bez zmiany ich wersji.
- Nowa wersja form-js to świadoma aktualizacja: nowy typ pojawia się w aplikacji dopiero po wpisie w katalogu pól i implementacji komponentu.
- Kanwa edycji wygląda jak w Modelerze, a nie jak u wykonawcy — dlatego projektant ma zakładkę „Podgląd jak u wykonawcy” opartą o renderer platformy.
- `design/**` staje się źródłem dla kodu: zmiany przez pull request z przeglądem projektanta UX; do zespołu referencyjnego dochodzi rola projektanta UX.

**Weryfikacja.** S07 (osadzenie edytora, trzy formatki wzorcowe w wariantach A i C, pomiar rozbieżności), S09 (tokeny, katalog pól, specyfikacje zatwierdzone), S49 (komponenty pól i regresja wizualna), S40 i S45 (renderer i projektant), S55 (zestaw zgodności w CI). Założenia wizualne: `design/forms/README.md`.

## Plik: docs/adr/ADR-020-form-server-validation-and-feel.md

# ADR-020: Walidacja formatek po stronie serwera i ewaluacja FEEL

**Status:** Proponowana — rozstrzyga S08

**Kontekst.** Camunda nie sprawdza zmiennych przesyłanych przy zakończeniu zadania względem formularza — w natywnym Tasklist robi to przeglądarka. Process Hub musi walidować dane na serwerze według przypiętej wersji formatki (FR-06). Schemat Camunda Forms zawiera reguły statyczne (wymagalność, długości, zakresy, wzorce, opcje) i reguły w FEEL (ukrywanie pól, dynamiczne `readonly`/`disabled`, opcje z wyrażeń). .NET nie ma dojrzałej implementacji FEEL. Według dokumentacji API klastra Camunda 8.9 udostępnia ewaluację wyrażenia FEEL silnikiem (`POST /v2/expression/evaluation`, uprawnienie `EVALUATE` na zasobie `EXPRESSION`) — dostępność, kształt żądania i pokrycie przez oficjalne SDK potwierdza S08.

**Decyzja.**
1. **Poziom A — zawsze, bez FEEL** (moduł `FormRuntime`): przyjmowane są tylko klucze znane schematowi; typ wartości zgodny z typem pola; ograniczenia statyczne; wartość z listy opcji statycznych; pole stale `readonly` nie może zmienić wartości wejściowej, a pole stale `disabled` nie jest przyjmowane z przeglądarki; komplet wyjść z kontraktu `ph:outputs`. Poziom A nie zależy od żadnego komponentu zewnętrznego.
2. **Poziom B — wyrażenia FEEL** przez nowy port `IExpressionEvaluator` w `CamundaIntegration` (oficjalne SDK albo klient z OpenAPI wewnątrz ACL — ADR-003). Port ewaluuje wyrażenia formatki z kontekstem danych zadania; `FormRuntime` na tej podstawie ustala pola ukryte, zablokowane i dozwolone opcje, a potem stosuje reguły poziomu A do pól widocznych.
3. **Niedostępność ewaluacji** (silnik niedostępny, limit czasu): zakończenie zadania i tak wymaga silnika, więc żądanie kończy się błędem z możliwością ponowienia — bez obniżania poziomu walidacji.
4. **Składnia wyrażeń** jest sprawdzana tym samym portem przy przekazaniu formatki do przeglądu i ponownie przy publikacji; błąd składni blokuje obie operacje.
5. Klient techniczny roli `api` dostaje autoryzację `EXPRESSION: EVALUATE`; nie dostaje prawa wdrażania zasobów.

**Warianty do porównania w S08.**

| Wariant | Opis | Ryzyko |
| --- | --- | --- |
| **B1. Ewaluacja w silniku Camunda 8.9** (rekomendacja) | port na endpoint ewaluacji wyrażeń | różnice semantyki między `feelin` w przeglądarce a FEEL silnika; narzut wywołań przy dużych formatkach |
| B2. Usługa pomocnicza Node z form-js bez interfejsu | ta sama biblioteka co w przeglądarce | nowy komponent uruchomieniowy do utrzymania i zabezpieczenia w banku |
| B3. `feelin` w interpreterze JavaScript wewnątrz procesu .NET | ta sama biblioteka, bez nowego komponentu | nowa paczka NuGet, wydajność i zgodność interpretera |
| B0. Tylko poziom A | brak FEEL na serwerze | pola warunkowe walidowane wyłącznie w przeglądarce — niedopuszczalne jako stan docelowy, akceptowalne jako stan przejściowy do G2 |

**Konsekwencje.**
- Zestaw zgodności (ADR-019) zawiera przypadki FEEL wykonywane w przeglądarce i przez port — rozbieżność semantyki wychodzi w CI, nie w produkcji.
- Formatki powinny używać podzbioru FEEL wspólnego dla obu silników; lista konstrukcji dopuszczonych w wyrażeniach formatek powstaje w S08 i trafia do katalogu pól.
- Poziom A jest gotowy niezależnie od wyniku PoC i wystarcza do bramki G2.

**Weryfikacja.** S08: kształt żądania i odpowiedzi endpointu, przekazywanie kontekstu, czas dla formatki o 50 wyrażeniach, lista różnic `feelin` ↔ silnik, decyzja B1/B2/B3; S37: implementacja; scenariusze `specs/forms/form-rendering.feature`.

## Plik: docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md

# RFC-FLO-03: Operacja na danych profilu bez zadania i sprawy

| Pole | Wartość |
| --- | --- |
| Zgłasza | zespół profilu `flota` (`@bank/zespol-flota`) |
| Krok | FLO-03 — katalog samochodów (`profiles/flota/backlog.yaml`) |
| Dotyczy | kontrakt profili (`profiles/profile.schema.json`), SDK rozszerzeń, potok operacji (S38), sloty UI (S47) |
| Propozycja rozstrzygnięcia | ADR-017 (Proponowana) — zatwierdza architekt platformy w przeglądzie PR (`CODEOWNERS`) |

## Potrzeba

Wnioskodawca wybiera samochód z katalogu floty banku. Katalog — marka, model, wersja, kategoria floty, cena, emisja CO2, umowa ramowa — uzupełnia w aplikacji jedna rola profilu: **Administrator katalogu samochodów**. Wszystkie role profilu widzą katalog w sekcji nawigacji „Flota”; role innych profili go nie widzą, a formatki innych procesów nie mogą z niego korzystać.

## Dlaczego obecne punkty rozszerzeń nie wystarczają

| Punkt | Dlaczego nie |
| --- | --- |
| `query`, `form-data-source`, `task-enricher` | tylko odczyt |
| `task-action` | wymaga zadania i assignee (R1); dopisanie modelu do katalogu nie jest krokiem żadnego procesu |
| `case-action` | wymaga instancji procesu; katalog istnieje niezależnie od spraw |
| `event-handler` | reaguje na zdarzenia platformy, nie na decyzję użytkownika |

## Propozycja

Nowy rodzaj operacji `profile-action` — zapis danych profilu w `prj_<id>`, wykonywany przez ten sam potok co pozostałe operacje:

```yaml
- id: flota.SaveCatalogItem
  kind: profile-action
  title: Zapisz model w katalogu
  permission: flota.Catalog.Manage      # uprawnienie projektu rodzaju write
  requiresAssignee: false               # jawnie: nie ma zadania, R1 nie dotyczy
  idempotent: true                      # bez appliesTo — operacja nie dotyczy procesów (R9)
```

```csharp
public interface IProfileAction<TInput>
{
    ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, TInput input, CancellationToken ct);
}

public sealed record ProfileActionContext(ActorContext Actor, IClock Clock);   // bez zadania i bez komend Camunda
```

- Endpoint `POST /p/<id>/actions/{operationId}` z `requestId`; potok: uprawnienie, odmowa audytowana (`Denied`), audyt Intent/Outcome (zasób `profile:<id>/<encja>/<klucz>`), idempotencja, limit czasu, kontekst bazy `prj_<id>`.
- Wynik zapytania profilu (`query`) przychodzi z `allowedActions` — przyciski „Dodaj model”, „Zmień”, „Wycofaj” renderuje powłoka.
- SDK 1.1 (zmiana zgodna wstecz); profile na `^1.0` bez zmian.

## Rozważone alternatywy

| Wariant | Ocena |
| --- | --- |
| Proces BPMN „zmiana katalogu” (wniosek → zatwierdzenie → zapis przez workera) | działa na obecnych punktach i daje cztery oczy, ale każda poprawka ceny to sprawa w Camunda, a administrator czeka na zatwierdzenie, którego biznes nie wymaga. Zostaje zalecanym wzorcem, gdy cztery oczy są wymagane |
| Synchronizacja katalogu z systemu zakupowego (worker lub `event-handler`) | dobra, gdy katalog prowadzi inny system; tu katalog prowadzi zespół floty w aplikacji |
| Endpoint w kodzie platformy | odrzucone — profil nie obchodzi braku punktu rozszerzenia kodem platformy (ADR-012, `docs/architecture/13-project-profiles.md` §10) |

## Wpływ

| Obszar | Zmiana | Krok |
| --- | --- | --- |
| Kontrakt profilu | `profile-action` w `profiles/profile.schema.json`; reguły walidatora (Python i `ph`) z autotestem | ten PR |
| SDK | `IProfileAction<TInput>`, `ProfileActionContext`, rejestracja `AddProfileAction<…>()`, test zgodności | S19 |
| Potok | endpoint `/p/<id>/actions/…`, audyt, idempotencja, kontekst bazy | S38 |
| UI | `allowedActions` w wyniku zapytania profilu, przyciski w powłoce | S47 |
| Istniejące profile | bez zmian | — |

## Pytania do architekta platformy

1. Czy zasób audytu `profile:<id>/<encja>/<klucz>` wystarczy do raportów audytora, czy potrzebne jest osobne pole „typ zasobu”?
2. Czy limit czasu `profile-action` ma być taki jak operacji na zadaniu (propozycja NFR-13: 5 s)?

## Plik: config/authorization/assignments.example.yaml

````yaml
# Przypisania RÓL GLOBALNYCH do grup AD (claim "groups" z RHBK).
# Role projektowe i grupy kandydujące przypisuje każdy profil we własnym pliku: profiles/<id>/authorization.yaml (ADR-012).
# Reconciler łączy oba źródła; konflikty rozdziału obowiązków (R7) i naruszenia przestrzeni nazw (R10) odrzuca.
tenant: "<default>"
assignments:
  - group: PH-AUDYT
    role: auditor
    scope: { processes: ["*"] }
  - group: PH-PLATFORMA-ADM
    role: platform-administrator
    scope: { processes: [] }

profiles: "profiles/*/authorization.yaml"
````

## Plik: config/authorization/roles.example.yaml

````yaml
# Katalog ról PLATFORMY. Uprawnienia L2 = enum Permission w kodzie; L1 = autoryzacje Camunda na PROCESS_DEFINITION.
# Role projektowe składają się z tych ról i uprawnień projektu — definiują je profile (profiles/<id>/profile.yaml).
# Nazwy uprawnień Camunda do potwierdzenia w S02 dla wersji 8.9.
roles:
  - id: participant
    name: Uczestnik
    readOnly: false
    permissions: [Task.ViewOwn, Task.ViewGroup, Task.Claim, Task.Complete, Process.ViewOwn, Absence.ManageOwn]
    camunda: [READ_PROCESS_DEFINITION, READ_USER_TASK, UPDATE_USER_TASK]

  - id: process-starter
    name: Inicjator procesu
    readOnly: false
    permissions: [Process.Start, Process.ViewOwn]
    camunda: [READ_PROCESS_DEFINITION, CREATE_PROCESS_INSTANCE]

  - id: process-manager
    name: Menadżer procesu
    readOnly: false
    permissions: [Task.ViewAllInScope, Task.Reassign, Task.ReassignBulk, Absence.ManageInScope,
                  Process.ViewAllInScope, Insight.Dashboard, Insight.Escalations,
                  StageMap.Edit, Form.View, Form.Edit, Form.Approve, Form.Publish, Form.Withdraw]
    camunda: [READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK, UPDATE_USER_TASK]

  - id: process-administrator
    name: Administrator procesu
    readOnly: false
    permissions: [Process.ViewAllInScope, Insight.Dashboard, StageMap.Edit, StageMap.MapElements,
                  Bpmn.ViewTechnical, Form.View, Form.Edit, Form.Approve, Form.Publish, Form.Withdraw]
    camunda: [READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE]

  - id: auditor
    name: Audytor
    readOnly: true            # inwariant: żadnych uprawnień zapisu
    permissions: [Task.ViewAllInScope, Process.ViewAllInScope, Insight.Dashboard, Insight.Escalations, Form.View, Audit.ViewJournal]
    camunda: [READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK]

  - id: platform-administrator
    name: Administrator platformy
    readOnly: false
    permissions: [Platform.Configure, Audit.ViewTrace]
    camunda: []               # autoryzacje zmienia wyłącznie reconciler swoim klientem

segregationOfDuties:
  - conflict: [auditor, participant]
  - conflict: [auditor, process-manager]
  - conflict: [auditor, process-administrator]
````

## Plik: config/ownership.yaml

````yaml
# Własność kodu platformy (źródło dla CODEOWNERS; własność profili pochodzi z profiles/*/profile.yaml).
# Nazwy grup są przykładowe — ustaw grupy z systemu kontroli wersji banku.
platform: "@bank/zespol-platformy"
architects: "@bank/architekci-platformy"
security: "@bank/bezpieczenstwo"
design: "@bank/zespol-design-systemu"     # projektant UX i inżynierowie design systemu
paths:                                   # ścieżki platformy wymagające dodatkowego przeglądu
  - { path: /config/authorization/, owners: [platform, security] }
  - { path: /tools/guard/, owners: [platform, security] }
  - { path: /src/Platform/ProcessHub.Extensibility/, owners: [platform, architects] }
  - { path: /frontend/libs/platform/extension-sdk/, owners: [platform, architects] }
  - { path: /docs/adr/, owners: [architects] }
  - { path: /profiles/README.md, owners: [platform, architects] }
  - { path: /profiles/profile.schema.json, owners: [platform, architects] }
  - { path: /profiles/_template/, owners: [platform] }
  - { path: /design/, owners: [design, platform] }
  - { path: /design/forms/field-catalog.yaml, owners: [design, architects, security] }
  - { path: /frontend/libs/core/ui-kit/, owners: [platform, design] }
  - { path: /frontend/libs/core/theming/, owners: [platform, design] }
  - { path: /docs/artifacts/04-wytyczne-ui.md, owners: [design, architects] }
````

## Plik: CODEOWNERS

````text
# WYGENEROWANE przez tools/profiles/validate_profiles.py --write-codeowners — źródła: config/ownership.yaml, profiles/*/profile.yaml

*  @bank/zespol-platformy
/config/authorization/  @bank/zespol-platformy @bank/bezpieczenstwo
/tools/guard/  @bank/zespol-platformy @bank/bezpieczenstwo
/src/Platform/ProcessHub.Extensibility/  @bank/zespol-platformy @bank/architekci-platformy
/frontend/libs/platform/extension-sdk/  @bank/zespol-platformy @bank/architekci-platformy
/docs/adr/  @bank/architekci-platformy
/profiles/README.md  @bank/zespol-platformy @bank/architekci-platformy
/profiles/profile.schema.json  @bank/zespol-platformy @bank/architekci-platformy
/profiles/_template/  @bank/zespol-platformy
/design/  @bank/zespol-design-systemu @bank/zespol-platformy
/design/forms/field-catalog.yaml  @bank/zespol-design-systemu @bank/architekci-platformy @bank/bezpieczenstwo
/frontend/libs/core/ui-kit/  @bank/zespol-platformy @bank/zespol-design-systemu
/frontend/libs/core/theming/  @bank/zespol-platformy @bank/zespol-design-systemu
/docs/artifacts/04-wytyczne-ui.md  @bank/zespol-design-systemu @bank/architekci-platformy

/profiles/aml/  @bank/zespol-aml
/profiles/aml/profile.yaml  @bank/zespol-aml @bank/architekci-platformy
/profiles/aml/authorization.yaml  @bank/zespol-aml @bank/architekci-platformy @bank/bezpieczenstwo
/profiles/flota/  @bank/zespol-flota
/profiles/flota/profile.yaml  @bank/zespol-flota @bank/architekci-platformy
/profiles/flota/authorization.yaml  @bank/zespol-flota @bank/architekci-platformy @bank/bezpieczenstwo
/profiles/kredyty/  @bank/zespol-kredyty
/profiles/kredyty/profile.yaml  @bank/zespol-kredyty @bank/architekci-platformy
/profiles/kredyty/authorization.yaml  @bank/zespol-kredyty @bank/architekci-platformy @bank/bezpieczenstwo
````

