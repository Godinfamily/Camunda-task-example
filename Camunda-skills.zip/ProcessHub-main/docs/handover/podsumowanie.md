# Podsumowanie: dane wejściowe, wymagania i rezultaty projektu Process Hub (v4)

Dokument zbiera wszystko, co powstało w projekcie: materiały wejściowe, wymagania zgłaszane w kolejnych krokach, podjęte decyzje, wytworzone artefakty i kluczowe liczby. Jest rejestrem wymagań W-xx, do którego odwołują się inne dokumenty (np. `docs/artifacts/assumptions.yaml`).

## 1. Materiały wejściowe (wersja v1)

| Plik | Zawartość |
| --- | --- |
| `architektura-platforma-bpm-camunda.md` | Platforma „Process Hub” zastępująca natywny Tasklist Camunda 8.9: Camunda jako jedyne źródło prawdy, CQRS z read modelem, ACL do Camunda, SSO Keycloak RHBK (jeden realm, federacja AD), dwupoziomowa autoryzacja, etapy biznesowe w BPMN, audyt append-only, fazy wdrożenia |
| `backend-architektura-szczegolowa.md` | Aktorzy, funkcje, konteksty, konfiguracja klienta Camunda, outbox, idempotencja, układ rozwiązania .NET, testy behawioralne |
| `frontend-architektura-ui.md` | Angular i Telerik Kendo UI, Nx, UI Kit, motywy na tokenach (kolory marki banku do potwierdzenia), WCAG AAA z wyjątkami, i18n, Signals, zapis widoków list |
| `camunda-devops-przygotowanie-srodowiska.md` | Camunda 8.9 Self-Managed na Kubernetes, realm RHBK, klienci OIDC, Identity, multi-tenancy, sieć, observability, hosting BFF i SPA, licencja Kendo |

## 2. Zasady pracy

Zwięźle i precyzyjnie; wzorce architektoniczne i archetypy; jakość kodu, testowalność i reużywalność; testy behawioralne (Gherkin, dziś Reqnroll); przy BPMN/Camunda uzasadnienie „dlaczego”; persystencja w MS SQL Server.

## 3. Wymagania

| Id | Wymaganie |
| --- | --- |
| W-01 | Plan architektury własnego TaskList dla Camunda 8.9: własny interfejs użytkownika |
| W-02 | Moduł generowania formatek przez administratora |
| W-03 | Użytkownik widzi swoje zadania oraz stan zadań tej samej grupy uprawnień |
| W-04 | Edytować i kończyć zadanie może tylko osoba, która je przyjęła |
| W-05 | Warstwa menadżera: stan wszystkich zadań zespołu |
| W-06 | DDD, SOLID i archetypy (np. Party) |
| W-07 | Separacja widoczności między grupami operacyjnymi i biznesami |
| W-08 | Audytowalność wszystkich operacji |
| W-09 | Testy BDD |
| W-10 | Plan prac, ścieżka krytyczna, harness modeli AI oszczędzający tokeny przy rzetelnej weryfikacji |
| W-11 | Implementacja przez rój agentów AI — konfiguracja roju |
| W-12 | Frontend w Angularze, SSO w RHBK |
| W-13 | Diagramy modułów, kontekstów i architektury |
| W-14 | Domyślnie jeden tenant, architektura gotowa na wielu |
| W-15 | Widoczność w tenancie przez autoryzacje zasobów Camunda |
| W-16 | Backend korzysta z oficjalnego SDK Camunda |
| W-17 | Wszystkie artefakty w repozytorium, czytelne dla agentów |
| W-18 | Każda akcja audytowana i zapisywana w bazie (bezpieczeństwo, analiza problemów) |
| W-19 | Jedna osoba może mieć wiele ról |
| W-20 | Start procesów z aplikacji |
| W-21 | Formatki edytuje menadżer procesu lub administrator |
| W-22 | Rola audytora: odczyt wszystkich procesów |
| W-23 | Menadżer zmienia osobę lub grupę w trakcie procesu (urlopy) |
| W-24 | Eskalacje i widok procesów eskalowanych |
| W-25 | Dashboard menadżera: wystartowane, sukces, błąd, metryki zdrowia |
| W-26 | Workflow i stan procesu dla formatki bez technikaliów BPMN — warstwa etapów |
| W-27 | Harmonogram bez dat — wykonywalny plan kroków dla agentów |
| W-28 | Instrukcja dostosowania agentów do różnych dostawców modeli i modeli self-hosted (w v3 zastąpiona przez W-36) |
| W-29 | Klikalna makieta UI w barwach zbliżonych do barw Polski |
| W-30 | Złożoność i pracochłonność kroków w hybrydzie AI + ludzie |
| W-31 | Interaktywny dashboard harmonogramu z warstwami dla planowania i decydentów |
| W-32 | Podsumowanie i prompt do odtworzenia artefaktów w innym modelu |
| W-33 | Prompty odtwarzające repozytorium od zera, bez przekazywania plików |
| W-34 | Prompt kontekstowy do notesu w innym modelu |
| W-35 | Instrukcja startu projektu z OpenCode krok po kroku |
| W-36 | Agenci orkiestrowani przez OpenCode z modelem z rodziny GLM 5.3 Flash; repozytorium bez odniesień do poprzedniego narzędzia agentowego |
| W-37 | Repozytorium neutralne: zamiast nazwy konkretnego banku — „bank” |
| W-38 | Profile określające role w ramach projektów korzystających z TaskList; wydzielona część specyficzna (dane, operacje dedykowane) realizowana niezależnie przez zespoły projektów; część platformowa wspólna; separacja kodu |
| W-39 | Artefakty projektowe: plan systemu, aktorzy i główne założenia |
| W-40 | Model zawsze uruchomiony w infrastrukturze banku (self-hosted) — żadnych zewnętrznych API |
| W-41 | Narzędzia repozytorium także w C# (.NET 10, język C# 10) z kodem źródłowym, bez instalacji przez `pip` i bez zależności od Pythona; pliki Pythona zostają, wersja .NET jest opcją |
| W-42 | Przykładowe procesy: opiniowanie rejestracji samochodu udostępnione komórkom banku (IT, HR, Prawny, Finanse, Ryzyko) z diagramem; dedykowane menu z katalogiem samochodów widocznym tylko dla profilu procesu i uzupełnianym przez jedną z ról administracyjnych; instrukcja dla zespołów o możliwościach i ograniczeniach platformy, konfiguracji i podpięciu; makieta z tą opcją; prompty od zera zgodne z repozytorium |
| W-43 | Moduł zarządzania formatkami Camunda Forms z poziomu systemu: menadżer lub administrator procesu tworzy formatki zgodne z biblioteką używaną przez Camunda 8.9, analogicznie jak w Modelerze |
| W-44 | Pełne zarządzanie wersjami formatek, akceptacja i wycofywanie |
| W-45 | Formatki renderowane na zadaniu w wyglądzie spójnym z resztą systemu: definicja zgodna z możliwościami biblioteki Camunda, materializacja zgodna z warstwą wizualną przygotowaną przez projektanta UX w Figma; biznes decyduje o polach i układzie, wygląd jest wspólny |
| W-46 | Separacja widoczności formatek: każdy proces ma formatki wyłącznie dla siebie |
| W-47 | Szczegółowy opis działania modułu dla osób rozwijających system (założenia wizualne, koncepcje, odpowiedzialności), plan wykonywalny modułu i agenci odpowiadający za warstwę wizualną |
| W-48 | Artefakt z wytycznymi i założeniami systemu dla osoby zaczynającej pracę nad interfejsem użytkownika |

## 4. Kluczowe decyzje

- **Architektura.** Modularny monolit .NET 10 w rolach `api`, `projector`, `jobs`, `worker`; moduły heksagonalne; potok komend: ślad → walidacja → autoryzacja → audyt Intent/Outcome → idempotencja → transakcja z outboxem.
- **Konteksty DDD.** Rdzeń: Task Work, Process Lifecycle, Process Insight, Form Management; wspierające: Form Runtime, Party & Accountability, Access Policy, Audit, Extension Host; generyczne: Camunda Integration (ACL z oficjalnym SDK), Platform Administration, User Preferences, Notification. Profile projektów to osobne konteksty poza platformą.
- **Uprawnienia.** Role platformy (Uczestnik, Inicjator, Menadżer procesu, Administrator procesu) i globalne (Audytor, Administrator platformy); role projektowe w profilach. L1 autoryzacje Camunda, L2 polityka aplikacji; uprawnienia jako kod z reconcilerem; reguły R1–R11 (R9 zasoby profilu, R10 przestrzeń nazw profilu, R11 formatka należy do procesu).
- **Profile projektów (ADR-012…014, ADR-017).** Manifest profilu (procesy, role projektowe, uprawnienia, dane, operacje na zadaniu, sprawie i danych profilu, sloty UI z sekcją nawigacji, integracje); SDK rozszerzeń jako jedyna zależność; potok operacji platformy; przykład kompletu dedykowanych elementów: profil `flota` (katalog samochodów, opinie komórek banku); modele in-process i remote; separacja w ośmiu warstwach (repozytorium, kompilacja, uprawnienia, wykonanie, dane, wdrożenie, CI, agenci AI); schemat i użytkownik bazy per profil; własne plany zespołów.
- **Formatki (ADR-018…020).** Format Camunda Forms (schemat form-js, FEEL) z importem i eksportem `.form`; aplikacja jest systemem zapisu — formatek nie wdraża się do silnika, zadanie wskazuje je referencją zewnętrzną. Wersje w cyklu szkic → przegląd → zatwierdzenie (R8) → publikacja → zastąpienie albo wycofanie (`Form.Withdraw`, z wersją zastępczą i opcjonalnym przepięciem zadań). Formatka należy do jednego procesu (R11). Projektant osadza edytor form-js z paletą ograniczoną katalogiem pól; na zadaniu formatkę materializuje własny renderer komponentami design systemu; dane waliduje serwer (reguły schematu, FEEL przez silnik).
- **Warstwa wizualna.** Trzy warstwy: struktura (biznes, schemat formatki), materializacja (katalog pól: typ → komponent `ui-kit`), wygląd (projektant UX: Figma → `design/tokens.json`). Agenci `ux-designer`, `design-system-engineer`, `ui-reviewer`; regresja wizualna i axe w CI; wytyczne dla nowych osób w `docs/artifacts/04-wytyczne-ui.md`.
- **Dane.** MS SQL Server 2022+: schematy per moduł i `prj_<id>` per profil, RLS, Ledger, partycjonowany ślad operacyjny, tabele temporalne.
- **Wgląd menadżera.** Mapa etapów nad BPMN, dashboard z wynikiem biznesowym na zdarzeniach końcowych, eskalacje, przekazywanie i zastępstwa.
- **Agenci (ADR-015, ADR-016).** OpenCode z `glm-5.3-flash` wyłącznie na bramce w infrastrukturze banku (jeden profil modeli `glm-self-hosted`, polityka danych tylko on-prem); poziomy ról jako warianty rozumowania wysyłane bramce (`low`, `high`); agenci profili z zapisem tylko we własnym profilu; strażnik zapisu w OpenCode i CI.
- **Narzędzia.** Dwie równoważne implementacje: Python (`tools/*.py`) i .NET (`tools/dotnet`, polecenie `ph`, C# 10, zero paczek NuGet). Wyniki identyczne co do bajtu (zaokrąglanie, `repr`, sumy i JSON jak w Pythonie 3.12+, YAML jak PyYAML); obie przechodzą te same bramki `--check`; plugin strażnika i `ph step dod` same przełączają się na .NET, gdy Pythona brak.

## 5. Rezultaty (repozytorium `process-hub`, v4)

| Obszar | Pliki | Zawartość |
| --- | --- | --- |
| Wejście | `README.md`, `AGENTS.md`, `CODEOWNERS` | mapa, zasady dla agentów i ludzi, tabela agentów, własność kodu |
| Architektura | `docs/architecture/00–14`, `docs/glossary.md` | 15 dokumentów, w tym profile projektów i moduł zarządzania formatkami; słownik PL ↔ kod |
| Decyzje | `docs/adr/ADR-001…020`, `docs/rfc/` | 20 ADR (ADR-018…020: formatki), wnioski RFC |
| Artefakty projektowe | `docs/artifacts/` | plan systemu, aktorzy, założenia, wytyczne UI (Markdown i strony HTML), rejestry YAML |
| Profile projektów | `profiles/`, `docs/guides/` | schemat manifestu, szablon, przewodnik, instrukcja dedykowanych elementów, profile `kredyty` (in-process), `aml` (remote) i `flota` (in-process: katalog samochodów, opinie komórek banku, modele BPMN) z planami i scenariuszami |
| Uprawnienia | `config/authorization/`, `profiles/*/authorization.yaml` | role platformy, role globalne, role projektowe |
| Specyfikacje | `specs/**`, `profiles/*/specs/` | scenariusze platformy (w tym profile) i scenariusze zespołów profili |
| Plan i wycena | `plan/` | 57 kroków (w tym 8 kroków modułu formatek i warstwy wizualnej), bramki G0–G3, model wyceny, raport, dashboard (strona działa z dysku) |
| Agenci | `.opencode/`, `opencode.json`, `agents/`, `config/models.yaml`, `evals/agents/` | agenci platformy i profili, skille, komendy, plugin strażnika, profile modeli GLM, kwalifikacja E01–E11; role warstwy wizualnej i skille `camunda-forms`, `design-system` |
| Narzędzia | `tools/` | generator agentów, prowadzenie kroków, strażnik zapisu, walidacja profili, wycena, eksport dashboardu, artefakty, źródła notesu — w Pythonie |
| Narzędzia .NET | `tools/dotnet/` | te same narzędzia w C# (`ph`), testy bez zewnętrznych paczek, skrypt zgodności w obie strony |
| UI | `design/` | propozycja projektowa, tokeny, klikalna makieta, `forms/`: założenia wizualne formatek, katalog pól, formatka wzorcowa |
| Przekazanie | `docs/handover/` | to podsumowanie, prompty od zera, prompt i źródła notesu |

## 6. Kluczowe liczby (model, do kalibracji)

| Wielkość | Z AI | Bez AI |
| --- | --- | --- |
| Czas do końca pilotażu | 27,6 tyg. (P80: 30,8) | 38,3 tyg. (P80: 42,9) |
| Praca ludzi z narzutami | 459 osobodni | 597 osobodni |
| Ścieżka krytyczna | 138 dni roboczych | 177 dni roboczych |

Zespół referencyjny 6,2 etatu (w tym 0,5 etatu projektanta UX), wykorzystanie 75%. Moduł formatek z warstwą wizualną dodał ok. 59 osobodni bez zmiany kalendarza; jego łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma ok. 2,6 dnia zapasu. Najtrudniejsze kroki: S02, S50, S23, S21, S60, S06, S24, S27, S34. Kroki profili (S19, S27, S38, S47, S48) dodają ok. 39 osobodni, ale mają zapas i nie wydłużają kalendarza. Wrażliwość: wolne procedury banku +4,9 tyg.; podział kroków krytycznych −2,0 tyg.; słabsi agenci +2,7 tyg.; większy zespół 0 tyg.

## 7. Do weryfikacji

Pokrycie oficjalnego SDK Camunda dla .NET w 8.9; nazwy uprawnień autoryzacji Camunda; korekty w task listenerach; token delegowany w RHBK; `EXECUTE AS USER` z pulą połączeń EF Core (izolacja profili); ograniczenie workerów profili do ich procesów; parametry wariantów rozumowania i limity modelu GLM na bramce banku; bramka i sprzęt GPU (S-2); kolory z księgi znaku banku i biblioteka w Figma (S09); zgodność własnego renderera z form-js (S07); endpoint ewaluacji FEEL w 8.9 (S08); licencja bpmn.io dla osadzonego edytora; decyzje D-01…D-16; właściciele i oceny ryzyk.
