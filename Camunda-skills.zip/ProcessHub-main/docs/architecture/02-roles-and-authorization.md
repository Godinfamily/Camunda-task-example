# 02. Role, uprawnienia i autoryzacja

Uprawnienia są danymi, a nie kodem: rola to nazwany zbiór uprawnień, przypisany grupie AD w zakresie (tenant + definicje procesów). Ten sam plik deklaracji zasila autoryzacje zasobów w Camunda (poziom L1) i politykę aplikacji (L2), więc oba poziomy nie mogą się rozjechać.

## Model (archetyp Party + Knowledge Level)

```mermaid
classDiagram
    class Party {
      PartyId
      AdObjectGuid
    }
    class Permission {
      <<enumeration>>
      TaskClaim
      TaskReassign
      ProcessStart
    }
    class Role {
      RoleId
      Name
      ReadOnly
    }
    class RoleAssignment {
      Subject
      ValidFrom
      ValidTo
    }
    class Scope {
      TenantId
      Processes
      TeamId
    }
    Role "1" o-- "*" Permission
    RoleAssignment "*" --> "1" Role
    RoleAssignment "1" *-- "1" Scope
    Party "1" --> "*" RoleAssignment : przez grupy AD
```

- **Permission** — enum w kodzie (jedyne miejsce, gdzie uprawnienie „istnieje”). Test sprawdza, że YAML nie używa nieistniejących uprawnień.
- **Role** — dane w `config/authorization/roles.yaml`. Flaga `readOnly: true` (audytor) jest inwariantem: rola tylko do odczytu nie może zawierać uprawnień zapisu.
- **RoleAssignment** — grupa AD (z claimu `groups`) lub osoba → rola w zakresie, opcjonalnie z okresem ważności.
- **Uprawnienia efektywne** = suma przypisań, których zakres obejmuje zasób. Jedna osoba może być jednocześnie uczestnikiem procesu A, menadżerem procesu B i administratorem procesu C.

## Katalog uprawnień aplikacji (L2)

| Uprawnienie | Znaczenie |
| --- | --- |
| `Task.ViewOwn`, `Task.ViewGroup` | moje zadania; zadania moich grup kandydujących |
| `Task.Claim`, `Task.Complete` | przejęcie; zakończenie i szkic (dodatkowo reguła R1) |
| `Task.ViewAllInScope` | wszystkie zadania procesów w zakresie |
| `Task.Reassign`, `Task.ReassignBulk` | przekazanie zadania osobie lub grupie; masowo |
| `Absence.ManageOwn`, `Absence.ManageInScope` | własne zastępstwa; zastępstwa innych w zakresie |
| `Process.Start`, `Process.ViewOwn`, `Process.ViewAllInScope` | start; moje procesy; wszystkie instancje w zakresie |
| `Insight.Dashboard`, `Insight.Escalations` | dashboard i lista eskalacji |
| `StageMap.Edit` | nazwy, kolejność, opisy, progi SLA etapów |
| `StageMap.MapElements`, `Bpmn.ViewTechnical` | przypisanie elementów BPMN do etapów; techniczny podgląd BPMN |
| `Form.View` | lista formatek procesu, wersje, historia, porównanie, eksport |
| `Form.Edit`, `Form.Approve`, `Form.Publish` | tworzenie i edycja szkicu, import; zatwierdzenie (inna osoba niż autor); publikacja |
| `Form.Withdraw` | wycofanie wersji albo całej formatki, z powodem i skutkiem dla zadań w toku |
| `Audit.ViewJournal`, `Audit.ViewTrace` | dziennik bezpieczeństwa; ślad diagnostyczny |
| `Platform.Configure` | konfiguracja platformy, bez danych biznesowych |

## Role i ich odwzorowanie w Camunda

Zasób Camunda: `PROCESS_DEFINITION`, `resourceId` = `bpmnProcessId` lub `*`. Nazwy uprawnień Camunda do potwierdzenia w kroku S02 względem wersji 8.9.

| Rola | Zakres typowy | Uprawnienia aplikacji (L2) | Autoryzacje Camunda (L1) |
| --- | --- | --- | --- |
| Uczestnik | procesy, w których grupa uczestniczy | ViewOwn, ViewGroup, Claim, Complete, Process.Start*, Process.ViewOwn, Absence.ManageOwn | READ_PROCESS_DEFINITION, READ_USER_TASK, UPDATE_USER_TASK, CREATE_PROCESS_INSTANCE* |
| Menadżer procesu | wybrane definicje | ViewAllInScope, Reassign, ReassignBulk, Absence.ManageInScope, Process.ViewAllInScope, Insight.*, StageMap.Edit, Form.* | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK, UPDATE_USER_TASK |
| Administrator procesu | wybrane definicje | Process.ViewAllInScope, Insight.Dashboard, StageMap.Edit, StageMap.MapElements, Bpmn.ViewTechnical, Form.* | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE |
| Audytor | `*` | ViewAllInScope (tylko odczyt), Process.ViewAllInScope, Insight.*, Form.View, Audit.ViewJournal | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK na `*` |
| Administrator platformy | tenant | Platform.Configure, Audit.ViewTrace | zarządzanie autoryzacjami tylko przez klienta reconcilera |

`*` — tylko gdy proces dopuszcza start z aplikacji przez tę grupę. `Form.*` = `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw`; uczestnik nie ma żadnego z nich — formatkę widzi wyłącznie na zadaniu.

**Dlaczego dwa poziomy.** Autoryzacja zasobów w Camunda jest gruba: `READ_USER_TASK` na definicji daje wszystkie zadania tej definicji. Reguły „tylko assignee edytuje”, „uczestnik widzi swoje i grupowe”, „menadżer nie edytuje treści” musi wymusić aplikacja (L2). L1 jest siatką bezpieczeństwa: nawet błąd w L2 nie pozwoli wyjść poza definicje w zakresie.

## Reguły na poziomie wiersza (L2)

1. **R1 Zapis = assignee.** `SaveDraft`, `Complete`, `Unclaim` wymagają `actor == assignee`; uprawnienie roli nie wystarcza.
2. **R2 Przejęcie.** Aktor należy do `candidateGroups` (lub `candidateUsers`), zadanie jest nieprzypisane.
3. **R3 Widoczność** = assignee ∨ grupa kandydująca ∨ inicjator ∨ `Task.ViewAllInScope` w zakresie definicji.
4. **R4 Ograniczenie projekcji.** XML BPMN, identyfikatory elementów, nazwy elementów niezmapowanych i zmienne spoza formatek tylko z `Bpmn.ViewTechnical`; pozostali widzą mapę etapów.
5. **R5 Odmowa jest zdarzeniem** audytu z wynikiem `Denied` i kodem reguły.
6. **R6 Przekazanie** wymaga `Task.Reassign`, kodu powodu (urlop, choroba, obciążenie, inne + opis), a osoba docelowa musi mieć rolę Uczestnika w zakresie definicji (inaczej nie mogłaby działać na zadaniu).
7. **R7 Rozdział obowiązków.** Audytor nie może mieć ról operacyjnych w tym samym zakresie — reconciler odrzuca taką konfigurację.
8. **R8 Cztery oczy.** Zatwierdzający formatkę ≠ autor ostatniej zmiany; zatwierdzenie dotyczy konkretnej treści i każda późniejsza zmiana je unieważnia.
9. **R9 Zasoby profilu.** Operacje, wzbogacenia, sloty i dane profilu dotyczą wyłącznie zadań i instancji procesów należących do tego profilu; uprawnienie projektowe działa tylko w procesach profilu. Operacja na danych profilu (`profile-action`, ADR-017) nie dotyczy żadnego procesu — działa wyłącznie na danych własnego profilu (`prj_<id>`), a jej trasy i wyniki widzą tylko role tego profilu.
10. **R10 Przestrzeń nazw profilu.** Profil definiuje uprawnienia, role, operacje i typy zadań wyłącznie z własnym prefiksem (`<id>.`), nie nadaje roli audytora ani administratora platformy; walidator manifestów i reconciler odrzucają naruszenia.
11. **R11 Formatka należy do procesu.** Formatka, jej wersje i przypięcia należą do dokładnie jednego procesu (`BpmnProcessId`) w tenancie. Uprawnienia `Form.*` działają wyłącznie w zakresie tego procesu; zadanie i start procesu renderują tylko formatkę własnego procesu; operacja łącząca formatki dwóch procesów (szkic z cudzej wersji, przypięcie albo wersja zastępcza spoza procesu) jest odrzucana (`14-form-management.md`).

## Ścieżka decyzji

```mermaid
flowchart LR
    A[Żądanie + Actor z sesji] --> B{Uprawnienie w roli<br/>dla zakresu zasobu?}
    B -- nie --> D[Denied + audyt]
    B -- tak --> C{Reguły wiersza R1–R11}
    C -- nie --> D
    C -- tak --> E[Allowed, GrantedBy = RoleAssignment]
    E --> F[Wywołanie Camunda przez SDK<br/>L1 sprawdza ponownie]
    F --> G[Audyt: Intent / Outcome]
```

`AccessDecision` zwraca `GrantedBy` — przypisanie roli, które uzasadnia akcję. Trafia ono do audytu jako „rola, w której działano”, co odpowiada na pytanie „dlaczego Marta mogła to zrobić”.

## Autoryzacje jako kod

- Źródło prawdy: `config/authorization/roles.yaml` (role platformy) i `assignments.yaml` (role globalne: Audytor, Administrator platformy) oraz `profiles/<id>/profile.yaml` i `profiles/<id>/authorization.yaml` (role projektowe, uprawnienia projektu, grupy AD i grupy kandydujące profilu).
- **Reconciler** (moduł `PlatformAdministration`, adapter w `CamundaIntegration`) liczy stan docelowy grup, ról, reguł mapowania i autoryzacji w Camunda, porównuje ze stanem faktycznym (wyszukiwanie przez SDK) i stosuje różnicę. W PR działa jako dry-run (raport różnic w komentarzu), po scaleniu — apply. Nocą w roli `jobs` wykrywa dryf i raportuje go w audycie.
- Aplikacja ładuje te same pliki dla L2, więc nie ma drugiej, ręcznie utrzymywanej tabeli ról.
- Zmiana uprawnień = PR z przeglądem; historia w Git + wpis w dzienniku bezpieczeństwa przy apply.

## Role projektowe (profile)

Rola projektowa (np. „Underwriter” w profilu `kredyty`) składa się z ról platformy i uprawnień projektu, w zakresie procesów profilu — szczegóły i przykłady: `13-project-profiles.md`, sekcja 4.

```mermaid
flowchart LR
  G["Grupa AD<br/>PH-KREDYT-UNDERWRITING"] --> RP["Rola projektowa<br/>kredyty/underwriter"]
  RP --> RPL["Role platformy<br/>Uczestnik"]
  RP --> UP["Uprawnienia projektu<br/>kredyty.Applicant.View<br/>kredyty.Limit.Override"]
  RP --> Z["Zakres<br/>procesy profilu: wniosek-kredytowy"]
  RPL --> L1["Autoryzacje Camunda (L1)<br/>na PROCESS_DEFINITION"]
  RPL --> L2["Uprawnienia aplikacji (L2)"]
  UP --> L2
```

- `AccessDecision.GrantedBy` dla roli projektowej ma postać `<profil>/<rola>`; audyt zapisuje też identyfikator profilu.
- Uprawnienia projektu są w katalogu L2 obok uprawnień platformy, ale `IAccessPolicy` zwraca je tylko dla zasobów procesów profilu (R9).
- Reconciler łączy deklaracje platformy i profili; konfiguracja naruszająca R7 albo R10 nie zostanie zastosowana.

## Tożsamość wywołań do Camunda (ADR-004, rozstrzyga S02)

| Wariant | Opis | Za | Przeciw |
| --- | --- | --- | --- |
| A. Delegowana | komendy użytkownika idą z jego tokenem (token exchange w RHBK) | L1 egzekwowane per osoba | wymaga, by SDK przyjmowało poświadczenia per wywołanie |
| B. Techniczna | klient techniczny per rola hosta, L2 egzekwowane w aplikacji z tych samych deklaracji | prostsze; standardowy tryb SDK | L1 chroni per klient, nie per osoba |

Rekomendacja: A dla komend użytkownika, jeśli PoC potwierdzi wsparcie SDK; B zawsze dla `projector` (tylko odczyt), `worker` (task listenery) i reconcilera — każdy z osobnym, minimalnym zestawem autoryzacji.

## Gotowość na wielu tenantów

- `TenantId` jest value object w Shared Kernel, obecny w każdym agregacie, zapytaniu, zdarzeniu i wpisie audytu.
- Dziś `ITenantContext` zwraca `<default>` (identyfikator tenanta Camunda przy wyłączonym multi-tenancy).
- RLS w MSSQL filtruje po `TenantId` już teraz (jedna wartość) — włączenie drugiego tenanta nie zmienia zapytań.
- Zakres `RoleAssignment` zawiera tenant; deklaracje w `assignments.yaml` mają klucz `tenant`.
- Włączenie multi-tenancy w Camunda wymaga decyzji przed pierwszym uruchomieniem środowiska docelowego (dokument DevOps v1, sekcja 7) — dlatego ADR-002 zapisuje, kiedy i jak to zrobić.
