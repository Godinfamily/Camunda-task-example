# 13. Profile projektów — część wspólna i część specyficzna

Każdy projekt biznesowy korzysta z tej samej platformy, ale ma własny profil: role projektowe, dane, operacje dedykowane, rozszerzenia UI i integracje. Profil deklaruje je w manifeście (`profiles/<id>/profile.yaml`) i implementuje wyłącznie przez SDK rozszerzeń. Separację wymuszają osobno: repozytorium, kompilacja, uprawnienia, wykonanie, baza danych, wdrożenie, CI i agenci AI — dzięki temu zespół projektu pracuje samodzielnie i nie może zrealizować części innego projektu (ADR-012, ADR-013, ADR-014).

## 1. Pojęcia

| Pojęcie | Znaczenie |
| --- | --- |
| Profil projektu | Projekt biznesowy korzystający z platformy (np. `kredyty`, `aml`); właściciel procesów, ról projektowych i danych projektu |
| Manifest profilu | `profile.yaml` — kontrakt z platformą (schemat `profiles/profile.schema.json`); `authorization.yaml` — grupy AD → role projektowe |
| Rola projektowa | Rola w ramach projektu: złożenie ról platformy (Uczestnik, Inicjator, Menadżer, Administrator procesu) i uprawnień projektu, ograniczone do procesów profilu |
| Uprawnienie projektu | Uprawnienie w przestrzeni nazw profilu, np. `kredyty.Scoring.Recalculate` |
| Operacja dedykowana | Akcja projektu na zadaniu, sprawie albo danych profilu (np. „Przelicz scoring”, „Zapisz model w katalogu”), wykonywana przez potok platformy |
| Punkt rozszerzenia | Miejsce, w którym platforma oddaje sterowanie profilowi: operacja, wzbogacenie zadania, źródło danych formatki, zapytanie, obsługa zdarzeń, slot UI |
| SDK rozszerzeń | Jedyna zależność profilu: `ProcessHub.Extensibility` (.NET) i `@process-hub/extension-sdk` (Angular); wersjonowane semantycznie |
| Model integracji | `in-process` — moduł profilu w hoście platformy; `remote` — usługa zespołu wywoływana przez platformę |

## 2. Platforma a profil

```mermaid
flowchart TB
  subgraph PL["Platforma — wspólna dla wszystkich profili"]
    CORE["Moduły platformy<br/>Task Work · Process Lifecycle · Process Insight<br/>Form Management · Access Policy · Audit · Camunda Integration"]
    EXT["Extension Host<br/>rejestr profili · potok operacji · sloty UI · zdarzenia"]
    SDK["SDK rozszerzeń<br/>ProcessHub.Extensibility · @process-hub/extension-sdk"]
    CORE --- EXT
    EXT --- SDK
  end
  subgraph KR["Profil kredyty — in-process"]
    KM["Kredyty.Extension<br/>operacje · wzbogacenia · zapytania"]
    KU["profile-kredyty-ui<br/>sloty · trasy /p/kredyty/"]
    KD[("schemat prj_kredyty")]
  end
  subgraph AM["Profil aml — remote"]
    AS["Usługa AML zespołu<br/>profile-operations v1"]
    AU["profile-aml-ui"]
    AD[("schemat prj_aml")]
  end
  subgraph FL["Profil flota — in-process (przykład)"]
    FM["Flota.Extension<br/>katalog samochodów · opinie komórek"]
    FU["profile-flota-ui<br/>sekcja „Flota” · /p/flota/katalog"]
    FD[("schemat prj_flota")]
  end
  KM -->|implementuje| SDK
  KU -->|implementuje| SDK
  AU -->|implementuje| SDK
  FM -->|implementuje| SDK
  FU -->|implementuje| SDK
  EXT -->|"żądanie z podpisanym kontekstem"| AS
  KM --> KD
  AS --> AD
  FM --> FD
```

Profil `flota` jest przykładem kompletu dedykowanych elementów jednego projektu: własna sekcja nawigacji i strona katalogu widoczne tylko dla ról profilu, operacje na danych profilu, pole formatki i panel zadania. Opis krok po kroku: `docs/guides/dedykowane-elementy-profilu.md`.

| Platforma — działa tak samo dla każdego profilu | Profil — decyduje zespół projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie, reguły R1–R4 | Role projektowe i ich przypisanie do grup AD |
| Start procesu, moje procesy, przekazywanie, zastępstwa, eskalacje | Operacje dedykowane na zadaniach i sprawach |
| Dashboard, mapa etapów, formatki (projektowanie, wersje, runtime) | Dane projektu w schemacie `prj_<id>` i ich retencja |
| Audyt każdej akcji, autoryzacje jako kod, odmowy (R5) | Rozszerzenia UI w slotach i trasy `/p/<id>/` |
| Integracja z Camunda, projekcja read modelu | Workery typów zadań `<id>.*` i integracje z systemami projektu |
| SDK rozszerzeń, potok operacji, testy zgodności | Model integracji, rytm wydań, własny plan pracy |

## 3. Kontrakt profilu

Manifest (`profile.yaml`) deklaruje wszystko, co platforma ma zarejestrować: procesy, uprawnienia, role, dane, operacje, sloty UI, integracje i zakres pracy agentów. Platforma rejestruje tylko zadeklarowane elementy — kod profilu bez wpisu w manifeście nie zostanie uruchomiony.

`tools/profiles/validate_profiles.py` (bramka CI) sprawdza schemat i reguły międzyprofilowe:

| Reguła | Sprawdzenie |
| --- | --- |
| Własność procesu | proces należy do dokładnie jednego profilu |
| Przestrzeń nazw (R10) | uprawnienia, operacje i typy zadań mają prefiks `<id>.`; schemat danych `prj_<id>`; trasy `/p/<id>/` |
| Spójność ról | role używają tylko uprawnień profilu i procesów profilu; rola audytora nie występuje w profilach |
| Operacje | uprawnienie istnieje; proces należy do profilu (R9); operacja zapisu jawnie deklaruje `requiresAssignee`; `task-action` zawsze wymaga assignee (R1); `profile-action` ma uprawnienie projektu rodzaju `write`, `requiresAssignee: false` i nie ma `appliesTo` (ADR-017); odczyt wrażliwy ma `sensitive: true` |
| Grupy | grupa AD i grupa kandydująca należą do jednego profilu |
| Klasa danych | klasa danych dla agentów nie jest słabsza niż klasyfikacja danych profilu |
| Plan zespołu | kroki planu profilu zapisują wyłącznie w `profiles/<id>/` |
| Własność kodu | `CODEOWNERS` wygenerowany i aktualny |

Zmiany `profile.yaml` i `authorization.yaml` zatwierdza zespół profilu i architekt platformy; `authorization.yaml` także bezpieczeństwo.

## 4. Role projektowe

Rola projektowa składa się z ról platformy i uprawnień projektu, w zakresie procesów profilu:

| Profil | Rola projektowa | Role platformy | Uprawnienia projektu | Procesy |
| --- | --- | --- | --- | --- |
| kredyty | Analityk kredytowy | Uczestnik, Inicjator | `kredyty.Scoring.Recalculate`, `kredyty.Applicant.View` | wniosek-kredytowy |
| kredyty | Underwriter | Uczestnik | `kredyty.Applicant.View`, `kredyty.Limit.Override` | wniosek-kredytowy |
| kredyty | Kierownik zespołu kredytowego | Menadżer procesu | `kredyty.Applicant.View`, `kredyty.Portfolio.Report` | wszystkie procesy profilu |
| kredyty | Administrator procesów kredytowych | Administrator procesu | — | wszystkie procesy profilu |
| aml | Analityk AML | Uczestnik | `aml.Sanctions.Recheck`, `aml.Party.View` | weryfikacja-aml |
| aml | Kierownik zespołu AML | Menadżer procesu | `aml.Party.View`, `aml.Case.Export` | weryfikacja-aml |
| flota | Wnioskodawca | Inicjator | `flota.Catalog.View` | rejestracja-samochodu |
| flota | Opiniujący (komórka banku: IT, HR, Prawny, Finanse, Ryzyko) | Uczestnik | `flota.Catalog.View` | opiniowanie-rejestracji |
| flota | Administrator katalogu samochodów | — (tylko uprawnienia projektu) | `flota.Catalog.View`, `flota.Catalog.Manage` | dane profilu |

Uprawnienia efektywne to suma uprawnień ról (platformy i projektowych) w zakresach. Audyt zapisuje rolę uzasadniającą w postaci `<profil>/<rola projektowa>`, np. `kredyty/underwriter`. Role globalne — Audytor i Administrator platformy — pozostają w `config/authorization/` i nie są częścią profili (rozdział obowiązków R7).

Reconciler łączy `config/authorization/*.yaml` z `profiles/*/authorization.yaml`, odrzuca konfigurację naruszającą R10 i nadaje w Camunda autoryzacje zasobów dla procesów profilu.

## 5. Punkty rozszerzeń

| Punkt | Rodzaj w manifeście | Platforma zapewnia | Profil implementuje |
| --- | --- | --- | --- |
| Operacja na zadaniu | `task-action` | uprawnienie, R1 (assignee), R9, audyt Intent/Outcome, idempotencja, `allowedActions` | `ITaskOperation<TInput>` — logika i dane projektu |
| Operacja na sprawie | `case-action` | jak wyżej, kontekst instancji procesu | `ICaseOperation<TInput>` |
| Operacja na danych profilu | `profile-action` | uprawnienie projektu (`write`), audyt Intent/Outcome, idempotencja, kontekst bazy `prj_<id>`, `allowedActions` w wyniku zapytania; bez zadania, więc bez R1 (ADR-017, SDK 1.1) | `IProfileAction<TInput>` — np. katalog, słownik, progi |
| Wzbogacenie zadania | `task-enricher` | sekcja `extensions.<id>` w widoku zadania, limit czasu, audyt odczytu wrażliwego | `ITaskEnricher` |
| Źródło danych formatki | `form-data-source` | wywołanie z formatek procesów profilu, pamięć podręczna | `IFormDataSource` |
| Zapytanie | `query` | endpoint `/p/<id>/queries/...`, autoryzacja, ślad | `IProfileQuery<TResult>` |
| Obsługa zdarzeń | `event-handler` | zdarzenia platformy tylko dla procesów profilu (outbox, ponowienia) | `IPlatformEventHandler` — np. read model projektu |
| Slot UI | `ui.slots` | renderowanie w powłoce, widoczność wg procesu i uprawnienia | komponent Angular |

Potok operacji — ten sam dla każdego profilu:

```mermaid
sequenceDiagram
  participant UI as UI (allowedActions)
  participant API as Potok platformy
  participant AP as Access Policy
  participant AU as Audit
  participant EX as Extension Host
  participant OP as Operacja profilu
  UI->>API: POST /tasks/{key}/operations/kredyty.RecalculateScoring (requestId)
  API->>AP: uprawnienie, R1 assignee, R9 proces profilu
  AP-->>API: Allowed, GrantedBy kredyty/analityk-kredytowy
  API->>AU: Intent
  API->>EX: wykonaj w kontekście profilu (użytkownik bazy prj_kredyty)
  EX->>OP: ExecuteAsync(ctx, input)
  OP-->>EX: wynik i zmiany szkicu
  EX-->>API: wynik
  API->>AU: Outcome
  API-->>UI: wynik i nowe allowedActions
```

Szkic SDK (.NET):

```csharp
public interface IProfileModule
{
    ProfileId Id { get; }
    void Register(IProfileBuilder profile);
}

public interface ITaskOperation<TInput>
{
    ValueTask<OperationResult> ExecuteAsync(TaskOperationContext ctx, TInput input, CancellationToken ct);
}

public sealed record TaskOperationContext(
    TaskView Task,                   // zadanie procesu profilu, w granicach uprawnień aktora
    ActorContext Actor,              // kto i na podstawie jakiej roli
    IPlatformTaskCommands Tasks,     // szkic i zakończenie zadania przez platformę (R1)
    IClock Clock);

public interface IProfileAction<TInput>  // od SDK 1.1 (ADR-017)
{
    ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, TInput input, CancellationToken ct);
}

public sealed record ProfileActionContext(
    ActorContext Actor,              // kto i na podstawie jakiej roli projektowej
    IClock Clock);                   // bez zadania i bez komend procesu — wyłącznie dane profilu
```

Operacja nie sprawdza uprawnień i nie pisze audytu — robi to potok. Zmienne procesu zmienia tylko przez platformę (szkic lub zakończenie zadania), nigdy przez Camunda; `profile-action` w ogóle nie zmienia procesów.

## 6. Dane profilu

- **Schemat i tożsamość.** Każdy profil ma schemat `prj_<id>` i użytkownika bazy `prj_<id>` bez loginu, z uprawnieniami wyłącznie do własnego schematu i do widoków `platform_api`.
- **Wykonanie w kontekście profilu.** Platforma wykonuje operację profilu w tej samej transakcji, przełączając kontekst bezpieczeństwa bazy (`EXECUTE AS USER = 'prj_<id>'` … `REVERT`). Audyt platformy zapisuje się po powrocie do kontekstu aplikacji. Nawet błąd w kodzie profilu nie da dostępu do tabel platformy ani innych profili [DO WERYFIKACJI w S27: zgodność z pulą połączeń EF Core].
- **Dane platformy.** Profil czyta je wyłącznie przez widoki `platform_api` (zadania, instancje, etapy), filtrowane predykatem RLS do procesów profilu (`SESSION_CONTEXT('ProfileId')`).
- **Migracje.** Uruchamiane osobną tożsamością migracji profilu, z prawem DDL tylko w `prj_<id>`.
- **Retencja i klasyfikacja.** Z manifestu (`data.retentionMonths`, `data.classification`); klasa `restricted` wymaga przeglądu bezpieczeństwa i modelu AI w infrastrukturze banku.
- **Model remote.** Usługa zespołu może trzymać dane we własnej bazie — wtedy klasyfikacja i retencja z manifestu obowiązują tę bazę, a platforma nie ma do niej dostępu.

## 7. Rozszerzenia UI

| Slot | Gdzie | Warunek wyświetlenia |
| --- | --- | --- |
| `task.panel` | zakładka w szczegółach zadania | proces zadania należy do profilu i aktor ma uprawnienie slotu |
| `case.panel` | zakładka w szczegółach sprawy | jak wyżej, dla instancji procesu |
| `dashboard.widget` | pulpit i panel procesu | uprawnienie slotu |
| `form.field` | pole formatki w projektancie i runtime: wariant typu bazowego Camunda Forms z własnością `ph:field`, w palecie tylko dla formatek procesów profilu | formatka procesu profilu |
| `nav.section` | sekcja nawigacji z trasami `/p/<id>/` | uprawnienie trasy |

Przyciski operacji renderuje powłoka z `allowedActions` — komponent profilu nie decyduje o dostępności akcji. Na trasach `/p/<id>/` wynik zapytania profilu przychodzi z `allowedActions` operacji `profile-action` (np. „Dodaj model” w katalogu floty tylko dla administratora katalogu). Sekcja `nav.section` i trasy profilu nie pojawiają się u osób bez uprawnienia trasy; wejście z adresu kończy się odmową zapisaną w dzienniku (R5). Biblioteki profili mają tag Nx `scope:profile-<id>` i mogą zależeć tylko od `scope:extension-sdk`. Domyślnie ładowane leniwie w obrazie aplikacji; dla profilu, który potrzebuje niezależnych wydań frontendu, opcja Native Federation [DO WERYFIKACJI ze zgodnością Kendo UI].

## 8. Camunda i integracje

- Procesy profilu leżą w `profiles/<id>/bpmn/` i są wdrażane z pipeline'u z jawnym tenantem — jak procesy platformy (C21).
- Typy zadań service tasków mają prefiks profilu (`kredyty.rejestr.sprawdz`); reguła bpmnlint `job-type-prefix` porównuje prefiks z właścicielem procesu.
- Workery profilu łączą się z Camunda własnym klientem o minimalnych uprawnieniach [DO WERYFIKACJI w S02: ograniczanie aktywacji zadań do procesów profilu].
- Grupy kandydujące BPMN profilu mapuje `authorization.yaml` (`candidateGroups`).
- Mapa etapów, dashboard, eskalacje i formatki działają dla procesów profilu bez zmian — konfigurują je menadżer i administrator procesu z ról projektowych. Formatki należą do pojedynczego procesu, nie do profilu: menadżer jednego procesu profilu nie zarządza formatkami innego, jeśli nie ma go w zakresie (R11, `14-form-management.md`).

## 9. Separacja

| Warstwa | Mechanizm | Co zatrzymuje |
| --- | --- | --- |
| Repozytorium | `profiles/<id>/**` z `CODEOWNERS` (generowany); kontrakt profilu wymaga też architekta platformy | zmianę bez przeglądu właściciela |
| Kompilacja | profil zależy tylko od SDK; testy architektury (.NET) i granice modułów Nx | odwołanie do platformy lub innego profilu |
| Uprawnienia | przestrzeń nazw profilu, reconciler, walidator manifestów (R10) | uprawnienia i role poza profilem |
| Wykonanie | Extension Host wywołuje operację tylko dla procesów profilu (R9); osobny kontener zależności per profil | operację na zadaniu innego projektu |
| Dane | schemat i użytkownik bazy per profil, widoki `platform_api` z RLS | odczyt i zapis cudzych danych |
| Wdrożenie | in-process: wspólny obraz z pociągiem wydań; remote: osobna usługa i wydania zespołu | wzajemne blokowanie wydań (remote) |
| CI | filtry ścieżek per profil; `enforce_write_scope.py --verify-diff --profile <id>` | PR zespołu zmieniający kod spoza profilu |
| Agenci AI | agenci `<id>-<rola>` z zapisem tylko w `profiles/<id>/**`; plugin strażnika; klasa danych wybiera model | agenta jednego profilu realizującego część innego |

## 10. Autonomia zespołów

- **Plan i rytm.** Zespół prowadzi `profiles/<id>/backlog.yaml` tymi samymi narzędziami co platforma (`plan_status.py`, `prepare_step.py`, `run_dod.py` z `--backlog`). Kroki profilu mogą zależeć od kroków platformy (np. S38).
- **Kontrakt z platformą.** SDK wersjonowane semantycznie; zmiana niezgodna wstecz tylko w nowej wersji głównej, z okresem przejściowym co najmniej dwóch wersji pomocniczych. Platforma dostarcza testy zgodności i host testowy `ProcessHub.Extensibility.Testing`.
- **Nowe potrzeby.** Brak punktu rozszerzenia → RFC do zespołu platformy; profil nie obchodzi braku kodem platformy.
- **Wydania.** In-process: profil wchodzi do pociągu wydań platformy (propozycja: co dwa tygodnie). Remote: wydania zespołu w dowolnym rytmie, w granicach kontraktu `profile-operations`.
- **Cykl życia profilu.** Propozycja → PR z manifestem → walidacja i przegląd → reconciler nadaje autoryzacje → pierwsze wydanie → eksploatacja → wygaszenie (archiwizacja danych wg retencji, odebranie autoryzacji, usunięcie z rejestru).

## 11. In-process czy remote

| Kryterium | In-process (domyślnie) | Remote |
| --- | --- | --- |
| Technologia | .NET, SDK platformy | dowolna, kontrakt `profile-operations v1` |
| Wydania | pociąg wydań platformy | niezależne |
| Opóźnienie i spójność | jedna transakcja z platformą | wywołanie sieciowe, wynik w osobnej transakcji, limit czasu |
| Izolacja awarii | błąd profilu w procesie hosta (ograniczony limitami czasu i kontekstem bazy) | awaria usługi = operacja niedostępna, praca na zadaniu trwa dalej |
| Koszt utrzymania | niski | zespół utrzymuje własną usługę, mTLS, monitoring |
| Kiedy | większość projektów | inna technologia, osobny rytm wydań, ciężkie obliczenia, dane we własnej bazie |

## 12. Otwarte kwestie

- D-08: domyślny model integracji profili (rekomendacja: in-process; remote na wniosek zespołu).
- D-09: monorepo z `CODEOWNERS` czy osobne repozytoria profili publikujące paczki (rekomendacja: monorepo na start, bo walidacja międzyprofilowa i testy architektury działają w jednym miejscu).
- D-10: rytm pociągu wydań dla profili in-process.
- D-11: zakres danych platformy dostępnych w widokach `platform_api`.
- ADR-017 (operacje na danych profilu): zatwierdzenie przez architekta platformy, zasób audytu i limit czasu (`docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md`).
- Do weryfikacji w PoC: `EXECUTE AS USER` z pulą połączeń EF Core (S27), ograniczenie aktywacji zadań workerów do procesów profilu (S02), Native Federation z Kendo UI (S47).
