# 03. Mapa kontekstów (DDD)

Cztery konteksty są rdzeniem — tam powstaje przewaga nad natywnym Tasklistem: praca na zadaniach, cykl życia procesów z perspektywy użytkownika, wgląd menadżera (etapy, eskalacje, metryki) i formatki. Pozostałe są cienkie i wymienialne. Profile projektów to osobne konteksty poza platformą — każdy należy do zespołu projektu i rozmawia z platformą wyłącznie przez SDK rozszerzeń (Extension Host).

| Kontekst | Typ | Odpowiedzialność | Agregaty / modele |
| --- | --- | --- | --- |
| Task Work | core | przejęcie, zwolnienie, szkic, zakończenie, przekazanie (pojedyncze i masowe) | `WorkItem`, `ReassignmentBatch` |
| Process Lifecycle | core | start procesu z formatką startową, „moje procesy” | `ProcessStartRequest`; odczyt `MyProcessView` |
| Process Insight | core | mapa etapów, stan etapów instancji, eskalacje, dashboard, progi zdrowia | `StageMap`, `ProcessHealthPolicy`; odczyt `ProcessInstanceView`, `EscalationRecord`, `ProcessStats` |
| Form Management | core | formatki w formacie Camunda Forms: cykl życia wersji, cztery oczy (R8), publikacja z kontraktem danych zadania, wycofanie, separacja per proces (R11), import i eksport | `FormDefinition` (`FormVersion`, `FormReview`, `FormWithdrawal`) |
| Form Runtime | wspierający | wydanie schematu wersji przypiętej, walidacja danych na serwerze (reguły schematu, FEEL przez port `IExpressionEvaluator`) | bezstanowy |
| Party & Accountability | wspierający | osoby, grupy, przypisania ról, zastępstwa | `Party`, `RoleAssignment`, `Absence` |
| Access Policy | wspierający | uprawnienia efektywne (platformy i projektowe), reguły R1–R11, materializacja widoczności | `AccessDecision`, `TaskAccess` (odczyt) |
| Audit | wspierający | dziennik bezpieczeństwa (Ledger) i ślad operacyjny | `JournalEntry`, `OperationTrace` |
| Camunda Integration | generyczny (ACL) | oficjalne SDK: komendy, wyszukiwanie, przyjmowanie zdarzeń, workery task listenerów, katalog elementów BPMN (w tym referencje formatek i kontrakt danych), ewaluacja wyrażeń FEEL | bramy (porty) + adaptery SDK |
| Platform Administration | generyczny | autoryzacje jako kod: reconciler, raport dryfu | `AuthorizationPlan` |
| User Preferences, Notification | generyczne | widoki list, motyw; powiadomienia o przekazaniach, eskalacjach oraz przeglądach i wycofaniach formatek | `SavedListView` |
| Extension Host | wspierający | rejestr profili z manifestów, potok operacji profili, wzbogacenia, sloty UI, dystrybucja zdarzeń do profili (R9) | `ProfileRegistration`, `OperationDescriptor` |
| Profil projektu (np. kredyty, aml) | kontekst zespołu projektu, poza platformą | dane i operacje specyficzne dla projektu | definiuje zespół profilu |

```mermaid
flowchart TB
    RHBK[[RHBK / AD]]:::ext
    CAM[[Camunda 8.9]]:::ext

    subgraph CORE[Rdzeń]
      TW[Task Work]
      PL[Process Lifecycle]
      PI[Process Insight]
      FM[Form Management]
    end

    PA[Party & Accountability]
    AP[Access Policy]
    FR[Form Runtime]
    CI[Camunda Integration<br/>ACL + oficjalne SDK]
    ADM[Platform Administration]
    AU[(Audit)]
    EH[Extension Host<br/>SDK rozszerzeń]

    subgraph PROF[Profile projektów — poza platformą]
      PK[Profil kredyty]
      PAML[Profil aml]
    end

    RHBK -- Conformist: OIDC, claim groups --> PA
    CAM -- ACL --> CI
    CI -- Published Language: zdarzenia integracyjne --> TW
    CI -- zdarzenia + katalog elementów --> PI
    PA -- Customer/Supplier --> AP
    ADM -- deklaracje ról --> AP
    ADM -- plan autoryzacji --> CI
    AP -- Open Host: IAccessPolicy --> CORE
    FM -- Published Language: schemat formatki --> FR
    TW --> FR
    PL --> FR
    PI -- mapa etapów --> FM
    CORE -. zdarzenia audytu przez outbox .-> AU
    AP -. odmowy .-> AU
    ADM -. zmiany uprawnień .-> AU
    CORE -- operacje i zdarzenia --> EH
    AP -- decyzje R9 --> EH
    EH -- Open Host + Published Language: SDK --> PROF
    EH -. audyt operacji profili .-> AU
    ADM -- manifesty i role projektowe --> AP
    classDef ext stroke-dasharray: 5 5
```

## Relacje i dlaczego takie

- **Camunda → Camunda Integration: Anti-Corruption Layer.** Typy SDK i pojęcia silnika (`userTaskKey`, `elementId`, typy zdarzeń) kończą się na granicy modułu. Aktualizacja SDK lub Camunda dotyka jednego modułu i jego testów kontraktowych.
- **RHBK → Party: Conformist.** OIDC to język opublikowany; nie negocjujemy go.
- **Party → Access Policy: Customer/Supplier.** Polityka czyta przypisania i zastępstwa, nigdy ich nie zmienia.
- **Access Policy → rdzeń: Open Host Service.** Jeden kontrakt `IAccessPolicy` w `AccessPolicy.Contracts`.
- **Form Management → Form Runtime: Published Language.** Schemat formatki w formacie Camunda Forms (form-js) z profilem zgodności `ph-forms-8.9`; ten sam dokument czyta renderer w przeglądarce i walidator na serwerze (ADR-018).
- **Camunda Integration → Form Management i Form Runtime.** Katalog elementów dostarcza referencje `ph:form/<klucz>` i kontrakt `ph:inputs`/`ph:outputs`; port `IExpressionEvaluator` wykonuje wyrażenia FEEL formatek silnikiem (ADR-020). Formatki nie są wdrażane do silnika.
- **Process Insight → Form Management.** Edytor formatki pokazuje mapę etapów z zaznaczonym etapem zadania (FR-16) — odczyt przez kontrakt `IStageMapQueries`.
- **Wszystko → Audit: Published Language zdarzeń audytu**, dostarczanych przez outbox; ślad operacyjny zapisuje middleware hosta.
- **Extension Host → profile: Open Host Service + Published Language.** SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`, kontrakt `profile-operations v1` dla profili remote) to jedyna powierzchnia, jaką widzi profil. Wersjonowanie semantyczne chroni zespoły przed zmianami wewnątrz platformy, a platformę przed zależnością od kodu profili.
- **Profile → platforma: brak zależności w drugą stronę.** Platforma nie zna kodu profili; rejestruje je z manifestów przy starcie. Profile nie znają się nawzajem (R9, R10, testy architektury).
- **Shared Kernel** minimalny: `TenantId`, `PartyId`, `BpmnProcessId`, `CorrelationId`, `Result<T>`; SDK rozszerzeń udostępnia profilom ich odpowiedniki jako typy publiczne.
