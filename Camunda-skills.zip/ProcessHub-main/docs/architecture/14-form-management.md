# 14. Moduł zarządzania formatkami (Camunda Forms)

Formatka w Process Hub to formularz w formacie **Camunda Forms** — tym samym, który tworzy Camunda Modeler (biblioteka form-js). Biznes projektuje ją w aplikacji, w edytorze znanym z Modelera; aplikacja prowadzi jej wersje, akceptację i wycofanie; zadanie renderuje ją **komponentami design systemu**, a nie wyglądem biblioteki. Każda formatka należy do jednego procesu i poza nim nie istnieje. Decyzje: ADR-018 (format, cykl życia, separacja), ADR-019 (projektant i materializacja), ADR-020 (walidacja po stronie serwera). Warstwa wizualna: `design/forms/README.md`; wytyczne dla osób zaczynających pracę nad UI: `docs/artifacts/04-wytyczne-ui.md`.

## 1. Pięć zasad

1. **Schemat mówi „co”, design system mówi „jak”.** Schemat formatki zawiera pola, typy, etykiety, walidacje, warunki i układ w siatce. Nie zawiera kolorów, krojów ani stylów — i nie ma jak ich zawrzeć.
2. **Jedna formatka, jeden proces (R11).** Formatka, jej wersje i historia należą do dokładnie jednego `BpmnProcessId`. Nie ma biblioteki formatek wspólnych ani kopiowania między procesami w aplikacji.
3. **Każda zmiana przechodzi tę samą drogę:** szkic → przegląd → zatwierdzenie przez inną osobę (R8) → publikacja. Wersja opublikowana jest niezmienna.
4. **Zadanie renderuje wersję przypiętą przy jego utworzeniu** (FR-18). Publikacja nowej wersji nie zmienia zadań w toku; zmienia je wyłącznie świadome wycofanie wersji z przepięciem.
5. **Wycofać można zawsze, ale nigdy po cichu:** z powodem, ze wskazaniem skutku dla zadań w toku i z wpisem w dzienniku.

## 2. Pojęcia

| Pojęcie | Kod | Znaczenie |
| --- | --- | --- |
| Formatka | `FormDefinition` | Formularz jednego procesu: tożsamość `(TenantId, BpmnProcessId, FormKey)`, nazwa, zastosowanie, wersje |
| Klucz formatki | `FormKey` | Stały identyfikator w obrębie procesu, np. `ocena-wniosku`; model BPMN wskazuje go referencją `ph:form/ocena-wniosku` |
| Zastosowanie | `FormUsage` | `Task` — formatka zadań wskazujących klucz w BPMN; `ProcessStart` — formatka startowa procesu (najwyżej jedna obowiązująca na proces) |
| Wersja formatki | `FormVersion` | Stan treści w cyklu życia; numer nadawany przy publikacji (1, 2, 3…) |
| Wersja robocza | stany `Draft`, `InReview`, `Approved` | Jedyna edytowalna wersja formatki; najwyżej jedna naraz |
| Wersja obowiązująca | `CurrentVersion` | Opublikowana wersja przypinana nowym zadaniom; najwyżej jedna |
| Schemat | `Schema` | Dokument JSON w formacie Camunda Forms (`type: "default"`, `components`, `schemaVersion`…) |
| Katalog pól | `design/forms/field-catalog.yaml` | Lista typów komponentów Camunda Forms ze statusem wsparcia i komponentem design systemu, który je materializuje |
| Profil zgodności | `ph-forms-8.9` | Wersja katalogu pól + dopuszczalna `schemaVersion`; zapisywany przy każdej opublikowanej wersji |
| Kontrakt danych zadania | `ph:inputs`, `ph:outputs` | Zmienne, które zadanie dostaje i które musi oddać (praktyka C7) |
| Przypięcie | `WorkItem.FormVersion` | Wersja formatki zapisana przy zadaniu w chwili jego utworzenia |
| Wycofanie | `FormWithdrawal` | Zdjęcie opublikowanej wersji (albo całej formatki) z użycia, z powodem i trybem dla zadań w toku |
| Materializacja | `form-runtime` + `core/ui-kit` | Zamiana schematu na interfejs z komponentów design systemu |

## 3. Odpowiedzialności

| Kto | Decyduje o | Nie decyduje o |
| --- | --- | --- |
| Menadżer procesu, administrator procesu (biznes) | polach, typach, etykietach, podpowiedziach, walidacjach, warunkach widoczności, kolejności i układzie w wierszach; przeglądzie, publikacji i wycofaniu formatek swojego procesu | kolorach, krojach, rozmiarach, wyglądzie kontrolek i komunikatów; formatkach innych procesów |
| Zespół modelujący BPMN (zespół profilu) | referencji `ph:form/<klucz>` na zadaniu i kontrakcie danych `ph:inputs`/`ph:outputs` | treści formatki |
| Projektant UX (człowiek, Figma) | tokenach, wyglądzie i stanach komponentów pól, wzorcach formularza; akceptuje wzorce regresji wizualnej | strukturze konkretnych formatek |
| Agent `ux-designer` | przeniesieniu eksportów z Figma do `design/**` (tokeny, specyfikacje, katalog pól, makieta) | kodzie aplikacji |
| Agent `design-system-engineer` | `core/theming`, `core/ui-kit`, komponentach pól i ich testach wizualnych | logice interpretacji schematu |
| Agent `frontend-developer` | bibliotekach `form-designer` i `form-runtime` (interpretacja schematu, FEEL, układ) | wyglądzie — używa wyłącznie `core/ui-kit` |
| Agent `module-implementer` | modułach `FormManagement` i `FormRuntime` | kontraktach (architekt) |
| Agent `ui-reviewer` | zgodności zmian UI z tokenami, katalogiem pól i WCAG (tylko odczyt) | — |
| Architekt platformy | kontraktach modułu, statusach w katalogu pól, ADR | — |
| Zespół profilu | własnych polach formatek (`form.field` — warianty typów bazowych z katalogu pól) i źródłach danych — tylko dla procesów profilu (R9) | formatkach jako takich: prowadzą je menadżer i administrator procesu |
| Audytor | — (wgląd tylko do odczytu: `Form.View`, dziennik) | — |

## 4. Zgodność z Camunda Forms

**Format.** Wersja formatki przechowuje dokument dokładnie w formacie Camunda Forms: `type: "default"`, `id`, `schemaVersion`, `executionPlatform: "Camunda Cloud"`, `executionPlatformVersion: "8.9.0"`, `exporter` (`Process Hub` + wersja) i `components`. Metadane cyklu życia (stan, numer wersji, autorzy, przeglądy) żyją obok schematu, w kolumnach — do schematu nie dopisujemy własnych pól najwyższego poziomu. Każda opublikowana wersja jest poprawnym plikiem `.form`, który otworzy Camunda Modeler (NFR-14): serwer waliduje schemat katalogiem pól, który jest podzbiorem formatu, a zgodność z oficjalnym schematem formatu (`@bpmn-io/form-json-schema`) sprawdzają testy — na formatkach wzorcowych i na każdej wersji publikowanej w scenariuszach.

**Biblioteka.** Projektant osadza edytor `@bpmn-io/form-js-editor` — ten sam, którego używa Modeler. Wersja biblioteki jest przypięta; profil zgodności `ph-forms-8.9` dopuszcza `schemaVersion` ≤ 19 (form-js 2.x). Którą wersję form-js zawiera Modeler dla Camunda 8.9 — i czy lista typów jest ta sama — potwierdza **[PoC, S07]**.

**Katalog pól.** Camunda Forms ma 22 typy komponentów. Katalog pól przypisuje każdemu status i komponent design systemu; pełna specyfikacja: `design/forms/field-catalog.yaml`.

| Status | Typy | Skutek |
| --- | --- | --- |
| Wspierany | `textfield`, `textarea`, `number`, `datetime`, `checkbox`, `checklist`, `radio`, `select`, `taglist`, `group`, `dynamiclist`, `table`, `expression`, `separator` | dostępny w palecie projektanta, renderowany, walidowany |
| Wspierany z ograniczeniami | `text` (Markdown bez surowego HTML), `spacer` (wysokość ze skali odstępów), `image` (tylko zasób osadzony, z tekstem alternatywnym) | dostępny; publikacja sprawdza ograniczenie |
| Planowany | `filepicker`, `documentPreview` | poza paletą; publikacja odrzucona do decyzji D-15 o magazynie dokumentów (C9) |
| Zablokowany | `html`, `iframe`, `button` | poza paletą; import i publikacja odrzucone: brak dowolnego HTML i treści zewnętrznych (`10-audit-and-security.md`), a przyciski akcji renderuje powłoka z `allowedActions` |

**Wyrażenia.** Warunki widoczności (`conditional.hide`), dynamiczne `readonly`/`disabled`, opcje z wyrażenia (`valuesExpression`), pola wyliczane (`expression`) i szablony tekstu używają FEEL — tak jak w Camunda. W przeglądarce wykonuje je biblioteka `feelin` (ta sama co w form-js), po stronie serwera — silnik Camunda przez port `IExpressionEvaluator` (ADR-020).

**Import i eksport.** Formatkę można zaimportować z pliku `.form` (np. przygotowanego w Modelerze) i wyeksportować do pliku. Import tworzy wersję roboczą w bieżącym procesie albo zastępuje jej treść (jako kolejna rewizja szkicu) i przechodzi tę samą walidację katalogu co zapis; eksport wersji opublikowanej dopisuje `versionTag` z numerem wersji. Obie operacje są audytowane. To jedyna droga przeniesienia treści między procesami — świadoma, jawna i bez trwałego powiązania kopii z oryginałem.

**Czego nie robimy.** Formatki nie są wdrażane do silnika jako zasoby Camunda (`formId`). Zadanie wskazuje formatkę referencją zewnętrzną (C6), a cykl życia, wersje i przypięcia należą do aplikacji. Powody: prawo wdrażania zasobów w Camunda obejmuje także modele BPMN (za szerokie dla klienta technicznego platformy; nazwy uprawnień potwierdza S02), identyfikator formularza w silniku jest globalny dla tenanta (sprzeczne z R11), a wycofanie z przepięciem wymaga przypięć po stronie aplikacji (ADR-018).

**Pola profilu.** Pole dostarczane przez profil (slot `form.field`, np. „Model samochodu z katalogu”) to w schemacie zwykły komponent bazowy (zwykle `select`) z własnością `properties["ph:field"] = "<profil>.<nazwa>"`. Schemat pozostaje poprawnym Camunda Form; renderer podstawia komponent profilu tylko wtedy, gdy proces należy do tego profilu (R9), a paleta projektanta pokazuje pola profilu wyłącznie w formatkach jego procesów.

## 5. Model domenowy

```mermaid
classDiagram
    class FormDefinition {
      TenantId
      BpmnProcessId
      FormKey
      Name
      Usage
      Status
      CurrentVersion
    }
    class FormVersion {
      Number
      Status
      Schema
      Digest
      CatalogProfile
      LastChangedBy
      Contributors
    }
    class FormReview {
      Decision
      Reviewer
      Comment
      Digest
    }
    class FormWithdrawal {
      Reason
      Mode
      ReplacementVersion
      WithdrawnBy
    }
    class WorkItem {
      FormVersion
    }
    FormDefinition "1" *-- "1..*" FormVersion
    FormVersion "1" *-- "*" FormReview
    FormVersion "1" *-- "0..1" FormWithdrawal
    WorkItem "*" --> "0..1" FormVersion : przypięcie
```

**`FormDefinition`** (agregat, Form Management). Stan formatki: `Active` albo `Retired` (wycofana w całości).

**`FormVersion`** — stany i przejścia:

```mermaid
stateDiagram-v2
    [*] --> Draft: Create / NewVersion / Import
    Draft --> Draft: Save
    Draft --> InReview: SubmitForReview
    InReview --> Draft: Recall (autor) / Reject (z komentarzem)
    InReview --> Approved: Approve (R8)
    Approved --> Draft: Save (unieważnia zatwierdzenie)
    Approved --> Published: Publish (kontrakt danych, katalog pól)
    Published --> Superseded: publikacja nowszej wersji
    Published --> Withdrawn: Withdraw (powód)
    Superseded --> Withdrawn: Withdraw (powód)
    Superseded --> Published: przywrócenie jako zastępczej przy wycofaniu
    Draft --> [*]: Discard
```

Dawny cykl `Draft → InReview → Published → Deprecated` zostaje doprecyzowany: dochodzi `Approved` (już obecny w scenariuszach i makiecie), a `Deprecated` rozdziela się na `Superseded` (zastąpiona nowszą) i `Withdrawn` (wycofana decyzją człowieka).

**Inwarianty:**

1. Tożsamość `(TenantId, BpmnProcessId, FormKey)` jest unikalna i niezmienna; formatka nie zmienia procesu.
2. Formatka ma najwyżej jedną wersję roboczą (`Draft`, `InReview` lub `Approved`).
3. `Approve` wykonuje osoba inna niż autor ostatniej zmiany (R8); zatwierdzenie dotyczy konkretnej treści (skrót `Digest`) — każda późniejsza zmiana je unieważnia.
4. Treść wersji `Published`, `Superseded` i `Withdrawn` jest niezmienna; zmienia się tylko ich stan (zastąpienie, wycofanie, przywrócenie jako zastępczej).
5. `Publish` wymaga: stanu `Approved` z niezmienionym skrótem, zgodności z katalogiem pól, poprawnej składni wyrażeń FEEL i zgodności z kontraktem danych wszystkich zadań wskazujących formatkę (sekcja 9).
6. Numer wersji rośnie o jeden przy publikacji i nie jest używany ponownie; obowiązująca jest najwyżej jedna wersja.
7. `Withdraw` wymaga powodu; wersja zastępcza musi być wcześniej opublikowaną, niewycofaną wersją tej samej formatki, zgodną z bieżącym kontraktem danych.
8. Przypięcie może wskazywać wyłącznie wersję formatki tego samego procesu co zadanie (R11).
9. Formatki nie usuwa się fizycznie — wycofana (`Retired`) zachowuje historię, a jej klucz pozostaje zajęty; do stanu `Active` wraca wyłącznie przez publikację nowej wersji po pełnej akceptacji.

**Komendy:**

| Komenda | Uprawnienie | Reguły | Akcja w dzienniku |
| --- | --- | --- | --- |
| Utwórz formatkę | `Form.Edit` | R11; klucz wolny w procesie | `Form.Create` |
| Zapisz szkic | `Form.Edit` | wersja robocza; współbieżność optymistyczna | `Form.Save` |
| Importuj plik `.form` | `Form.Edit` | walidacja formatu i katalogu | `Form.Import` |
| Przekaż do przeglądu | `Form.Edit` | brak błędów walidacji katalogu i składni wyrażeń | `Form.SubmitForReview` |
| Cofnij z przeglądu | `Form.Edit` | tylko autor ostatniej zmiany | `Form.Recall` |
| Odrzuć do poprawy | `Form.Approve` | komentarz obowiązkowy | `Form.Reject` |
| Zatwierdź | `Form.Approve` | R8 | `Form.Approve` |
| Opublikuj | `Form.Publish` | inwariant 5 | `Form.Publish` |
| Utwórz nową wersję (szkic z wybranej wersji) | `Form.Edit` | inwariant 2 | `Form.NewVersion` |
| Porzuć szkic | `Form.Edit` | — | `Form.Discard` |
| Wycofaj wersję | `Form.Withdraw` | inwariant 7 | `Form.Withdraw` (+ `Form.Repin` dla przepiętych zadań) |
| Wycofaj formatkę | `Form.Withdraw` | powód obowiązkowy | `Form.Retire` |
| Eksportuj plik `.form` | `Form.View` | — | `Form.Export` |
| Przeglądaj formatki, wersje, historię | `Form.View` | R11 | odczyt w śladzie operacyjnym |

Uprawnienia `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw` mają menadżer i administrator procesu — każdy w zakresie swoich procesów; audytor ma `Form.View`. Uczestnik nie ma żadnego: formatkę widzi wyłącznie na zadaniu.

## 6. Wersjonowanie

- **Rewizje szkicu.** Każdy zapis wersji roboczej tworzy rewizję (tabela temporalna): kto, kiedy, co zmienił. Historia jest widoczna w projektancie; nie ma numerów — numer dostaje dopiero publikacja.
- **Wersje opublikowane.** Kolejne liczby całkowite w obrębie formatki. Każda ma skrót treści, profil zgodności, autora ostatniej zmiany, zatwierdzającego i publikującego.
- **Porównanie.** Dowolne dwie wersje (albo szkic z wersją obowiązującą) można porównać: pola dodane, usunięte i zmienione, z listą zmienionych właściwości. Zatwierdzający zawsze widzi różnicę względem wersji obowiązującej — bez tego cztery oczy byłyby formalnością.
- **Nowa wersja z dowolnej.** Szkic można utworzyć z każdej wcześniejszej wersji, także wycofanej; dalej idzie zwykłą drogą.
- **Wersje definicji procesu.** Formatka nie jest wersjonowana razem z BPMN. Zgodność z modelem zapewnia kontrakt danych sprawdzany przy publikacji dla każdej wersji definicji, która ma aktywne instancje i wskazuje formatkę (C19).

## 7. Akceptacja (cztery oczy)

```mermaid
sequenceDiagram
    actor M as Marta (menadżer)
    actor A as Adam (administrator)
    participant FM as Form Management
    participant N as Powiadomienia
    M->>FM: Zapisz szkic, Przekaż do przeglądu
    FM->>N: „Formatka czeka na przegląd” → osoby z Form.Approve w procesie
    A->>FM: Otwórz przegląd (różnica względem wersji obowiązującej)
    alt uwagi
        A->>FM: Odrzuć do poprawy (komentarz)
        FM->>N: powiadomienie autora
    else bez uwag
        A->>FM: Zatwierdź (R8: Adam ≠ autor ostatniej zmiany)
        M->>FM: Opublikuj (kontrakt danych, katalog pól)
        FM-->>M: wersja N opublikowana, poprzednia zastąpiona
    end
```

- R8 porównuje zatwierdzającego z autorem ostatniej zmiany. Lista wszystkich współautorów szkicu jest zapisywana i pokazywana zatwierdzającemu; zaostrzenie reguły do „żaden ze współautorów” to decyzja D-12.
- Publikować może każda osoba z `Form.Publish`, także autor — zatwierdzenie już się odbyło i dotyczy dokładnie tej treści.
- Zatwierdzenie nie wygasa z czasem; unieważnia je wyłącznie zmiana treści.

## 8. Wycofywanie

Wycofanie to osobna, audytowana operacja (`Form.Withdraw`) z obowiązkowym powodem: `Defect` (wada formatki), `Compliance` (wymóg zgodności), `ProcessChange` (zmiana procesu), `Other` (z opisem). Okno potwierdzenia pokazuje skutek: liczbę zadań w toku na tej wersji i zadania procesu wskazujące formatkę.

| Sytuacja | Nowe zadania | Zadania w toku na wycofanej wersji |
| --- | --- | --- |
| Wycofanie wersji obowiązującej **z wersją zastępczą** (wcześniej opublikowaną, zgodną z kontraktem) | dostają wersję zastępczą — wraca ona do stanu `Published` | do wyboru: **pozostają** na wycofanej wersji (domyślnie) albo są **przepinane** na zastępczą |
| Wycofanie wersji obowiązującej **bez zastępczej** | nie mają formatki do czasu kolejnej publikacji: zadanie pokazuje komunikat, zakończenie jest zablokowane, menadżer widzi alert | pozostają na wycofanej wersji; przepięcie niemożliwe |
| Wycofanie wersji zastąpionej (nieobowiązującej) | bez zmian | pozostają albo są przepinane na wersję obowiązującą |
| Wycofanie całej formatki (`Form.Retire`) | jak „bez zastępczej”; formatki nie da się opublikować ponownie bez nowego szkicu i pełnej akceptacji | pozostają na swoich wersjach |

- **Przepięcie** (`Repin`) jest jedynym wyjątkiem od niezmienności przypięcia. Wykonuje je zadanie w roli `jobs` z trwałym stanem i wznawianiem (wzorzec `ReassignmentBatch`). Szkic danych zadania przechodzi dla pól o tym samym kluczu i typie; pozostałe wartości są odrzucane, a wykonawca widzi na zadaniu informację o zmianie formatki. Każde przepięcie to wpis `Form.Repin`.
- **Przywrócenie** wycofanej wersji nie istnieje jako skrót: tworzy się z niej nowy szkic i przechodzi pełną akceptację.
- Wycofanie wykonuje jedna osoba — to operacja awaryjna; powiadomienie dostają wszyscy z `Form.Approve` w procesie. Wymóg drugiej osoby przy wycofaniu to decyzja D-13.
- Formatka startowa: wycofanie bez zastępczej wyłącza start procesu z aplikacji z czytelnym komunikatem w katalogu startowym.

## 9. Powiązanie z procesem i przypięcie

| Element | Jak wskazuje formatkę | Kontrakt danych |
| --- | --- | --- |
| User task | `zeebe:formDefinition externalReference="ph:form/<klucz>"` (C6) | `ph:inputs`, `ph:outputs` w `zeebe:properties` zadania (C7) |
| Start procesu | formatka z zastosowaniem `ProcessStart` przypisana do procesu w Form Management (zdarzenie startowe nie przyjmuje `externalReference`) | `ph:outputs` zdarzenia startowego |

Referencja nie zawiera identyfikatora procesu: klucz jest rozwiązywany zawsze w procesie zadania — `(TenantId, BpmnProcessId zadania, FormKey)`. Odwołanie do formatki innego procesu jest niewyrażalne.

```mermaid
sequenceDiagram
    participant CAM as Camunda
    participant CI as Camunda Integration (projektor)
    participant TW as Task Work
    participant FM as Form Management
    participant FR as Form Runtime
    actor U as Wykonawca
    CAM-->>CI: user task utworzony (elementId, bpmnProcessId)
    CI->>TW: zdarzenie integracyjne
    TW->>FM: wersja obowiązująca dla (tenant, proces, klucz z katalogu elementów)
    FM-->>TW: FormVersion N — przypięcie zapisane w WorkItem
    U->>FR: otwórz zadanie
    FR-->>U: schemat wersji N + dane wejściowe + tryb (edycja albo odczyt)
    U->>FR: Zakończ (wartości pól)
    FR->>FR: walidacja wg wersji N i kontraktu ph:outputs
    FR->>CAM: completion przez IUserTaskCommands (tylko zmienne z kontraktu)
```

- **Brak wersji obowiązującej** w chwili utworzenia zadania: zadanie powstaje bez przypięcia; przypięcie następuje przy pierwszym otwarciu po publikacji. Do tego czasu zadania nie da się zakończyć.
- **Kontrola spójności.** Katalog elementów (`IDefinitionCatalog`) daje listę referencji `ph:form/…` każdej wersji definicji. Projektant pokazuje „Powiązania”: które zadania (nazwa i etap; identyfikator elementu tylko z `Bpmn.ViewTechnical`) wskazują formatkę oraz referencje bez opublikowanej formatki („Brakujące formatki”). Po wdrożeniu nowej wersji definicji procesu kontrola sprawdza też, czy wersja obowiązująca spełnia jej kontrakt danych; niezgodność trafia jako ostrzeżenie do menadżera i administratora procesu. Naprawa: publikacja nowej wersji formatki, a dla zadań już przypiętych do starej — jej wycofanie z przepięciem.
- **Zgodność z kontraktem przy publikacji.** Każde wyjście z `ph:outputs` musi mieć pole o tym kluczu i zgodnym typie (`string` ↔ pola tekstowe, wyboru i dat; `number` ↔ `number`; `boolean` ↔ `checkbox`; `date` ↔ `datetime`). Pole czytające zmienną spoza `ph:inputs` daje ostrzeżenie. Sprawdzane są wszystkie wersje definicji z aktywnymi instancjami, które wskazują formatkę.
- **Formatka startowa nie ma przypięcia.** Start procesu waliduje dane względem wersji, którą wyświetlono (numer wersji jest w żądaniu); jeśli w międzyczasie zmieniła się wersja obowiązująca, żądanie jest odrzucane z prośbą o odświeżenie formatki — wpisane dane zostają w przeglądarce.
- **Reguły bpmnlint:** `ph/task-contract` (jest) oraz nowa `ph/form-reference` — user task wskazuje formatkę wyłącznie przez `externalReference` w postaci `ph:form/<klucz>`; `formId` i formularze osadzone są zabronione.

## 10. Separacja per proces (R11)

| Warstwa | Mechanizm |
| --- | --- |
| Model | tożsamość formatki zawiera `BpmnProcessId`; brak encji współdzielonych między procesami |
| Uprawnienia | `Form.*` sprawdzane w zakresie procesu formatki; menadżer procesu A nie ma ich w procesie B (odmowa `Denied` z nazwą uprawnienia) |
| Reguła wiersza | R11 odrzuca każdą operację łączącą dwa procesy: szkic z wersji formatki innego procesu, przypięcie spoza procesu zadania, wersję zastępczą z formatki innego procesu |
| API | wszystkie trasy pod `/api/processes/{bpmnProcessId}/forms/…`; lista zwraca wyłącznie procesy z `Form.View` |
| Baza | `TenantId` + `BpmnProcessId` w każdej tabeli schematu `form`; unikalność klucza w procesie; RLS po tenancie; test architektury: każde zapytanie modułu przyjmuje zakres procesu |
| Wykonanie | Form Runtime wydaje schemat tylko dla przypięcia zadania; brak trasy „pobierz formatkę po identyfikatorze” |
| Interfejs | ekran „Formatki” zawsze w kontekście jednego procesu; przełącznik procesu pokazuje tylko procesy w zakresie |
| Profile | pola profilu i źródła danych tylko w formatkach procesów profilu (R9) |
| Audyt | każdy wpis `Form.*` zawiera `BpmnProcessId`; odmowy R11 z kodem reguły |
| Testy | `specs/forms/form-isolation.feature`; macierz autoryzacji dla `Form.*` × proces |

## 11. Renderowanie na zadaniu

1. **Pobranie.** Widok zadania dostaje schemat przypiętej wersji, dane wejściowe (zmienne z `ph:inputs`), szkic danych i tryb: edycja (assignee) albo odczyt (pozostali — z jednym zdaniem wyjaśnienia, R1).
2. **Interpretacja** (`form-runtime`). Biblioteka czyta schemat Camunda Forms: drzewo komponentów, ścieżki danych (`key`, `path`), układ (`layout.row`, `layout.columns` w siatce 16 kolumn), warunki i wyrażenia FEEL, walidacje.
3. **Materializacja.** Każdy typ z katalogu pól ma dokładnie jeden komponent w `core/ui-kit` (opakowanie Kendo stylowane tokenami). Renderer nie zna kolorów ani rozmiarów — przekazuje komponentowi etykietę, podpowiedź, stan, błąd i wartość.
4. **Walidacja w przeglądarce** przy opuszczeniu pola i przy zakończeniu: wymagalność, długości, zakresy, wzorce, typy; podsumowanie błędów nad formatką z odnośnikami do pól.
5. **Walidacja na serwerze** (`FormRuntime`) przed wywołaniem silnika — zawsze, niezależnie od przeglądarki (FR-06):
   - poziom A (bezwarunkowy): tylko klucze znane schematowi, typy wartości, ograniczenia statyczne, przynależność do opcji statycznych, pole stale `readonly` nie może zmienić wartości wejściowej, a pole stale `disabled` nie jest przyjmowane, kontrakt `ph:outputs` (każde wyjście ma wartość zgodnego typu albo — gdy jego pole jest ukryte warunkiem — wartość pustą);
   - poziom B (wyrażenia): warunki ukrycia, dynamiczne `readonly`/`disabled`, opcje z wyrażeń — przez `IExpressionEvaluator` (ADR-020, PoC S08).
6. **Zakończenie.** Do silnika trafiają wyłącznie zmienne z kontraktu (C8).

Zestaw zgodności (NFR-14) uruchamia te same formatki wzorcowe w rendererze platformy i w referencyjnym form-js i porównuje zbiór widocznych pól, błędy walidacji i dane wyjściowe. Wygląd celowo się różni; zachowanie nie może.

## 12. Warstwa wizualna — założenia

Trzy warstwy, każda z jednym właścicielem:

| Warstwa | Zawartość | Właściciel | Gdzie |
| --- | --- | --- | --- |
| Struktura | pola, typy, teksty, walidacje, warunki, wiersze i szerokości | biznes (menadżer, administrator procesu) | schemat wersji formatki |
| Materializacja | typ pola → komponent, jego warianty i stany | zespół design systemu | `design/forms/field-catalog.yaml`, `core/ui-kit` |
| Wygląd | kolory, typografia, odstępy, promienie, wysokości kontrolek | projektant UX | Figma → `design/tokens.json` → `core/theming` |

- **Biznes układa, nie stylizuje.** W projektancie dostępne są wyłącznie własności katalogu. Układ to wiersze i szerokości w siatce; odstępy, wyrównania i typografię nadaje design system.
- **Jedna formatka, wszystkie motywy.** Ta sama wersja wygląda poprawnie w motywie jasnym i ciemnym, na telefonie (pola w jednej kolumnie poniżej progu szerokości) i przy powiększeniu 200%.
- **Spójność z resztą systemu.** Pole formatki to ten sam komponent, którego używają okna przekazania czy zastępstw; błędy, podpowiedzi i stan „tylko do odczytu” wyglądają wszędzie tak samo.
- **Zmiana wyglądu nie wymaga zmiany formatek.** Nowe tokeny albo poprawiony komponent działają dla wszystkich opublikowanych wersji; wersje formatek nie niosą wyglądu, więc pozostają niezmienne.
- **Figma jest źródłem wyglądu, repozytorium — źródłem prawdy dla kodu.** Projektant eksportuje zmienne i specyfikacje; do repozytorium trafiają jako pull request w `design/**`. Kod czyta wyłącznie `design/tokens.json` i katalog pól (ADR-019).

Szczegóły (siatka, stany pól, komunikaty, mapowanie każdego typu, proces Figma → kod): `design/forms/README.md`.

## 13. Projektant formatek

| Obszar ekranu | Zawartość |
| --- | --- |
| Nagłówek | proces, nazwa i klucz formatki, stan wersji roboczej, wersja obowiązująca, akcje cyklu życia z `allowedActions` |
| Miejsce w procesie | wstęga etapów z zaznaczonym etapem zadania i liczbą czekających spraw (FR-16); powiązania i kontrakt danych |
| Projekt | osadzony edytor form-js: paleta ograniczona do katalogu pól (plus pola profilu procesu), kanwa, panel właściwości bez własności zablokowanych |
| Podgląd jak u wykonawcy | ta sama formatka w rendererze platformy, z danymi przykładowymi, w obu motywach i szerokościach |
| Walidacja | błędy i ostrzeżenia katalogu oraz kontraktu, z odnośnikami do pól |
| Wersje | lista wersji ze stanami, autorami i datami; porównanie; „Utwórz nową wersję”, „Wycofaj”, eksport |
| Historia | rewizje szkicu, przeglądy z komentarzami, wycofania |

- Edytor pracuje na kanwie form-js (wygląd biblioteki, znak bpmn.io widoczny — wymóg licencji); o wyglądzie u wykonawcy rozstrzyga zakładka podglądu.
- Edycja możliwa tylko w stanie `Draft`; w pozostałych projektant jest tylko do odczytu, z jednym zdaniem „dlaczego”.
- Akcje nieodwracalne (publikacja, wycofanie) przechodzą przez okno potwierdzenia z podsumowaniem skutku.

## 14. API, dane, zdarzenia (szkic do kontraktów v1, krok S15)

| Trasa | Uprawnienie |
| --- | --- |
| `GET /api/processes/{p}/forms` · `GET …/forms/{key}` · `GET …/forms/{key}/versions/{n}` · `GET …/versions/{a}/diff/{b}` | `Form.View` |
| `POST /api/processes/{p}/forms` · `PUT …/forms/{key}/draft` · `POST …/draft/submit` · `POST …/draft/recall` · `DELETE …/draft` · `POST …/versions/{n}/new-version` · `POST …/import` | `Form.Edit` |
| `POST …/draft/approve` · `POST …/draft/reject` | `Form.Approve` |
| `POST …/draft/publish` | `Form.Publish` |
| `POST …/versions/{n}/withdraw` · `POST …/forms/{key}/retire` | `Form.Withdraw` |
| `GET …/versions/{n}/export` | `Form.View` |
| `GET /api/processes/{p}/forms/catalog` (katalog pól + pola profilu procesu) | `Form.View` |
| `GET /api/tasks/{taskKey}/form` · `GET /api/processes/{p}/start-form` | jak dla zadania i startu |

Schemat bazy `form`: `FormDefinition`, `FormVersion` (temporalna — rewizje szkicu), `FormReview`, `FormWithdrawal`, `FormRepinBatch`, `FormRepinItem`; przypięcie w `task.WorkItem` z historią przepięć. Zdarzenia przez outbox: `FormSubmittedForReview`, `FormApproved`, `FormRejected`, `FormVersionPublished`, `FormVersionWithdrawn`, `FormRetired` — odbiorcy: Task Work (przepięcia), Notification, Audit.

## 15. Bezpieczeństwo

- Biała lista typów i własności z katalogu pól, egzekwowana przy imporcie, zapisie, przekazaniu do przeglądu i publikacji — niezależnie od tego, co pozwolił edytor.
- Tekst formatek (`text`, etykiety, podpowiedzi) renderowany bez surowego HTML; Markdown po sanityzacji; brak zewnętrznych obrazów, ramek i skryptów (CSP bez zmian).
- FEEL jest interpretowany, nie kompilowany do kodu; limity długości wyrażeń i rozmiaru schematu; limit rozmiaru żądania zapisu.
- W dzienniku: skrót treści i lista zmienionych pól, bez wartości wpisanych przez wykonawców (NFR-09).
- Klient techniczny Camunda dostaje jedno nowe uprawnienie: ewaluację wyrażeń (`EXPRESSION: EVALUATE`, wariant B1 z ADR-020 — do potwierdzenia w S08) — bez prawa wdrażania zasobów.

## 16. Testy

| Zakres | Gdzie |
| --- | --- |
| Cykl życia, R8, kontrakt, przypięcie | `specs/forms/form-lifecycle.feature` (FR-17, FR-18) |
| Camunda Forms, katalog pól, import i eksport | `specs/forms/form-designer.feature` (FR-28) |
| Wersje, porównanie, nowa wersja | `specs/forms/form-versioning.feature` (FR-29) |
| Wycofanie i przepięcie | `specs/forms/form-withdrawal.feature` (FR-30) |
| Separacja per proces | `specs/forms/form-isolation.feature` (FR-31) |
| Materializacja i walidacja na zadaniu | `specs/forms/form-rendering.feature` (FR-32, FR-06) |
| Zgodność z form-js | zestaw zgodności w `form-runtime` (NFR-14) |
| Spójność wizualna i dostępność pól | regresja wizualna i axe na katalogu komponentów (NFR-15) |

## 17. Plan wykonania modułu

Kroki modułu są częścią planu platformy (`plan/backlog.yaml`, opis: `plan/execution-plan.md`); tu zebrane w kolejności wykonania.

| Krok | Faza | Cel | Wykonawca | Zależy od | Wynik |
| --- | --- | --- | --- | --- | --- |
| S07 | 0 | PoC: edytor form-js w Angularze, renderer na design systemie kontra viewer, zestaw zgodności na formatkach wzorcowych | `frontend-developer` + `ux-designer` | S00 | raport, decyzja ADR-019 |
| S08 | 0 | PoC: reguły schematu w .NET, ewaluacja FEEL przez API klastra, różnice względem przeglądarki | `camunda-integrator` + `module-implementer` | S01 | raport, decyzja ADR-020 |
| S09 | 0 | Warstwa wizualna: biblioteka w Figma, tokeny, katalog pól, specyfikacje komponentów | `ux-designer` + projektant UX | S00 | `design/**` zatwierdzone |
| S16 | 1 | Shell, motyw z tokenów, `ui-kit`, katalog komponentów | `frontend-developer` + `design-system-engineer` | S15, S09 | `frontend/**` |
| S26 | 2 | Form Management: wersje, R8, R11, publikacja z kontraktem i katalogiem, wycofanie, import i eksport | `module-implementer` + `bdd-tester` | S15 (G1) | moduł `FormManagement` |
| S28 | 2 | Schemat `form`, unikalność i klucze per proces, historia przypięć | `data-engineer` | S13, S15 (G1) | migracje |
| S29 | 2 | Referencje `ph:form` i kontrakt danych z katalogu elementów, kontrola spójności, reguła `ph/form-reference` | `camunda-integrator` + `module-implementer` | S17, S23, S26 | powiązania, reguła bpmnlint |
| S37 | 3 | Form Runtime: schemat przypiętej wersji, walidacja poziomu A i B, przypięcie | `module-implementer` + `bdd-tester` | S26, S29, S08 (G1) | moduł `FormRuntime` |
| S39 | 3 | Wycofanie w toku: przepięcie zadań, zadania bez formatki, powiadomienia | `module-implementer` + `bdd-tester` | S28, S30, S37 | saga przepięcia |
| S49 | 4 | Komponenty pól w `ui-kit` wg katalogu pól, regresja wizualna, axe | `design-system-engineer` + `ui-reviewer` | S16, S07, S09 | `ui-kit`, `ui-catalog` |
| S40 | 4 | Skrzynka zadań i renderer formatek (`form-runtime`) | `frontend-developer` + `ui-reviewer` | S16, S30, S37, S49 | formatka na zadaniu |
| S45 | 4 | Projektant formatek (`form-designer`) | `frontend-developer` + `ui-reviewer` | S16, S26, S40 | projektant |
| S55 | 5 | Zestaw zgodności, schemat `.form`, parytet katalogu i regresja wizualna w CI | `frontend-developer` + `ui-reviewer` | S50 | bramki CI |

- **Bramka G1** wymaga raportów S07 i S08 (ADR-019 i ADR-020 ze statusem „Przyjęta”) oraz zatwierdzonej warstwy wizualnej (S09) — kontrakty modułu są zamrażane dopiero po tych decyzjach.
- **Zapas.** Łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma ok. 2,6 dnia zapasu; po ścieżce krytycznej to najciaśniejsza część planu.
- **Otwarte decyzje:** D-12 (zakres reguły czterech oczu), D-13 (druga osoba przy wycofaniu), D-14 (domyślny skutek wycofania), D-15 (załączniki), D-16 (właściciel biblioteki w Figma) — `plan/execution-plan.md`.
