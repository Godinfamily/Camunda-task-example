# 12. Strategia testów

Te same scenariusze Gherkin działają na dwóch poziomach: szybko na adapterach in-memory (każdy commit) i na prawdziwym MSSQL + Camunda w Testcontainers (tag `@integration`). Kroki są cienkie; o poziomie decyduje wstrzyknięty driver.

| Poziom | Narzędzie | Co sprawdza | Kiedy |
| --- | --- | --- | --- |
| Domena | xUnit | inwarianty agregatów, specyfikacje R1–R11, algorytm stanu etapów | każdy commit |
| BDD aplikacyjne | Reqnroll + drivery in-memory | reguły z `specs/` | każdy commit |
| BDD integracyjne `@integration` | Reqnroll + Testcontainers (MSSQL, Camunda 8.9) | RLS, wyścig przejęcia, SDK, task listener, Ledger | PR do `main` |
| Kontraktowe | xUnit | porty `CamundaIntegration`: fake i SDK przechodzą ten sam zestaw | PR do `main` |
| Macierz autoryzacji | xUnit (generowane) | dla każdej pary rola × uprawnienie × zakres z YAML: oczekiwane Allowed/Denied | każdy commit |
| Kompletność audytu | xUnit + WebApplicationFactory | każdy endpoint zostawia ślad i (gdzie trzeba) wpis dziennika | każdy commit |
| Architektury | ArchUnitNET / NetArchTest | granice modułów, SDK tylko w ACL, potok, brak nazw ról w kodzie | każdy commit |
| bpmnlint | `bpmnlint-plugin-ph` | reguły z `06-camunda-integration.md` | każdy commit z BPMN |
| E2E | Playwright + axe-core | kluczowe ścieżki per rola, dostępność | nightly |
| Zgodność formatek | Jest + referencyjny form-js | formatki wzorcowe: te same widoczne pola, błędy walidacji i dane wyjściowe w rendererze platformy i w form-js; te same wyrażenia FEEL w przeglądarce i na serwerze | każdy commit `form-runtime`, każda zmiana wersji form-js |
| Schemat formatek | oficjalny schemat `@bpmn-io/form-json-schema` | każda formatka wzorcowa i każda wersja opublikowana w testach jest poprawnym plikiem `.form` | każdy commit |
| Regresja wizualna | Playwright (zrzuty katalogu komponentów) | komponenty `ui-kit` i pola formatek w obu motywach i trzech szerokościach; wzorce zatwierdza projektant UX | każdy commit `ui-kit`, `theming`, `design/tokens.json` |
| Parytet katalogu pól | xUnit + Jest | `design/forms/field-catalog.yaml` ↔ `IFieldType` ↔ rejestr `form-runtime` | każdy commit |
| Mutacyjne | Stryker.NET | siła testów domeny | nightly |
| Manifesty profili | `validate_profiles.py --check` + autotest | schemat, R9/R10, własność procesów i grup, `CODEOWNERS` | każdy commit |
| Zgodność SDK | `ProcessHub.Extensibility.Testing` | każdy profil przechodzi testy zgodności z bieżącą wersją SDK | każdy commit profilu i każda zmiana SDK |
| Scenariusze profili | Reqnroll na hoście testowym SDK | `profiles/<id>/specs/*.feature` (tagi `@<PROFIL>-FR-xx`) | każdy commit profilu |
| Granice zmian profilu | `enforce_write_scope.py --verify-diff --profile <id>` | PR zespołu zmienia wyłącznie `profiles/<id>/**` | każdy PR profilu |

## Konwencje BDD

- `# language: pl`; tag FR (`@FR-11`) na każdym scenariuszu; `@integration` dla scenariuszy wymagających infrastruktury.
- Świat testowy (osoby, grupy, procesy) opisany raz w `specs/README.md` — każdy plik korzysta z tych samych nazw.
- Kroki tylko delegują do driverów (`ITaskWorkDriver`, `IInsightDriver`, `IFormsDriver`…); żadnej logiki w bindingach.
- Asercje jako rozszerzenia domenowe (`ShouldBeDeniedBy("R6")`); bez komercyjnych bibliotek asercji.
- Pliki `.feature` zatwierdza człowiek (G0); implementer ma do nich dostęp tylko do odczytu.
- Scenariusze profilu leżą w `profiles/<id>/specs/` i należą do zespołu profilu (akceptuje właściciel produktu profilu); świat testowy pozostaje wspólny.
