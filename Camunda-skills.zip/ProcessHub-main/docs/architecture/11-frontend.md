# 11. Frontend (Angular)

UI nie liczy uprawnień: każdy zasób z API przychodzi z listą `allowedActions` (np. `["claim"]`, `["reassign","viewTechnical"]`), a akcje renderują się wyłącznie z niej. Reguły żyją w jednym miejscu — w backendzie. Motywy, WCAG, Signals i Kendo — jak w dokumencie wejściowym v1 o architekturze UI. Wzorzec wizualny i zachowania ekranów: `design/README.md` i klikalna makieta `design/mockups/index.html`; tokeny: `design/tokens.json`; formatki: `design/forms/README.md`. Wytyczne dla osób zaczynających pracę nad interfejsem: `docs/artifacts/04-wytyczne-ui.md`.

## Biblioteki (Nx)

| Biblioteka | Widoki |
| --- | --- |
| `task-workspace` | Moje zadania, Do przejęcia, Zadania grupy (odczyt), szczegóły zadania z formatką |
| `process-lifecycle` | Start procesu (katalog procesów, które mogę startować + formatka startowa), Moje procesy z paskiem etapów |
| `process-insight` | Dashboard, Eskalowane, Instancje procesu, szczegóły instancji (mapa etapów, historia, zadania) |
| `reassignment` | dialog przekazania (osoba/grupa, powód), przekazanie masowe z podglądem i raportem, zastępstwa |
| `stage-map-editor` | edytor mapy etapów: lista elementów + bpmn-js (viewer tylko do odczytu) dla `Bpmn.ViewTechnical`, edycja etapów |
| `form-designer` | lista formatek procesu, osadzony edytor form-js (paleta z katalogu pól), przegląd z porównaniem wersji, publikacja, wycofanie, import i eksport, podgląd jak u wykonawcy |
| `form-runtime` | renderer schematu Camunda Forms: interpretacja (dane, układ, FEEL, walidacja) i rejestr typ pola → komponent `core/ui-kit` |
| `audit-viewer` | dziennik bezpieczeństwa i ślad (wg uprawnień) |
| `core/*` | `ui-kit` (opakowania Kendo, w tym komponenty pól formatek), `auth`, `access` (sygnał `AccessContext`), `i18n`, `theming` (tokeny → zmienne CSS i motyw Kendo) |
| `apps/ui-catalog` | katalog komponentów `ui-kit` we wszystkich stanach — podstawa regresji wizualnej i przeglądu z projektantem UX |
| `platform/extension-sdk` | SDK rozszerzeń UI: typy `ProfileUiModule` i `SlotRegistration`, rejestr slotów, kontekst zadania i sprawy dla komponentów profili |
| `profiles/<id>/frontend` | biblioteka zespołu profilu (`profile-<id>-ui`): komponenty slotów i trasy `/p/<id>/` |

## Rozszerzenia profili (sloty)

- Powłoka renderuje sloty `task.panel`, `case.panel`, `dashboard.widget`, `form.field` i `nav.section`; komponent profilu pojawia się tylko, gdy proces należy do profilu i aktor ma uprawnienie slotu (decyzja przychodzi z API razem z `allowedActions`).
- Przyciski operacji dedykowanych renderuje powłoka z `allowedActions` (np. `kredyty.RecalculateScoring`) — profil dostarcza tylko etykietę i ewentualny formularz parametrów. Na stronach profilu (`/p/<id>/…`) `allowedActions` przychodzą z wynikiem zapytania profilu i obejmują operacje na danych profilu (`profile-action`, ADR-017), np. „Dodaj model” w katalogu floty.
- Sekcja nawigacji profilu (`nav.section`) to osobna grupa w szufladzie nawigacji, pod sekcjami platformy, z trasami `/p/<id>/`; widzą ją wyłącznie osoby z uprawnieniem trasy. Przykład: sekcja „Flota” → „Katalog samochodów” (`design/mockups/index.html`, persony Tomasz, Hanna, Karol).
- Granice Nx: biblioteki profili mają tag `scope:profile-<id>` i mogą zależeć wyłącznie od `scope:extension-sdk`; platforma nie importuje bibliotek profili (rejestracja przez manifest i `loadChildren`).
- Ładowanie domyślnie leniwe w obrazie aplikacji; Native Federation dla profilu z niezależnymi wydaniami frontendu [DO WERYFIKACJI w S47].
- Teksty profilu we własnych plikach i18n (`profiles/<id>/frontend/i18n/pl.json`); tokeny wizualne wyłącznie z `design/tokens.json`, żeby rozszerzenia wyglądały jak platforma.

## Formatki i design system

- **Podział ról.** Schemat formatki (Camunda Forms) niesie strukturę; `form-runtime` ją interpretuje; wygląd daje wyłącznie `core/ui-kit` na tokenach z `design/tokens.json`. Renderer nie zawiera kolorów, rozmiarów ani odstępów (ADR-019).
- **Rejestr materializacji.** Dla każdego typu z `design/forms/field-catalog.yaml` o statusie „wspierany” istnieje dokładnie jeden komponent pola; test parytetu porównuje katalog, rejestr frontendu i `IFieldType` w backendzie.
- **Edytor form-js** żyje wyłącznie w `form-designer` (granica Nx); renderuje w Preact wewnątrz komponentu-opakowania, bez wycieku stylów biblioteki do aplikacji. Znak bpmn.io pozostaje widoczny.
- **Wyrażenia.** FEEL i szablony wykonuje `form-runtime` bibliotekami `@bpmn-io/feelin` i `feelers`; o poprawności danych rozstrzyga serwer.
- **Układ.** Siatka 16 kolumn schematu jest odwzorowana w siatce CSS design systemu; poniżej progu szerokości pola układają się w jednej kolumnie.
- **Pola profili.** Slot `form.field` to wariant typu bazowego wskazany własnością `ph:field`; renderer podstawia komponent profilu tylko w formatkach procesów profilu.
- **Zestaw zgodności i regresja wizualna** są częścią `nx affected -t test` dla `form-runtime` i `ui-kit` (NFR-14, NFR-15).

## Ustalenia

- Wykresy dashboardu: Kendo Chart; liczniki i progi jako karty z kolorem statusu i etykietą tekstową (kolor nigdy nie jest jedynym nośnikiem informacji — WCAG 1.4.1).
- Mapa etapów: Kendo Stepper z czasami i flagami; w dashboardzie wykres słupkowy „aktywne na etapie”.
- bpmn-js wyłącznie w `stage-map-editor` i tylko dla uprawnienia `Bpmn.ViewTechnical`; edytor form-js wyłącznie w `form-designer`; licencja bpmn.io wymaga pozostawienia widocznego znaku wodnego w obu.
- Aktualizacje push przez SignalR (nowe zadanie, przekazanie, eskalacja); RxJS na brzegu, `toSignal` w komponentach.
- Konflikt przy przejęciu (`409` z silnika) → komunikat „zadanie przejął właśnie X” i odświeżenie listy.
- Formularze przekazania wymagają powodu z listy + opisu dla „inne”; przekazanie masowe pokazuje podgląd liczby zadań przed wykonaniem.
