# 06. Integracja z Camunda 8.9 — praktyki i ich uzasadnienie

Zasada przewodnia: silnik rozstrzyga o stanie (kto ma zadanie, czy jest zakończone, gdzie jest token), aplikacja rozstrzyga o widoczności i prezentacji. Każda praktyka poniżej z tego wynika; kolumna „Dlaczego” jest materiałem do nauki zespołu.

Elementy oznaczone **[PoC]** potwierdzamy w krokach S01–S04 na wersji 8.9 i wybranym wydaniu oficjalnego SDK.

## Oficjalne SDK

- SDK żyje wyłącznie w `CamundaIntegration.Infrastructure.Sdk`, za portami z `05-solution-architecture.md`.
- Jeden długożyjący klient na rolę hosta (bezpieczny wątkowo, z buforowaniem tokenu OAuth), wersja SDK przypięta w `Directory.Packages.props`, aktualizacja tylko z zielonymi testami kontraktowymi.
- Lista kontrolna pokrycia **[PoC, S01]**: start instancji z `tenantId`; wyszukiwanie instancji, zadań, instancji elementów, incydentów; `assignment` z `allowOverride`; zwolnienie; aktualizacja `candidateGroups`; `completion` ze zmiennymi; pobranie XML definicji; zarządzanie autoryzacjami; job worker (dla task listenerów) z korektami; ewaluacja wyrażenia FEEL (**[PoC, S08]**); anulowanie przez `CancellationToken`. Brakująca operacja → klient wygenerowany z OpenAPI Camunda, ale nadal wewnątrz ACL (ADR-003).
- Ponowienia: korzystamy z mechanizmu SDK; własny Polly tylko tam, gdzie SDK go nie ma — podwójne ponawianie mnoży obciążenie silnika przy awarii.

## Praktyki

| # | Praktyka | Dlaczego |
| --- | --- | --- |
| C1 | Kroki ludzkie jako Camunda user task (`<zeebe:userTask/>`) | Tylko ten typ obsługuje API v2, task listenery i aktualizację kandydatów; wariant oparty o job worker jest wycofywany |
| C2 | Przejęcie: `assignment` z `allowOverride: false`; przekazanie przez menadżera: `allowOverride: true` | Wyścig dwóch osób rozstrzyga silnik; świadome nadpisanie jest możliwe tylko w komendzie, która wymaga uprawnienia i powodu |
| C3 | Zmiana grupy: aktualizacja `candidateGroups` zadania (zwolnienie assignee, jeśli był) — nie anulowanie i ponowne utworzenie | Zadanie zachowuje klucz, historię i szkic; anulowanie zmieniłoby przebieg procesu i zgubiło ślad |
| C4 | `candidateGroups` jako FEEL ze zmiennej routingu, np. `=routing.ocenaGroups`, ze stabilnymi identyfikatorami grup | Reorganizacja zespołów nie wymaga wdrożenia BPMN; nazwy wyświetlane z AD nigdy nie trafiają do modelu |
| C5 | Start wyłącznie przez BFF: dopisuje `initiatorPartyId`, `initiatorGroupIds`, `caseId` i jawny `tenantId` | Camunda 8 nie ma klucza biznesowego ani pojęcia „inicjatora z grupy”; `caseId` służy też do korelacji komunikatów |
| C6 | Formatka przez referencję zewnętrzną (`zeebe:formDefinition externalReference="ph:form/<klucz>"`), klucz rozwiązywany w procesie zadania, wersja przypinana przy utworzeniu zadania | Silnik orkiestruje, a cykl życia formatki należy do aplikacji; instancja w toku nie zobaczy zmienionej formatki; referencja bez identyfikatora procesu nie pozwala wskazać formatki innego procesu (R11) |
| C7 | Kontrakt danych zadania jako `ph:inputs`/`ph:outputs` w `zeebe:properties` | Język opublikowany między zespołem BPMN a autorami formatek; publikacja formatki jest walidowana względem kontraktu: każde wyjście ma pole Camunda Forms o tym kluczu i zgodnym typie |
| C8 | Output mapping na user tasku, minimalny payload przy zakończeniu | Zmienne trafiają do magazynu wtórnego i eksportu: rozmiar, retencja, PII; proces dostaje tylko to, czego oczekuje |
| C9 | Załączniki jako referencje (obsługa dokumentów Camunda lub własny magazyn), nie zmienne | Limity rozmiaru zmiennych i retencja |
| C10 | Zastępstwa przez task listener (`creating`, `assigning`) zwracający korektę assignee/grup **[PoC, S03]** | Korekta dzieje się w silniku, zanim zadanie stanie się widoczne — bez wyścigu z projektorem i bez „mignięcia” zadania u nieobecnej osoby |
| C11 | Worker task listenera w trybie fail-open z limitem czasu: brak odpowiedzi platformy → zakończ job bez korekty + audyt `SubstitutionSkipped` | Listener blokuje przejście stanu; awaria platformy nie może zatrzymać produkcji bankowej. Pominięte korekty nadrabia job uzgadniający |
| C12 | Eskalacja: nieprzerywający timer boundary na user tasku + `ph:escalationLevel`, `ph:escalationReason`; propagacja do rodzica przez escalation event | Zadanie zostaje u wykonawcy, a eskalacja biegnie równolegle; oznaczenie w modelu czyni eskalację wykrywalną bez zgadywania po nazwach |
| C13 | Nie modeluj eskalacji ani odmowy jako błędu (`error event`) | Błąd BPMN zmienia przepływ i służy wyjątkom biznesowym; nadużycie miesza statystyki „błędów” z normalną ścieżką |
| C14 | Wynik biznesowy na każdym zdarzeniu końcowym: `ph:outcome` = `success` / `rejected` / `error` | Zakończenie techniczne ≠ sukces biznesowy; „wniosek odrzucony” to poprawne zakończenie, nie błąd. Incydent to osobna kategoria — błąd techniczny |
| C15 | Opcjonalny zasiew etapów: `ph:stage` na elementach | Zespół BPMN może podpowiedzieć etapy; ostateczną mapę ustala administrator procesu w aplikacji (ADR-006) |
| C16 | Autoryzacje jako kod, minimalne uprawnienia per klient techniczny; użytkownicy bez dostępu do webapp Tasklist/Operate | Platforma zastępuje Tasklist; bez odcięcia reguły R1 dałoby się obejść w natywnym UI |
| C17 | Read model ze zdarzeń / wyszukiwania przyrostowego, upsert po kluczach Camunda, znacznik czasu z zakładką | Kolejność i duplikaty są normalne; idempotentny upsert po kluczu daje „dokładnie raz” na read modelu |
| C18 | Katalog elementów budowany z XML raz na wersję definicji; XML nie trafia do UI bez `Bpmn.ViewTechnical` | Mapa etapów i wykrywanie eskalacji potrzebują typów i właściwości elementów; menadżer nie ma widzieć technikaliów |
| C19 | Instancje kończą się na swojej wersji definicji; migracja instancji tylko świadomie, z przemapowaniem etapów | Mapa etapów i formatki są per wersja; migracja bez przemapowania pokazałaby menadżerowi błędny etap |
| C20 | Idempotentne komendy (`requestId`); odpowiedź „zadanie już zakończone” przy tym samym `requestId` w dzienniku = sukces | Sieć może zerwać połączenie po przetworzeniu komendy; bez tego ponowienie dałoby błąd lub podwójny skutek |
| C21 | Reguły bpmnlint w CI (niżej) i wdrożenia tylko z pipeline'u, z jawnym tenantem | Braki w modelu (brak `ph:outcome`, brak nazwy zadania) psułyby dashboard i mapę etapów dopiero w produkcji |
| C22 | Formatki w formacie Camunda Forms prowadzi aplikacja; nie wdrażamy ich do silnika (`formId`) i nie używamy formularzy osadzonych | Prawo wdrażania zasobów obejmuje też BPMN — za szerokie dla klienta platformy; identyfikator formularza w silniku jest globalny w tenancie; wycofanie z przepięciem wymaga przypięć w aplikacji (ADR-018) |
| C23 | Wyrażenia FEEL formatek na serwerze wykonuje silnik (endpoint ewaluacji wyrażeń 8.9) za portem `IExpressionEvaluator` **[PoC, S08]** | Camunda nie waliduje danych zadania względem formularza; jeden silnik FEEL dla procesu i formatki zamiast własnej implementacji w .NET (ADR-020) |

## Przykładowy fragment BPMN

```xml
<bpmn:userTask id="OcenaWniosku" name="Ocena wniosku">
  <bpmn:extensionElements>
    <zeebe:userTask />
    <zeebe:assignmentDefinition candidateGroups="=routing.ocenaGroups" />
    <zeebe:formDefinition externalReference="ph:form/ocena-wniosku" />
    <zeebe:taskListeners>                                    <!-- [PoC, S03] typy zdarzeń dla 8.9 -->
      <zeebe:taskListener eventType="creating" type="ph.substitution" retries="3" />
      <zeebe:taskListener eventType="assigning" type="ph.substitution" retries="3" />
    </zeebe:taskListeners>
    <zeebe:properties>
      <zeebe:property name="ph:stage" value="ocena" />
      <zeebe:property name="ph:inputs" value="kwota:number,klientId:string" />
      <zeebe:property name="ph:outputs" value="decyzja:string,uzasadnienie:string" />
    </zeebe:properties>
    <zeebe:ioMapping>
      <zeebe:output source="=decyzja" target="decyzja" />
      <zeebe:output source="=uzasadnienie" target="uzasadnienie" />
    </zeebe:ioMapping>
  </bpmn:extensionElements>
</bpmn:userTask>

<bpmn:boundaryEvent id="SlaOcenyPrzekroczone" name="SLA oceny przekroczone"
                    attachedToRef="OcenaWniosku" cancelActivity="false">
  <bpmn:extensionElements>
    <zeebe:properties>
      <zeebe:property name="ph:escalationLevel" value="1" />
      <zeebe:property name="ph:escalationReason" value="Przekroczony czas oceny" />
    </zeebe:properties>
  </bpmn:extensionElements>
  <bpmn:timerEventDefinition><bpmn:timeDuration>=sla.ocena</bpmn:timeDuration></bpmn:timerEventDefinition>
</bpmn:boundaryEvent>

<bpmn:endEvent id="WniosekOdrzucony" name="Wniosek odrzucony">
  <bpmn:extensionElements>
    <zeebe:properties><zeebe:property name="ph:outcome" value="rejected" /></zeebe:properties>
  </bpmn:extensionElements>
</bpmn:endEvent>
```

## Reguły bpmnlint (własna wtyczka `bpmnlint-plugin-ph`)

| Reguła | Sprawdza |
| --- | --- |
| `ph/user-task-is-camunda` | każdy user task ma `zeebe:userTask` |
| `ph/user-task-named` | każdy user task ma nazwę (potrzebna w mapie etapów) |
| `ph/candidate-groups-expression` | `candidateGroups` to wyrażenie FEEL lub identyfikator z listy dozwolonych |
| `ph/end-event-outcome` | każde zdarzenie końcowe ma `ph:outcome` z dozwolonego zbioru |
| `ph/escalation-tagged` | nieprzerywające timery na user taskach i zdarzenia eskalacji mają `ph:escalationLevel` |
| `ph/task-contract` | user task z formatką ma `ph:outputs` |
| `ph/form-reference` | user task wskazuje formatkę wyłącznie przez `externalReference` w postaci `ph:form/<klucz>`; `formId`, `formKey` i formularze osadzone są zabronione |
| `ph/substitution-listener` | user task ma listenery `ph.substitution` (gdy proces objęty zastępstwami) |
| `ph/job-type-prefix` | typy zadań service tasków procesu profilu zaczynają się od identyfikatora profilu-właściciela (`kredyty.…`) |

## Zasilanie read modelu (ADR-010, rozstrzyga S04)

| Wariant | Opis | Kiedy |
| --- | --- | --- |
| Wyszukiwanie przyrostowe przez SDK | projektor co kilka sekund pobiera zmienione instancje, zadania, instancje elementów, incydenty (znacznik + zakładka czasowa) | start, jeden tenant, umiarkowany wolumen |
| Eksporter → Kafka → projektor | zdarzenia rekordów silnika w strumieniu | gdy opóźnienie lub obciążenie API wyszukiwania przekroczy cel NFR-04 |

Projektor jest napisany za portem `IProcessQueries`/`IEventFeed`, więc zmiana wariantu nie dotyka kontekstów rdzenia.
