# 01. Wymagania

Każde FR ma scenariusze w `specs/`; identyfikator FR pojawia się w tagu scenariusza (`@FR-11`), dzięki czemu raport Reqnroll jest macierzą śledzenia.

## Funkcjonalne

| ID | Wymaganie | Rola | Specyfikacja |
| --- | --- | --- | --- |
| FR-01 | „Moje zadania”: zadania, w których jestem assignee | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-02 | „Do przejęcia”: nieprzypisane zadania moich grup kandydujących | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-03 | Stan zadań moich grup (także przypisanych innym), tylko odczyt | Uczestnik | `access/visibility.feature` |
| FR-04 | Przejęcie tylko przez członka grupy kandydującej; wyścig rozstrzyga silnik | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-05 | Zwolnienie tylko przez assignee | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-06 | Edycja szkicu i zakończenie tylko przez assignee, walidacja wg przypiętej wersji formatki | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-07 | Start procesu z aplikacji z formatką startową, gdy mam uprawnienie startu dla definicji | Uczestnik | `processes/start-process.feature` |
| FR-08 | „Moje procesy”: wystartowane przeze mnie, z bieżącym etapem | Inicjator | `processes/start-process.feature` |
| FR-09 | Wiele ról jednocześnie; uprawnienia sumują się w zakresach; audyt zapisuje rolę uzasadniającą akcję | każda | `access/visibility.feature` |
| FR-10 | Menadżer procesu widzi wszystkie instancje i zadania procesów ze swojego zakresu | Menadżer procesu | `access/visibility.feature` |
| FR-11 | Przekazanie zadania osobie lub grupie w trakcie procesu, z obowiązkowym uzasadnieniem; pojedynczo i masowo | Menadżer procesu | `tasks/reassignment.feature` |
| FR-12 | Zastępstwa: nieobecność od–do z zastępcą; nowe zadania trafiają do zastępcy | Menadżer procesu, Uczestnik | `tasks/substitution.feature` |
| FR-13 | Lista procesów eskalowanych: poziom, od kiedy, etap, osoba | Menadżer procesu | `insight/escalations.feature` |
| FR-14 | Dashboard: wystartowane, zakończone sukcesem, negatywnie, błędem, aktywne, z incydentem; metryki; progi zdrowia | Menadżer procesu | `insight/process-dashboard.feature` |
| FR-15 | Mapa etapów: definiowanie etapów i przypisanie elementów BPMN, wersjonowanie per wersja definicji | Administrator procesu, Menadżer procesu | `insight/stage-map.feature` |
| FR-16 | Przy formatce i przy instancji widać mapę etapów z zaznaczonym etapem i stanem, bez technikaliów BPMN | Menadżer procesu | `insight/stage-map.feature` |
| FR-17 | Formatki tworzy i edytuje menadżer lub administrator procesu; zatwierdza inna osoba (R8); publikacja nadaje numer wersji | Menadżer, Administrator procesu | `forms/form-lifecycle.feature` |
| FR-18 | Zadanie renderuje wersję formatki przypiętą przy jego utworzeniu; przypięcie zmienia wyłącznie wycofanie wersji z przepięciem (FR-30) | Uczestnik | `forms/form-lifecycle.feature` |
| FR-19 | Audytor: wgląd tylko do odczytu we wszystkie procesy, zadania, historię i dziennik | Audytor | `access/visibility.feature` |
| FR-20 | Każda akcja zapisana w bazie: dziennik bezpieczeństwa i ślad diagnostyczny | system | `audit/audit.feature` |
| FR-21 | Uprawnienia jako kod: role, uprawnienia, przypisania do grup AD, uzgadnianie z Camunda | Administrator platformy | `access/authorization-as-code.feature` |
| FR-22 | Zapisane widoki list i preferencje UI | każda | — (v1, bez zmian) |
| FR-23 | Profil projektu: rejestracja z manifestu, procesy z jednym właścicielem, walidacja kontraktu | Administrator platformy, zespół profilu | `profiles/project-profiles.feature` |
| FR-24 | Role projektowe: złożenie ról platformy i uprawnień projektu, tylko w procesach profilu, rola uzasadniająca w audycie | Uczestnik, Menadżer procesu | `profiles/project-profiles.feature` |
| FR-25 | Operacje dedykowane profilu (na zadaniu, sprawie i danych profilu) w `allowedActions`, wykonywane przez potok platformy (uprawnienie, R1 dla zadań, R9, audyt, idempotencja) | Uczestnik, rola projektowa | `profiles/project-profiles.feature`, `profiles/flota/specs/katalog-samochodow.feature` |
| FR-26 | Dane projektu we własnym schemacie; wzbogacenie widoku zadania tylko w procesach profilu | Uczestnik | `profiles/project-profiles.feature` |
| FR-27 | Rozszerzenia UI profilu w slotach (panel zadania i sprawy, widżet, pole formatki, sekcja nawigacji, trasy `/p/<id>/`), widoczne tylko dla ról profilu | każda | `profiles/project-profiles.feature`, `profiles/flota/specs/katalog-samochodow.feature` |
| FR-28 | Formatki w formacie Camunda Forms: projektant z edytorem biblioteki form-js (jak w Modelerze), tylko elementy z katalogu pól, import i eksport plików `.form` | Menadżer, Administrator procesu | `forms/form-designer.feature` |
| FR-29 | Wersje formatki: historia zmian szkicu, numerowane wersje opublikowane, porównanie wersji, nowa wersja z dowolnej wcześniejszej | Menadżer, Administrator procesu | `forms/form-versioning.feature` |
| FR-30 | Wycofanie wersji albo całej formatki z obowiązkowym powodem, wersją zastępczą i wyborem skutku dla zadań w toku (pozostają albo są przepinane) | Menadżer, Administrator procesu | `forms/form-withdrawal.feature` |
| FR-31 | Separacja formatek: formatka należy do jednego procesu, jest widoczna i zarządzana tylko w jego zakresie, a zadanie renderuje wyłącznie formatkę własnego procesu (R11) | Menadżer, Administrator procesu, Uczestnik | `forms/form-isolation.feature` |
| FR-32 | Materializacja: formatkę renderują komponenty design systemu według katalogu pól; schemat nie niesie wyglądu; dane zadania są walidowane na serwerze według przypiętej wersji | Uczestnik | `forms/form-rendering.feature` |

Opis działania modułu formatek (FR-06, FR-07, FR-16–FR-18, FR-28–FR-32): `14-form-management.md`.

## Niefunkcjonalne

| ID | Wymaganie |
| --- | --- |
| NFR-01 | Deny by default; dwa poziomy autoryzacji (L1 Camunda, L2 aplikacja); OWASP ASVS L2 |
| NFR-02 | 100% żądań w śladzie operacyjnym, 100% komend i odczytów wrażliwych w dzienniku bezpieczeństwa; test kompletności audytu w CI |
| NFR-03 | Gotowość multi-tenant: `TenantId` w każdym agregacie, zapytaniu i wpisie audytu; włączenie kolejnego tenanta bez zmian w kodzie domeny |
| NFR-04 | Opóźnienie read modelu — cel do ustalenia w S04 (propozycja: P95 ≤ 5 s); dashboard pokazuje aktualną świeżość danych |
| NFR-05 | Listy i dashboard — cel do ustalenia (propozycja: P95 ≤ 500 ms przy danych z pilotażu) |
| NFR-06 | Niedostępność Camunda → tryb tylko do odczytu z read modelu, czytelny komunikat |
| NFR-07 | Awaria platformy nie zatrzymuje silnika: task listener zastępstw działa w trybie fail-open (ADR-007) |
| NFR-08 | WCAG 2.2 AA minimum; cele AAA wg `design/README.md` (kontrast tekstu, cele dotykowe, fokus) |
| NFR-09 | RODO: w audycie skróty i listy pól zamiast wartości PII; retencja wg compliance |
| NFR-10 | OpenTelemetry; `traceId` w każdym wpisie audytu i logu |
| NFR-11 | Separacja profili: kod profilu zależy tylko od SDK rozszerzeń; testy architektury, granice Nx, `CODEOWNERS` i strażnik zapisu w CI; schemat i użytkownik bazy per profil |
| NFR-12 | Zgodność SDK rozszerzeń: wersjonowanie semantyczne, zmiana niezgodna tylko w wersji głównej z okresem przejściowym ≥ 2 wersji pomocniczych; testy zgodności dla każdego profilu |
| NFR-13 | Awaria lub przekroczenie czasu operacji profilu nie blokuje pracy na zadaniu (propozycja limitu: 5 s dla operacji, 1 s dla wzbogacenia) |
| NFR-14 | Zgodność z Camunda Forms: każda opublikowana formatka jest poprawnym plikiem `.form` (oficjalny schemat formatu); zestaw zgodności porównuje w CI zachowanie renderera platformy z biblioteką form-js |
| NFR-15 | Spójność wizualna: komponenty UI używają wyłącznie tokenów z `design/tokens.json`; każdy typ z katalogu pól ma jeden komponent; regresja wizualna i axe-core dla katalogu komponentów w CI |
