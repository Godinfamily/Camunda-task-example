# 08. Dashboard menadżera procesu i eskalacje

Dashboard odpowiada na pytanie „czy z moim procesem wszystko w porządku” w jednym spojrzeniu: liczniki wyników, metryki przepływu i sygnalizacja zdrowia wg progów, które menadżer ustawia sam.

## Filtry

Proces (`bpmnProcessId`) z zakresu użytkownika · wersja definicji (domyślnie wszystkie) · okres (domyślnie 30 dni) · etap. Każdy widok pokazuje świeżość danych („dane sprzed N s”) z opóźnienia projektora.

## Liczniki wyników

| Licznik | Definicja |
| --- | --- |
| Wystartowane | instancje z datą startu w okresie |
| Zakończone sukcesem | zakończone w okresie na zdarzeniu `ph:outcome=success` |
| Zakończone negatywnie | `ph:outcome=rejected` — poprawne zakończenie, decyzja odmowna |
| Zakończone błędem | `ph:outcome=error` lub anulowane (D-06: czy anulowanie liczyć jako błąd) |
| Aktywne | trwające na koniec okresu |
| Z incydentem | aktywne z nierozwiązanym incydentem (błąd techniczny) |
| Eskalowane | aktywne z aktywną eskalacją |

## Metryki

| Metryka | Definicja | Uwagi |
| --- | --- | --- |
| Czas realizacji P50/P90 | koniec − start, instancje zakończone w okresie | `APPROX_PERCENTILE_CONT` w SQL Server 2022 dla dużych zbiorów |
| Czas na etapie P50/P90 | suma odwiedzin elementów etapu | wymaga opublikowanej mapy etapów |
| Przepustowość | zakończone / dzień | trend tygodniowy |
| Praca w toku i wiek | liczba aktywnych; najstarsza; rozkład wieku | |
| Naruszenia SLA | % zadań/etapów po celu SLA | cele z mapy etapów lub `dueDate` |
| Wskaźnik eskalacji | instancje eskalowane / wystartowane | |
| Wskaźnik incydentów | instancje z incydentem / wystartowane | |
| Oczekiwanie vs praca | utworzenie → przejęcie vs przejęcie → zakończenie | rozróżnia brak ludzi od trudności zadania |
| Przekazania | przekazania / zadanie | sygnał przeciążenia lub nieobecności |

Nowa metryka = implementacja `IProcessMetric` (definicja, zapytanie, kierunek „lepiej, gdy mniej/więcej”) — bez zmian w dashboardzie (OCP).

## Progi zdrowia

`ProcessHealthPolicy` per proces: dla każdej metryki progi `zielony / bursztynowy / czerwony` i kierunek. Status procesu = najgorszy status metryk oznaczonych jako kluczowe. Zmiana progów to komenda audytowana. Bez ustawionych progów metryka jest pokazywana bez koloru — nie zgadujemy norm za biznes.

## Eskalacje

- Wykrywanie: aktywacja elementu z `ph:escalationLevel` albo zdarzenia eskalacji (z katalogu elementów, C12) tworzy `EscalationRecord` (instancja, element, poziom, powód, od kiedy, zakres).
- Eskalacja jest aktywna, dopóki trwa jej zakres: dla timera na user tasku — dopóki zadanie nie zostanie zakończone lub anulowane; dla podprocesu zdarzeń — do jego zakończenia.
- Naruszenie SLA liczone przez aplikację (bez modelowania w BPMN) to osobna kategoria „po terminie”, pokazywana obok.
- Lista „Eskalowane”: proces, sprawa (`caseId`), etap, poziom, od kiedy, osoba lub grupa, akcja „Przekaż”.

## Źródło danych

- `insight.ProcessInstanceView`, `insight.ElementVisit`, `insight.EscalationRecord` z projektora.
- `insight.ProcessStatsDaily` — agregaty przyrostowe (rola `jobs`), z których dashboard czyta liczniki; percentyle liczone na żądanie dla okresu z indeksem kolumnowym na `ElementVisit`.
- Camunda Optimize mógłby dostarczyć analitykę, ale nie zna mapy etapów ani naszego modelu uprawnień — dlatego metryki liczymy sami; Optimize można rozważyć później dla analityków procesowych.
