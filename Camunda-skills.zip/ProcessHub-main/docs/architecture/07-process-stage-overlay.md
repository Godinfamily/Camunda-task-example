# 07. Mapa etapów — warstwa biznesowa nad BPMN

Menadżer procesu widzi etapy, nie BPMN: administrator procesu przypisuje elementy modelu do nazwanych etapów, a aplikacja liczy z historii instancji, na którym etapie jest sprawa. To odpowiedź na pytanie „jak dużo menadżer widzi” — tyle, ile opisuje mapa etapów, i nic poza nią.

## Poziomy wglądu

| Poziom | Kto | Co widzi | Czego nie widzi |
| --- | --- | --- | --- |
| Mapa etapów | menadżer procesu, inicjator („moje procesy”), audytor | nazwane etapy, bieżący etap, czasy, eskalacje, incydent jako „wstrzymane — zgłoszono do wsparcia” | XML, identyfikatory i nazwy elementów niezmapowanych, zmienne spoza formatek |
| Techniczny | administrator procesu (`Bpmn.ViewTechnical`) | diagram BPMN tylko do odczytu, pozycje tokenów, nakładka mapowania | — |

Rekomendacja: menadżer nie dostaje diagramu BPMN. Jeśli w organizacji menadżer ma sam mapować elementy, nadajemy mu `StageMap.MapElements` w `roles.yaml` — to decyzja konfiguracyjna, nie zmiana kodu (D-03 w `plan/execution-plan.md`).

## Przykład: technika kontra etapy

```mermaid
flowchart LR
    subgraph BPMN[Model techniczny — widzi administrator procesu]
      S((start)) --> A[Weryfikuj dane<br/>service task] --> B[Ocena wniosku<br/>user task] --> G{decyzja}
      G --> C[Wylicz ofertę<br/>service task] --> D[Akceptacja klienta<br/>user task] --> E((sukces))
      G --> R((odrzucony))
    end
    subgraph MAP[Mapa etapów — widzi menadżer]
      E1[1. Rejestracja] --> E2[2. Ocena] --> E3[3. Oferta] --> E4[4. Zakończenie]
    end
    A -.-> E1
    B -.-> E2
    C -.-> E3
    D -.-> E3
    E -.-> E4
    R -.-> E4
```

## Cykl edycji

1. **Nowa wersja definicji** (wdrożenie z pipeline'u) → `CamundaIntegration` buduje katalog elementów z XML (C18).
2. **Szkic mapy** powstaje automatycznie: przeniesienie z poprzedniej wersji po `elementId` albo zasiew z `ph:stage`. Raport różnic: elementy nowe (niezmapowane), usunięte, zmienione typy.
3. **Administrator procesu** mapuje elementy w edytorze: lista elementów pogrupowana po typie (user taski na górze) + diagram bpmn-js tylko do odczytu z podświetleniem zaznaczenia.
4. **Menadżer procesu** nadaje nazwy, kolejność, opisy i cele SLA etapów (`StageMap.Edit`).
5. **Walidacja:** każdy user task zmapowany (błąd); każde zdarzenie końcowe zmapowane (ostrzeżenie); co najmniej jeden etap; brak elementu w dwóch etapach.
6. **Publikacja** wersji mapy (audyt, wersja niezmienna). Dotyczy instancji danej wersji definicji — także już trwających, bo mapa jest prezentacją, a stan liczony jest z historii.

## Stan etapu instancji (algorytm)

Wejście: historia instancji elementów (`ElementVisit`: elementId, start, koniec, incydent), aktywne eskalacje, opublikowana mapa dla wersji definicji instancji.

| Stan etapu | Warunek |
| --- | --- |
| `Active` | co najmniej jeden element etapu jest aktywny |
| `Completed` | elementy etapu były odwiedzone, żaden nie jest aktywny |
| `Pending` | żaden element etapu nie był odwiedzony, instancja trwa |
| `Skipped` | instancja zakończona lub minęła etap, a etap nie był odwiedzony |
| flaga `Escalated` | aktywna eskalacja na elemencie etapu |
| flaga `Blocked` | incydent na aktywnym elemencie etapu |

Przypadki brzegowe:
- **Równoległość** (bramka równoległa): kilka etapów może być `Active` naraz — UI pokazuje wszystkie.
- **Pętle**: ponowne wejście zmienia `Completed` → `Active`; historia pokazuje wszystkie wejścia.
- **Call activity**: domyślnie etap rodzica obejmuje całe wywołanie; opcjonalnie rozwinięcie do mapy procesu podrzędnego (ten sam mechanizm, osobna mapa).
- **Aktywny element niezmapowany**: instancja pokazuje ostatni znany etap z adnotacją „w toku”; nazwa elementu nie jest ujawniana.

## Gdzie mapa jest używana

- **Instancja**: pasek etapów (Kendo Stepper) z czasami wejścia/wyjścia, eskalacją, blokadą.
- **Dashboard**: liczba aktywnych instancji na etapie i czas na etapie (P50/P90) — wąskie gardła.
- **Formatka**: edytor i podgląd formatki pokazują mapę z zaznaczonym etapem, do którego należy zadanie tej formatki, oraz liczbę zadań aktualnie czekających na tym kroku (FR-16).

## Przykład zapisu wersji mapy

```json
{
  "bpmnProcessId": "wniosek-kredytowy",
  "tenantId": "<default>",
  "version": 3,
  "forDefinitionVersions": [7],
  "status": "Published",
  "stages": [
    { "id": "rejestracja", "order": 1, "name": "Rejestracja", "slaTarget": "PT4H" },
    { "id": "ocena", "order": 2, "name": "Ocena", "slaTarget": "P2D" },
    { "id": "oferta", "order": 3, "name": "Oferta", "slaTarget": "P3D" },
    { "id": "zakonczenie", "order": 4, "name": "Zakończenie" }
  ],
  "mappings": [
    { "elementId": "WeryfikujDane", "stageId": "rejestracja" },
    { "elementId": "OcenaWniosku", "stageId": "ocena" },
    { "elementId": "WyliczOferte", "stageId": "oferta" },
    { "elementId": "AkceptacjaKlienta", "stageId": "oferta" },
    { "elementId": "WniosekZaakceptowany", "stageId": "zakonczenie" },
    { "elementId": "WniosekOdrzucony", "stageId": "zakonczenie" }
  ]
}
```
