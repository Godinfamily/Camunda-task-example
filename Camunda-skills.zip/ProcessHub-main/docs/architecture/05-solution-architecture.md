# 05. Architektura rozwiązania

Jeden obraz kontenera .NET uruchamiany w czterech rolach; przeglądarka zna tylko Host, a Camunda — tylko moduł `CamundaIntegration` korzystający z oficjalnego SDK.

## Kontenery

```mermaid
flowchart LR
    U[Przeglądarka] -->|HTTPS + cookie __Host-| SPA[SPA Angular / nginx]
    SPA -->|/api| API
    subgraph HOST[Host .NET 10 — jeden obraz]
      API[rola api<br/>BFF, komendy, zapytania]
      PRJ[rola projector<br/>zdarzenia → read model]
      JOBS[rola jobs<br/>outbox, uzgadnianie, statystyki, reconciler]
      WRK[rola worker<br/>task listenery: zastępstwa]
    end
    API -->|OIDC| RHBK[(RHBK)]
    API -->|oficjalne SDK: komendy| CAM[(Camunda 8.9)]
    PRJ -->|oficjalne SDK: wyszukiwanie / strumień| CAM
    WRK -->|oficjalne SDK: job worker| CAM
    JOBS -->|oficjalne SDK: autoryzacje| CAM
    API --> DB[(MS SQL Server)]
    PRJ --> DB
    JOBS --> DB
    WRK --> DB
    API -->|operacje profili remote: mTLS + token platformy| PSV[Usługi profili remote<br/>np. AML]
    PWK[Workery profili<br/>typy zadań id.*] -->|job worker| CAM
```

Moduły profili `in-process` działają wewnątrz hosta (Extension Host ładuje je z rejestru manifestów przy starcie roli `api` i `jobs`). Usługi profili `remote` i workery profili wdraża zespół profilu; platforma nie zależy od nich przy starcie.

| Rola | Klient Camunda (minimalne uprawnienia) | Skalowanie |
| --- | --- | --- |
| `api` | delegowany token użytkownika lub `ph-api` (ADR-004); `ph-api` ma dodatkowo ewaluację wyrażeń (ADR-020) | HPA po żądaniach |
| `projector` | `ph-projector`: tylko odczyt na `*` | 1 aktywna instancja na partycję strumienia (lease w MSSQL) |
| `jobs` | `ph-reconciler`: zarządzanie autoryzacjami; reszta bez Camunda | 1 aktywna instancja na zadanie cykliczne (lease) |
| `worker` | `ph-worker`: aktywacja jobów typu `ph.substitution` | ≥ 2 repliki (task listener blokuje tworzenie zadania) |

**Dlaczego osobna rola `worker`.** Task listener wstrzymuje przejście stanu zadania w silniku do czasu obsługi joba. Worker musi być dostępny i szybki niezależnie od obciążenia API, więc ma własne repliki i własny klient o najmniejszych możliwych uprawnieniach.

## Układ rozwiązania

```
ProcessHub.sln
├── src/
│   ├── ProcessHub.Host/                        composition root, role (api|projector|jobs|worker), middleware śladu
│   ├── BuildingBlocks/
│   │   ├── ProcessHub.SharedKernel/            TenantId, PartyId, Result<T>, Permission (enum)
│   │   ├── ProcessHub.Application/             ICommand, IQuery, potok (behaviors), Actor, ITenantContext
│   │   └── ProcessHub.Infrastructure/          outbox, inbox, lease, interceptor RLS, EF Core bazowe
│   └── Modules/
│       ├── TaskWork/{Domain,Application,Infrastructure,Api,Contracts}
│       ├── ProcessLifecycle/…
│       ├── ProcessInsight/…
│       ├── FormManagement/…
│       ├── FormRuntime/…
│       ├── PartyAccountability/…
│       ├── AccessPolicy/…
│       ├── Audit/…
│       ├── PlatformAdministration/…
│       ├── UserPreferences/…
│       ├── ExtensionHost/…                     rejestr profili, potok operacji, wzbogacenia, sloty, zdarzenia (R9)
│       └── CamundaIntegration/{Application,Infrastructure.Sdk,Contracts}   jedyny moduł z referencją do SDK
│   └── Platform/
│       ├── ProcessHub.Extensibility/           SDK rozszerzeń (paczka NuGet, semver) — jedyna zależność profili
│       └── ProcessHub.Extensibility.Testing/   host testowy w pamięci i testy zgodności dla zespołów profili
├── tests/
│   ├── <Moduł>.UnitTests
│   ├── <Moduł>.Specs                          Reqnroll: kroki + drivery (in-memory i integracyjny)
│   ├── CamundaIntegration.ContractTests        ten sam zestaw na fake i na Camunda w Testcontainers
│   └── ProcessHub.ArchitectureTests
├── frontend/                                   Nx workspace (apps/process-hub, libs/platform/…, libs/platform/extension-sdk)
├── bpmn/                                       procesy przykładowe + reguły bpmnlint
├── config/authorization/                       autoryzacje jako kod (role platformy, role globalne)
└── profiles/<id>/                              profile projektów: manifest, backend, frontend, db, bpmn, workers, specs (własność zespołów)
```

## Potok komend i zapytań

Kolejność jest kontraktem testowanym w testach architektury:

1. **Ślad operacyjny** (middleware HTTP, każde żądanie, także odrzucone przed potokiem).
2. Walidacja wejścia.
3. Autoryzacja: `IAccessPolicy` → `AccessDecision` (z `GrantedBy`).
4. Audyt bezpieczeństwa: `Intent` przed wykonaniem, `Outcome` po nim.
5. Idempotencja po `requestId` (nagłówek `Idempotency-Key`).
6. Transakcja: Unit of Work + outbox w jednej transakcji.
7. Handler.

Zapytania: ślad → autoryzacja i specyfikacja widoczności → audyt odczytu (`[AuditedRead]`) → handler na read modelu.

Dispatcher: generowany źródłowo (np. biblioteka `Mediator`) lub własny — bez komercyjnych wersji MediatR.

## Porty modułu `CamundaIntegration` (ISP)

| Port | Operacje |
| --- | --- |
| `IUserTaskCommands` | `AssignAsync(key, user, allowOverride)`, `UnassignAsync`, `UpdateCandidatesAsync`, `CompleteAsync(key, variables)` |
| `IProcessStarter` | `StartAsync(bpmnProcessId, variables, tenantId)` |
| `IProcessQueries` | wyszukiwanie instancji, zadań, instancji elementów, incydentów (dla projektora i uzgadniania) |
| `IDefinitionCatalog` | pobranie XML wersji definicji i zbudowanie katalogu elementów (nazwa, typ, zdarzenie, `zeebe:properties`) |
| `IAuthorizationAdmin` | wyszukiwanie i zmiana grup, ról, reguł mapowania, autoryzacji (tylko reconciler) |
| `ITaskListenerHost` | rejestracja workera typu `ph.substitution` z korektami assignee/grup |
| `IExpressionEvaluator` | ewaluacja i sprawdzenie składni wyrażeń FEEL formatek silnikiem Camunda (ADR-020) **[PoC, S08]** |

Każdy port ma implementację na SDK i fake in-memory; testy kontraktowe uruchamiają ten sam zestaw na obu (dowód podstawialności — LSP).

## SOLID w praktyce

- **S** — jeden handler na komendę; inwarianty w agregatach; modele odczytu oddzielone od zapisu.
- **O** — nowe uprawnienie to wpis enuma i YAML; nowy typ pola formatki to wpis w katalogu pól i implementacja `IFieldType` (walidacja) oraz komponent w `core/ui-kit` (wygląd); nowa metryka dashboardu to implementacja `IProcessMetric`.
- **L** — fake i adapter SDK przechodzą te same testy kontraktowe.
- **I** — wąskie porty zamiast jednego „CamundaClient”.
- **D** — domena i aplikacja zależą od portów własnego modułu; adaptery wiąże tylko Host.

## Testy architektury (CI)

- Tylko `CamundaIntegration.Infrastructure.Sdk` referuje paczkę SDK Camunda.
- Moduł nie referuje wnętrza innego modułu (tylko `*.Contracts`).
- `Domain` nie zna EF Core, HTTP ani SDK.
- Każdy endpoint ma politykę autoryzacji i przechodzi przez potok; każda komenda ma deskryptor audytu.
- Kod nie porównuje nazw ról (`"Manager"`, `"Admin"`) — tylko `Permission`.
- Każda komenda i każde zapytanie modułu `FormManagement` przyjmuje zakres procesu (`TenantId`, `BpmnProcessId`); typy z katalogu pól mają po jednej implementacji `IFieldType` (parytet z `design/forms/field-catalog.yaml`).
- Zestawy profili (`profiles/*/backend/**`) referują tylko `ProcessHub.Extensibility` i paczki z listy dozwolonej; nie referują `ProcessHub.Modules.*`, `BuildingBlocks` ani innych profili.
- Platforma nie referuje żadnego zestawu z `profiles/` (kompozycja tylko przez rejestr manifestów).
- Każda klasa oznaczona `[ProfileOperation]` ma odpowiednik w `operations` manifestu; nazwa przestrzeni nazw .NET zawiera identyfikator profilu.
