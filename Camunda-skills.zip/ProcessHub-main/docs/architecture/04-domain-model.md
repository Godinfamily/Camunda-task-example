# 04. Archetypy i model domeny

Model opiera się na archetypie Party (kto), Knowledge Level (co wolno i jak wygląda proces z perspektywy biznesu) i Journal (co się stało). Dzięki temu nowe role, etapy czy progi to dane, a nie zmiany w kodzie.

## Zastosowane archetypy i wzorce

| Archetyp / wzorzec | Gdzie | Co daje |
| --- | --- | --- |
| Party, PartyRole (Arlow, Neustadt) | Party & Accountability | Osoba z identyfikatorem AD; role grane w zakresie (`RoleAssignment`) |
| Accountability + Effectivity (Fowler) | Party | `Absence` (zastępstwo od–do), przypisania z okresem ważności, zapytania „na dzień” |
| Knowledge Level | Access, Insight, Forms | `Role → Permission`, `StageMap` (wiedza o definicji procesu), `FormDefinition` (typ) ↔ szkic w `WorkItem` (instancja) |
| Rule | Insight, Forms | Progi zdrowia; reguły walidacji i widoczności pól jako dane w schemacie Camunda Forms (wyrażenia FEEL) |
| Journal | Audit | Wpisy tylko dopisywane; korekta = wpis kompensujący |
| Specification | Access Policy | Reguły R1–R11 jako składane specyfikacje, testowalne bez bazy |
| Process Manager / Saga | Task Work | `ReassignmentBatch` — masowe przekazanie z trwałym stanem i wznowieniem |
| State | Forms, StageMap | Mapa etapów: `Draft → InReview → Published → Deprecated`; wersja formatki: `Draft → InReview → Approved → Published → Superseded / Withdrawn` |

## Agregaty i inwarianty

**`WorkItem`** (Task Work) — lokalny obraz zadania Camunda + szkic.
- `Claim(actor)`: R2; `Unclaim(actor)`, `SaveDraft`, `Complete`: R1.
- `Reassign(actor, target, reason)`: `Task.Reassign` w zakresie, kod powodu obowiązkowy, `target` uprawniony (R6), `target ≠ assignee`. Szkic przechodzi z zadaniem (decyzja D-05), zdarzenie zapisuje poprzedniego i nowego wykonawcę.
- `ChangeCandidateGroups(actor, groups, reason)`: zbiór niepusty, każda grupa uprawniona w zakresie; jeśli zadanie było przypisane — najpierw zwolnienie.
- `FormVersion` przypięta przy utworzeniu; zmienia ją wyłącznie przepięcie przy wycofaniu wersji (`Form.Repin`), zawsze w obrębie formatek tego samego procesu (R11).

**`ReassignmentBatch`** (Task Work) — `Start(actor, selection, target, reason)`, pozycje ze stanem `Pending/Done/Failed/Skipped`, idempotencja `batchId + taskKey`, wznawianie po awarii. Każda pozycja to osobna komenda `Reassign` (te same inwarianty i audyt).

**`Absence`** (Party) — `from < to`; zastępca ≠ nieobecny; brak nakładających się nieobecności tej samej osoby w tym samym zakresie; zastępca uprawniony w zakresie procesów.

**`StageMap`** (Process Insight) — dla `BpmnProcessId`, wersjonowana per wersja definicji.
- Element BPMN należy do co najwyżej jednego etapu; elementy spoza mapy są „techniczne” i niewidoczne dla menadżera.
- Kolejność etapów unikalna; nazwa etapu niepusta.
- Mapować można tylko elementy istniejące w danej wersji definicji (z katalogu elementów).
- Wersja `Published` jest niezmienna; każda zmiana tworzy nową wersję.

**`FormDefinition`** (Form Management) — formatka jednego procesu: tożsamość `(TenantId, BpmnProcessId, FormKey)`, zastosowanie (`Task` albo `ProcessStart`), wersje w formacie Camunda Forms. Pełny model, stany i komendy: `14-form-management.md`.
- Najwyżej jedna wersja robocza (`Draft`, `InReview`, `Approved`) i jedna obowiązująca (`Published`).
- `Approve` przez osobę ≠ autor ostatniej zmiany (R8); zatwierdzenie dotyczy skrótu treści.
- `Publish` wymaga zatwierdzenia, zgodności z katalogiem pól i z kontraktem danych zadania; nadaje kolejny numer; wersje opublikowane są niezmienne.
- `Withdraw` wymaga powodu; wersja zastępcza musi być wcześniej opublikowana i zgodna z kontraktem; zadania w toku pozostają albo są przepinane.
- Żadna operacja nie łączy formatek dwóch procesów (R11).

**`ProcessHealthPolicy`** (Process Insight) — progi `green/amber/red` per metryka; progi monotoniczne (np. `amber ≤ red` dla metryk „im mniej, tym lepiej”).

**`RoleAssignment`, `Role`** (Party/Access, ładowane z YAML) — rola `readOnly` bez uprawnień zapisu; konflikty rozdziału obowiązków odrzucane.

## Cykl życia zadania (lokalny obraz)

```mermaid
stateDiagram-v2
    [*] --> Open: utworzone w Camunda
    Open --> Assigned: Claim (R2) / Reassign / korekta zastępstwa
    Assigned --> Open: Unclaim (R1) / ChangeCandidateGroups
    Assigned --> Assigned: Reassign (menadżer, R6) / SaveDraft (R1)
    Assigned --> CompletionRequested: Complete (R1 + walidacja formatki)
    CompletionRequested --> Completed: potwierdzenie z silnika
    CompletionRequested --> Assigned: odrzucenie przez silnik
    Open --> Canceled: instancja anulowana / ścieżka zamknięta
    Assigned --> Canceled
    Completed --> [*]
    Canceled --> [*]
```

## Model mapy etapów

```mermaid
classDiagram
    class StageMap {
      BpmnProcessId
      TenantId
    }
    class StageMapVersion {
      Version
      ForDefinitionVersions
      Status
    }
    class Stage {
      StageId
      Order
      Name
      SlaTarget
    }
    class ElementMapping {
      ElementId
      StageId
    }
    class ElementCatalogEntry {
      ElementId
      Name
      Type
      Properties
    }
    StageMap "1" *-- "*" StageMapVersion
    StageMapVersion "1" *-- "*" Stage
    StageMapVersion "1" *-- "*" ElementMapping
    ElementMapping "*" --> "1" ElementCatalogEntry : tylko elementy z wersji
```

## Przykład kodu — przekazanie w agregacie

```csharp
public Result Reassign(Actor actor, PartyId target, ReassignReason reason, IReassignTargetPolicy targets)
{
    if (Status is not (WorkItemStatus.Open or WorkItemStatus.Assigned)) return Result.Fail(Rule.TaskNotActive);
    if (!actor.Has(Permission.TaskReassign, Scope)) return Result.Fail(Rule.R6NoPermission);
    if (reason.IsEmpty) return Result.Fail(Rule.R6ReasonRequired);
    if (Assignee == target) return Result.Fail(Rule.SameAssignee);
    if (!targets.CanWorkOn(target, Scope)) return Result.Fail(Rule.R6TargetNotEligible);

    var previous = Assignee;
    Assignee = target;
    Status = WorkItemStatus.Assigned;
    Raise(new WorkItemReassigned(Id, Tenant, previous, target, actor.PartyId, reason, DraftTransferred: Draft is not null));
    return Result.Ok();
}
```

Agregat nie woła Camunda. Handler najpierw zapisuje audyt `Intent`, potem woła bramę (`assignment` z `allowOverride: true`), a stan i `Outcome` zatwierdza dopiero po sukcesie silnika.
