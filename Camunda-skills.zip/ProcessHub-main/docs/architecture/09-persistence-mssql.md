# 09. Persystencja — MS SQL Server 2022+

Jedna baza, schemat i `DbContext` per moduł. Izolację tenantów wymusza baza (RLS), niezmienność dziennika — tabela Ledger, a retencję śladu operacyjnego — partycje; żadna z tych gwarancji nie zależy od dyscypliny w kodzie.

| Schemat | Moduł | Tabele kluczowe |
| --- | --- | --- |
| `party` | Party & Accountability | `Party`, `GroupMembershipSnapshot`, `Absence` (temporal) |
| `access` | Access Policy | `TaskAccess` (materializacja widoczności), `EffectivePermissionCache` |
| `task` | Task Work | `WorkItem` (z przypięciem wersji formatki), `ReassignmentBatch`, `ReassignmentBatchItem`, `TaskView`, `FormPinHistory` |
| `process` | Process Lifecycle | `ProcessStartRequest`, `MyProcessView` |
| `insight` | Process Insight | `ElementCatalog`, `StageMap*` (temporal), `ProcessInstanceView`, `ElementVisit`, `EscalationRecord`, `ProcessStatsDaily`, `ProcessHealthPolicy` |
| `form` | Form Management | `FormDefinition`, `FormVersion` (temporal — rewizje szkicu; schemat Camunda Forms jako JSON), `FormReview`, `FormWithdrawal`, `FormRepinBatch`, `FormRepinItem` |
| `audit` | Audit | `SecurityJournal` (Ledger append-only), `OperationTrace` (partycjonowana) |
| `integration` | Camunda Integration | `Inbox`, `ProcessedRequest`, `FeedWatermark`, `Lease` |
| `admin` | Platform Administration | `AuthorizationApplyLog`, `DriftReport` |
| `prefs` | User Preferences | `SavedListView`, `UiSettings` |
| `ext` | Extension Host | `ProfileRegistration`, `ProfileProcess` (który proces należy do którego profilu), `OperationRequest` (idempotencja operacji profili) |
| `platform_api` | widoki dla profili | `Tasks`, `ProcessInstances`, `StageStates` — tylko odczyt, RLS do procesów profilu |
| `prj_<id>` | profil projektu | tabele zespołu profilu (np. `prj_kredyty.ScoringResult`); użytkownik bazy `prj_<id>` bez loginu |

## Rozwiązania i powody

- **RLS po tenancie.** Funkcja `security.fn_TenantPredicate(@TenantId)` porównuje wiersz z `SESSION_CONTEXT(N'TenantIds')`. Interceptor EF Core (`DbConnectionInterceptor`) ustawia wartość przy otwarciu połączenia przez `sp_set_session_context ... @read_only = 1`. Predykaty `FILTER` oraz `BLOCK AFTER INSERT/UPDATE`. Dziś jedna wartość `<default>` — dodanie tenanta nie zmienia zapytań (NFR-03).
- **Widoczność wewnątrz tenanta** nie jest robiona przez RLS, tylko przez `access.TaskAccess(TenantId, TaskKey, PrincipalKind, PrincipalId, AccessLevel)`: zapytanie łączy zadania z moimi principalami (osoba, grupy, zakresy ról). RLS pilnuje twardej granicy, `TaskAccess` — reguł biznesowych.
- **Dziennik bezpieczeństwa:** `audit.SecurityJournal` jako `LEDGER = ON (APPEND_ONLY = ON)`; cykliczny digest (`sys.sp_generate_database_ledger_digest`) do magazynu WORM; weryfikacja `sys.sp_verify_database_ledger`.
- **Ślad operacyjny:** `audit.OperationTrace` partycjonowana miesięcznie po `OccurredAt`, klastrowany indeks kolumnowy (analiza problemów, duże wolumeny). Retencja przez `TRUNCATE TABLE … WITH (PARTITIONS (…))` — bez kosztownego `DELETE`.
- **Tabele temporalne** (`SYSTEM_VERSIONING`) dla `Absence`, `StageMap*`, `FormVersion`: zapytania `FOR SYSTEM_TIME AS OF` („jaka mapa obowiązywała w chwili decyzji”).
- **Formatki per proces (R11).** Każda tabela schematu `form` ma `TenantId` i `BpmnProcessId`; unikalność `(TenantId, BpmnProcessId, FormKey)`; indeksy filtrowane pilnują jednej wersji roboczej i jednej obowiązującej na formatkę; klucz obcy przypięcia w `task.WorkItem` obejmuje `BpmnProcessId`, więc zadanie nie wskaże wersji formatki innego procesu — to świadomy wyjątek od zasady, że schematy modułów nie mają kluczy obcych między sobą: separację formatek ma gwarantować baza, a nie dyscyplina w kodzie. Kolumna schematu ma ograniczenie `ISJSON` i limit rozmiaru.
- **Współbieżność optymistyczna:** `rowversion` na agregatach.
- **Outbox per moduł** w transakcji zmiany stanu; dispatcher z `UPDLOCK, READPAST, ROWLOCK` (wiele instancji bez podwójnej wysyłki).
- **Inbox, `ProcessedRequest`, `FeedWatermark`:** deduplikacja zdarzeń, idempotencja komend, wznowienie projektora.
- **Lease:** tabela dzierżaw dla zadań singletonowych (`projector`, zadania `jobs`) — bez zewnętrznego koordynatora.
- **Uprawnienia bazy:** login aplikacji w `audit` ma tylko `INSERT`/`SELECT`; nie może zmieniać polityk bezpieczeństwa; migracje wykonuje osobna tożsamość pipeline'u.
- **Izolacja profili (ADR-014).** Każdy profil ma schemat `prj_<id>` i użytkownika bazy bez loginu z prawami tylko do tego schematu i `SELECT` na widokach `platform_api`. Extension Host wykonuje operację profilu w transakcji platformy pod `EXECUTE AS USER = 'prj_<id>'` i wraca `REVERT` przed zapisem audytu; widoki `platform_api` filtruje predykat RLS po `SESSION_CONTEXT(N'ProfileId')` i tabeli `ext.ProfileProcess`. Migracje profilu wykonuje osobna tożsamość z DDL tylko w `prj_<id>` [DO WERYFIKACJI w S27: zgodność z pulą połączeń EF Core].
- **Dostęp:** EF Core po stronie zapisu; listy i dashboard przez Dapper/SQL na widokach z indeksami pod `TaskAccess (PrincipalId, TenantId, Status)` i `ElementVisit (BpmnProcessId, StageId, StartedAt)`.
