# 10. Audyt każdej akcji i bezpieczeństwo

Każde żądanie zostawia dwa ślady w bazie: rekord diagnostyczny w `OperationTrace` (dla analizy problemów) i — dla akcji istotnych dla bezpieczeństwa — niezmienny wpis w `SecurityJournal`. Oba są wymuszone przez infrastrukturę hosta i sprawdzane testem kompletności w CI.

## Co jest audytowane

| Kategoria | `OperationTrace` | `SecurityJournal` |
| --- | --- | --- |
| Każde żądanie HTTP do BFF (także 401/403/4xx/5xx) | tak | — |
| Komendy (przejęcie, zakończenie, przekazanie, start, zastępstwa, formatki, mapa etapów, progi) | tak | tak: `Intent` + `Outcome` |
| Odczyty wrażliwe (szczegóły zadania, instancja, dashboard, eksport, dziennik audytu) | tak | tak |
| Odmowy autoryzacji | tak | tak, `Denied` + kod reguły |
| Logowanie, wylogowanie, odnowienie sesji | tak | tak |
| Zmiany uprawnień (apply reconcilera), wykryty dryf | tak | tak |
| Korekty zastępstw w task listenerze, pominięte korekty | tak | tak |
| Błędy frontendu (endpoint raportowania) | tak | — |

## Pola

| Pole | `OperationTrace` | `SecurityJournal` |
| --- | --- | --- |
| `OccurredAt` (UTC serwera), `TenantId`, `TraceId`, `CorrelationId` | ✓ | ✓ |
| `Actor` (PartyId + identyfikator AD), `OnBehalfOf` | ✓ | ✓ |
| `GrantedBy` (przypisanie roli uzasadniające akcję; dla roli projektowej `<profil>/<rola>`) | — | ✓ |
| `ProfileId` (profil projektu, gdy akcja to operacja, wzbogacenie lub zapytanie profilu) | ✓ | ✓ |
| `Action`, `Resource` (typ, id), `ProcessInstanceKey`, `UserTaskKey`, `BpmnProcessId` | ✓ | ✓ |
| `Outcome` (`Succeeded`/`Denied`/`Failed`/`Reconciled`), kod reguły | ✓ | ✓ |
| `Phase` (`Intent`/`Outcome`) | — | ✓ |
| `PayloadDigest` (SHA-256), lista zmienionych pól — bez wartości PII | — | ✓ |
| Endpoint, metoda, status HTTP, czas trwania, rozmiar odpowiedzi | ✓ | — |
| Błąd: typ wyjątku, komunikat po sanityzacji, kod problemu Camunda (problem detail), liczba ponowień | ✓ | — |
| Adres IP (skrócony wg polityki), User-Agent | ✓ | ✓ |

## Mechanika

- **Middleware śladu** w hoście opakowuje całe żądanie (także to odrzucone przed potokiem) i zapisuje rekord asynchronicznie przez kanał w pamięci z zapisem wsadowym; przy przepełnieniu zapis przechodzi w tryb synchroniczny, nie gubi rekordów.
- **Audyt dwufazowy** dla wywołań Camunda: `Intent` w osobnej, krótkiej transakcji przed wywołaniem SDK; po odpowiedzi stan + `Outcome` + outbox w jednej transakcji. Job uzgadniający rozstrzyga intencje bez wyniku na podstawie read modelu (`Reconciled`).
- **Test kompletności audytu** (CI): enumeruje wszystkie endpointy z `ApiExplorer`, wywołuje je w środowisku testowym jako użytkownik z uprawnieniem i bez, i sprawdza, że każdy zostawił `OperationTrace`, a komendy i odczyty wrażliwe — `SecurityJournal`.
- Dostęp: `Audit.ViewJournal` (audytor, bezpieczeństwo), `Audit.ViewTrace` (administrator platformy, wsparcie). Przeglądanie audytu jest audytowane.

## Kontrole bezpieczeństwa

- OWASP ASVS L2 jako baza wymagań; SAST/DAST i skan zależności w CI.
- BFF z ciasteczkiem `__Host-`, `HttpOnly`, `Secure`, `SameSite=Strict`, ochrona CSRF nagłówkiem; tokeny tylko po stronie serwera (ADR-008).
- CSP bez `unsafe-inline` dla skryptów; nagłówki HSTS, `X-Content-Type-Options`, `frame-ancestors 'none'`.
- Rate limiting per użytkownik i per endpoint w BFF; limity rozmiaru żądań (formatki).
- **Profile projektów.** Operacje profili przechodzą przez potok platformy (autoryzacja, R1, R9, audyt Intent/Outcome, idempotencja) — profil nie ma własnej ścieżki do zapisu zmiennych ani do Camunda. Limity czasu operacji i wzbogaceń (NFR-13); awaria profilu nie blokuje pracy na zadaniu. Profile `remote` wywoływane przez mTLS z krótkotrwałym tokenem platformy zawierającym aktora, zadanie, operację i `requestId`; odpowiedź walidowana schematem kontraktu `profile-operations v1`.
- Klienci techniczni Camunda z minimalnymi uprawnieniami per rola hosta; sekrety z magazynu sekretów (External Secrets), rotacja.
- Formatki: biała lista typów i własności z katalogu pól (`design/forms/field-catalog.yaml`) egzekwowana przy imporcie, zapisie i publikacji; typy `html`, `iframe` i `button` zablokowane; tekst Markdown po sanityzacji, bez surowego HTML i zasobów zewnętrznych; wyrażenia FEEL interpretowane, z limitem długości.
- Akcje formatek w dzienniku: `Form.Create`, `Form.Save`, `Form.Import`, `Form.Export`, `Form.SubmitForReview`, `Form.Recall`, `Form.Reject`, `Form.Approve`, `Form.Publish`, `Form.NewVersion`, `Form.Discard`, `Form.Withdraw`, `Form.Retire`, `Form.Repin` — każda z `BpmnProcessId`, kluczem formatki, numerem wersji i skrótem treści; odmowy z kodem R8 albo R11.
- Rozdział obowiązków (R7), cztery oczy przy formatkach (R8) i separacja formatek per proces (R11).
- Network Policy: tylko pody Host łączą się z Camunda; użytkownicy nie mają dostępu do webapp Tasklist/Operate.
