# Dedykowane elementy procesów w profilu projektu — przewodnik dla zespołów

Dla zespołu projektu, który chce dodać do Process Hub coś, czego potrzebują tylko jego procesy: własne menu i strony, dane projektu (np. katalog, słownik), operacje, pola formatek, panele w zadaniach. Przewodnik mówi, co platforma pozwala zbudować, czego nie pozwala i dlaczego, jak to zadeklarować w manifeście i jak podpiąć kod do platformy.

Przykład przewija się przez cały tekst: profil **`flota`** (`profiles/flota/`) — rejestracja samochodu służbowego z opiniami komórek banku (IT, HR, Prawny, Finanse, Ryzyko) i **katalogiem samochodów**, który widzą tylko role tego profilu, a uzupełnia jedna z jego ról administracyjnych. W klikalnej makiecie (`design/mockups/index.html`) zobaczysz go jako Tomasz (wnioskodawca), Hanna (opiniująca z HR) i Karol (administrator katalogu); Anna z profilu `kredyty` nie widzi niczego z tego.

Podstawy: `docs/architecture/13-project-profiles.md` (profile i punkty rozszerzeń), `profiles/README.md` (założenie profilu), skill `profile-extension` (kod), ADR-012, ADR-013, ADR-014, ADR-017.

## 1. W skrócie

- **Dedykowany element = deklaracja w manifeście + kod na SDK.** Platforma rejestruje tylko to, co jest w `profiles/<id>/profile.yaml`. Kod bez wpisu w manifeście nie zostanie uruchomiony, a wpis bez kodu nie przejdzie testów zgodności.
- **Platforma pilnuje dostępu, profil dostarcza logikę.** Uprawnienia, odmowy, audyt, idempotencja, kontekst bazy i decyzja, czy przycisk w ogóle się pojawi (`allowedActions`), są po stronie platformy. Zespół pisze logikę biznesową, zapytania i komponenty.
- **Wszystko jest ograniczone do profilu.** Elementy profilu działają tylko w jego procesach (R9), mają jego przestrzeń nazw (R10) i widzą je tylko osoby z jego rolami projektowymi. Inne profile, ich procesy i formatki nie mają do nich dostępu.
- **Brakuje punktu rozszerzenia? RFC, nie obejście.** Tak powstał `profile-action` dla katalogu floty: `docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md` → ADR-017.

```mermaid
flowchart LR
  M["profile.yaml<br/>authorization.yaml"] --> V["Walidator profili<br/>bramka CI"]
  V --> PR["PR: zespół profilu<br/>+ architekt platformy<br/>(+ bezpieczeństwo)"]
  PR --> R["Reconciler<br/>role i autoryzacje Camunda"]
  PR --> H["Rejestr profili<br/>Extension Host"]
  K["Kod profilu na SDK<br/>backend · frontend · workery"] --> H
  H --> API["API platformy<br/>uprawnienia · audyt · allowedActions"]
  R --> API
  API --> UI["Powłoka Angular<br/>sekcja nawigacji · strony · sloty"]
  UI --> U["Tylko role profilu"]
```

## 2. Co możesz zbudować

| Potrzeba biznesowa | Punkt rozszerzenia | Przykład | Platforma zapewnia | Ty piszesz |
| --- | --- | --- | --- | --- |
| Własne menu i miejsce w aplikacji | `ui.slots: nav.section` + `ui.routes` (`/p/<id>/…`) | sekcja „Flota” → „Katalog samochodów” (`/p/flota/katalog`) | widoczność sekcji i trasy z uprawnienia, odmowa z wpisem w dzienniku, układ, okruszki, motyw | komponent sekcji i strony |
| Lista lub raport danych projektu | `query` | `flota.CarCatalog`, `kredyty.PortfolioReport` | endpoint `/p/<id>/queries/…`, autoryzacja, ślad, `allowedActions` w wyniku | zapytanie (`IProfileQuery`) |
| Edycja danych projektu bez zadania (katalog, słownik, progi) | `profile-action` (SDK 1.1, ADR-017) | „Dodaj model”, „Wycofaj model” w katalogu floty | uprawnienie, odmowy, audyt Intent/Outcome, idempotencja, kontekst bazy `prj_<id>`, przyciski z `allowedActions` | logika i walidacja (`IProfileAction`) |
| Akcja na zadaniu | `task-action` | „Sprawdź cenę i termin dostawy” (flota), „Przelicz scoring” (kredyty) | to samo + R1 (tylko assignee) i R9 | `ITaskOperation`, zapis szkicu przez `ctx.Tasks` |
| Akcja na sprawie | `case-action` | „Eksport sprawy dla nadzoru” (aml) | to samo w kontekście instancji procesu | `ICaseOperation` |
| Dodatkowe informacje w zadaniu | `task-enricher` + `ui.slots: task.panel` | panel „Opinie komórek” w zadaniu decyzji | sekcja `extensions.<id>`, limit czasu, audyt odczytu wrażliwego | `ITaskEnricher` i komponent panelu |
| Informacje w sprawie | `ui.slots: case.panel` | „Eksport dla nadzoru” (aml) | jak wyżej, dla instancji | komponent panelu |
| Pole formatki z danymi projektu | `ui.slots: form.field` + `form-data-source` | „Model samochodu z katalogu” w formatce startowej | pole w palecie projektanta i w rendererze formatek jako wariant typu bazowego Camunda Forms (zwykle `select`) z własnością `ph:field`; wywołanie tylko z formatek procesów profilu, pamięć podręczna | `IFormDataSource` i komponent pola z `core/ui-kit` |
| Widżet na pulpicie | `ui.slots: dashboard.widget` | „Katalog samochodów” | miejsce na pulpicie, widoczność z uprawnienia | komponent widżetu |
| Dane projektu ze zdarzeń procesów | `event-handler` | rejestr opinii `flota.OpinionRegister` | zdarzenia platformy tylko z procesów profilu, outbox, ponowienia | `IPlatformEventHandler` |
| Krok systemowy w procesie | service task z typem `<id>.*` + worker | `flota.zamowienie.zloz`, `flota.ewidencja.dodaj` | wdrożenie BPMN z pipeline'u, lint, minimalne uprawnienia klienta workera | worker w `profiles/<id>/workers/` |
| Zadanie dla kilku komórek banku | grupy kandydujące w `authorization.yaml` + zadanie wielokrotne w BPMN | opiniowanie IT, HR, Prawny, Finanse, Ryzyko | widoczność per grupa (R3), przejęcie tylko przez członka grupy (R2), audyt z rolą | konfiguracja i model BPMN (sekcja 6) |
| Role projektu | `roles` + `authorization.yaml` | „Administrator katalogu samochodów” bez ról platformy | reconciler, role w audycie (`<profil>/<rola>`), suma uprawnień w zakresach | deklaracja |

## 3. Czego nie możesz — i co zrobić zamiast

| Ograniczenie | Dlaczego | Zamiast tego |
| --- | --- | --- |
| Nie dodasz pozycji do sekcji platformy (Praca, Nadzór, Konfiguracja procesu, Kontrola) ani nie zmienisz jej ekranów | powłoka jest wspólna dla wszystkich profili; zmiana jednego projektu zmieniłaby wszystkim | własna sekcja `nav.section` i sloty; brak potrzebnego slotu → RFC |
| Nie decydujesz w komponencie, czy przycisk akcji ma się pojawić, i nie sprawdzasz ról | UI nie liczy uprawnień; reguły żyją w backendzie, a przyciski renderuje powłoka z `allowedActions` | zadeklaruj operację z uprawnieniem; w kodzie sprawdzasz uprawnienie (`flota.Catalog.Manage`), nigdy nazwę roli |
| Nie piszesz własnych kontrolerów ani endpointów | każde wywołanie musi przejść potok: uprawnienie, deny by default, audyt, idempotencja | operacja albo zapytanie w manifeście |
| Nie łączysz się z Camunda poza workerami typów `<id>.*` i nie zmieniasz zmiennych procesu bezpośrednio | Camunda tylko przez moduł `CamundaIntegration` (ADR-003) | zapis szkicu lub zakończenie zadania przez `ctx.Tasks`; krok systemowy jako service task z workerem |
| Nie czytasz tabel platformy ani innych profili | izolacja danych: schemat i użytkownik bazy per profil (ADR-014) | widoki `platform_api` (filtrowane do procesów profilu) albo `IPlatformQueries` |
| Nie udostępnisz elementów profilu innym profilom ani procesom innych profili | R9; proces ma jednego właściciela (Z-16) | wspólny proces wymaga decyzji o właścicielu; raport przekrojowy — osobny, zatwierdzony mechanizm (ADR-014) |
| Nie używasz cudzej przestrzeni nazw i nie nadajesz ról audytora ani administratora platformy | R10, rozdział obowiązków (R7) | uprawnienia, operacje i typy zadań z prefiksem `<id>.`; grupy AD i grupy kandydujące tylko własne (jedna grupa należy do jednego profilu) |
| Operacja na danych profilu nie ma akceptacji drugiej osoby | `profile-action` to pojedyncza, audytowana zmiana | gdy biznes wymaga czterech oczu — proces z zadaniem zatwierdzenia (R1) |
| Menadżer procesu nie edytuje treści zadań | R1: edytuje i kończy tylko assignee | `task-action` zawsze z `requiresAssignee: true` |
| Operacja ma limit czasu (propozycja: 5 s; wzbogacenie: 1 s) | awaria profilu nie może blokować pracy na zadaniu (NFR-13) | długie obliczenia w workerze albo asynchronicznie ze zdarzenia |
| Nie zapisujesz w audycie ani w logach wartości danych osobowych | RODO, NFR-09 | identyfikatory i listy pól; odczyty wrażliwe oznacz `sensitive: true` |
| Nie wprowadzasz własnych kolorów, krojów ani komponentów spoza Kendo i SDK | rozszerzenia mają wyglądać jak platforma, WCAG 2.2 AA | tokeny z `design/tokens.json`, komponenty `core/ui-kit`, teksty w `profiles/<id>/frontend/i18n/pl.json` |
| Nie dodajesz paczek npm ani NuGet bez zgody | zasada 9 w `AGENTS.md` | wniosek do architekta platformy |
| Nie zmieniasz SDK, kontraktów platformy ani `specs/**` | zasada 8 w `AGENTS.md` | RFC w `docs/rfc/` (wzór: `RFC-FLO-03`) |
| Pole profilu nie zmienia formatu formatki | formatka pozostaje poprawnym dokumentem Camunda Forms, który otworzy Modeler (ADR-018) | pole to typ bazowy z katalogu pól (`design/forms/field-catalog.yaml`) z własnością `ph:field = <profil>.<nazwa>`; bez własnych typów komponentów i bez stylów |
| Profil nie prowadzi formatek poza platformą | wersje, akceptację (R8) i wycofanie prowadzi platforma; formatka należy do jednego procesu (R11) | formatki projektują menadżer i administrator procesu z ról projektowych — `docs/architecture/14-form-management.md` |
| Zdarzenie startowe BPMN nie wskazuje formatki przez `externalReference` | Zeebe 8.9 przyjmuje tam tylko `formId` albo `formKey` | formatkę startową przypisuje do procesu Form Management; kontrakt danych w `ph:outputs` zdarzenia startowego |

## 4. Jak element trafia na ekran

1. **Manifest.** Zespół deklaruje uprawnienia, role, operacje, trasy i sloty w `profile.yaml`, a przypisania grup AD w `authorization.yaml`.
2. **Walidacja.** `python3 tools/profiles/validate_profiles.py --check` (albo `ph profiles validate --check`) sprawdza schemat i reguły międzyprofilowe; bez zielonej walidacji PR nie przejdzie CI.
3. **Przegląd.** `CODEOWNERS`: zespół profilu, a dla `profile.yaml` także architekt platformy, dla `authorization.yaml` także bezpieczeństwo.
4. **Uzgodnienie autoryzacji.** Reconciler łączy role platformy i role projektowe, nadaje w Camunda autoryzacje na procesach profilu i odrzuca naruszenia R7 i R10.
5. **Rejestracja.** Przy starcie host platformy rejestruje moduł profilu (backend) i bibliotekę `profile-<id>-ui` (frontend, ładowanie leniwe).
6. **Wywołanie.** Użytkownik dostaje sekcję nawigacji i strony tylko z uprawnieniem trasy. Wynik zapytania przychodzi z `allowedActions`, a przyciski renderuje powłoka. Kliknięcie idzie przez potok platformy do kodu profilu w kontekście bazy `prj_<id>`.

```mermaid
sequenceDiagram
  participant U as Osoba z rolą profilu
  participant UI as Powłoka + profile-flota-ui
  participant API as Potok platformy
  participant EX as Extension Host
  participant Q as flota.CarCatalog
  U->>UI: otwiera aplikację
  UI->>API: nawigacja i sloty dla aktora
  API-->>UI: sekcja „Flota” (uprawnienie flota.Catalog.View)
  U->>UI: Flota → Katalog samochodów
  UI->>API: GET /p/flota/queries/flota.CarCatalog
  API->>API: uprawnienie trasy i zapytania, ślad
  API->>EX: wykonaj w kontekście profilu
  EX->>Q: ExecuteAsync
  Q-->>EX: modele, liczba wniosków w toku (platform_api)
  EX-->>API: wynik
  API-->>UI: wynik + allowedActions (np. flota.SaveCatalogItem dla administratora katalogu)
  UI-->>U: lista, przyciski tylko z allowedActions
```

Osoba bez uprawnienia nie widzi sekcji. Gdy wpisze adres ręcznie, dostaje stronę „Brak dostępu”, a próba trafia do dziennika bezpieczeństwa z wynikiem `Denied` (R5) — kod profilu nie jest wywoływany.

## 5. Krok po kroku: katalog samochodów w profilu `flota`

### 5.1. Załóż profil (albo pracuj w istniejącym)

```bash
python3 tools/profiles/new_profile.py flota --name "Flota samochodowa" --team "@bank/zespol-flota" --process rejestracja-samochodu
python3 tools/profiles/validate_profiles.py --write-codeowners   # CODEOWNERS dla profiles/flota/
python3 tools/agents/render_agents.py                            # agenci flota-* z zapisem tylko w profiles/flota/**
# bez Pythona: ph profiles new …, ph profiles validate --write-codeowners, ph agents render
```

### 5.2. Uprawnienia i role

Najpierw uprawnienia projektu (zawsze w przestrzeni nazw profilu), potem role projektowe złożone z ról platformy i tych uprawnień:

```yaml
permissions:
  - { id: flota.Catalog.View, kind: read, description: Podgląd katalogu samochodów dostępnych do zakupu }
  - { id: flota.Catalog.Manage, kind: write, description: Dodawanie i zmiana modeli w katalogu oraz ich wycofywanie }

roles:
  - id: wnioskodawca
    name: Wnioskodawca
    platformRoles: [process-starter]
    permissions: [flota.Catalog.View]
    processes: [rejestracja-samochodu]
  - id: administrator-procesow-floty     # formatki, mapa etapów — bez prawa zmiany katalogu
    name: Administrator procesów floty
    platformRoles: [process-administrator]
    permissions: [flota.Catalog.View]
  - id: administrator-katalogu           # tylko opcja dedykowana, bez ról platformy
    name: Administrator katalogu samochodów
    platformRoles: []
    permissions: [flota.Catalog.View, flota.Catalog.Manage]
```

Wskazówki:
- Daj uprawnienie podglądu wszystkim rolom, które mają widzieć element, a uprawnienie zapisu — jednej, wąskiej roli. „Jedna z ról administratora” to rola projektowa z uprawnieniem `…Manage`; druga rola administracyjna (procesów) go nie ma.
- Rola może nie mieć żadnej roli platformy (`platformRoles: []`) — wtedy dostaje wyłącznie opcje dedykowane, bez zadań, formatek i dashboardu.
- Przypisania do grup AD w `authorization.yaml` (jedna grupa AD należy do jednego profilu):

```yaml
assignments:
  - { group: PH-FLOTA-KATALOG, roles: [administrator-katalogu] }
```

### 5.3. Operacje

```yaml
operations:
  - id: flota.CarCatalog                 # lista na stronie i w widżecie
    kind: query
    permission: flota.Catalog.View
  - id: flota.SaveCatalogItem            # dodanie albo zmiana modelu
    kind: profile-action
    title: Zapisz model w katalogu
    permission: flota.Catalog.Manage     # uprawnienie projektu rodzaju write
    requiresAssignee: false              # jawnie: nie ma zadania
    idempotent: true                     # bez appliesTo
  - id: flota.WithdrawCatalogItem
    kind: profile-action
    title: Wycofaj model z katalogu
    permission: flota.Catalog.Manage
    requiresAssignee: false
    idempotent: true
  - id: flota.CarModels                  # pole formatki w procesach profilu
    kind: form-data-source
    permission: flota.Catalog.View
```

`profile-action` wymaga `sdk: "^1.1"` w manifeście.

### 5.4. Interfejs: sekcja nawigacji, strona, widżet, pole formatki

```yaml
ui:
  routes:
    - { path: /p/flota/katalog, title: Katalog samochodów, permission: flota.Catalog.View }
  slots:
    - { slot: nav.section, component: FleetNavSectionComponent, title: Flota, permission: flota.Catalog.View }
    - { slot: dashboard.widget, component: CatalogWidgetComponent, title: Katalog samochodów, permission: flota.Catalog.View }
    - { slot: form.field, component: CarModelSelectComponent, title: Model samochodu z katalogu, permission: flota.Catalog.View, appliesTo: { process: rejestracja-samochodu } }
```

Trasa musi zaczynać się od `/p/<id>/`. Sekcja nawigacji pojawia się w szufladzie pod sekcjami platformy i zawiera tylko trasy, do których aktor ma uprawnienie.

### 5.5. Walidacja manifestu

```bash
python3 tools/profiles/validate_profiles.py --check     # albo: ph profiles validate --check
```

Typowe błędy i ich przyczyny:

| Komunikat walidatora | Co poprawić |
| --- | --- |
| `uprawnienie … spoza przestrzeni nazw flota. (R10)` | prefiks profilu w identyfikatorze |
| `trasa … musi zaczynać się od /p/flota/` | ścieżka trasy |
| `profile-action … wymaga uprawnienia projektu rodzaju write` | uprawnienie zapisu z manifestu, nie platformy |
| `profile-action … działa na danych profilu — bez appliesTo (R9)` | usuń `appliesTo` |
| `profile-action … nie dotyczy zadania — requiresAssignee musi być false` | `requiresAssignee: false` |
| `operacja zapisu … musi jawnie deklarować requiresAssignee` | dodaj pole |
| `task-action … bez wymogu assignee łamie R1` | `requiresAssignee: true` |
| `operacja … z uprawnieniem odczytu wrażliwego musi mieć sensitive: true` | oznacz odczyt wrażliwy |
| `slot … na procesie … spoza profilu (R9)` | `appliesTo` tylko z procesami profilu |
| `grupa … jest już przypisana w profilu …` | osobna grupa AD dla każdego profilu |
| `NIEAKTUALNE: CODEOWNERS` | `--write-codeowners` |

### 5.6. Dane profilu

Migracje w `profiles/flota/db/` tworzą tabele w schemacie `prj_flota` (uruchamia je tożsamość migracji profilu). Dane platformy, np. liczbę wniosków w toku dla modelu, czytasz wyłącznie z widoków `platform_api`, które pokazują tylko procesy profilu.

### 5.7. Backend (C#, `profiles/flota/backend/Flota.Extension`)

```csharp
public sealed class FlotaProfile : IProfileModule
{
    public ProfileId Id => new("flota");
    public void Register(IProfileBuilder p) => p
        .UseDatabase<FlotaDb>()                                              // schemat prj_flota
        .AddQuery<CarCatalog, CarCatalog.Result, CarCatalogHandler>()          // flota.CarCatalog
        .AddProfileAction<SaveCatalogItem, SaveCatalogItem.Input>()            // flota.SaveCatalogItem (SDK 1.1)
        .AddProfileAction<WithdrawCatalogItem, WithdrawCatalogItem.Input>()
        .AddFormDataSource<CarModels>("flota.CarModels");
}

[ProfileOperation("flota.SaveCatalogItem")]                                    // = operations[].id
internal sealed class SaveCatalogItem(FlotaDb db) : IProfileAction<SaveCatalogItem.Input>
{
    public sealed record Input(string? ItemId, string Brand, string Model, string Version, string Category, decimal NetPrice, int Co2);

    public async ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, Input input, CancellationToken ct)
    {
        if (input.Co2 > CarCatalogPolicy.MaxCo2)                               // reguła biznesowa, nie uprawnienie
            return OperationResult.Invalid("co2", $"Emisja CO2 przekracza limit polityki floty ({CarCatalogPolicy.MaxCo2} g/km).");
        var item = await db.CatalogItems.FindOrNewAsync(input.ItemId, ct);
        item.Apply(input, ctx.Actor.PartyId, ctx.Clock.UtcNow);                // historia zmian w prj_flota
        return OperationResult.Ok(new { itemId = item.Id });
    }
}
```

Kod nie sprawdza uprawnień, nie pisze audytu i nie obsługuje ponowień — robi to potok. Szczegóły interfejsów: `docs/architecture/13-project-profiles.md` §5, skill `profile-extension`.

### 5.8. Frontend (Angular, biblioteka `profile-flota-ui`)

Szkic — ostateczny kształt SDK UI ustalają kroki S19 i S47:

```ts
export const flotaUi: ProfileUiModule = {
  id: "flota",
  routes: [{ path: "katalog", loadComponent: () => import("./catalog.page").then(m => m.CatalogPage) }],   // /p/flota/katalog
  slots: [
    { slot: "nav.section", component: FleetNavSectionComponent },
    { slot: "dashboard.widget", component: CatalogWidgetComponent },
    { slot: "form.field", component: CarModelSelectComponent, when: { process: "rejestracja-samochodu" } },
  ],
  actions: [                                                         // formularz parametrów operacji; przycisk i potwierdzenie — powłoka
    { operation: "flota.SaveCatalogItem", form: CatalogItemFormComponent },
    { operation: "flota.WithdrawCatalogItem", confirm: "Wycofać model z katalogu? Wnioski w toku zachowają wybrany model." },
  ],
}
```

- Komponent strony pobiera dane zapytaniem profilu; przyciski „Dodaj model”, „Zmień”, „Wycofaj” pojawiają się tylko wtedy, gdy `allowedActions` wyniku je zawiera.
- Biblioteka ma tag Nx `scope:profile-flota` i zależy wyłącznie od `scope:extension-sdk`; platforma jej nie importuje.
- Kolory, odstępy i krój — wyłącznie z `design/tokens.json` przez `core/ui-kit`; teksty w `profiles/flota/frontend/i18n/pl.json`.
- Wzór wyglądu i zachowania: makieta, persona Karol → „Flota” → „Katalog samochodów”.

### 5.9. Scenariusze i testy

- Scenariusze w `profiles/flota/specs/` (`# language: pl`, tagi `@FLO-FR-xx`): kto widzi stronę i sekcję (także odmowy dla innych profili), kto zmienia katalog, walidacja polityki, idempotencja, R9 dla źródła danych formatki, izolacja bazy (`@integration`).
- Testy w CI profilu: `dotnet test profiles/flota/backend`, testy architektury profili, `npx nx run-many … --projects=tag:scope:profile-flota`, strażnik `enforce_write_scope.py --verify-diff origin/main --profile flota`.

### 5.10. PR, wdrożenie i eksploatacja

- PR przeglądają `CODEOWNERS` profilu; `profile.yaml` także architekt platformy, `authorization.yaml` także bezpieczeństwo. Klasa danych `restricted` wymaga przeglądu bezpieczeństwa.
- Po scaleniu reconciler nadaje autoryzacje, a profil rejestruje się przy starcie platformy (in-process: pociąg wydań; remote: wydania zespołu).
- Zmiany w katalogu po wdrożeniu nie wymagają wydania — to dane profilu zmieniane operacją `profile-action`, każda zmiana z wpisem w dzienniku.

## 6. Wzorzec: zadanie udostępnione kilku komórkom banku

Opiniowanie w profilu `flota` trafia jednocześnie do IT, HR, Prawnego, Finansów i Ryzyka. Każda komórka widzi i przejmuje tylko swoje zadanie, a nowa komórka nie wymaga zmiany modelu.

1. **Jedna rola, wiele grup.** Rola `opiniujacy` (Uczestnik w `opiniowanie-rejestracji`) przypisana do pięciu grup AD; każda komórka ma też własną grupę kandydującą:

   ```yaml
   assignments:
     - { group: PH-FLOTA-OPINIA-IT, roles: [opiniujacy] }
     - { group: PH-FLOTA-OPINIA-HR, roles: [opiniujacy] }
     # … Prawny, Finanse, Ryzyko
   candidateGroups:
     flota-opinia-it: PH-FLOTA-OPINIA-IT
     flota-opinia-hr: PH-FLOTA-OPINIA-HR
   ```

2. **Jedno zadanie wielokrotne w BPMN.** Lista komórek pochodzi ze zmiennej `routing.komorkiOpiniujace`, a grupa kandydująca każdej instancji — z elementu listy (praktyka C4):

   ```xml
   <bpmn:userTask id="OpiniaKomorki" name="Opinia komórki">
     <bpmn:extensionElements>
       <zeebe:userTask />
       <zeebe:assignmentDefinition candidateGroups="=[komorka.grupa]" />
       <zeebe:ioMapping>
         <zeebe:input source="=null" target="opinia" />      <!-- zmienne lokalne instancji: brak wyścigu między komórkami -->
         <zeebe:input source="=null" target="warunki" />
       </zeebe:ioMapping>
     </bpmn:extensionElements>
     <bpmn:multiInstanceLoopCharacteristics>
       <bpmn:extensionElements>
         <zeebe:loopCharacteristics inputCollection="=komorkiOpiniujace" inputElement="komorka"
           outputCollection="opinie" outputElement="={komorka: komorka.kod, opinia: opinia, warunki: warunki}" />
       </bpmn:extensionElements>
     </bpmn:multiInstanceLoopCharacteristics>
   </bpmn:userTask>
   ```

3. **Minimalne dane w procesie.** Do procesu wraca tylko komórka, opinia i warunki (C8). Uzasadnienie, które może zawierać dane osobowe, zapisuje rejestr opinii profilu (`event-handler`) w `prj_flota`; decydent widzi je w panelu `task.panel` z wzbogaceniem oznaczonym `sensitive: true` (każdy odczyt w dzienniku).
4. **Nowa komórka** = grupa AD i grupa kandydująca w `authorization.yaml` + wpis w `routing.komorkiOpiniujace`. Bez zmiany BPMN i bez wdrożenia modelu.

Pełny model: `profiles/flota/bpmn/opiniowanie-rejestracji.bpmn`; diagramy i mapa etapów: `profiles/flota/README.md`.

## 7. Ściąga: rodzaje operacji w manifeście

| `kind` | Kontekst | `appliesTo` | `requiresAssignee` | Uprawnienie | Uwagi |
| --- | --- | --- | --- | --- | --- |
| `task-action` | zadanie | proces (i zadania) profilu | zawsze `true` (R1) | projektu albo platformy | zapis szkicu przez `ctx.Tasks` |
| `case-action` | instancja procesu | proces profilu | jawnie `true` albo `false` | projektu albo platformy | |
| `profile-action` | dane profilu | **brak** | jawnie `false` | projektu, rodzaju `write` | SDK 1.1, ADR-017 |
| `task-enricher` | widok zadania | proces (i zadania) profilu | — | projektu albo platformy | `sensitive: true` przy odczycie wrażliwym |
| `form-data-source` | formatka procesu profilu | — | — | projektu albo platformy | |
| `query` | trasa, widżet | — | — | projektu albo platformy | wynik z `allowedActions` |
| `event-handler` | zdarzenia platformy | — | — | wymagane przez schemat | tylko procesy profilu |

Każda operacja: identyfikator `<id>.NazwaOperacji` (R10), uprawnienie istniejące w manifeście albo w katalogu platformy, odczyt wrażliwy z `sensitive: true`.

## 8. Lista kontrolna przed PR

- [ ] Każdy dedykowany element ma wpis w `profile.yaml`; identyfikatory w kodzie = identyfikatory w manifeście.
- [ ] Uprawnienie podglądu mają wszystkie role, które mają widzieć element; uprawnienie zapisu — tylko wąska rola.
- [ ] Trasy pod `/p/<id>/`; sekcja `nav.section` i trasy z uprawnieniem.
- [ ] Operacje zapisu: `requiresAssignee` zadeklarowane (`task-action`: `true`, `profile-action`: `false`); odczyty wrażliwe `sensitive: true`.
- [ ] Scenariusze: dostęp dla ról profilu, odmowa (z wpisem w dzienniku) dla innych profili i ról, audyt z rolą `<profil>/<rola>`, idempotencja, R9.
- [ ] Brak wartości danych osobowych w audycie i logach.
- [ ] Wygląd z `design/tokens.json`; teksty w i18n profilu; tekst odmowy mówi, dlaczego i że próba trafiła do dziennika.
- [ ] `validate_profiles.py --check`, testy profilu, testy architektury, Nx i strażnik zakresu zapisu — zielone.
- [ ] Potrzeba spoza punktów rozszerzeń → RFC w `docs/rfc/`, nie kod platformy.

## 9. Gdzie szukać

| Temat | Plik |
| --- | --- |
| Profile i punkty rozszerzeń | `docs/architecture/13-project-profiles.md`, ADR-012, ADR-017 |
| Role, uprawnienia, reguły R1–R11 | `docs/architecture/02-roles-and-authorization.md` |
| Praktyki Camunda (C1–C21), lint BPMN | `docs/architecture/06-camunda-integration.md` |
| Frontend, sloty, `allowedActions` | `docs/architecture/11-frontend.md`, `design/README.md` |
| Izolacja danych profilu | ADR-014 |
| Przykład kompletnego profilu | `profiles/flota/` (README, manifest, BPMN, scenariusze, plan) |
| Założenie profilu, lista kontrolna wydania | `profiles/README.md` |
| Kod na SDK | skill `.opencode/skills/profile-extension/SKILL.md` |
