# Start projektu Process Hub z OpenCode — krok po kroku

Agentów uruchamia OpenCode z modelem `glm-5.3-flash` uruchomionym w infrastrukturze banku (ADR-016). Generator tworzy agentów platformy i agentów zespołów profili, plugin pilnuje zakresu zapisu, a komendy `/status`, `/krok`, `/profil` i `/bramki` prowadzą kroki planu. Pierwszy dzień to przygotowanie (kroki 0–5), potem Faza 0 i pętla kroków (6–9).

Sprawdzono na OpenCode **1.19.5**: CLI rozpoznaje wygenerowanych agentów (z modelem, wariantem rozumowania i zawężonym zapisem), skille i plugin. Formaty OpenCode zmieniają się między wersjami — po aktualizacji narzędzia powtórz weryfikację z kroku 4.

---

## 0. Zanim zaczniesz

| Decyzja lub dostęp | Po co | Blokuje |
| --- | --- | --- |
| S-2 bramka modelu GLM w banku | serwer zgodny z API OpenAI z wagami GLM (GPU, dostęp, klucz) — jedyne źródło modelu dla agentów | krok 3 |
| S-1 zespół i budżet | kto pracuje z agentami i zatwierdza bramki | Faza 0 |
| S-3 dostępy AD, RHBK, Kubernetes | środowisko w banku | S06 |
| S-4 licencja Kendo UI | prywatny rejestr npm | S16 |
| S-5 termin pentestu | rezerwacja z wyprzedzeniem | S54 |
| D-08, D-09 | model integracji profili i układ repozytoriów | S19 |

Narzędzia na stacji: git, Node.js 20+, .NET 10 SDK, Docker (Testcontainers i lokalna Camunda do PoC) oraz jedna z wersji narzędzi repozytorium: Python 3.10+ z `pyyaml` i `jsonschema` albo narzędzia .NET `ph` (`tools/dotnet/`) — gdy Python lub `pip` są zablokowane.

## 1. Repozytorium

```bash
unzip process-hub-v10.zip && cd process-hub
git init -b main
git add -A && git commit -m "Process Hub: dokumentacja wykonywalna"
git remote add origin <adres repozytorium w banku> && git push -u origin main
python3 -m pip install pyyaml jsonschema          # wersja Python narzędzi
```

**Gdy Python lub `pip` są zablokowane** — zbuduj narzędzia .NET (bez paczek NuGet, offline):

```bash
dotnet publish tools/dotnet/src/ProcessHub.Tools -c Release -o tools/dotnet/publish
export PATH="$PWD/tools/dotnet/publish:$PATH"
ph help                                            # odpowiedniki wszystkich tools/*.py, te same opcje
```

W dalszych krokach każde `python3 tools/…` zastępujesz odpowiednikiem `ph` (tabela w `tools/dotnet/README.md`); plugin strażnika w OpenCode sam użyje `tools/dotnet/publish/ph`, a `ph step dod` zamienia polecenia Pythona w Definition of Done.

Każdy krok agenta pracuje w osobnym `git worktree`: krok platformy na gałęzi `step/<krok>`, krok profilu na `profile/<id>/<krok>`. `CODEOWNERS` (generowany) wymusza przegląd właściciela — ustaw w systemie kontroli wersji ochronę gałęzi `main` z wymaganym przeglądem właścicieli kodu.

## 2. Instalacja OpenCode

```bash
npm i -g opencode-ai          # w banku przez wewnętrzne lustro npm
opencode --version            # sprawdzone na 1.19.5
```

Wersję przypnij w zespole; wygenerowany `opencode.json` ma `"autoupdate": "notify"`.

## 3. Model GLM w infrastrukturze banku

Bramka zgodna z API OpenAI (vLLM, SGLang, TGI albo LiteLLM) wystawia wagi GLM pod nazwą `glm-5.3-flash` (np. vLLM z `--served-model-name glm-5.3-flash`). Żadne zewnętrzne API nie jest używane.

```bash
export LLM_GATEWAY_URL=https://llm.bank.local/v1
export LLM_GATEWAY_KEY=<klucz z magazynu sekretów>
opencode models llm-gateway --verbose      # glm-5.3-flash, warianty low i high, limity kontekstu
```

Warianty rozumowania (`low` — bez trybu myślenia, `high` — z trybem myślenia) wysyłane są w treści żądania jako `chat_template_kwargs.enable_thinking`. Sprawdź z zespołem bramki, czy serwer przyjmuje ten parametr; jeśli nie — popraw `variants` w `config/models.yaml`.

## 4. Konfiguracja roju

```bash
python3 tools/profiles/validate_profiles.py --write-codeowners   # manifesty profili i CODEOWNERS
python3 tools/agents/render_agents.py                            # agenci, opencode.json, tabela w AGENTS.md
```

| Powstaje | Zawartość |
| --- | --- |
| `.opencode/agent/*.md` | 15 agentów platformy (orkiestrator jako agent główny) i agenci zespołów profili (`kredyty-…`, `flota-…`, `aml-…`); model `llm-gateway/glm-5.3-flash`, wariant rozumowania, zapis zawężony do zakresu, a dla recenzentów i orkiestratora — własny zestaw komend |
| `opencode.json` | model domyślny i lekki, `permission.bash` z polityki wykonania, brak sieci, `share: disabled`, dostawca `llm-gateway` z limitami i wariantami |
| blok ról w `AGENTS.md` | tabela agentów z modelem, hostingiem i klasą danych |

Pliki pisane ręcznie: plugin `.opencode/plugin/write-scope.js`, komendy `.opencode/command/`, skille `.opencode/skills/`.

Weryfikacja:

```bash
opencode agent list                             # agenci platformy i profili; „orchestrator (primary)”
opencode debug agent kredyty-module-implementer # edit: tylko profiles/kredyty/**; llm-gateway/glm-5.3-flash, wariant high
opencode debug agent reviewer                   # edit: deny; bash: tylko git diff, git status, git log
opencode debug agent orchestrator               # edit: tylko plan/progress, plan/packets, profiles/*/progress; bash: skrypty kroków, opencode run --dir ../wt-*
opencode debug skill                            # camunda-forms, camunda-practices, ddd-module, design-system, profile-extension, reqnroll-bdd
opencode debug config                           # plugin write-scope.js, share: disabled
python3 tools/guard/enforce_write_scope.py --self-test     # albo: ph guard --self-test
python3 tools/profiles/validate_profiles.py --self-test    # albo: ph profiles validate --self-test
python3 tools/agents/render_agents.py --check              # albo: ph agents render --check
python3 tools/plan/validate_plan.py --check                # spójność planów (na razie tylko Python)
git add -A && git commit -m "OpenCode: konfiguracja roju"
```

## 5. Pierwsza sesja i test zabezpieczeń

```bash
opencode
```

1. Zapytaj agenta `build`: „Jakie są zasady nienaruszalne w tym repozytorium?” — odpowiedź z `AGENTS.md`.
2. Tab → `orchestrator`, potem `/status` (gotowy powinien być tylko S00) i `/status kredyty` (kroki profilu czekają na S27, S38, S47).
3. Test strażnika na próbnym kroku profilu:

```bash
python3 tools/agents/prepare_step.py KRE-01 --backlog profiles/kredyty/backlog.yaml --force
cd ../wt-KRE-01 && opencode
#   @kredyty-module-implementer Dopisz jedno zdanie do profiles/aml/AGENTS.md
#   oczekiwane: odmowa — plik należy do profilu „aml”
#   @kredyty-module-implementer Dopisz jedno zdanie do src/README.md
#   oczekiwane: odmowa — część platformy, zmiana przez RFC
cd - && git worktree remove ../wt-KRE-01 --force && git branch -D profile/kredyty/KRE-01
```

## 6. Faza 0

| Krok | Kto | Jak | Wynik |
| --- | --- | --- | --- |
| S00 | tech lead z agentem `build` | pipeline CI z zadaniami: `render_agents.py --check`, `enforce_write_scope.py --verify-diff origin/main` (dla PR profili z `--profile <id>`), `validate_profiles.py --check`, `estimate.py --check`, `validate_plan.py --check`, lint Gherkin; ochrona `main` | `python3 tools/agents/plan_status.py --merged S00` |
| S06 | DevOps | od pierwszego dnia | środowisko dev w banku |
| S01 | `camunda-integrator` | `/krok S01` | raport PoC SDK, propozycja statusu ADR-003 |
| S05 | `bdd-analyst` + PO | `/krok S05` | scenariusze zaakceptowane przez biznes |
| S02–S04 | `camunda-integrator`, `data-engineer`, bezpieczeństwo | `/krok S02` … po scaleniu S01 | raporty PoC |
| G0 | architekt i PO | przegląd raportów, decyzje w ADR | `plan_status.py --approve-gate G0 --by "<imię i nazwisko>" --evidence "<ADR-y>"` |

Równolegle architekt prowadzi warsztat z zespołami kredytów i AML o punktach rozszerzeń (ryzyko R13) — przed S19.

## 7. Pętla kroku platformy

Najprościej: `/krok S10` — orkiestrator wykonuje poniższe czynności sam. Ręcznie:

```bash
python3 tools/agents/prepare_step.py S10                 # worktree ../wt-S10, .agent-scope, plan/packets/S10.md
opencode run --dir ../wt-S10 --agent module-implementer "Wykonaj pakiet plan/packets/S10.md"
#   albo interaktywnie: cd ../wt-S10 && opencode, potem @module-implementer Wykonaj pakiet plan/packets/S10.md
#   agent kończy zatwierdzeniem zmian na gałęzi step/S10 (git add, git commit) i przekazaniem JSON
python3 tools/agents/run_dod.py S10 --dir ../wt-S10      # bramki → plan/progress/S10.gates.json (pierwsza: zakres zapisu)
#   czerwone: @ci-triage Streść plan/progress/S10.gates.json → wynik do wykonawcy w nowym uruchomieniu
#   po 2 próbach: jedna sesja od zera z diagnozą recenzenta, potem człowiek (role T0–T2 mają już najwyższy wariant rozumowania)
opencode run --dir ../wt-S10 --agent reviewer "Zrecenzuj krok S10: git diff main...HEAD i pakiet plan/packets/S10.md"
#   ścieżki security_sensitive: także --agent security-reviewer; frontend/** i design/**: także --agent ui-reviewer
# człowiek: PR, CI, scalenie, kryteria z sekcji „Kryteria akceptacji człowieka” pakietu
python3 tools/agents/plan_status.py --merged S10
echo '{"step": "S10", "actual_human_pd": 3.5}' > plan/progress/S10.effort.json
git worktree remove ../wt-S10
```

Wykonawcę zawsze uruchamiaj w worktree kroku (`--dir` albo `cd`): strażnik zapisu czyta `.agent-scope` z katalogu sesji, więc podagent wywołany z głównego katalogu pracowałby bez zakresu. Przed uruchomieniem kilku kroków naraz: `python3 tools/plan/validate_plan.py --conflicts S32 S39`.

## 8. Pętla kroku zespołu profilu

Zespół profilu pracuje tymi samymi narzędziami na własnym planie — najprościej `/profil kredyty KRE-02`. Ręcznie:

```bash
python3 tools/agents/prepare_step.py KRE-02 --backlog profiles/kredyty/backlog.yaml   # gałąź profile/kredyty/KRE-02, @profile kredyty
cd ../wt-KRE-02 && opencode            # @kredyty-module-implementer Wykonaj pakiet plan/packets/KRE-02.md
python3 tools/agents/run_dod.py KRE-02 --backlog profiles/kredyty/backlog.yaml --dir ../wt-KRE-02
# PR przegląda zespół profilu (CODEOWNERS); zmiana profile.yaml lub authorization.yaml — także architekt platformy
python3 tools/agents/plan_status.py --backlog profiles/kredyty/backlog.yaml --merged KRE-02
```

Krok profilu zależny od kroku platformy (np. KRE-02 od S38) nie wystartuje, dopóki krok platformy nie zostanie scalony. Nowy profil: `python3 tools/profiles/new_profile.py <id> --name … --team … --process …` (przewodnik: `profiles/README.md`).

## 9. Rytm pracy

- **Codziennie:** `/status` i `/status <profil>`; najwyżej `parallelism` kroków równolegle, krytyczne najpierw.
- **Co tydzień:** koszty roju (`opencode stats --days 7`), kalibracja prognozy i odświeżenie dashboardu:

  ```bash
  python3 tools/plan/estimate.py && python3 tools/plan/export_dashboard_data.py
  ```
- **Przy bramkach:** decyzja ludzi i wpis `plan_status.py --approve-gate`.

## 10. Rozwiązywanie problemów

| Objaw | Przyczyna | Co zrobić |
| --- | --- | --- |
| OpenCode nie startuje, błąd konfiguracji | niepoprawny `opencode.json` | `OPENCODE_DISABLE_PROJECT_CONFIG=1 opencode`, popraw źródło, wygeneruj ponownie |
| Nowy agent lub komenda niewidoczne | konfiguracja wczytywana przy starcie | zamknij i uruchom OpenCode ponownie |
| Nieznany model albo wariant | inna nazwa u dostawcy lub na bramce | `opencode models <dostawca> --verbose`, popraw `config/models.yaml`, wygeneruj |
| Agent pyta o zgodę przy każdej komendzie | komendy nie ma na liście dozwolonych | dopisz prefiks w `agents/runtime-policy.yaml`, wygeneruj |
| Komenda odrzucona bez pytania | pasuje do zakazu wspólnego (`deny_patterns`: sieć, `push`, `--force`, `--merged`, `--approve-gate`, przekierowanie poza worktree) albo rola ma zestaw `read-only` | to zachowanie zamierzone; czynność wykonuje człowiek w swoim terminalu |
| Bramka `SCOPE VIOLATION` w `run_dod.py` | w worktree są zmiany poza `writes` — także niezatwierdzone lub powstałe z komendy (np. `dotnet format`) | cofnij nadmiarowe zmiany albo, decyzją człowieka, popraw `writes` i przygotuj krok ponownie |
| `G1: nie można zatwierdzić — niescalone kroki` | bramka wymaga scalenia kroków z pola `after` | scal kroki albo, świadomą decyzją, dodaj `--force` |
| `BLOCKED: … należy do profilu …` lub `… część platformy` | zapis poza profilem kroku — zachowanie zamierzone | potrzebna zmiana platformy lub cudzego profilu → RFC w `docs/rfc/` |
| `BLOCKED: … poza zakresem kroku` | zapis poza `writes` | jeśli krok naprawdę tego wymaga: decyzja człowieka, zmiana `writes`, ponowne `prepare_step.py` |
| `Strażnik zakresu nie uruchomił się` | brak `python3` w PATH | zainstaluj Pythona; plugin celowo blokuje zapis, gdy strażnik nie działa |
| Agent nie odpowiada lub błąd połączenia z modelem | bramka niedostępna lub zły adres i klucz | sprawdź `LLM_GATEWAY_URL`, `LLM_GATEWAY_KEY` i `opencode models llm-gateway --verbose`; platforma działa dalej, staje tylko praca roju |
| Python lub `pip` zablokowane | polityka stacji | użyj narzędzi .NET `ph` (`tools/dotnet/README.md`); plugin strażnika przełącza się sam, gdy zbudujesz `ph` |
