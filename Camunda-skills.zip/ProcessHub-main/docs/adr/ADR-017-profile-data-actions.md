# ADR-017: Operacje na danych profilu (`profile-action`)

**Status:** Proponowana — uzupełnia ADR-012 (punkty rozszerzeń); zatwierdza architekt platformy, rozstrzygają S38 i S47

**Kontekst.** Punkty rozszerzeń z ADR-012 pozwalają profilowi zapisywać dane tylko w kontekście zadania (`task-action`) albo sprawy (`case-action`). Profil `flota` potrzebuje katalogu samochodów dostępnych do zakupu, który w aplikacji uzupełnia wskazana rola administracyjna profilu — taki zapis nie dotyczy żadnego zadania ani instancji procesu (wniosek zespołu: `docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md`). Bez nowego punktu zespół musiałby obchodzić brak procesem BPMN „zmiana katalogu” albo kodem platformy — a to łamie zasadę, że profil nie obchodzi braku punktu rozszerzenia, i rozprasza autoryzację oraz audyt.

**Decyzja.**
1. Nowy rodzaj operacji w manifeście: `profile-action` — zapis danych profilu (`prj_<id>`), niezwiązany z zadaniem ani sprawą. Interfejs SDK: `IProfileAction<TInput>`; endpoint: `POST /p/<id>/actions/{operationId}`.
2. Operację wykonuje ten sam potok platformy co pozostałe: uprawnienie z manifestu (deny by default, odmowa audytowana z wynikiem `Denied`), audyt Intent/Outcome z zasobem `profile:<id>/<encja>/<klucz>`, idempotencja po `requestId`, limit czasu (NFR-13), kontekst bazy `prj_<id>` (ADR-014).
3. Reguły manifestu (walidator profili): uprawnienie projektu rodzaju `write` (nie uprawnienie platformy); jawne `requiresAssignee: false` (R1 nie dotyczy — nie ma zadania); brak `appliesTo` (R9: operacja działa wyłącznie na danych własnego profilu).
4. Operacja nie zmienia zmiennych procesów i nie łączy się z Camunda; dane platformy czyta wyłącznie przez widoki `platform_api`.
5. UI: przyciski renderuje powłoka z `allowedActions`, które platforma dołącza do wyniku zapytania profilu (`query`) wyświetlanego na trasie `/p/<id>/…`. Komponent profilu nie decyduje o dostępności akcji.
6. SDK rozszerzeń 1.1 (zmiana zgodna wstecz). Profil korzystający z `profile-action` deklaruje `sdk: "^1.1"`; profile na `^1.0` działają bez zmian.

**Konsekwencje.**
- Profile prowadzą dane referencyjne (katalogi, słowniki, progi) w aplikacji, bez procesu BPMN i bez zmian w platformie.
- `profile-action` nie ma wbudowanej akceptacji drugiej osoby. Zmiana danych wymagająca czterech oczu nadal powinna być procesem z zadaniem zatwierdzenia (R1).
- Walidator manifestów (Python i `ph`) zna nowy rodzaj; testy zgodności SDK obejmują `IProfileAction`.

**Weryfikacja.** S19 (interfejs w SDK, walidacja manifestu), S38 (potok: uprawnienie, audyt, idempotencja, kontekst bazy), S47 (przyciski z `allowedActions` na trasach profilu); scenariusze `profiles/flota/specs/katalog-samochodow.feature`.
