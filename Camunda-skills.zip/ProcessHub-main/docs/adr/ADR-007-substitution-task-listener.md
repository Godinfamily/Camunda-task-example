# ADR-007: Zastępstwa przez task listener, fail-open

**Status:** Proponowana — potwierdza S03

**Kontekst.** Podczas nieobecności nowe zadania mają trafiać do zastępcy; istniejące zadania przekazuje menadżer (pojedynczo lub masowo).

**Decyzja.** Task listener (`creating`, `assigning`) typu `ph.substitution`, obsługiwany przez rolę `worker`, sprawdza rejestr `Absence` i zwraca korektę assignee lub grup. Limit czasu odpowiedzi; przy awarii platformy job kończy się bez korekty (fail-open) + audyt `SubstitutionSkipped`; job uzgadniający wykonuje przekazanie później. Wariant zapasowy (gdy 8.9 nie wspiera korekt): projektor wykrywa przypisanie do nieobecnego i wykonuje `Reassign` — z krótkim oknem widoczności u nieobecnego.

**Konsekwencje.** Korekta przed udostępnieniem zadania, bez wyścigów. Worker musi mieć ≥ 2 repliki i monitoring czasu odpowiedzi.
