# ADR-015: Agenci w OpenCode z modelami GLM 5.3 Flash

**Status:** Przyjęta; punkty 3 i 4 (profile modeli i polityka danych) zastąpione przez ADR-016 — wyłącznie model w infrastrukturze banku

**Kontekst.** Prace wytwórcze wspiera rój agentów AI. Wybrano jedno narzędzie orkiestracji i jedną rodzinę modeli, żeby uprościć utrzymanie harnessu, kwalifikację i koszty.

**Decyzja.**
1. Agentów uruchamia **OpenCode** (zweryfikowano na 1.19.5): definicje w `.opencode/agent/` generowane z `agents/registry.yaml` i manifestów profili, zasady w `AGENTS.md`, skille w `.opencode/skills/`, strażnik zapisu jako plugin `.opencode/plugin/write-scope.js` (logika: `tools/guard/enforce_write_scope.py`, ta sama w CI).
2. Model: **`glm-5.3-flash`** (rodzina GLM 5.3 Flash). Poziomy ról różnią się wariantem rozumowania (`low`, `high`, `max`); eskalacja to wyższy wariant, potem człowiek.
3. Dwa profile modeli: `glm` — API dostawcy (`zai-coding-plan`), `glm-self-hosted` — wagi GLM uruchomione w infrastrukturze banku (bramka zgodna z API OpenAI).
4. Polityka danych: klasy `internal` i `confidential` mogą trafić do API po zatwierdzeniu umowy powierzenia i lokalizacji przetwarzania (S-2); klasa `restricted` (kod bezpieczeństwa, profil `aml`) — wyłącznie do modelu w infrastrukturze banku. Generator wymusza to automatycznie.

**Konsekwencje.**
- Jedna rodzina modeli to mniejsza różnorodność recenzji — kompensują ją bramki deterministyczne, recenzja człowieka przed scaleniem i przypadki kwalifikacyjne E01–E08.
- Zewnętrzne API oznacza przetwarzanie kodu poza bankiem — bez decyzji S-2 zespół pracuje na profilu `glm-self-hosted`.
- Zmiana modelu lub wariantu wymaga ponownej kwalifikacji ról.

**Weryfikacja.** Identyfikatory i warianty potwierdza `opencode models <dostawca> --verbose`; kwalifikacja E01–E08 na obu profilach modeli przed krokami krytycznymi.
