# ADR-004: Autoryzacje dwupoziomowe i autoryzacje jako kod

**Status:** Proponowana — tożsamość wywołań potwierdza S02; reszta przyjęta

**Kontekst.** W ramach tenanta widoczność ograniczają resource authorizations Camunda. Reguły wierszowe (assignee, grupa, inicjator) są drobniejsze niż autoryzacje silnika. Użytkownik może mieć wiele ról.

**Decyzja.**
1. L1 — autoryzacje Camunda na `PROCESS_DEFINITION` (`resourceId` = `bpmnProcessId` lub `*`) dla grup i ról.
2. L2 — polityka aplikacji: uprawnienia z ról w zakresach + reguły R1–R10 (R9 i R10 — profile projektów, ADR-012).
3. Jedno źródło: `config/authorization/*.yaml`; reconciler stosuje je w Camunda przez SDK (dry-run w PR, apply po scaleniu, nocne wykrywanie dryfu); aplikacja ładuje te same pliki.
4. Tożsamość wywołań: wariant A (token delegowany) dla komend użytkownika, jeśli SDK go obsługuje; wariant B (klienci techniczni z minimalnymi uprawnieniami) dla `projector`, `worker`, reconcilera — i awaryjnie dla `api`.

**Konsekwencje.** Brak drugiej tabeli ról; zmiana uprawnień przez PR z przeglądem. Generowane testy macierzy autoryzacji pilnują zgodności L2 z deklaracjami.
