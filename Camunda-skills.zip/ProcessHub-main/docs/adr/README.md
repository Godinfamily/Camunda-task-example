# Rejestr decyzji (ADR)

| ADR | Tytuł | Status | Rozstrzyga |
| --- | --- | --- | --- |
| ADR-001 | Modularny monolit, jeden obraz w czterech rolach | Przyjęta | — |
| ADR-002 | Jeden tenant domyślnie, gotowość na wielu | Przyjęta | — |
| ADR-003 | Oficjalne SDK Camunda wyłącznie za ACL | Proponowana | S01 |
| ADR-004 | Autoryzacje dwupoziomowe i autoryzacje jako kod | Proponowana (tożsamość wywołań) | S02 |
| ADR-005 | MSSQL: RLS, Ledger, partycjonowany ślad operacyjny | Przyjęta | — |
| ADR-006 | Mapa etapów jako warstwa aplikacji | Przyjęta | — |
| ADR-007 | Zastępstwa przez task listener, fail-open | Proponowana | S03 |
| ADR-008 | BFF z ciasteczkiem zamiast publicznego klienta SPA | Przyjęta | — |
| ADR-009 | Reqnroll i biblioteki o licencjach otwartych | Przyjęta | — |
| ADR-010 | Zasilanie read modelu | Proponowana | S04 |
| ADR-011 | Wynik biznesowy na zdarzeniach końcowych | Przyjęta | — |
| ADR-012 | Profile projektów i punkty rozszerzeń | Przyjęta (model domyślny: D-08) | S19, S38 |
| ADR-013 | Separacja kodu profili i własność | Przyjęta (repozytoria: D-09) | S27 |
| ADR-014 | Izolacja danych profilu | Proponowana | S27 |
| ADR-015 | Agenci w OpenCode z modelami GLM 5.3 Flash | Przyjęta, częściowo zastąpiona przez ADR-016 | S00 |
| ADR-016 | Wyłącznie model w infrastrukturze banku | Przyjęta | S06 |
| ADR-017 | Operacje na danych profilu (`profile-action`) | Proponowana (uzupełnia ADR-012) | S38, S47 |
| ADR-018 | Formatki w formacie Camunda Forms: system zapisu, cykl życia z wycofaniem, separacja per proces | Przyjęta (decyzje D-12…D-14) | S26, S28, S29, S39 |
| ADR-019 | Projektant na edytorze form-js, materializacja komponentami design systemu | Proponowana | S07, S09 |
| ADR-020 | Walidacja formatek po stronie serwera i ewaluacja FEEL | Proponowana | S08 |

Zmiana ADR = nowy plik ze statusem „Zastępuje ADR-xxx”. Agent nie edytuje ADR — składa RFC w `docs/rfc/`.
