# ADR-003: Oficjalne SDK Camunda wyłącznie za ACL

**Status:** Proponowana — potwierdza S01

**Kontekst.** Wymóg: backend korzysta z oficjalnego SDK Camunda. Chcemy izolacji od zmian API między wersjami.

**Decyzja.** Paczka SDK referowana wyłącznie przez `CamundaIntegration.Infrastructure.Sdk`; reszta systemu zna porty (`IUserTaskCommands`, `IProcessStarter`, `IProcessQueries`, `IDefinitionCatalog`, `IAuthorizationAdmin`, `ITaskListenerHost`). Wersja przypięta centralnie. Jeśli SDK nie pokrywa operacji z listy kontrolnej (`06-camunda-integration.md`), uzupełniamy ją klientem wygenerowanym z OpenAPI Camunda — wewnątrz tego samego modułu.

**Weryfikacja (S01).** Nazwa i wersja paczki zgodnej z 8.9; pokrycie listy kontrolnej; obsługa `tenantId`; job worker z korektami task listenera; poświadczenia per wywołanie (dla ADR-004).

**Konsekwencje.** Aktualizacja SDK dotyka jednego modułu, sprawdzana testami kontraktowymi na Testcontainers.
