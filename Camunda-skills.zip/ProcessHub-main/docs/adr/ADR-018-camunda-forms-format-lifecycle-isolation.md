# ADR-018: Formatki w formacie Camunda Forms — aplikacja jako system zapisu, cykl życia z wycofaniem, separacja per proces

**Status:** Przyjęta (format, system zapisu, separacja, cykl życia); otwarte decyzje biznesowe D-12, D-13, D-14 nie zmieniają modelu

**Kontekst.** Dotychczas formatka była opisana ogólnie: „wersjonowany schemat (JSON Schema)”, reguły w JSON Logic, cykl `Draft → InReview → Published → Deprecated`, bez modelu wersji, wycofania i przynależności do procesu. Wymaganie: menadżer i administrator procesu tworzą formatki zgodne z biblioteką używaną przez Camunda 8.9 (tak jak w Modelerze), z pełnym wersjonowaniem, akceptacją i wycofaniem; każdy proces ma formatki wyłącznie dla siebie. Praktyka C6 już ustala, że zadanie wskazuje formatkę referencją zewnętrzną, a jej cykl życia należy do aplikacji.

**Decyzja.**
1. **Format.** Treścią wersji formatki jest dokument Camunda Forms (schemat form-js: `type`, `schemaVersion`, `executionPlatform`, `executionPlatformVersion`, `exporter`, `components`). Wyrażenia w FEEL. JSON Schema i JSON Logic nie są używane. Zgodność definiuje profil `ph-forms-8.9`: przypięta wersja biblioteki, `schemaVersion` ≤ 19 i katalog pól (`design/forms/field-catalog.yaml`).
2. **System zapisu.** Formatki, wersje, przeglądy, wycofania i przypięcia prowadzi moduł `FormManagement` w MSSQL. Formatki nie są wdrażane do silnika jako zasoby (`formId`); user task wskazuje formatkę przez `externalReference="ph:form/<klucz>"`, formatkę startową przypisuje do procesu Form Management.
3. **Separacja (R11).** Tożsamość formatki to `(TenantId, BpmnProcessId, FormKey)`. Klucz z referencji BPMN jest rozwiązywany wyłącznie w procesie zadania. Uprawnienia `Form.*` działają w zakresie procesu formatki. Nie ma formatek współdzielonych ani kopiowania między procesami w aplikacji; przeniesienie treści możliwe tylko przez jawny eksport i import pliku `.form`.
4. **Cykl życia wersji.** `Draft → InReview → Approved → Published`, dalej `Superseded` (zastąpiona nowszą) albo `Withdrawn` (wycofana). Najwyżej jedna wersja robocza i jedna obowiązująca. Zatwierdza osoba inna niż autor ostatniej zmiany (R8), a zatwierdzenie dotyczy skrótu treści. Wersje opublikowane są niezmienne i numerowane kolejno.
5. **Wycofanie.** Nowe uprawnienie `Form.Withdraw`. Wycofanie wymaga powodu; przy wersji obowiązującej wskazuje się wersję zastępczą (wcześniej opublikowaną, zgodną z kontraktem danych) albo świadomie zostawia formatkę bez wersji obowiązującej. Zadania w toku pozostają na wycofanej wersji albo — tryb `Repin` — są przepinane na zastępczą. Przepięcie jest jedynym wyjątkiem od niezmienności przypięcia i ma własny wpis w dzienniku.
6. **Uprawnienia.** Katalog L2: `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw`. Menadżer i administrator procesu mają komplet w swoich procesach; audytor — `Form.View`.
7. **Import i eksport.** Plik `.form` z Modelera można zaimportować jako szkic; każdą wersję można wyeksportować. Import przechodzi walidację katalogu pól.
8. **Zgodność z formatem.** W czasie działania serwer waliduje schemat katalogiem pól, który jest podzbiorem formatu Camunda Forms. Zgodność z oficjalnym schematem formatu (`@bpmn-io/form-json-schema`) sprawdzają testy: w frontendzie `ajv` (ADR-019), w .NET walidator JSON Schema używany wyłącznie w projektach testowych — paczkę o otwartej licencji wybiera S26 i zatwierdza architekt (zasada 9 w `AGENTS.md`).

**Odrzucone warianty.**
- *Wdrażanie formatek do silnika (linked forms, `formId`).* Silnik sam wiązałby wersję z zadaniem, ale: prawo tworzenia wdrożeń w Camunda obejmuje także BPMN i DMN (za szerokie dla klienta technicznego platformy; nazwy uprawnień potwierdza S02), identyfikator formularza jest globalny w tenancie (łamie separację per proces), wycofanie z przepięciem zadań i tak wymaga przypięć po stronie aplikacji, a dwa cykle życia (aplikacja i silnik) mogłyby się rozjechać. Do rozważenia ponownie tylko wtedy, gdy potrzebny będzie awaryjny dostęp przez natywny Tasklist.
- *Własny format formatek.* Brak zgodności z Modelerem i konieczność utrzymywania własnego edytora — wprost sprzeczne z wymaganiem.
- *Formatki współdzielone między procesami (biblioteka).* Zmiana wspólnej formatki dotykałaby procesów, których autor nie nadzoruje; sprzeczne z wymaganiem separacji.

**Konsekwencje.**
- Opublikowana formatka jest poprawnym plikiem `.form`; narzędzia Camunda (Modeler, walidatory schematu) działają na niej bez zmian.
- Platforma musi sama rozwiązywać referencje, przypinać wersje i walidować dane — silnik tego nie zrobi (ADR-020).
- Nowa reguła wiersza R11 i dwa nowe uprawnienia zmieniają macierz autoryzacji, deklaracje ról i scenariusze.
- Model BPMN nie może używać `formId` ani formularzy osadzonych — pilnuje tego reguła `ph/form-reference` wtyczki bpmnlint.
- Formatek nie usuwa się; schemat `form` rośnie z historią. Retencję wersji wycofanych ustala compliance.

**Weryfikacja.** S26 (agregat, cykl życia, R8, R11, wycofanie), S28 (schemat `form`), S29 (referencje, przypięcie, bpmnlint), S39 (przepięcie); scenariusze `specs/forms/*.feature`. Opis działania: `docs/architecture/14-form-management.md`.
