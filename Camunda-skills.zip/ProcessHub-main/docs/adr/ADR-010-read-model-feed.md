# ADR-010: Zasilanie read modelu

**Status:** Proponowana — rozstrzyga S04

**Opcje.** (A) wyszukiwanie przyrostowe przez SDK ze znacznikiem i zakładką czasową; (B) eksporter rekordów silnika → Kafka → projektor.

**Rekomendacja.** Start z A (jeden tenant, prostota, oficjalne SDK); przejście na B, gdy pomiar w S04 lub produkcji przekroczy cel NFR-04 albo obciąży API wyszukiwania. Projektor za portem `IEventFeed`, więc zmiana nie dotyka rdzenia.

**Weryfikacja (S04).** Opóźnienie P95 przy obciążeniu z pilotażu; kompletność (brak zgubionych zmian przy restarcie); koszt zapytań po stronie Camunda.
