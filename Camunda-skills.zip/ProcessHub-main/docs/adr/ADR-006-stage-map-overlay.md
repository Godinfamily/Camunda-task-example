# ADR-006: Mapa etapów jako warstwa aplikacji

**Status:** Przyjęta

**Kontekst.** Menadżer ma wiedzieć, na jakim etapie jest proces, bez technikaliów BPMN. W v1 etykiety żyły w `zeebe:properties`, zmieniane tylko przez zespół BPMN.

**Decyzja.** `StageMap` w Process Insight, wersjonowana per wersja definicji, edytowana w aplikacji: elementy mapuje administrator procesu (`StageMap.MapElements`), nazwy/kolejność/SLA ustala menadżer (`StageMap.Edit`). `ph:stage` w BPMN jest tylko zasiewem szkicu. Stan etapów liczony z historii instancji elementów.

**Konsekwencje.** Biznes zmienia prezentację bez wdrożenia BPMN; nowa wersja definicji wymaga przeglądu raportu różnic. Ryzyko niezmapowanych elementów ograniczają walidacja i reguła bpmnlint `ph/user-task-named`.
