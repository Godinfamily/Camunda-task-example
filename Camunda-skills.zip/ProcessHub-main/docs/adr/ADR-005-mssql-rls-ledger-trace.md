# ADR-005: MSSQL — RLS, Ledger, partycjonowany ślad operacyjny

**Status:** Przyjęta

**Decyzja.** SQL Server 2022+. RLS po `TenantId` (`SESSION_CONTEXT`, `@read_only = 1`). `audit.SecurityJournal` jako tabela Ledger append-only z digestami do WORM. `audit.OperationTrace` partycjonowana miesięcznie z indeksem kolumnowym i retencją przez `TRUNCATE … WITH (PARTITIONS)`. Tabele temporalne dla danych z okresem obowiązywania.

**Konsekwencje.** Niezmienność i izolacja egzekwowane przez bazę. Wymagana wersja 2022+ (Ledger, `APPROX_PERCENTILE_CONT`). Koszt: wolumen śladu — planowanie pojemności w S52.
