# ADR-001: Modularny monolit, jeden obraz w czterech rolach

**Status:** Przyjęta

**Kontekst.** Jeden zespół, wiele kontekstów, potrzeba niezależnego skalowania obsługi żądań, projekcji zdarzeń i task listenerów.

**Decyzja.** Modularny monolit .NET 10; moduły jako pionowe wycinki z `Contracts`; jeden obraz kontenera uruchamiany w rolach `api`, `projector`, `jobs`, `worker` (zmienna `PH_ROLE`). Granice wymuszają testy architektury.

**Konsekwencje.** Jedno wdrożenie i wersja; role skalowane osobno; wydzielenie modułu do usługi możliwe bez przepisywania domeny. Koszt: dyscyplina granic musi być automatyczna (testy architektury blokują merge).
