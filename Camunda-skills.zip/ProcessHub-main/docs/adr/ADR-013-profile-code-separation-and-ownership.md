# ADR-013: Separacja kodu profili i własność

**Status:** Przyjęta (monorepo czy osobne repozytoria — D-09)

**Kontekst.** Część specyficzną realizują niezależne zespoły, także z pomocą agentów AI. Trzeba zagwarantować, że zespół lub agent jednego profilu nie zrealizuje części innego projektu ani nie zmieni platformy, a jednocześnie nie blokować zespołów w ich własnym obszarze.

**Decyzja.** Separację wymusza osiem niezależnych warstw:
1. **Repozytorium:** kod profilu wyłącznie w `profiles/<id>/**`; `CODEOWNERS` generowany z manifestów (`tools/profiles/validate_profiles.py`); kontrakt profilu zatwierdza też architekt platformy.
2. **Kompilacja:** profil zależy tylko od SDK rozszerzeń; testy architektury (.NET) i granice Nx (`scope:profile-<id>` → `scope:extension-sdk`).
3. **Uprawnienia:** przestrzeń nazw profilu; walidator manifestów i reconciler odrzucają naruszenia (R10).
4. **Wykonanie:** Extension Host wywołuje profil tylko dla procesów profilu (R9).
5. **Dane:** schemat i użytkownik bazy per profil (ADR-014).
6. **Wdrożenie:** in-process w pociągu wydań, remote — niezależnie.
7. **CI:** filtry ścieżek per profil; `enforce_write_scope.py --verify-diff --profile <id>` dla PR zespołu.
8. **Agenci AI:** agenci `<id>-<rola>` z zapisem tylko w `profiles/<id>/**` (uprawnienia OpenCode + plugin strażnika); agenci platformy nie zapisują w profilach.

**Konsekwencje.**
- Monorepo (rekomendacja na start) pozwala walidować reguły międzyprofilowe w jednym miejscu; przejście na osobne repozytoria wymagałoby publikacji SDK i manifestów jako paczek.
- Generator agentów i walidator manifestów stają się częścią bramek CI.

**Weryfikacja.** S27 (testy architektury profili, CODEOWNERS, strażnik w CI); przypadek kwalifikacji agentów E08.
