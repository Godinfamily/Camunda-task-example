# ADR-014: Izolacja danych profilu

**Status:** Proponowana (mechanizm kontekstu bazy) — rozstrzyga S27

**Kontekst.** Profile przechowują dane projektu (np. wyniki scoringu, profile ryzyka AML) o różnej klasyfikacji. Błąd w kodzie jednego profilu nie może dać dostępu do danych platformy ani innych profili.

**Decyzja.**
1. Każdy profil ma schemat `prj_<id>` i użytkownika bazy `prj_<id>` bez loginu, z prawami tylko do własnego schematu i `SELECT` na widokach `platform_api`.
2. Extension Host wykonuje operację profilu w transakcji platformy pod `EXECUTE AS USER = 'prj_<id>'`, a przed zapisem audytu wraca `REVERT` — jedna transakcja, granica egzekwowana przez bazę.
3. Widoki `platform_api` udostępniają zadania, instancje i stany etapów tylko dla procesów profilu (predykat RLS po `SESSION_CONTEXT(N'ProfileId')` i tabeli `ext.ProfileProcess`).
4. Migracje profilu uruchamia osobna tożsamość z DDL tylko w `prj_<id>`; retencja i klasyfikacja z manifestu.
5. Profil remote może trzymać dane we własnej bazie — obowiązują go klasyfikacja i retencja z manifestu; platforma nie ma do niej dostępu.

**Konsekwencje.**
- Potrzebny interceptor połączeń przełączający kontekst i testy integracyjne izolacji.
- Raporty przekrojowe między profilami wymagają osobnego, jawnie zatwierdzonego mechanizmu (poza zakresem).

**Weryfikacja (S27).** Zgodność `EXECUTE AS USER` z pulą połączeń EF Core i z transakcjami rozproszonymi; test: kod profilu próbujący czytać `task.WorkItem` lub `prj_<inny>` dostaje odmowę bazy; koszt wydajnościowy przełączania kontekstu.
