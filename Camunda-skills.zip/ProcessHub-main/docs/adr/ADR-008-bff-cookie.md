# ADR-008: BFF z ciasteczkiem zamiast publicznego klienta SPA

**Status:** Przyjęta (zmienia ustalenie z v1)

**Decyzja.** Klient poufny `process-hub-bff` w RHBK (Authorization Code + PKCE); tokeny tylko w BFF; przeglądarka dostaje ciasteczko `__Host-` (`HttpOnly`, `Secure`, `SameSite=Strict`) i chroni się przed CSRF nagłówkiem. Klient publiczny `process-hub-spa` z v1 nie jest tworzony.

**Konsekwencje.** XSS nie wykradnie tokenu; SPA prostsza. BFF musi obsłużyć odświeżanie tokenów i wylogowanie globalne.
