# ADR-019: Projektant na edytorze form-js, materializacja formatek komponentami design systemu

**Status:** Proponowana — rozstrzygają S07 (edytor i renderer) i S09 (warstwa wizualna); zatwierdza architekt platformy z projektantem UX

**Kontekst.** Formatki mają być definiowane zgodnie z możliwościami biblioteki Camunda Forms, „analogicznie jak w Modelerze”, ale wyświetlane spójnie z resztą systemu: biznes decyduje o polach i ich układzie, a wygląd ustala projektant UX w Figma dla całej aplikacji. Biblioteka form-js renderuje formularze w Preact, z własnymi kontrolkami i stylem; aplikacja jest w Angularze i używa Kendo UI przez `core/ui-kit`. Poprzednie założenie — własna kanwa projektanta na Angular CDK — wymagałoby odtworzenia edytora i nie gwarantowałoby zgodności schematu.

**Decyzja.**
1. **Projektant.** Biblioteka `form-designer` osadza edytor `@bpmn-io/form-js-editor` (ten sam silnik co w Modelerze) w komponencie Angulara. Paleta i panel właściwości są ograniczone do katalogu pól; własności zablokowane nie są wyświetlane. Pola profili (`form.field`) pojawiają się w palecie jako warianty typów bazowych z własnością `ph:field`. Znak bpmn.io pozostaje widoczny (licencja).
2. **Renderer.** Biblioteka `form-runtime` to własny renderer w Angularze, który interpretuje schemat Camunda Forms i materializuje każdy typ dokładnie jednym komponentem z `core/ui-kit`. Wyrażenia FEEL i szablony wykonują te same biblioteki co w form-js (`@bpmn-io/feelin`, `feelers`); tekst Markdown — `marked` z sanityzacją `dompurify`.
3. **Katalog pól** (`design/forms/field-catalog.yaml`) jest kontraktem materializacji: typ → status → komponent → dozwolone własności. Czytają go: projektant (paleta), backend (walidacja publikacji), renderer (rejestr), testy (parytet rejestrów) i dokumentacja.
4. **Zestaw zgodności.** Formatki wzorcowe uruchamiane w rendererze platformy i w referencyjnym `@bpmn-io/form-js-viewer` (tylko w testach) muszą dawać ten sam zbiór widocznych pól, te same błędy walidacji i te same dane wyjściowe. Wygląd nie jest porównywany.
5. **Wygląd.** Źródłem wyglądu jest biblioteka w Figma prowadzona przez projektanta UX. Do repozytorium trafia jako eksport: zmienne → `design/tokens.json`, specyfikacje komponentów → `design/forms/` i `design/README.md`. Kod czyta wyłącznie pliki z repozytorium; agenci nie mają dostępu do Figma (ADR-016). Komponent UI nie używa wartości spoza tokenów — sprawdza to lint i regresja wizualna.
6. **Regresja wizualna i dostępność.** Katalog komponentów pól (aplikacja w Nx) jest fotografowany przez Playwright w obu motywach i trzech szerokościach; wzorce zatwierdza projektant UX. axe-core dla każdego komponentu i stanu.
7. **Nowe paczki npm** (zasada 9 w `AGENTS.md`): `@bpmn-io/form-js-editor` z zależnością `@bpmn-io/form-js-viewer` (licencja bpmn.io: MIT z obowiązkiem widocznego znaku), `@bpmn-io/feelin`, `feelers`, `marked` (MIT), `dompurify` (MPL-2.0 albo Apache-2.0); tylko do testów: `@bpmn-io/form-json-schema`, `ajv` (MIT). Wersje przypięte; aktualizacja z zielonym zestawem zgodności.
8. **Agenci warstwy wizualnej:** `ux-designer` (zapis w `design/**`), `design-system-engineer` (`core/theming`, `core/ui-kit`, komponenty pól), `ui-reviewer` (przegląd, tylko odczyt). Zakres zapisu ustala krok planu.

**Rozważane warianty renderera.**

| Wariant | Za | Przeciw |
| --- | --- | --- |
| A. Viewer form-js ze stylem nadpisanym w CSS | pełna zgodność zachowania bez pracy własnej | inne kontrolki niż w reszcie aplikacji (brak Kendo), wygląd i dostępność zależne od biblioteki; znak bpmn.io na każdym zadaniu |
| B. Viewer form-js z własnymi rendererami pól (Preact) | zgodność logiki, własny wygląd | drugi framework w aplikacji; komponenty `ui-kit` nie do użycia — design system w dwóch technologiach |
| **C. Własny renderer w Angularze na `ui-kit`** (rekomendacja) | jeden design system, te same komponenty co w całej aplikacji, pełna kontrola dostępności, sloty pól profili | zgodność zachowania trzeba utrzymywać — stąd katalog pól i zestaw zgodności |

Jeżeli PoC S07 pokaże, że koszt zgodności wariantu C jest nie do przyjęcia, wariantem zapasowym jest B dla typów złożonych (`dynamiclist`, `table`) przy zachowaniu C dla pozostałych.

**Konsekwencje.**
- Zmiana tokenów albo komponentu zmienia wygląd wszystkich formatek bez zmiany ich wersji.
- Nowa wersja form-js to świadoma aktualizacja: nowy typ pojawia się w aplikacji dopiero po wpisie w katalogu pól i implementacji komponentu.
- Kanwa edycji wygląda jak w Modelerze, a nie jak u wykonawcy — dlatego projektant ma zakładkę „Podgląd jak u wykonawcy” opartą o renderer platformy.
- `design/**` staje się źródłem dla kodu: zmiany przez pull request z przeglądem projektanta UX; do zespołu referencyjnego dochodzi rola projektanta UX.

**Weryfikacja.** S07 (osadzenie edytora, trzy formatki wzorcowe w wariantach A i C, pomiar rozbieżności), S09 (tokeny, katalog pól, specyfikacje zatwierdzone), S49 (komponenty pól i regresja wizualna), S40 i S45 (renderer i projektant), S55 (zestaw zgodności w CI). Założenia wizualne: `design/forms/README.md`.
