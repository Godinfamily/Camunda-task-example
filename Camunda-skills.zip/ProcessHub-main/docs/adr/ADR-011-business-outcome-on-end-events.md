# ADR-011: Wynik biznesowy na zdarzeniach końcowych

**Status:** Przyjęta

**Decyzja.** Każde zdarzenie końcowe ma `ph:outcome` ∈ {`success`, `rejected`, `error`} (reguła bpmnlint). Dashboard liczy sukces/odmowę/błąd z tego tagu; incydenty to osobna kategoria techniczna; anulowanie — decyzja D-06.

**Dlaczego.** Techniczne zakończenie instancji nie mówi, czy sprawa zakończyła się sukcesem; bez tagu „wniosek odrzucony” wyglądałby jak sukces albo błąd, zależnie od interpretacji.
