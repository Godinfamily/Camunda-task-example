# ADR-020: Walidacja formatek po stronie serwera i ewaluacja FEEL

**Status:** Proponowana — rozstrzyga S08

**Kontekst.** Camunda nie sprawdza zmiennych przesyłanych przy zakończeniu zadania względem formularza — w natywnym Tasklist robi to przeglądarka. Process Hub musi walidować dane na serwerze według przypiętej wersji formatki (FR-06). Schemat Camunda Forms zawiera reguły statyczne (wymagalność, długości, zakresy, wzorce, opcje) i reguły w FEEL (ukrywanie pól, dynamiczne `readonly`/`disabled`, opcje z wyrażeń). .NET nie ma dojrzałej implementacji FEEL. Według dokumentacji API klastra Camunda 8.9 udostępnia ewaluację wyrażenia FEEL silnikiem (`POST /v2/expression/evaluation`, uprawnienie `EVALUATE` na zasobie `EXPRESSION`) — dostępność, kształt żądania i pokrycie przez oficjalne SDK potwierdza S08.

**Decyzja.**
1. **Poziom A — zawsze, bez FEEL** (moduł `FormRuntime`): przyjmowane są tylko klucze znane schematowi; typ wartości zgodny z typem pola; ograniczenia statyczne; wartość z listy opcji statycznych; pole stale `readonly` nie może zmienić wartości wejściowej, a pole stale `disabled` nie jest przyjmowane z przeglądarki; komplet wyjść z kontraktu `ph:outputs`. Poziom A nie zależy od żadnego komponentu zewnętrznego.
2. **Poziom B — wyrażenia FEEL** przez nowy port `IExpressionEvaluator` w `CamundaIntegration` (oficjalne SDK albo klient z OpenAPI wewnątrz ACL — ADR-003). Port ewaluuje wyrażenia formatki z kontekstem danych zadania; `FormRuntime` na tej podstawie ustala pola ukryte, zablokowane i dozwolone opcje, a potem stosuje reguły poziomu A do pól widocznych.
3. **Niedostępność ewaluacji** (silnik niedostępny, limit czasu): zakończenie zadania i tak wymaga silnika, więc żądanie kończy się błędem z możliwością ponowienia — bez obniżania poziomu walidacji.
4. **Składnia wyrażeń** jest sprawdzana tym samym portem przy przekazaniu formatki do przeglądu i ponownie przy publikacji; błąd składni blokuje obie operacje.
5. Klient techniczny roli `api` dostaje autoryzację `EXPRESSION: EVALUATE`; nie dostaje prawa wdrażania zasobów.

**Warianty do porównania w S08.**

| Wariant | Opis | Ryzyko |
| --- | --- | --- |
| **B1. Ewaluacja w silniku Camunda 8.9** (rekomendacja) | port na endpoint ewaluacji wyrażeń | różnice semantyki między `feelin` w przeglądarce a FEEL silnika; narzut wywołań przy dużych formatkach |
| B2. Usługa pomocnicza Node z form-js bez interfejsu | ta sama biblioteka co w przeglądarce | nowy komponent uruchomieniowy do utrzymania i zabezpieczenia w banku |
| B3. `feelin` w interpreterze JavaScript wewnątrz procesu .NET | ta sama biblioteka, bez nowego komponentu | nowa paczka NuGet, wydajność i zgodność interpretera |
| B0. Tylko poziom A | brak FEEL na serwerze | pola warunkowe walidowane wyłącznie w przeglądarce — niedopuszczalne jako stan docelowy, akceptowalne jako stan przejściowy do G2 |

**Konsekwencje.**
- Zestaw zgodności (ADR-019) zawiera przypadki FEEL wykonywane w przeglądarce i przez port — rozbieżność semantyki wychodzi w CI, nie w produkcji.
- Formatki powinny używać podzbioru FEEL wspólnego dla obu silników; lista konstrukcji dopuszczonych w wyrażeniach formatek powstaje w S08 i trafia do katalogu pól.
- Poziom A jest gotowy niezależnie od wyniku PoC i wystarcza do bramki G2.

**Weryfikacja.** S08: kształt żądania i odpowiedzi endpointu, przekazywanie kontekstu, czas dla formatki o 50 wyrażeniach, lista różnic `feelin` ↔ silnik, decyzja B1/B2/B3; S37: implementacja; scenariusze `specs/forms/form-rendering.feature`.
