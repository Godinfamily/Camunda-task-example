# ADR-009: Reqnroll i biblioteki o licencjach otwartych

**Status:** Przyjęta

**Decyzja.** Reqnroll zamiast SpecFlow (wycofany przez Tricentis z końcem 2024; Gherkin i bindingi przenoszą się 1:1). Dispatcher generowany źródłowo lub własny zamiast komercyjnych wersji MediatR; mapowanie ręczne lub generowane (np. Mapperly) zamiast komercyjnego AutoMappera; własne asercje domenowe zamiast komercyjnych wersji FluentAssertions.

**Konsekwencje.** Brak ryzyka licencyjnego w łańcuchu budowania; każda nowa zależność wymaga ADR.
