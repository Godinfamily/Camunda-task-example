# ADR-002: Jeden tenant domyślnie, gotowość na wielu

**Status:** Przyjęta

**Kontekst.** Start z jednym tenantem; separacja obszarów biznesowych wewnątrz tenanta przez autoryzacje zasobów. W przyszłości możliwe kolejne tenanty.

**Decyzja.** `TenantId` w Shared Kernel, w każdym agregacie, zapytaniu, zdarzeniu, wpisie audytu i zakresie roli. `ITenantContext` zwraca dziś `<default>`. RLS po `TenantId` działa od początku. Multi-tenancy w Camunda pozostaje wyłączone do decyzji o drugim tenancie; ta decyzja musi zapaść przed uruchomieniem środowiska docelowego z danymi (zmiana post factum wymaga ponownej inicjalizacji — dokument DevOps v1, sekcja 7).

**Konsekwencje.** Brak kosztu dziś poza dyscypliną przekazywania `TenantId`; drugi tenant = konfiguracja (Camunda, `assignments.yaml`, `ITenantContext` z claimu). Testy BDD mają scenariusz z dwoma tenantami w trybie in-memory, aby gotowość nie była deklaracją.
