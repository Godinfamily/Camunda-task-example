# ADR-012: Profile projektów i punkty rozszerzeń

**Status:** Przyjęta (model integracji domyślnej — D-08)

**Kontekst.** Z platformy korzysta wiele projektów biznesowych (kredyty, AML, kolejne). Każdy ma własne potrzeby co do danych i dedykowanych operacji, a część specyficzną mają realizować niezależne zespoły. Wbudowanie potrzeb projektów w moduły platformy uzależniłoby wydania wszystkich projektów od jednego zespołu i zatarło granice odpowiedzialności.

**Decyzja.**
1. Projekt korzysta z platformy przez **profil projektu** (`profiles/<id>/`): manifest `profile.yaml` (procesy, uprawnienia, role projektowe, dane, operacje, sloty UI, integracje) i `authorization.yaml` (grupy AD → role projektowe).
2. Część specyficzna łączy się z platformą wyłącznie przez **punkty rozszerzeń** SDK: operacje na zadaniu i sprawie, wzbogacenia widoku zadania, źródła danych formatek, zapytania, obsługa zdarzeń platformy, sloty UI.
3. Operacje profili wykonuje **potok platformy** (uprawnienie, R1, R9, audyt Intent/Outcome, idempotencja); profil implementuje tylko logikę biznesową.
4. Dwa modele integracji: **in-process** (moduł .NET w hoście, domyślny) i **remote** (usługa zespołu, kontrakt `profile-operations v1`, mTLS + krótkotrwały token platformy).
5. Nowe reguły dostępu: **R9** (zasoby tylko procesów profilu) i **R10** (przestrzeń nazw profilu).

**Konsekwencje.**
- Platforma dostaje moduł Extension Host i paczki SDK z wersjonowaniem semantycznym i testami zgodności (kroki S19, S38, S47).
- Proces ma dokładnie jednego właściciela-profil; wspólne procesy wielu projektów wymagają decyzji, który profil jest właścicielem.
- Nowa potrzeba bez punktu rozszerzenia oznacza RFC do platformy — to celowe tarcie chroniące spójność.
- Profil remote zwiększa koszt utrzymania zespołu, ale daje niezależne wydania i dowolną technologię.

**Weryfikacja.** S19 (SDK i rejestr), S38 (potok operacji i profil przykładowy), S47 (sloty UI); scenariusze `specs/profiles/project-profiles.feature`.
