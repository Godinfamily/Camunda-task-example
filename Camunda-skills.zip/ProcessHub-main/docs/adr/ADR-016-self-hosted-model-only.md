# ADR-016: Wyłącznie model w infrastrukturze banku

**Status:** Przyjęta — zastępuje ADR-015 w części dotyczącej profilu modeli `glm` (API dostawcy) i polityki danych

**Kontekst.** ADR-015 dopuszczał dwa profile modeli: API dostawcy GLM (po decyzji S-2) i model w infrastrukturze banku. Bank zdecydował, że agenci zawsze korzystają z modelu uruchomionego u siebie — kod, specyfikacje i dane testowe nie opuszczają infrastruktury banku.

**Decyzja.**
1. Jedyny profil modeli: `glm-self-hosted` — wagi z rodziny GLM 5.3 Flash na bramce zgodnej z API OpenAI (vLLM, SGLang, TGI albo LiteLLM), wystawione pod nazwą `glm-5.3-flash`.
2. Polityka danych: każda klasa (`internal`, `confidential`, `restricted`) — wyłącznie `on-prem`. Generator agentów odrzuci profil modeli z hostingiem zewnętrznym.
3. Poziomy ról: warianty rozumowania wysyłane bramce w treści żądania (`low` — bez trybu myślenia, `high` — z trybem myślenia), zdefiniowane w `config/models.yaml` i przekazywane do `opencode.json`.
4. OpenCode dostaje limity modelu (kontekst i wyjście) z `config/models.yaml`, żeby poprawnie zarządzać kontekstem.

**Konsekwencje.**
- Bramka modelu staje się elementem środowiska (krok S06) z wymaganiami wydajności i dostępności; jej niedostępność zatrzymuje pracę roju (ryzyko R15), ale nie platformę.
- Brak różnorodności modeli w recenzji kompensują bramki deterministyczne, recenzja człowieka i kwalifikacja E01–E08.
- Decyzja S-2 dotyczy teraz bramki w banku (sprzęt, serwer, dostęp), a nie zgody na zewnętrzne API.

**Weryfikacja.** Parametry wariantów (`chat_template_kwargs.enable_thinking`) z wersją serwera bramki [DO WERYFIKACJI w S06]; `opencode models llm-gateway --verbose` pokazuje warianty i limity; kwalifikacja E01–E08 na bramce przed krokami krytycznymi.
