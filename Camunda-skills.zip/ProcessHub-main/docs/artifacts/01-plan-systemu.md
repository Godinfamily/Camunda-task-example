<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Plan systemu Process Hub

Process Hub to własny TaskList dla Camunda 8.9 w banku: jedna platforma wspólna dla wszystkich projektów i profile projektów z częścią specyficzną realizowaną przez zespoły projektów. Według modelu wyceny pierwszy projekt kończy pilotaż po 27,6 tyg. z rojem agentów AI (ostrożnie 30,8 tyg.), wobec 38,3 tyg. bez AI, przy 459 osobodniach pracy ludzi zamiast 597.

## 1. System w kontekście

```mermaid
flowchart LR
  subgraph U["Użytkownicy"]
    U1["Uczestnik · Inicjator"]
    U2["Menadżer i Administrator procesu"]
    U3["Audytor · Administrator platformy"]
  end
  subgraph PH["Process Hub"]
    SPA["Aplikacja Angular<br/>sloty UI profili"]
    HOST["Host .NET 10 — platforma<br/>api · projector · jobs · worker"]
    EXT["Extension Host<br/>SDK rozszerzeń"]
    PK["Profil kredyty<br/>in-process"]
    PF["Profil flota<br/>in-process"]
    SPA --> HOST
    HOST --- EXT
    EXT --- PK
    EXT --- PF
  end
  PA["Usługa profilu AML<br/>remote"]
  CAM[("Camunda 8.9")]
  IDP[("RHBK + AD")]
  DB[("MS SQL Server<br/>platforma + prj_*")]
  SYS["Systemy projektów<br/>scoring, rejestry, listy sankcyjne, zakupy floty"]
  U --> SPA
  HOST -->|oficjalne SDK| CAM
  HOST -->|OIDC| IDP
  HOST --> DB
  EXT -->|mTLS + token platformy| PA
  PK --> SYS
  PF --> SYS
  PA --> SYS
```

Camunda pozostaje jedynym źródłem prawdy o stanie procesów i zadań; platforma decyduje, kto co widzi i co może zrobić, i audytuje każdą akcję. Użytkownicy nie korzystają z natywnych aplikacji Camunda.

## 2. Część wspólna i część specyficzna

| Platforma — tak samo dla każdego profilu | Profil projektu — decyduje zespół projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4) | Role projektowe z ról platformy i uprawnień projektu |
| Start procesu, moje procesy, przekazywanie, zastępstwa | Operacje dedykowane na zadaniach i sprawach |
| Eskalacje, dashboard menadżera, mapa etapów, formatki | Dane projektu w schemacie `prj_<id>` |
| Audyt każdej akcji, autoryzacje jako kod | Sloty UI (panel zadania i sprawy, widżet, pole formatki, trasy) |
| Integracja z Camunda (wyłącznie platforma) | Workery typów zadań `<id>.*`, integracje z systemami projektu |
| SDK rozszerzeń i jego zgodność wsteczna | Model integracji (in-process albo remote), własny plan i rytm wydań |

Separację wymuszają osobno: repozytorium (`CODEOWNERS`), kompilacja (zależność tylko od SDK), uprawnienia (przestrzeń nazw, R10), wykonanie (R9), baza danych (schemat i użytkownik per profil), wdrożenie, CI i agenci AI (zapis tylko we własnym profilu). Szczegóły: `docs/architecture/13-project-profiles.md`.

## 3. Główne przepływy

- **Praca na zadaniu.** Uczestnik przejmuje zadanie swojej grupy, zapisuje szkic i kończy je; wyścig o przejęcie rozstrzyga Camunda; każda akcja trafia do dziennika bezpieczeństwa z rolą uzasadniającą.
- **Wgląd menadżera.** Dashboard, eskalacje i stan spraw na etapach biznesowych (mapa etapów nad BPMN); przekazywanie pojedyncze i masowe z powodem; zastępstwa na czas nieobecności.
- **Operacja profilu.** Akcja projektu (np. „Przelicz scoring”) pojawia się w akcjach zadania tylko dla uprawnionego assignee; potok platformy sprawdza uprawnienie, R1 i R9, audytuje i wywołuje kod profilu w jego kontekście danych.
- **Dedykowane miejsce profilu.** Profil może mieć własną sekcję nawigacji i strony (np. „Flota” → „Katalog samochodów”), które widzą tylko jego role; dane referencyjne profilu zmienia wskazana rola operacją na danych profilu (ADR-017), a każda zmiana trafia do dziennika.
- **Formatki.** Menadżer albo administrator procesu projektuje formatkę w formacie Camunda Forms (edytor jak w Modelerze), inna osoba ją zatwierdza, publikacja nadaje wersję; wersję można wycofać z powodem. Każda formatka należy do jednego procesu (R11), a na zadaniu renderują ją komponenty design systemu — biznes decyduje o polach i układzie, wygląd jest wspólny (`docs/architecture/14-form-management.md`).
- **Uprawnienia jako kod.** Role platformy, role projektowe i grupy AD w YAML; reconciler uzgadnia je z Camunda, odrzucając naruszenia rozdziału obowiązków (R7) i przestrzeni nazw (R10).

## 4. Plan realizacji

| Faza | Tygodnie (najwcześniej) | Kroki | Praca ludzi bez AI | Z AI | Oszczędność |
| --- | --- | --- | --- | --- | --- |
| 0 — Przygotowanie i PoC | 0,0–3,3 | 10 | 78,3 | 63,5 | 19% |
| 1 — Fundament | 2,0–8,2 | 10 | 76,5 | 48,3 | 37% |
| 2 — Dostęp, Camunda, audyt, formatki | 6,7–11,6 | 10 | 111,7 | 75,5 | 32% |
| 3 — Funkcje rdzenia | 8,5–15,3 | 10 | 95,5 | 61,4 | 36% |
| 4 — Frontend funkcjonalny | 8,2–16,0 | 10 | 99,2 | 56,1 | 43% |
| 5 — Integracja i hardening | 16,0–22,3 | 6 | 61,0 | 50,8 | 17% |
| 6 — Pilotaż | 22,3–27,6 | 1 | 20,8 | 20,8 | 0% |

| Bramka | Tydzień | Warunek | Kto decyduje |
| --- | --- | --- | --- |
| G0 | 3,3 | ADR-003, ADR-004, ADR-007 i ADR-010 przyjęte na podstawie PoC; scenariusze zatwierdzone przez PO | Architekt, Product Owner |
| G1 | 7,0 | Kontrakty v1 i OpenAPI zamrożone; szkielet, baza i harness BDD zielone w CI; ADR-019 i ADR-020 przyjęte na podstawie PoC formatek, warstwa wizualna zatwierdzona przez projektanta UX | Architekt, Tech lead |
| G2 | 12,6 | Przejęcie i zakończenie zadania działają end-to-end na prawdziwej Camunda przez oficjalne SDK | Tech lead |
| G3 | 22,3 | Wszystkie scenariusze zielone; pentest, kompletność audytu i compliance zaakceptowane | Bezpieczeństwo, Compliance |

Liczby pochodzą z modelu wyceny (`plan/estimation-report.md`) i zmieniają się po kalibracji rzeczywistymi danymi. Część specyficzną profili planują zespoły projektów (`profiles/<id>/backlog.yaml`); pilotaż (S60) wymaga gotowości profilu `kredyty`.

## 5. Wytwarzanie

- Zespół platformy realizuje plan platformy (`plan/backlog.yaml`); zespoły profili — własne plany, zależne od kroków S27, S38 i S47.
- Rój agentów AI działa w OpenCode z modelem `glm-5.3-flash` uruchomionym wyłącznie w infrastrukturze banku: agenci platformy nie zapisują w profilach, agenci profilu zapisują tylko we własnym profilu.
- Interfejs powstaje z design systemu: tokeny z Figma w `design/tokens.json`, komponenty w `core/ui-kit`, agenci warstwy wizualnej `ux-designer`, `design-system-engineer` i `ui-reviewer`. Wytyczne dla osób zaczynających pracę nad UI: `04-wytyczne-ui.md`.
- Ludzie zatwierdzają bramki G0–G3 i scalają każdą zmianę; bramki deterministyczne (build, testy, testy architektury, strażnik zakresu) działają przed recenzją modelu.
