# Artefakty projektowe

Plan systemu, aktorzy, przyjęte założenia i wytyczne UI — dla decydentów, zespołów platformy i profili oraz dla agentów AI. Pliki 01–03 i strona `index.html` są generowane; źródła edytujesz ręcznie.

| Plik | Zawartość | Źródło |
| --- | --- | --- |
| `index.html` | strona do przeglądania (działa z dysku, jasny i ciemny motyw, telefon) | wszystkie poniższe |
| `01-plan-systemu.md` | system w kontekście, część wspólna i specyficzna, przepływy, plan realizacji, wytwarzanie | `templates/01-plan-systemu.md.tmpl` + dane planu |
| `02-aktorzy.md` | użytkownicy, role projektowe, zespoły, systemy | `actors.yaml` |
| `03-zalozenia.md` | rejestr założeń ze statusem, źródłem, sprawdzeniem i skutkiem | `assumptions.yaml` |
| `04-wytyczne-ui.md`, `wytyczne-ui.html` | wytyczne i założenia interfejsu dla osób zaczynających pracę nad UI (pisane ręcznie; strona działa z dysku) | `design/README.md`, `design/tokens.json`, `design/forms/` |

Odświeżenie (po zmianie planu, profili lub rejestrów):

```bash
python3 tools/plan/estimate.py && python3 tools/plan/export_dashboard_data.py
python3 tools/artifacts/render_artifacts.py
# bez Pythona: ph plan estimate && ph plan export && ph artifacts render
```
