# Wytyczne UI Process Hub — start dla nowej osoby

Wszystko, czego potrzebujesz, żeby zacząć pracę nad interfejsem Process Hub: czym jest system, dla kogo projektujemy, jakie zasady są nienaruszalne, skąd bierze się wygląd, jak zbudowany jest frontend, jak działają formatki i kto za co odpowiada. Dokument jest pisany ręcznie; wartości i listy pochodzą z plików źródłowych wskazanych przy każdej sekcji — przy rozbieżności rozstrzyga źródło. Wersja do przeglądania: `wytyczne-ui.html`.

## 1. System w pięciu zdaniach

1. Process Hub zastępuje natywny Tasklist Camunda 8.9 własnym interfejsem; Camunda pozostaje jedynym źródłem prawdy o stanie procesów i zadań.
2. Platforma decyduje, kto co widzi i co może zrobić, i zapisuje każdą akcję w dzienniku audytu.
3. Menadżer procesu nie ogląda BPMN — widzi etapy biznesowe (wstęgę etapów), dashboard, eskalacje i przekazuje zadania.
4. Formatki zadań projektuje biznes w formacie Camunda Forms; wygląd nadaje im design system wspólny dla całej aplikacji.
5. Projekty biznesowe (profile: kredyty, AML, flota) dokładają własne elementy w wyznaczonych miejscach interfejsu, w tym samym wyglądzie.

## 2. Dla kogo projektujesz

| Rola | Po co przychodzi | Główne ekrany |
| --- | --- | --- |
| Uczestnik | wykonać swoje zadania | Pulpit, Zadania, Zadanie z formatką, Start procesu, Moje procesy, Zastępstwa |
| Menadżer procesu | pilnować przepływu pracy | Panel procesu, Eskalacje, Sprawy, Przekazanie, Formatki, Mapa etapów (nazwy i SLA) |
| Administrator procesu | utrzymać konfigurację procesu | Mapa etapów (z diagramem), Formatki |
| Audytor | sprawdzić zgodność | wszystko tylko do odczytu, Dziennik audytu |
| Administrator platformy | utrzymać uprawnienia | Uprawnienia, ślad operacyjny |
| Role profili (np. flota) | praca w procesach projektu | sekcja profilu w nawigacji, strony `/p/<id>/…` |

Jedna osoba może mieć kilka ról naraz — nawigacja pokazuje sumę. Persony do testów i makiety: `specs/README.md`; pełna lista aktorów: `02-aktorzy.md`.

## 3. Dziesięć zasad nienaruszalnych

1. **UI nie liczy uprawnień.** Każdy zasób z API przychodzi z listą `allowedActions`; przycisk istnieje tylko wtedy, gdy akcja jest na liście.
2. **Akcji, której nie wolno wykonać, nie ma** — zamiast wyszarzonego przycisku jest jedno zdanie, dlaczego („Edytować może tylko osoba, która przejęła zadanie: …”).
3. **Kolor nigdy nie jest jedynym nośnikiem informacji.** Status ma kształt i słowo: krytyczny — kwadrat, ostrzeżenie — trójkąt, poprawny — koło.
4. **Jedna nazwa akcji w całym przepływie:** „Opublikuj” na przycisku → „Opublikować wersję 4?” w potwierdzeniu → „Opublikowano wersję 4” w komunikacie.
5. **Decyzje nieodwracalne** (zakończenie zadania, przekazanie, publikacja, wycofanie) przechodzą przez okno potwierdzenia z podsumowaniem skutku.
6. **Formularz nie gubi danych.** Błędy: podsumowanie na górze z odnośnikami do pól i komunikat przy polu.
7. **Puste stany mówią, co zrobić dalej;** odmowa dostępu mówi, że próba trafiła do dziennika.
8. **Wartości wizualne wyłącznie z tokenów** (`design/tokens.json`); widoki składasz z komponentów `core/ui-kit`, nie z kontrolek Kendo wprost.
9. **Menadżer nie widzi technikaliów BPMN** — identyfikatory i diagram tylko dla uprawnienia `Bpmn.ViewTechnical`.
10. **Teksty po polsku, w plikach i18n;** kod i identyfikatory po angielsku.

## 4. Kierunek wizualny i tokeny

Biel i czerwień jak barwy Polski, użyte oszczędnie — to narzędzie pracy na cały dzień. Biały pasek aplikacji kończy się 4-pikselowym pasem flagowej czerwieni; jedynym mocnym elementem jest wstęga etapów; liczby czytamy jak pasek księgowy; jeden krój — Lato, hierarchia przez grubość (400/700/900). Źródło: `design/README.md`, `design/tokens.json`.

| Token | Jasny | Ciemny | Użycie |
| --- | --- | --- | --- |
| `flag-red` | #DC143C | #DC143C | pas pod paskiem aplikacji, akcenty nietekstowe — nigdy tekst |
| `action` / `action-hover` | #A10F2B / #86081F | #FF6B7E / #FF8A99 | przyciski główne, odnośniki, bieżący etap (8,02:1 na bieli) |
| `action-ink` | #FFFFFF | #16181B | tekst na `action` |
| `ink` / `ink-2` | #1F2328 / #4A5059 | #ECEDEF / #B5BAC1 | tekst / tekst pomocniczy |
| `bg` / `surface` / `surface-2` | #F4F5F7 / #FFFFFF / #F9FAFB | #16181B / #1F2226 / #24282D | tło strony / panele / tło wtórne |
| `line` / `line-strong` | #D9DCE1 / #AEB3BB | #353A41 / #4E555E | linie / obramowania kontrolek |
| `ok`, `warn`, `crit`, `info` (+ `-bg`) | ciemne odcienie na jasnym tle | jasne odcienie na ciemnym tle | statusy, każdy ≥ 6,5:1 |

| Skala | Wartości |
| --- | --- |
| Typografia (px) | h1 28 · h2 19 · tekst 16 · mały 14 · liczba kluczowa 34; interlinia tekstu 1,5 |
| Odstępy (px) | 4 · 8 · 12 · 16 · 24 · 32 · 48 |
| Promienie (px) | kontrolka 6 · panel 8 · pigułka 999 |
| Kontrolka (px) | wysokość 44 · obramowanie 1 · wypełnienie 8 × 10 · fokus 3 z odstępem 2 |
| Progi szerokości (px) | telefon 600 · tablet 860 · pulpit 1100; układ bez przewijania w poziomie od 390 |

**Skąd się bierze wygląd.** Projektant UX prowadzi bibliotekę w Figma (zmienne, komponenty, wzorce). Zmiana wyglądu to eksport do pull requestu w `design/**`; kod czyta wyłącznie pliki z repozytorium. Brakuje tokenu? Nie wpisujesz wartości „na chwilę” — zgłaszasz to projektantowi UX (agent `ux-designer` przenosi eksport). Wartości są do potwierdzenia z księgą znaku banku (krok S09).

## 5. Architektura informacji

Nawigacja jest liczona z uprawnień, nie z nazwy roli.

| Sekcja | Pozycje | Kto widzi |
| --- | --- | --- |
| Praca | Pulpit, Zadania, Start procesu, Moje procesy, Zastępstwa | uczestnik, inicjator |
| Nadzór | Panel procesu, Eskalacje, Sprawy, Przekazanie masowe | menadżer procesu (audytor bez przekazywania) |
| Konfiguracja procesu | Mapa etapów, Formatki | menadżer i administrator procesu |
| Kontrola | Dziennik audytu, Uprawnienia | audytor, administrator platformy |
| Sekcja profilu (np. Flota) | strony profilu `/p/<id>/…` | wyłącznie role profilu |

Każdy widok ma okruszki, nagłówek z fokusem po zmianie widoku i odnośnik „Przejdź do treści”. Ekrany, trasy i wymagania: tabela w `design/README.md`; zachowanie zobaczysz w makiecie `design/mockups/index.html` (przełącznik „Podgląd jako”).

## 6. Stos i układ frontendu

Angular, Nx, Kendo UI for Angular (przez `core/ui-kit`), Signals z `OnPush`, RxJS na brzegu, SignalR dla aktualizacji, klient API generowany z OpenAPI. Źródło: `docs/architecture/11-frontend.md`.

| Biblioteka (Nx) | Zawartość |
| --- | --- |
| `core/theming` | tokeny → zmienne CSS i motyw Kendo; motywy jasny, ciemny, systemowy |
| `core/ui-kit` | komponenty aplikacji (opakowania Kendo), w tym komponenty pól formatek `ph-*` i wstęga etapów |
| `core/auth`, `core/access`, `core/i18n` | sesja, `allowedActions`, teksty |
| `apps/ui-catalog` | każdy komponent w każdym stanie — do przeglądu i regresji wizualnej |
| `task-workspace` | listy zadań, szczegóły zadania z formatką |
| `process-lifecycle` | start procesu, moje procesy |
| `process-insight` | dashboard, eskalacje, sprawy |
| `reassignment` | przekazania, zastępstwa |
| `stage-map-editor` | mapa etapów; jedyne miejsce bpmn-js |
| `form-designer` | projektant formatek; jedyne miejsce edytora form-js |
| `form-runtime` | renderer formatek: interpretacja schematu + rejestr typ → komponent |
| `audit-viewer` | dziennik i ślad |
| `platform/extension-sdk`, `profiles/<id>/frontend` | sloty i biblioteki profili projektów |

Granice Nx: widok nie importuje Kendo wprost; biblioteki profili zależą tylko od SDK rozszerzeń; `form-runtime` nie zawiera stylów.

## 7. Komponenty — wzorce wspólne

| Wzorzec | Zasada |
| --- | --- |
| Przycisk | 44 px, tekst 15 px/700; główny na `action`, zwykły z obramowaniem, cichy bez tła; najwyżej jeden główny w grupie |
| Pole | etykieta nad polem (700), „(wymagane)” słowem, podpowiedź 14 px pod polem, błąd 14 px/700 ze znacznikiem |
| Wstęga etapów | etapy jako segmenty biało-czerwonej wstęgi; bieżący w pełnej czerwieni akcji; eskalacja i blokada słowem |
| Pasek księgowy | liczby w jednej linii oddzielone kreskami zamiast jednakowych kafelków |
| Listy | tabela na szerokim ekranie, karty na telefonie; stan widoku zapisywany |
| Znacznik stanu | kształt + słowo + kolor statusu |
| Okno potwierdzenia | tytuł = nazwa akcji, podsumowanie skutku, przycisk o tej samej nazwie |
| Komunikat | region `aria-live`; mówi, co się stało, tymi samymi słowami co akcja |
| Wykres | zawsze z tabelą danych jako alternatywą |

## 8. Formatki — jak to działa

Źródła: `docs/architecture/14-form-management.md` (działanie), `design/forms/README.md` (wygląd), `design/forms/field-catalog.yaml` (kontrakt).

**Trzy warstwy.** Struktura (schemat Camunda Forms: pola, typy, teksty, walidacje, warunki, wiersze) należy do biznesu. Materializacja (typ pola → komponent) należy do design systemu. Wygląd (tokeny) należy do projektanta UX. Schemat nie ma jak nieść kolorów ani krojów; renderer nie ma własnych stylów.

**Cykl życia wersji:** Szkic → W przeglądzie → Zatwierdzona → Opublikowana → Zastąpiona albo Wycofana. Zatwierdza inna osoba niż autor ostatniej zmiany (R8). Opublikowana wersja jest niezmienna; zadanie renderuje wersję przypiętą przy jego utworzeniu. Wycofanie wymaga powodu, wersji zastępczej (albo świadomego jej braku) i decyzji o zadaniach w toku.

**Separacja.** Formatka należy do jednego procesu (R11): ekran „Formatki” działa zawsze w kontekście wybranego procesu, a przełącznik pokazuje tylko procesy z zakresu roli.

**Katalog pól** (typy Camunda Forms → komponenty):

| Status | Typy |
| --- | --- |
| Wspierane (14) | `textfield`, `textarea`, `number`, `datetime`, `checkbox`, `checklist`, `radio`, `select`, `taglist`, `group`, `dynamiclist`, `table`, `expression`, `separator` |
| Z ograniczeniami (3) | `text` (Markdown bez HTML), `spacer` (skala odstępów), `image` (zasób osadzony, tekst alternatywny) |
| Planowane (2) | `filepicker`, `documentPreview` — po decyzji o magazynie dokumentów |
| Zablokowane (3) | `html`, `iframe`, `button` — akcje renderuje powłoka z `allowedActions` |

**Układ.** Siatka 16 kolumn ze schematu, odstęp 16 px, szerokość formatki do 880 px, jedna kolumna poniżej 600 px.

**Tryby:** edycja (assignee), odczyt (pozostali, z jednym zdaniem wyjaśnienia), podgląd (projektant), niedostępna (brak wersji obowiązującej).

**Projektant.** Zakładka „Projekt” osadza edytor form-js — ten sam co w Camunda Modelerze — z paletą ograniczoną do katalogu pól. Kanwa wygląda jak w Modelerze; o wyglądzie u wykonawcy rozstrzyga zakładka „Podgląd jak u wykonawcy”, oparta o renderer platformy. Znak bpmn.io musi pozostać widoczny (licencja).

**Czego nie robimy:** żadnych stylów per formatka, żadnego HTML w treści, żadnych przycisków w formatce, żadnych wartości wyglądu w schemacie.

## 9. Dostępność — lista kontrolna (WCAG 2.2 AA, wybrane cele AAA)

- Kontrast: tekst podstawowy, pomocniczy i akcje ≥ 7:1 (cel AAA), tekst statusów ≥ 6,5:1, żaden tekst poniżej 4,5:1 (wymóg AA), elementy nietekstowe ≥ 3:1; pomiary w `design/tokens.json`.
- Widoczny fokus 3 px; kolejność fokusu = kolejność czytania; wszystko działa z klawiatury.
- Cele dotykowe ≥ 44 px.
- Etykieta dla każdej kontrolki; podpowiedź i błąd przez `aria-describedby`; `aria-invalid` przy błędzie; grupy opcji w `fieldset` z `legend`.
- Zmiany stanu w regionie `aria-live`; fokus na nagłówku po zmianie widoku; okruszki na każdym widoku.
- Wykres ma tabelę danych; kolor nie jest jedynym nośnikiem.
- `prefers-reduced-motion`; motyw jasny, ciemny i systemowy; powiększenie 200% bez utraty treści; brak przewijania w poziomie od 390 px.

## 10. Jak pracujemy

| Etap | Kto | Wynik |
| --- | --- | --- |
| Projekt w Figma | projektant UX | zmienne, komponenty ze stanami, wzorce |
| Eksport do repozytorium | agent `ux-designer` + projektant UX | pull request w `design/**` (tokeny, specyfikacje, katalog pól, makieta) |
| Komponenty | agent `design-system-engineer` | `core/theming`, `core/ui-kit`, strona w katalogu komponentów, zrzuty wzorcowe |
| Widoki i logika | agent `frontend-developer` | biblioteki funkcjonalne na `ui-kit` i `allowedActions` |
| Przegląd | agent `ui-reviewer` + człowiek | zgodność z tokenami, katalogiem pól, wzorcami i WCAG |
| Scalenie | człowiek | każda zmiana; wzorce regresji wizualnej tylko za zgodą projektanta UX |

Praca agenta zaczyna się od pakietu kroku (`plan/packets/<krok>.md`) i kończy bramkami Definition of Done. Dla UI: `npx nx affected -t lint test build`, test axe-core widoku lub komponentu, zrzuty regresji wizualnej (motyw jasny i ciemny; 390, 768, 1280 px), scenariusz Playwright dla widoku. Kroki dotyczące UI: S09 (warstwa wizualna), S16 (shell, motyw, ui-kit), S49 (komponenty pól), S40–S47 (widoki), S53 (dostępność), S55 (zgodność i spójność formatek) — `plan/execution-plan.md`.

## 11. Kto za co odpowiada

| Obszar | Decyduje | Wykonuje | Sprawdza |
| --- | --- | --- | --- |
| Tokeny, wygląd komponentów, wzorce | projektant UX | `ux-designer` (eksport), `design-system-engineer` (kod) | `ui-reviewer`, projektant UX (zrzuty) |
| Katalog pól formatek | architekt platformy z projektantem UX | `ux-designer`, `design-system-engineer` | testy parytetu |
| Treść i układ formatki | menadżer, administrator procesu | oni sami, w projektancie | druga osoba (R8) |
| Zachowanie widoków, `allowedActions` | architekt (kontrakty API) | `frontend-developer` | `reviewer`, testy |
| Dostępność | — (wymóg NFR-08) | wszyscy | axe w CI, przegląd z czytnikiem ekranu (S53) |
| Elementy profili w UI | zespół profilu | agenci profilu | granice Nx, `ui-reviewer` |

## 12. Pierwszy dzień — co zrobić

1. Otwórz makietę `design/mockups/index.html` i przejdź scenariusze 1, 3, 5, 6 i 13 z `design/README.md` (uczestnik, menadżer, formatki, wycofanie wersji).
2. Przeczytaj `design/README.md`, potem `design/forms/README.md`.
3. Przejrzyj `design/tokens.json` i `design/forms/field-catalog.yaml` — to dwa pliki, z których czyta kod.
4. Przeczytaj `docs/architecture/11-frontend.md` i sekcje 1–3 oraz 11–13 w `docs/architecture/14-form-management.md`.
5. Zajrzyj do `AGENTS.md` (zasady repozytorium) i skilli `.opencode/skills/design-system` oraz `.opencode/skills/camunda-forms`.
6. Sprawdź swój krok w `plan/execution-plan.md` i otwarte decyzje D-12…D-16.

## 13. Słownik

| Pojęcie | Znaczenie |
| --- | --- |
| Formatka | formularz zadania albo startu procesu w formacie Camunda Forms; należy do jednego procesu |
| Katalog pól | lista typów pól ze statusem i komponentem design systemu |
| Materializacja | zamiana schematu formatki na interfejs z komponentów |
| Token | nazwana wartość wizualna (kolor, odstęp, wymiar) w `design/tokens.json` |
| Wstęga etapów | komponent pokazujący etapy biznesowe procesu i bieżący etap |
| `allowedActions` | lista akcji, które bieżąca osoba może wykonać na zasobie — jedyne źródło przycisków |
| Slot | miejsce w interfejsie na komponent profilu projektu |
| Wersja obowiązująca | opublikowana wersja formatki przypinana nowym zadaniom |
| Przypięcie | wersja formatki zapisana przy zadaniu w chwili jego utworzenia |

## 14. Otwarte sprawy, które dotyczą UI

| Sprawa | Gdzie |
| --- | --- |
| Potwierdzenie kolorów z księgą znaku banku i założenie biblioteki w Figma | S09, D-16 |
| Wariant renderera formatek (własny na design systemie — rekomendacja) | ADR-019, PoC S07 |
| Załączniki w formatkach | D-15 |
| Testy z użytkownikami na makiecie (po 5 osób na rolę) | `design/README.md`, „Jak dalej projektować” |
