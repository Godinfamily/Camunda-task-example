# Słownik pojęć (Ubiquitous Language)

| Pojęcie (PL) | Kod | Definicja | Odwzorowanie w Camunda 8.9 |
| --- | --- | --- | --- |
| Tenant | `TenantId` | Najwyższa granica separacji danych. Domyślnie jeden: `<default>` | Tenant (multi-tenancy wyłączone = `<default>`) |
| Definicja procesu | `ProcessDefinitionKey` / `BpmnProcessId` | Model BPMN w konkretnej wersji; `BpmnProcessId` to identyfikator niezależny od wersji | Process definition |
| Instancja procesu | `ProcessInstanceKey` | Pojedyncze wykonanie definicji | Process instance |
| Zadanie | `WorkItem` (`UserTaskKey`) | Krok wymagający człowieka | Camunda user task |
| Assignee | `Assignee` | Osoba, która przejęła zadanie; jedyna może je edytować i zakończyć | `assignee` |
| Grupa kandydująca | `CandidateGroups` | Grupy, których członkowie mogą przejąć zadanie | `candidateGroups` |
| Inicjator | `InitiatorPartyId` | Osoba, która wystartowała proces z aplikacji | zmienna `initiatorPartyId` |
| Uprawnienie | `Permission` | Atomowa zdolność, np. `Task.Reassign` | — |
| Rola | `Role` | Nazwany zbiór uprawnień, zdefiniowany jako dane | Role / Group + Authorizations |
| Zakres | `Scope` | Do czego rola się odnosi: tenant, definicje procesów, zespół | `resourceId` autoryzacji |
| Przypisanie roli | `RoleAssignment` | Grupa AD lub osoba → rola w zakresie | Mapping rule + authorization |
| Menadżer procesu | rola `ProcessManager` | Nadzoruje instancje swoich procesów, przekazuje zadania, prowadzi formatki swoich procesów (projekt, przegląd, publikacja, wycofanie) i mapę etapów | autoryzacje READ/UPDATE na definicjach w zakresie |
| Administrator procesu | rola `ProcessAdministrator` | Konfiguruje proces w aplikacji: formatki, mapowanie elementów BPMN na etapy, progi | jw. + odczyt definicji |
| Audytor | rola `Auditor` | Wgląd tylko do odczytu we wszystkie procesy i dziennik audytu | READ na `*` |
| Formatka | `FormDefinition` (`FormKey`) | Formularz zadania albo startu procesu w formacie Camunda Forms; należy do dokładnie jednego procesu (R11) | brak zasobu w silniku — user task wskazuje ją przez `zeebe:formDefinition externalReference="ph:form/<klucz>"` |
| Wersja formatki | `FormVersion` | Treść formatki w cyklu `Draft → InReview → Approved → Published → Superseded / Withdrawn`; numer nadaje publikacja | — |
| Wersja obowiązująca | `CurrentVersion` | Opublikowana wersja przypinana nowym zadaniom; najwyżej jedna na formatkę | — |
| Przypięcie | `WorkItem.FormVersion` | Wersja formatki zapisana przy zadaniu w chwili utworzenia; zmienia ją tylko przepięcie przy wycofaniu | — |
| Wycofanie | `FormWithdrawal` (`Form.Withdraw`) | Zdjęcie opublikowanej wersji albo całej formatki z użycia, z powodem, wersją zastępczą i trybem dla zadań w toku | — |
| Kontrakt danych zadania | `ph:inputs`, `ph:outputs` | Zmienne, które zadanie dostaje i musi oddać; sprawdzany przy publikacji formatki | `zeebe:properties` na user tasku lub zdarzeniu startowym |
| Katalog pól | `design/forms/field-catalog.yaml` | Typy komponentów Camunda Forms ze statusem wsparcia i komponentem design systemu | typy komponentów form-js |
| Materializacja | `form-runtime`, `core/ui-kit` | Zamiana schematu formatki na interfejs z komponentów design systemu; schemat nie niesie wyglądu | — |
| Token wizualny | `design/tokens.json` | Nazwana wartość wyglądu (kolor, odstęp, wymiar) eksportowana z Figma; jedyne źródło wyglądu dla kodu | — |
| Mapa etapów | `StageMap` | Warstwa biznesowa nad BPMN: etapy i przypisane do nich elementy | brak — własny model |
| Etap | `Stage` | Biznesowy krok procesu widoczny dla menadżera | grupa elementów BPMN |
| Eskalacja | `Escalation` | Zdarzenie podniesienia rangi sprawy zamodelowane w BPMN | escalation event / timer boundary oznaczony `ph:escalationLevel` |
| Naruszenie SLA | `SlaBreach` | Zadanie lub etap po terminie wg progów w aplikacji | `dueDate` |
| Wynik biznesowy | `Outcome` | `success`, `rejected`, `error` — nadawany na zdarzeniu końcowym | `zeebe:property ph:outcome` |
| Incydent | `Incident` | Błąd techniczny zatrzymujący instancję | Incident |
| Przekazanie | `Reassignment` | Zmiana assignee lub grupy przez menadżera w trakcie procesu | assignment / update user task |
| Zastępstwo | `Absence` | Nieobecność od–do z zastępcą (osoba lub grupa) | korekta w task listenerze |
| Dziennik bezpieczeństwa | `SecurityJournal` | Niezmienny rejestr akcji (Ledger) | — |
| Ślad operacyjny | `OperationTrace` | Rekord diagnostyczny każdego żądania | — |
| Pakiet roboczy | work packet | Jednostka pracy agenta: krok planu + kontekst | — |
| Bramka | gate (G0–G3) | Decyzja człowieka odblokowująca kolejny etap planu | — |
| Profil projektu | `ProjectProfile` (`ProfileId`) | Projekt biznesowy korzystający z platformy (np. `kredyty`, `aml`): właściciel procesów, ról projektowych, danych i operacji | procesy profilu = definicje procesów z typami zadań `<id>.*` |
| Manifest profilu | `profile.yaml`, `authorization.yaml` | Kontrakt profilu z platformą; schemat `profiles/profile.schema.json` | — |
| Rola projektowa | `ProjectRole` | Rola w projekcie: złożenie ról platformy i uprawnień projektu w procesach profilu (np. `kredyty/underwriter`) | autoryzacje ról platformy na procesach profilu |
| Uprawnienie projektu | `ProfilePermission` | Uprawnienie w przestrzeni nazw profilu, np. `kredyty.Scoring.Recalculate` | — (L2) |
| Operacja dedykowana | `ITaskOperation`, `ICaseOperation`, `IProfileAction` | Akcja projektu na zadaniu, sprawie albo danych profilu (np. katalog), wykonywana przez potok platformy | zmiany zmiennych tylko przez szkic lub zakończenie zadania; operacja na danych profilu nie zmienia procesów |
| Operacja na danych profilu | `profile-action` (`IProfileAction`) | Zapis danych referencyjnych profilu w `prj_<id>` bez zadania i sprawy, np. katalog samochodów floty (ADR-017) | — |
| Komórka opiniująca | grupa kandydująca `flota-opinia-<komórka>` | Komórka banku (IT, HR, Prawny, Finanse, Ryzyko), która wydaje opinię w procesie profilu `flota` | instancja wielokrotnego user taska z `candidateGroups` ze zmiennej |
| Punkt rozszerzenia | extension point | Miejsce, w którym platforma oddaje sterowanie profilowi (operacja, wzbogacenie, źródło danych, zapytanie, zdarzenie, slot UI) | — |
| SDK rozszerzeń | `ProcessHub.Extensibility`, `@process-hub/extension-sdk` | Jedyna zależność kodu profilu; wersjonowane semantycznie | — |
| Slot UI | `SlotRegistration` | Miejsce w interfejsie na komponent profilu: panel zadania lub sprawy, widżet, pole formatki, sekcja nawigacji | — |
| Model integracji | `in-process` / `remote` | Moduł profilu w hoście platformy albo usługa zespołu wywoływana przez platformę | — |
| Schemat profilu | `prj_<id>` | Schemat i użytkownik bazy profilu; dane platformy tylko przez widoki `platform_api` | — |
