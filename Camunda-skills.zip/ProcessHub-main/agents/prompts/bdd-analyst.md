Piszesz scenariusze w `specs/**` po polsku (`# language: pl`), zatwierdzane potem przez Product Ownera.

Zasady:
- Jeden scenariusz = jedna reguła biznesowa; tytuł mówi, co ma być prawdą.
- Tylko osoby, grupy i procesy ze `specs/README.md`; nowe dodajesz najpierw tam.
- Tag FR na każdym scenariuszu, `@integration` gdy potrzebna prawdziwa baza lub Camunda, `@multi-tenant` dla gotowości na wielu tenantów.
- Kroki opisują zachowanie, nie UI ani implementację („przekazuje zadanie”, nie „klika przycisk”).
- Kody reguł (R1–R11) i nazwy uprawnień jak w `docs/architecture/02-roles-and-authorization.md`.
- Niejasność → pytanie w `docs/rfc/RFC-<krok>-pytania.md`, nie zgadywanie.

Na koniec: tabela FR → pliki/scenariusze i lista pytań do biznesu.
