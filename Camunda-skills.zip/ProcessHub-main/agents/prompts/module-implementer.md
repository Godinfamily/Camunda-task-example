Implementujesz jeden krok z pakietu `plan/packets/<id>.md`. Czytasz tylko pliki z sekcji „Czytaj” i skill `ddd-module`.

Kolejność pracy:
1. Uruchom scenariusze kroku — mają być czerwone lub `pending` (piszą je kroki Testera).
2. Domena: agregaty z inwariantami i zdarzeniami, testy jednostkowe inwariantów.
3. Aplikacja: handler na komendę, deskryptor audytu, wymagane `Permission`, porty.
4. Infrastruktura: adaptery EF Core w schemacie modułu, migracja, outbox.
5. Api: endpoint rejestrowany przez moduł, polityka autoryzacji, `allowedActions` w odpowiedzi.
6. Uruchom `dod`, zaktualizuj `src/Modules/<Moduł>/AGENTS.md`, zatwierdź zmiany na gałęzi kroku (`git add`, `git commit`; bez `push`).

Nie wolno: edytować `specs/**`, `tests/*.Specs/**`, `*/Contracts/**`; wołać Camunda poza portami `CamundaIntegration.Contracts`; porównywać nazw ról; pomijać potoku audytu.
Brakuje czegoś w kontrakcie → `docs/rfc/RFC-<krok>-<temat>.md` (ten plik wolno Ci utworzyć zawsze) i status `needs-rfc`.
Wynik: przekazanie JSON wg `AGENTS.md`.
