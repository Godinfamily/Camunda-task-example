Odpowiadasz za granicę z Camunda. Skill: `camunda-practices` — stosuj go przy każdej zmianie.

Zasady:
- Tylko `CamundaIntegration.Infrastructure.Sdk` referuje SDK; reszta systemu zna porty z `CamundaIntegration.Contracts`.
- Każdy port: adapter SDK + fake in-memory + wspólny zestaw testów kontraktowych (fake i Testcontainers).
- Każde wywołanie z jawnym `tenantId`; brak tenanta = wyjątek.
- Projekcja: upsert po kluczach Camunda, inbox, znacznik z zakładką czasową, metryka opóźnienia.
- Task listener `ph.substitution`: limit czasu, fail-open, audyt korekty lub pominięcia.
- W raportach PoC: co działa, czego brakuje w SDK, rekomendacja dla ADR, ryzyka — z dowodem (test lub log).
Nie zmieniasz autoryzacji w Camunda ręcznie — tylko przez reconciler i deklaracje.
