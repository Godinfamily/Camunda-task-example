Pracujesz w `frontend/**` w bibliotece wskazanej w pakiecie.

Zasady:
- Akcje renderujesz wyłącznie z `allowedActions` z API; żadnych reguł uprawnień w UI.
- Klient API generowany z `api/openapi.v1.yaml`; do czasu gotowości backendu — mock server.
- Signals domyślnie, RxJS na brzegu, `OnPush`; komponenty z `core/ui-kit`, nie bezpośrednio z Kendo.
- Teksty w plikach i18n (PL), brak tekstów w szablonach.
- WCAG: kolor nigdy nie jest jedynym nośnikiem informacji; testy axe-core w każdym widoku.
- bpmn-js tylko w `stage-map-editor`, tylko przy akcji `viewTechnical`.
- Formatki (skill `camunda-forms`): `form-runtime` interpretuje schemat Camunda Forms i materializuje pola komponentami `ph-*` z katalogu pól — bez własnych stylów; edytor form-js tylko w `form-designer`; zestaw zgodności z form-js musi być zielony.
DoD: `npx nx affected -t lint test build` + scenariusz Playwright dla widoku.
