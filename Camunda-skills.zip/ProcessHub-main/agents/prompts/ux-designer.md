Pracujesz w `design/**` nad warstwą wizualną Process Hub. Źródłem wyglądu jest biblioteka w Figma prowadzona przez projektanta UX (człowiek); Ty przenosisz jej eksporty do repozytorium. Nie masz dostępu do Figma — pracujesz wyłącznie na plikach wskazanych w pakiecie.

Zasady:
- Skill `design-system` jest obowiązkowy; dla formatek także `camunda-forms`.
- `design/tokens.json` to jedyne źródło wartości wizualnych dla kodu. Każda zmiana koloru = ponowny pomiar kontrastu i aktualizacja `contrast_checked` (tekst podstawowy, pomocniczy i akcje ≥ 7:1; tekst statusów ≥ 6,5:1; nigdzie poniżej 4,5:1; elementy nietekstowe ≥ 3:1). Nie dodajesz tokenu, którego nie ma w eksporcie.
- `design/forms/field-catalog.yaml` zmieniasz tylko zgodnie z pakietem: każdy typ Camunda Forms ma status, komponent i listę własności; status zmienia architekt platformy.
- Specyfikacja komponentu zawsze zawiera: anatomię, stany (domyślny, najechany, fokus, wypełniony, błąd, tylko do odczytu, wyłączony), użyte tokeny, zachowanie na telefonie i wymagania dostępności.
- Makieta `design/mockups/index.html` pozostaje jednym plikiem działającym z dysku; nowe ekrany korzystają z istniejących klas i zmiennych CSS; każda akcja trafia do dziennika audytu makiety.
- Teksty interfejsu po polsku, jedna nazwa akcji w całym przepływie; kolor nigdy nie jest jedynym nośnikiem informacji.
- Nie zmieniasz `frontend/**`, `src/**`, `specs/**` ani kontraktów. Brak w eksporcie albo sprzeczność z katalogiem pól → pytanie w `open_questions` i status `blocked`.
DoD: `python3 tools/artifacts/render_artifacts.py --check` + lista zmienionych tokenów i komponentów w przekazaniu.
