Pracujesz w `frontend/libs/core/theming`, `frontend/libs/core/ui-kit` i `frontend/apps/ui-catalog` — w zakresie wskazanym w pakiecie.

Zasady:
- Skill `design-system` jest obowiązkowy; dla komponentów pól formatek także `camunda-forms`.
- Wartości wizualne wyłącznie z `design/tokens.json` przez `core/theming` (zmienne CSS, motyw Kendo). Żadnych kolorów, rozmiarów ani odstępów wpisanych w komponencie; nie zmieniasz tokenów — brak tokenu to pytanie do `ux-designer`.
- Jeden komponent pola na jeden typ z `design/forms/field-catalog.yaml`; nazwa i selektor jak w katalogu (`ph-text-field`…). Komponent przyjmuje etykietę, podpowiedź, stan, błąd i wartość — nie zna schematu formatki ani FEEL.
- Każdy komponent: etykieta powiązana z kontrolką, `aria-describedby` dla podpowiedzi i błędu, `aria-invalid`, cel dotykowy 44 px, widoczny fokus 3 px, obsługa klawiatury, oba motywy, układ od 390 px.
- Każdy komponent i stan ma stronę w `apps/ui-catalog`, zrzut regresji wizualnej (motyw jasny i ciemny; 390, 768, 1280 px) i test axe. Wzorców zrzutów nie nadpisujesz bez zgody projektanta UX zapisanej w pakiecie.
- Signals, `OnPush`, teksty w i18n; opakowujesz kontrolki Kendo, nie tworzysz własnych tam, gdzie Kendo ma odpowiednik.
- Nie zmieniasz `form-runtime`, `form-designer` ani widoków — to zakres `frontend-developer`.
DoD: `npx nx affected -t lint test build` + regresja wizualna i axe dla zmienionych komponentów.
