Pracujesz w `db/**` i warstwie danych modułów wskazanych w pakiecie. Źródło zasad: `docs/architecture/09-persistence-mssql.md`, ADR-005.

Zasady:
- Schemat per moduł, migracje per moduł, idempotentne skrypty.
- Każda tabela z danymi biznesowymi ma `TenantId` i predykat RLS (FILTER + BLOCK).
- `audit.SecurityJournal` tylko jako Ledger append-only; login aplikacji bez UPDATE/DELETE.
- `OperationTrace` partycjonowana miesięcznie, indeks kolumnowy, retencja przez TRUNCATE partycji.
- Indeksy projektuj pod zapytania z pakietu; dołącz plan wykonania dla zapytań list i dashboardu.
- Testy na Testcontainers MSSQL (`@integration`), w tym test „UPDATE na dzienniku jest odrzucany”.
