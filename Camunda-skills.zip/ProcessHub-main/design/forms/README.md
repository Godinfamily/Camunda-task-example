# Formatki — założenia wizualne i kontrakt materializacji

Formatka jest opisana schematem Camunda Forms, ale wygląda jak reszta Process Hub. Ten dokument mówi, jak to osiągamy: co ustala biznes, co design system, jak każdy typ pola zamienia się w komponent i jak zmiany z Figma trafiają do kodu. Opis działania modułu: `docs/architecture/14-form-management.md`; decyzja: ADR-019; maszynowa wersja kontraktu: `field-catalog.yaml`.

## 1. Koncepcja: trzy warstwy

```mermaid
flowchart LR
    S["Struktura<br/>schemat Camunda Forms<br/>pola · typy · teksty · walidacje · warunki · wiersze"] --> M["Materializacja<br/>katalog pól<br/>typ → komponent ui-kit"]
    T["Wygląd<br/>tokeny z Figma<br/>kolory · typografia · odstępy · kontrolki"] --> M
    M --> UI["Formatka na zadaniu<br/>spójna z całym systemem"]
```

| Warstwa | Kto decyduje | Gdzie żyje | Jak się zmienia |
| --- | --- | --- | --- |
| Struktura | menadżer i administrator procesu | wersja formatki (schemat) | szkic → przegląd → zatwierdzenie → publikacja |
| Materializacja | zespół design systemu z architektem | `field-catalog.yaml`, `core/ui-kit` | pull request, regresja wizualna |
| Wygląd | projektant UX | Figma → `design/tokens.json` → `core/theming` | eksport z Figma jako pull request |

Skutek: zmiana tokenów albo komponentu poprawia wygląd wszystkich formatek naraz, bez nowych wersji; zmiana formatki nigdy nie zmienia wyglądu systemu.

## 2. Co ustala biznes, a czego nie

| Biznes ustawia w projektancie | Design system ustala raz dla całej aplikacji |
| --- | --- |
| typ pola z katalogu, etykietę, podpowiedź, wartość domyślną | krój, rozmiary i grubości tekstu |
| wymagalność, długości, zakresy, wzorzec, format daty | kolory, obramowania, promienie, cienie |
| warunek widoczności, tylko do odczytu, wyłączenie (także wyrażeniem FEEL) | wysokość i wypełnienie kontrolek, fokus |
| opcje wyboru (stałe, ze zmiennej, z wyrażenia) | odstępy między polami, sekcjami i wierszami |
| kolejność pól, wiersze i szerokości (2–16 z 16 kolumn) | wygląd błędu, podpowiedzi, znacznika „wymagane” |
| sekcje i listy powtarzane, teksty objaśniające, linie podziału | zachowanie na telefonie, motyw jasny i ciemny |
| przedrostek i przyrostek pola (np. „PLN”) | teksty systemowe: komunikaty walidacji, „Dodaj pozycję”, „Usuń” |

Projektant nie pokazuje własności, których katalog nie dopuszcza. Schemat Camunda Forms nie ma pól na kolor czy krój — jedyne własności bliskie wyglądowi to układ w siatce, przedrostki, wysokość odstępu i obrys sekcji, a te design system zamienia na własne wartości.

## 3. Anatomia pola

```
Etykieta (wymagane)            ← 700; słowo „(wymagane)”, nie sama gwiazdka
[ kontrolka 44 px            ] ← obramowanie line-strong, promień 6, fokus 3 px
Podpowiedź                     ← 14 px, ink-2
■ Komunikat błędu              ← 14 px, 700, crit, z kwadratowym znacznikiem
```

- Odstępy z `design/tokens.json`: etykieta–kontrolka 6 px, kontrolka–podpowiedź 4 px, pole–pole 16 px.
- Podpowiedź i błąd są powiązane z kontrolką przez `aria-describedby`; błąd ustawia `aria-invalid`.
- Grupy opcji (`radio`, `checklist`) to `fieldset` z `legend`; każda opcja ma cel dotykowy 44 px.
- Pole tylko do odczytu pokazuje wartość jako tekst na tle `surface-2`, bez obramowania kontrolki; pole wyłączone ma obniżony kontrast i nie przyjmuje fokusu.
- Stany każdego komponentu w Figma i w katalogu komponentów: domyślny, najechany, fokus, wypełniony, błąd, tylko do odczytu, wyłączony — w obu motywach.

## 4. Układ

- Schemat układa pola w wierszach (`layout.row`) w siatce 16 kolumn (`layout.columns` 2–16; brak wartości = równy podział wiersza). Design system odwzorowuje to w siatce CSS z odstępem kolumn 16 px.
- Formatka ma szerokość do 880 px i jest wyrównana do lewej krawędzi panelu zadania; nie rozciąga pól na całą szerokość szerokiego ekranu.
- Poniżej 600 px każde pole zajmuje pełną szerokość, w kolejności ze schematu; nic nie przewija się w poziomie (od 390 px).
- Sekcja (`group`) to `fieldset` z nagłówkiem; `showOutline` rysuje obramowanie panelu (promień 8, wypełnienie 16 px). Sekcje można zagnieżdżać najwyżej do dwóch poziomów — głębsze zagnieżdżenie zgłasza ostrzeżenie w projektancie.
- Lista powtarzana (`dynamiclist`) pokazuje pozycje jako kolejne sekcje z numerem; przyciski „Dodaj pozycję” i „Usuń” pochodzą z design systemu i mają opisy dla czytników ekranu.
- `spacer` zaokrągla wysokość do skali odstępów (4, 8, 12, 16, 24, 32, 48 px); `separator` to linia `line` z odstępem 16 px.

## 5. Walidacja i komunikaty

- Walidacja przy opuszczeniu pola i przy „Zakończ zadanie”; „Zapisz szkic” nie wymaga poprawności.
- Po nieudanej próbie zakończenia nad formatką pojawia się podsumowanie błędów z odnośnikami do pól, a fokus przechodzi na podsumowanie. Formatka nie gubi wpisanych danych.
- Komunikaty walidacji pochodzą z plików i18n aplikacji („Podaj wartość”, „Najwyżej 5000 znaków”), nie z formatki — wyjątkiem jest `patternErrorMessage` pola tekstowego.
- Błąd z serwera (np. pole wymagane warunkowo) pokazuje się tak samo jak błąd z przeglądarki.
- Kolor nigdy nie jest jedynym nośnikiem: błąd ma znacznik i tekst, pole wymagane ma słowo.

## 6. Tryby formatki

| Tryb | Kiedy | Wygląd |
| --- | --- | --- |
| Edycja | zadanie przejęte przez bieżącą osobę | kontrolki aktywne; akcje „Zapisz szkic”, „Zakończ zadanie” z `allowedActions` pod formatką |
| Odczyt | każda inna osoba z wglądem | wartości jako tekst; nad formatką jedno zdanie, kto może edytować |
| Podgląd | zakładka „Podgląd jak u wykonawcy” w projektancie | jak edycja, z danymi przykładowymi; przełącznik motywu i szerokości |
| Niedostępna | brak wersji obowiązującej (wycofanie bez zastępczej) | komunikat w miejscu formatki; zakończenie zablokowane |

Przyciski akcji nie należą do formatki — renderuje je powłoka. Dlatego typ `button` jest zablokowany w katalogu.

## 7. Mapowanie typów na komponenty

Pełne dane (własności, ograniczenia, nazwy w Figma): `field-catalog.yaml`.

| Typ Camunda Forms | Nazwa w palecie | Komponent `ui-kit` | Podstawa Kendo | Status |
| --- | --- | --- | --- | --- |
| `textfield` | Pole tekstowe | `ph-text-field` | `kendo-textbox` | wspierany |
| `textarea` | Tekst długi | `ph-textarea` | `kendo-textarea` | wspierany |
| `number` | Liczba | `ph-number-field` | `kendo-numerictextbox` | wspierany |
| `datetime` | Data i czas | `ph-date-field` | `kendo-datepicker`, `-timepicker`, `-datetimepicker` | wspierany |
| `checkbox` | Pole wyboru | `ph-checkbox` | `kendo-checkbox` | wspierany |
| `checklist` | Lista pól wyboru | `ph-checklist` | `fieldset` + `kendo-checkbox` | wspierany |
| `radio` | Wybór jednej opcji | `ph-radio-group` | `fieldset` + `kendo-radiobutton` | wspierany |
| `select` | Lista rozwijana | `ph-select` | `kendo-dropdownlist` / `kendo-combobox` | wspierany |
| `taglist` | Wybór wielu wartości | `ph-taglist` | `kendo-multiselect` | wspierany |
| `group` | Sekcja | `ph-group` | `fieldset` | wspierany |
| `dynamiclist` | Lista powtarzana | `ph-repeater` | własny na `ui-kit` | wspierany |
| `table` | Tabela | `ph-data-table` | `kendo-grid` (odczyt) | wspierany |
| `expression` | Pole wyliczane | — (bez interfejsu) | — | wspierany |
| `separator` | Linia podziału | `ph-separator` | — | wspierany |
| `text` | Tekst | `ph-text-block` | — | z ograniczeniami: Markdown bez HTML |
| `spacer` | Odstęp | `ph-spacer` | — | z ograniczeniami: skala odstępów |
| `image` | Obraz | `ph-image` | — | z ograniczeniami: zasób osadzony, tekst alternatywny |
| `filepicker`, `documentPreview` | Załącznik, Podgląd dokumentu | `ph-file-field`, `ph-document-preview` | `kendo-upload` | planowane (decyzja D-15) |
| `html`, `iframe`, `button` | — | — | — | zablokowane |

Pole profilu (slot `form.field`) to typ bazowy z własnością `ph:field`; w palecie ma nazwę z manifestu profilu i znacznik „profil”, a wygląda jak każde inne pole, bo komponent profilu buduje się z `ui-kit` i tokenów.

## 8. Projektant formatek

- **Układ ekranu:** nagłówek ze stanem i akcjami → „Miejsce w procesie” (wstęga etapów, powiązania, kontrakt danych) → zakładki „Projekt”, „Podgląd jak u wykonawcy”, „Wersje”, „Historia”.
- **Zakładka „Projekt”** osadza edytor form-js: paleta, kanwa, panel właściwości. Otoczenie edytora (nagłówki paneli, tło, obramowania) używa tokenów; sama kanwa zachowuje wygląd biblioteki, a znak bpmn.io pozostaje widoczny i niczym nieprzysłonięty.
- **Znaczniki stanu wersji** (kształt + słowo, jak w całym systemie): Szkic — neutralny; W przeglądzie — ostrzeżenie; Zatwierdzona — informacja; Opublikowana — poprawny; Zastąpiona — neutralny; Wycofana — krytyczny.
- **Nazwy akcji** są takie same na przycisku, w oknie potwierdzenia i w komunikacie: „Zapisz szkic”, „Przekaż do przeglądu”, „Cofnij z przeglądu”, „Odrzuć do poprawy”, „Zatwierdź”, „Opublikuj”, „Utwórz nową wersję”, „Wycofaj wersję”, „Wycofaj formatkę”, „Importuj”, „Eksportuj”.
- **Przegląd** pokazuje różnicę względem wersji obowiązującej: pola dodane, usunięte i zmienione z listą własności; zablokowany przycisk „Zatwierdź” ma obok jedno zdanie o regule czterech oczu.
- **Wycofanie** to okno potwierdzenia z powodem (lista + opis), wyborem wersji zastępczej, wyborem skutku dla zadań w toku i liczbami: ile zadań jest na tej wersji, ile zadań procesu wskazuje formatkę.

## 9. Z Figma do kodu

```mermaid
flowchart LR
    F["Figma: biblioteka Process Hub<br/>zmienne · komponenty pól · wzorce"] -->|eksport: zmienne JSON, specyfikacje| PR["Pull request w design/**<br/>ux-designer + projektant UX"]
    PR --> TOK["design/tokens.json<br/>design/forms/field-catalog.yaml"]
    TOK --> TH["core/theming<br/>zmienne CSS, motyw Kendo"]
    TOK --> KIT["core/ui-kit<br/>komponenty pól"]
    KIT --> CAT["apps/ui-catalog<br/>wszystkie stany"]
    CAT -->|zrzuty Playwright, axe| REV["ui-reviewer + projektant UX<br/>zatwierdzenie wzorców"]
```

1. Projektant UX prowadzi w Figma jedną bibliotekę: zmienne (kolory, typografia, odstępy, promienie, wymiary kontrolek), komponenty pól z kompletem stanów i wzorce formularza. Nazwy komponentów pól są zapisane w katalogu (`figma`).
2. Zmiana wyglądu to eksport zmiennych i specyfikacji do pull requestu w `design/**`. Agenci nie mają dostępu do Figma — pracują na plikach w repozytorium (ADR-016).
3. Każda zmiana kolorów przechodzi ponowny pomiar kontrastu (`contrast_checked` w `design/tokens.json`): tekst podstawowy, pomocniczy i akcje ≥ 7:1 (cel AAA), tekst statusów ≥ 6,5:1, żaden tekst poniżej 4,5:1 (wymóg AA), elementy nietekstowe ≥ 3:1.
4. `core/theming` generuje z tokenów zmienne CSS i motyw Kendo; komponenty nie zawierają wartości „na sztywno” (lint).
5. Katalog komponentów pokazuje każdy komponent w każdym stanie; zrzuty w motywie jasnym i ciemnym przy 390, 768 i 1280 px są porównywane ze wzorcami. Wzorce zmienia się tylko za zgodą projektanta UX.

## 10. Jak dodać albo zmienić typ pola

1. Wpis w `field-catalog.yaml` (status, komponent, własności, ograniczenie) — przegląd architekta i projektanta UX.
2. Komponent w Figma ze stanami; specyfikacja w tym dokumencie (tabela w sekcji 7).
3. Komponent w `core/ui-kit` i wpis w rejestrze `form-runtime`; `IFieldType` w `FormRuntime` (walidacja na serwerze).
4. Formatka wzorcowa w zestawie zgodności i wzorce regresji wizualnej.
5. Testy parytetu (katalog ↔ rejestr ↔ `IFieldType`) i axe zielone.

## 11. Lista kontrolna przeglądu formatki i komponentu

- Każde pole wprowadzania ma etykietę; podpowiedź mówi, co wpisać, a nie powtarza etykietę.
- Kolejność fokusu = kolejność czytania; nic nie wymaga myszy.
- Błąd wskazuje pole i mówi, jak go poprawić.
- Formatka mieści się na telefonie bez przewijania w poziomie i działa przy powiększeniu 200%.
- Żadnych wartości kolorów, rozmiarów ani odstępów poza tokenami.
- Wygląd w obu motywach sprawdzony w katalogu komponentów.
