# Makieta UI Process Hub — propozycja projektowa

Makieta to jeden plik `mockups/index.html`: klikalna aplikacja z przełącznikiem „Podgląd jako”, który pokazuje ten sam system oczami dziewięciu osób — sześciu z ról platformy i trzech z przykładowego profilu projektu „Flota samochodowa” (`profiles/flota/`). Wszystkie akcje działają na danych w pamięci i od razu pojawiają się w dzienniku audytu (widok audytora), więc na pokazie widać zasadę „każda akcja jest audytowana”. Otwórz plik w przeglądarce — bez serwera i bez instalacji.

Zaczynasz pracę nad interfejsem? Najpierw `docs/artifacts/04-wytyczne-ui.md` (wytyczne i założenia w jednym miejscu), potem ten dokument, `forms/README.md` (formatki) i makieta.

## Kierunek wizualny

Biel i czerwień jak barwy Polski, ale użyte oszczędnie, bo to narzędzie pracy na cały dzień, nie plakat.

- **Biel nad czerwienią:** biały pasek aplikacji kończy się 4-pikselowym pasem flagowej czerwieni. To jedyne miejsce, gdzie czerwień działa jako znak.
- **Wstęga etapów** jest jedynym mocnym elementem wizualnym: etapy procesu jako segmenty biało-czerwonej wstęgi, bieżący etap w pełnej czerwieni. Ten sam komponent wraca w zadaniu, sprawie, „moich procesach”, edytorze formatki i mapie etapów, więc menadżer uczy się go raz.
- **Liczby jako pasek księgowy**, nie siedem jednakowych kafelków: jedna linia wartości oddzielonych pionowymi kreskami, czytana jak zestawienie w raporcie banku.
- **Krój Lato** — zaprojektowany przez polskiego typografa Łukasza Dziedzica, z pełnym wsparciem polskich znaków; jeden krój, hierarchia przez grubość (400/700/900).

### Paleta (sprawdzone kontrasty WCAG)

| Token | Jasny | Ciemny | Użycie | Kontrast |
| --- | --- | --- | --- | --- |
| `flag-red` | #DC143C | #DC143C | pas pod paskiem aplikacji, akcenty nietekstowe | 4,99:1 — dlatego nie dla tekstu |
| `action` | #A10F2B | #FF6B7E | przyciski główne, linki, bieżący etap | 8,02:1 na bieli (AAA) |
| `ink` / `ink-2` | #1F2328 / #4A5059 | #ECEDEF / #B5BAC1 | tekst / tekst pomocniczy | 15,8:1 / 7,45:1 |
| `ok`, `warn`, `crit`, `info` | ciemne odcienie na jasnym tle | jasne odcienie na ciemnym tle | statusy | każdy ≥ 6,5:1 |

**Konflikt czerwieni marki i czerwieni alarmu** rozwiązuje kształt i słowo: status krytyczny ma kwadratowy znacznik i etykietę („Krytyczne”, „Odmowa R2”), ostrzeżenie — trójkąt, poprawny — koło. Kolor nigdy nie jest jedynym nośnikiem informacji (WCAG 1.4.1). Wartości dla Kendo ThemeBuilder: `tokens.json` (do potwierdzenia z księgą znaku banku). Źródłem wyglądu jest biblioteka w Figma prowadzona przez projektanta UX; `tokens.json` jest jej eksportem i jedynym źródłem dla kodu — oprócz kolorów zawiera skalę odstępów, wymiary kontrolek, siatkę formatek i progi szerokości (`forms/README.md`, sekcja 9).

## Architektura informacji

Nawigacja jest liczona z uprawnień, nie z nazwy roli — dokładnie tak jak `allowedActions` w API. Osoba z kilkoma rolami (Piotr) widzi sumę sekcji.

| Sekcja | Pozycje | Kto widzi |
| --- | --- | --- |
| Praca | Pulpit, Zadania, Start procesu, Moje procesy, Zastępstwa | uczestnik, inicjator |
| Nadzór | Panel procesu, Eskalacje, Sprawy, Przekazanie masowe | menadżer procesu (audytor bez przekazywania) |
| Konfiguracja procesu | Mapa etapów, Formatki | menadżer i administrator procesu |
| Kontrola | Dziennik audytu, Uprawnienia | audytor, administrator platformy |
| Flota (sekcja profilu) | Katalog samochodów | wyłącznie role profilu „Flota samochodowa” (Tomasz, Hanna, Karol); zmiany katalogu — tylko administrator katalogu |

**Sekcje profili projektów.** Profil może dodać własną sekcję nawigacji (slot `nav.section`) z trasami `/p/<id>/…`. Sekcja stoi pod sekcjami platformy, ma znacznik „profil” i używa tych samych tokenów co reszta aplikacji. Widzą ją tylko osoby z uprawnieniem trasy; wejście z adresu kończy się stroną „Brak dostępu” z informacją, do którego profilu należy strona, i wpisem w dzienniku. Przyciski na stronie profilu (np. „Dodaj model”) przychodzą z `allowedActions`, tak jak na ekranach platformy. Jak budować takie elementy: `docs/guides/dedykowane-elementy-profilu.md`.

## Ekrany i wymagania

| Ekran (trasa) | Wymagania | Co pokazuje |
| --- | --- | --- |
| Pulpit `#/start` | FR-01, FR-08, FR-14 | sekcje zależne od ról: moje zadania, moje procesy, zdrowie procesów, zadania konfiguracyjne, ostatnie wpisy dziennika |
| Zadania `#/zadania` | FR-01–FR-03, FR-22 | zakładki Moje / Do przejęcia / Mojej grupy / Wszystkie; zapisany widok; na telefonie wiersze jako karty |
| Zadanie `#/zadanie/T-2041` | FR-04–FR-06, FR-18 | wstęga z zaznaczonym etapem zadania, formatka z pomocą przy polach, blokada edycji dla nie-assignee z wyjaśnieniem, podsumowanie błędów, potwierdzenie zakończenia |
| Start procesu `#/start-procesu` | FR-07 | katalog tylko dozwolonych procesów, formatka startowa, załącznik jako odnośnik |
| Moje procesy, Sprawy, Sprawa `#/sprawa/K-0136` | FR-08, FR-10, FR-16 | wstęga etapów, eskalacja i blokada słowami, historia biznesowa; model BPMN tylko dla administratora procesu |
| Panel procesu `#/panel` | FR-14 | liczniki wyników (sukces / negatywnie / błąd osobno), werdykt zdrowia, wąskie gardło etapów, trend, czasy etapów; każdy wykres ma tabelę danych |
| Eskalacje `#/eskalacje` | FR-13 | eskalowane vs po terminie, przekazanie z listy |
| Przekazanie (okno) i przekazanie masowe | FR-11 | osoba lub grupa, obowiązkowy powód, tylko uprawnione osoby, raport partii |
| Zastępstwa `#/zastepstwa` | FR-12 | nieobecność od–do, zastępca, walidacja nakładania się |
| Mapa etapów `#/mapa-etapow` | FR-15 | administrator: diagram tylko do odczytu, lista elementów, przypisanie, walidacja, publikacja; menadżer: nazwy i SLA etapów, bez diagramu |
| Formatki `#/formatki`, projektant `#/formatka/F-ocena` | FR-16, FR-17, FR-28–FR-31 | formatki wybranego procesu (R11), miejsce formatki na wstędze, kontrakt danych zadania, cztery oczy (R8), wersje ze stanami, wycofanie wersji z powodem i wersją zastępczą, podgląd jak u wykonawcy; w produkcie zakładka „Projekt” osadza edytor form-js z paletą z katalogu pól |
| Dziennik audytu `#/audyt` | FR-19, FR-20 | dziennik z rolą uzasadniającą, odmowy, integralność Ledger, ślad operacyjny dla wsparcia |
| Uprawnienia `#/uprawnienia` | FR-21, FR-24 | macierz ról, przypisania grup AD, role projektowe profili, zgodność z Camunda, zmiany tylko przez PR |
| Katalog samochodów `#/p/flota/katalog` (profil Flota) | FR-25, FR-27, FLO-FR-01…03 | strona profilu z sekcji „Flota”: modele z filtrami, liczba wniosków w toku; administrator katalogu: „Dodaj model”, „Zmień”, „Wycofaj”, „Przywróć” z walidacją polityki floty (CO2 do 130 g/km) i wpisem w dzienniku; wnioskodawca: „Złóż wniosek” z wybranym modelem; pozostali — tylko podgląd; spoza profilu — odmowa |
| Widżet „Katalog samochodów” na pulpicie | FR-27 | slot `dashboard.widget` profilu: liczba dostępnych modeli, ostatnia zmiana, odnośniki |
| Wniosek o samochód `#/start-procesu/rejestracja-samochodu` | FR-07, FLO-FR-03 | pole profilu „Model samochodu z katalogu” (tylko dostępne modele), błędy bez utraty danych, sprawa w „Moich procesach” |
| Opinia komórki `#/zadanie/T-2051` | FR-04–FR-06, FLO-FR-04 | wstęga sprawy nadrzędnej z etapem „Opiniowanie” (proces podrzędny), formatka opinii: pozytywna, z warunkami, negatywna; każda komórka widzi tylko swoje zadanie |

## Wzorce interakcji

- **Akcje z `allowedActions`:** przycisk, którego nie wolno użyć, nie istnieje; zamiast niego jest jedno zdanie, dlaczego („Edytować może tylko osoba, która przejęła zadanie: …”).
- **Jedna nazwa akcji w całym przepływie:** „Przekaż zadanie” → komunikat „Przekazano…”, „Opublikuj” → „Opublikowano…”.
- **Błędy:** podsumowanie na górze z odnośnikami do pól + komunikat przy polu; formularz nie gubi danych.
- **Decyzje nieodwracalne** (zakończenie zadania, przekazanie, publikacja) przez okno potwierdzenia z podsumowaniem skutku.
- **Puste stany mówią, co zrobić dalej**, a odmowa dostępu mówi, że próba trafiła do dziennika.

## Dostępność

Link „Przejdź do treści”, okruszki na każdym widoku (WCAG 2.4.8), fokus na nagłówku po zmianie widoku, widoczny fokus 3 px, cele dotykowe ≥ 44 px (2.5.5), status w regionie `aria-live`, wykresy z alternatywą tabelaryczną, `prefers-reduced-motion`, motyw jasny/ciemny/systemowy, układ bez przewijania w poziomie od 390 px szerokości. Makieta przeszła automatyczny test wszystkich ról i ścieżek w przeglądarce bezgłowej; audyt axe-core i z czytnikiem ekranu to krok S53.

## Odwzorowanie w Kendo UI for Angular

| Element makiety | Komponent docelowy |
| --- | --- |
| pasek aplikacji, szuflada nawigacji | `kendo-appbar`, `kendo-drawer` |
| listy zadań i spraw | `kendo-grid` (tryb kart na wąskich ekranach, stan zapisywany w `SavedListView`) |
| zakładki, okruszki | `kendo-tabstrip`, `kendo-breadcrumb` |
| wstęga etapów | komponent własny w `core/ui-kit` (Kendo nie ma chevronowej wstęgi z flagami) |
| wykresy | `kendo-chart` (słupki poziome, linia) z tabelą danych |
| okna potwierdzeń, powiadomienia | `kendo-dialog`, `kendo-notification` |
| formatki | komponenty pól `ph-*` w `core/ui-kit` na kontrolkach Kendo — jeden na każdy typ Camunda Forms z katalogu pól (`forms/field-catalog.yaml`, tabela w `forms/README.md`) |
| projektant formatek | osadzony edytor `@bpmn-io/form-js-editor` (jak w Camunda Modelerze) z paletą ograniczoną katalogiem pól; podgląd w rendererze platformy (ADR-019) |
| diagram techniczny | bpmn-js NavigatedViewer (tylko z uprawnieniem `Bpmn.ViewTechnical`) |

## Jak dalej projektować

1. **Pokaz z rolami:** 30 minut na rolę, scenariusze z listy niżej; notujemy, gdzie ktoś się zawahał.
2. **Testy z użytkownikami:** po 5 osób na rolę (uczestnik, menadżer procesu, administrator procesu, audytor) na makiecie, zanim powstanie kod Angulara.
3. **Warsztat mapy etapów z menadżerami** dwóch procesów: czy 4–6 etapów wystarcza, które kroki techniczne muszą być widoczne jako „w toku”.
4. **Księga znaku banku i Figma:** projektant UX zakłada bibliotekę w Figma (zmienne = tokeny, komponenty pól, wzorce); eksport podmienia `tokens.json`, ponowny pomiar kontrastu (krok S09).
5. **Przeniesienie do kodu:** tokeny → Kendo ThemeBuilder → `core/theming`; komponenty pól → `core/ui-kit` z regresją wizualną (S49); ekrany → biblioteki z `docs/architecture/11-frontend.md` (kroki S40–S46).

## Scenariusze do kliknięcia

1. **Anna (uczestnik):** Zadania → Do przejęcia → Przejmij → Otwórz → Zakończ bez uzasadnienia (błędy) → uzupełnij → Zakończ.
2. **Anna:** Start procesu → Wniosek kredytowy → Moje procesy → wstęga sprawy.
3. **Marta (menadżer procesu):** Panel procesu → wąskie gardło „Ocena” → Eskalacje → Przekaż (bez powodu, potem z powodem).
4. **Marta:** Przekazanie masowe zadań osoby na urlopie → raport partii → Zastępstwa (spróbuj nakładających się dat).
5. **Marta:** Formatki → wybierz proces (lista pokazuje tylko jej procesy) → Ocena wniosku → Przekaż do przeglądu → „Zatwierdź” jest zablokowane (cztery oczy).
6. **Adam (administrator procesu):** zatwierdź i opublikuj tę formatkę → Mapa etapów → przypisz „Akceptacja klienta” → Opublikuj → Sprawa → Pokaż model BPMN.
7. **Olga (audytor):** wszystko tylko do odczytu → Dziennik audytu z akcjami z poprzednich kroków, łącznie z odmowami.
8. **Zenon (administrator platformy):** Uprawnienia → Sprawdź zgodność z Camunda; spróbuj wejść w `#/panel` — odmowa trafia do dziennika.
9. **Karol (administrator katalogu, profil Flota):** sekcja „Flota” → Katalog samochodów → Dodaj model z emisją 220 g/km (odmowa polityki floty) → popraw na 0 → Wycofaj „Toyota Corolla Touring Sports” (okno mówi, że wniosek w toku zachowa model) → filtr „Wycofane” → Przywróć.
10. **Tomasz (wnioskodawca, profil Flota):** Katalog — bez przycisków zmian → „Złóż wniosek” przy modelu → formatka z wybranym modelem → złóż bez uzasadnienia (błąd, dane zostają) → złóż → nowa sprawa w etapie „Wniosek” → Moje procesy → sprawa F-0012: etap „Opiniowanie”, zadania komórek nie są widoczne.
11. **Hanna (opiniująca z HR, profil Flota):** Zadania → T-2051 → „Pozytywna z warunkami” bez warunków (błąd) → uzupełnij → Zakończ → Do przejęcia: T-2056; zadanie Prawnego `#/zadanie/T-2053` — odmowa.
12. **Anna (kredyty):** nie ma sekcji „Flota”; wejście na `#/p/flota/katalog` — odmowa z informacją o profilu. **Olga:** dziennik pokazuje operacje `flota.*` z rolami `flota/administrator-katalogu` i `flota/opiniujacy`. **Zenon:** Uprawnienia → Role projektowe profili.
13. **Marta (wycofanie wersji):** Formatki → Ocena wniosku → zakładka „Wersje” → „Wycofaj wersję” przy v3 → bez powodu (błąd) → powód „Wada formatki”, wersja zastępcza v2, „Przepnij na wersję obowiązującą” → obowiązuje v2, v3 ma stan „Wycofana”; **Olga:** dziennik pokazuje `Form.Withdraw` i `Form.Repin`, a w formatkach ma tylko wgląd; **Piotr:** w Formatkach widzi wyłącznie proces „Weryfikacja AML”, wejście na `#/formatka/F-ocena` kończy się odmową.
