# Dashboard harmonogramu i wyceny

Interaktywny widok planu wykonawczego dla zespołu i decydentów: harmonogram kroków na osi tygodni ze ścieżką krytyczną, bramkami i warstwami (wycena, ryzyko, zakres, role, udział AI, blokery, zapas), obciążenie ról w tygodniach, złożoność a oszczędność, rejestr ryzyk i decyzji. Każda liczba na stronie wskazuje swoje źródło (zbiór danych poniżej).

| Plik | Rola |
| --- | --- |
| `index.html` | samodzielna strona (otwierana z dysku, bez serwera); jasny i ciemny motyw |
| `data.js` | wszystkie zbiory danych dla strony (`window.PH_DATA`) — generowany |
| `data/*.json` | te same zbiory osobno: `steps`, `gates`, `summary`, `phases`, `roles`, `role_weekly`, `scenarios`, `risks`, `decisions` |
| `register.yaml` | ręcznie utrzymywany rejestr ryzyk, decyzji i warunków bramek |
| `vendor/d3.v7.9.0.min.js` | biblioteka wykresów d3 (licencja ISC, `vendor/d3-LICENSE.txt`) dołączona lokalnie — strona nie pobiera nic z internetu |

## Odświeżenie po zmianie planu

```bash
python3 tools/plan/estimate.py                  # przelicza model (plan/estimation-report.md)
python3 tools/plan/export_dashboard_data.py     # zapisuje plan/dashboard/data/*.json i plan/dashboard/data.js
```

Potem wystarczy odświeżyć `index.html` w przeglądarce.

## Obserwowanie wykonania

- Status i postęp kroku: pola `status` (`Planowany`, `W toku`, `Zakończony`, `Zablokowany`) i `progress` w `steps.json` — eksporter ustawia je dziś na wartości startowe; po włączeniu śledzenia czyta je z `plan/progress/*.json`.
- Rzeczywista praca ludzi: `plan/progress/<krok>.effort.json` → kalibracja prognozy (`plan/estimation.md`, sekcja 7) → nowe tygodnie i wyceny na wykresie.
- Warstwa „Status” na harmonogramie i filtr ról pokazują, co jest w toku i kto jest potrzebny w danym tygodniu.
- Plany zespołów profili (`profiles/<id>/backlog.yaml`) nie są częścią tej wyceny — dashboard pokazuje plan platformy, a kroki profili są blokerem zewnętrznym pilotażu (S60).
