# Postęp wykonania

| Plik | Kto zapisuje | Zawartość |
| --- | --- | --- |
| `<krok>.json` | orkiestrator (przekazanie agenta), człowiek przez `plan_status.py --merged` | status `done/blocked/needs-rfc`, zmienione pliki, bramki, pytania; `merged: true` po scaleniu |
| `<krok>.gates.json` | `tools/agents/run_dod.py` | wynik każdej komendy dod, ogon logu przy błędzie |
| `<krok>.effort.json` | człowiek | `{"step": "S10", "actual_human_pd": 3.5}` — rzeczywista praca ludzi, do kalibracji wyceny |
| `gates.json` | człowiek przez `plan_status.py --approve-gate` (dopiero po scaleniu kroków z pola `after` bramki) | kto i kiedy zatwierdził bramkę, dowód |
| `logs/` | `run_dod.py` | pełne logi bramek (poza gitem) |

Narzędzia: `tools/agents/*.py` albo ich odpowiedniki .NET `ph step status | prepare | dod` (`tools/dotnet/README.md`).

Krok jest gotowy do startu, gdy wszystkie zależności mają `status: done` i `merged: true`, a bramka z `gate_before` jest w `gates.json`.

Plany zespołów profili (`profiles/<id>/backlog.yaml`) zapisują postęp w tym samym formacie w `profiles/<id>/progress/` (narzędzia z opcją `--backlog`).
