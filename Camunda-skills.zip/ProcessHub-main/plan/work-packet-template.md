# Pakiet roboczy — <ID kroku>: <tytuł>

> Generowany przez `tools/agents/prepare_step.py` z `plan/backlog.yaml`. Agent czyta tylko ten plik i pliki z sekcji „Czytaj”. Sekcje bez treści są pomijane.

## Cel
<pole `title`> · wykonawca, para, rozmiar, ścieżka krytyczna

## Wynik (co ma powstać)
<pole `outcome` — pliki, moduły i dowody, po których poznać, że krok jest zrobiony>

## Wskazówki startowe
<pole `notes` — granice z innymi krokami, decyzje D-xx, pułapki>

## Czytaj (w tej kolejności)
1. `AGENTS.md` (i `profiles/<id>/AGENTS.md` dla kroku profilu)
2. <pliki z `reads` — w całości; pilnuj budżetu kontekstu>

## Sięgaj punktowo (wyszukuj fragment, nie czytaj w całości)
<pole `refs` — duże pliki, np. makieta>

## Wejście od poprzedników
<kroki z `depends_on` z tytułem i plikiem przekazania — pytania otwarte i lista zmienionych plików>

## Wolno zapisywać (`.agent-scope`)
<globy z `writes`> oraz zawsze `docs/rfc/RFC-<ID>-<temat>.md`

## Para
<rola pary i jej część pracy: `pair_task` albo domyślna dla roli>

## Scenariusze do zaliczenia
<pliki i tagi z `specs`, np. `specs/tasks/reassignment.feature @FR-11`>

## Kontrakty zależności (tylko do odczytu)
<`*/Contracts` modułów, od których zależy krok>

## Definition of Done
- [ ] <komendy z `dod`> kończą się kodem 0 (pierwsza: bramka zakresu `enforce_write_scope.py --verify-diff main`)
- [ ] brak nowych ostrzeżeń analizatorów
- [ ] każda nowa komenda ma deskryptor audytu; każdy endpoint — politykę autoryzacji
- [ ] `AGENTS.md` modułu lub profilu zaktualizowany (cel, inwarianty, komendy)

## Kryteria akceptacji człowieka (poza bramkami)
<pole `acceptance`>

## Budżet
Próby: 2 · potem jedna sesja od zera z diagnozą recenzenta (albo wyższy wariant rozumowania, jeśli rola go ma) · potem człowiek · zakaz zmian poza `writes`

## Przekazanie
Zatwierdzenie zmian na gałęzi kroku (`git add`, `git commit`, bez `push`), potem ostatnia wiadomość: JSON wg `AGENTS.md` → `plan/progress/<ID>.json` (krok profilu: `profiles/<id>/progress/<ID>.json`)
