# Plan wykonywalny (harmonogram bez dat)

Plan platformy dzieli prace na 57 kroków w 6 fazach, rozdzielonych czterema bramkami decyzji człowieka. Ścieżka krytyczna (najdłuższa ścieżka ważona rozmiarem kroków) biegnie przez PoC SDK i autoryzacji, kontrakty, adaptery SDK, projekcję, politykę dostępu i pracę na zadaniach, a dalej przez mapę etapów, dashboard i jego UI — to wgląd menadżera, a nie skrzynka zadań, wydłuża projekt. Przekazywanie, zastępstwa, kroki profili projektów (SDK, izolacja, operacje, sloty UI, onboarding) i pozostałe UI mają zapas. Moduł formatek (PoC S07–S09, backend S26, S28, S29, S37, S39, frontend S49, S40, S45, hardening S55 — opis: `docs/architecture/14-form-management.md`) nie wydłuża kalendarza, ale jego łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma tylko ok. 2,6 dnia zapasu — to druga ścieżka do pilnowania. Część specyficzną projektów realizują zespoły profili według własnych planów (`profiles/<id>/backlog.yaml`) — zaczynają po krokach S27, S38 i S47. Ten sam plan w formie maszynowej: `plan/backlog.yaml` (Orkiestrator czyta tylko ten plik). Złożoność i pracochłonność kroków: `plan/estimation.md`.

## Ścieżka krytyczna

```mermaid
flowchart TD
    S01[S01 PoC SDK] --> S02[S02 PoC autoryzacji] --> G0{{G0}}
    G0 --> S10[S10 Szkielet] --> S12[S12 Building Blocks] --> S15[S15 Kontrakty v1] --> G1{{G1}}
    G1 --> S22[S22 Adaptery SDK] --> S23[S23 Projekcja] --> S24[S24 Access Policy] --> S30[S30 Task Work] --> G2{{G2}}
    G2 --> S34[S34 Mapa etapów] --> S36[S36 Dashboard] --> S42[S42 UI wglądu] --> S50[S50 E2E integracyjne]
    S50 --> S51[S51 Bezpieczeństwo] --> S54[S54 Pentest i compliance] --> G3{{G3}} --> S60[S60 Pilotaż]

    G1 --> S20[S20 Party] --> S24
    G1 --> S21[S21 Autoryzacje jako kod] --> S24
    G1 --> S25[S25 Audyt] --> S30
    G1 --> S26[S26 Formatki: cykl życia] --> S29[S29 Powiązania z BPMN] --> S37[S37 Form Runtime] --> S40[S40 Zadania i renderer formatek] --> S45[S45 Projektant formatek] --> S50
    S23 --> S29
    S37 --> S39[S39 Wycofanie i przepięcie] --> S50
    S28[S28 Schemat form] --> S39
    S07[S07 PoC formatek w UI] --> S49[S49 Komponenty pól] --> S40
    S08[S08 PoC walidacji i FEEL] --> S37
    S09[S09 Warstwa wizualna i Figma] --> S16
    S07 --> G1
    S08 --> G1
    S09 --> G1
    G1 --> S16[S16 Frontend shell i ui-kit] --> UI[S41, S43, S44, S46 UI]
    S16 --> S49
    S50 --> S55[S55 Zgodność i spójność formatek] --> S54
    S15 --> S19[S19 SDK rozszerzeń] --> S27[S27 Izolacja profili] --> S38[S38 Operacje profili] --> S50
    S19 --> S47[S47 Sloty UI profili] --> S50
    S38 --> S48[S48 Onboarding zespołów profili] --> S60
    G2 --> S32[S32 Przekazywanie] --> S50
    G2 --> S31[S31 Start procesu]
    S34 --> S35[S35 Eskalacje] --> S42
    S22 --> S33[S33 Zastępstwa] --> S50
    UI --> S50

    classDef crit stroke-width:3px
    class S01,S02,S10,S12,S15,S22,S23,S24,S30,S34,S36,S42,S50,S51,S54,S60 crit
```

## Bramki

| Bramka | Warunek przejścia | Kto decyduje |
| --- | --- | --- |
| **G0** | ADR-003, ADR-004, ADR-007, ADR-010 mają status „Przyjęta” na podstawie raportów PoC; pliki `specs/**` zatwierdzone przez PO | Architekt + PO |
| **G1** | Kontrakty v1 i `api/openapi.v1.yaml` zamrożone; szkielet zielony w CI; baza i harness Reqnroll działają (scenariusze w stanie „pending”); ADR-019 i ADR-020 mają status „Przyjęta” na podstawie PoC formatek (S07, S08), a tokeny i katalog pól są zatwierdzone przez projektanta UX (S09) | Architekt + tech lead |
| **G2** | Scenariusze `@FR-04`, `@FR-06` przechodzą `@integration` na prawdziwej Camunda przez oficjalne SDK (walking skeleton) | Tech lead |
| **G3** | Wszystkie scenariusze zielone; test kompletności audytu, macierz autoryzacji, pentest i przegląd compliance zaakceptowane | Bezpieczeństwo + compliance |

## Kroki

Legenda: **K** = ścieżka krytyczna · rozmiar S/M/L (względny, do budżetowania tokenów i równoległości).

### Faza 0 — Przygotowanie i PoC (→ G0)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S00 | Repozytorium: ten pakiet, `.opencode/` (agenci, skille, plugin strażnika), skrypty kroków, pusty pipeline CI | człowiek (tech lead) | — | repo gotowe dla agentów | S |
| S01 **K** | PoC oficjalnego SDK na Camunda 8.9: lista kontrolna z `06-camunda-integration.md` | camunda-integrator + DevOps | S00 | `poc/sdk/REPORT.md`, decyzja ADR-003 | M |
| S02 **K** | PoC autoryzacji: autoryzacje per `bpmnProcessId`, audytor `*`, token delegowany przez SDK, autoryzacje na poziomie zadania w 8.9 | camunda-integrator + security-reviewer | S01 | `poc/authz/REPORT.md`, decyzja ADR-004 | M |
| S03 | PoC task listenera: korekty assignee/grup, czas odpowiedzi, fail-open | camunda-integrator | S01 | `poc/listener/REPORT.md`, decyzja ADR-007 | S |
| S04 | PoC zasilania read modelu: wyszukiwanie przyrostowe vs eksporter, pomiar opóźnienia | camunda-integrator | S01 | `poc/feed/REPORT.md`, decyzja ADR-010 | M |
| S05 | Przegląd scenariuszy z biznesem, uzupełnienie świata testowego | bdd-analyst + PO | S00 | `specs/**` zatwierdzone | M |
| S06 | Środowisko dev: Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, dostępy sieciowe | DevOps + data-engineer | S00 | środowisko wg checklisty DevOps (sekcja 11) | L |
| S07 | PoC formatek w UI: edytor form-js w Angularze, renderer na design systemie kontra viewer, zestaw zgodności na formatkach wzorcowych | frontend-developer + ux-designer | S00 | `poc/forms-ui/REPORT.md`, decyzja ADR-019 | M |
| S08 | PoC walidacji formatek na serwerze: reguły schematu w .NET, ewaluacja FEEL przez API klastra 8.9, różnice względem przeglądarki | camunda-integrator + module-implementer | S01 | `poc/forms-validation/REPORT.md`, decyzja ADR-020 | S |
| S09 | Warstwa wizualna: biblioteka w Figma, tokeny, katalog pól i specyfikacje komponentów zatwierdzone przez projektanta UX | ux-designer + projektant UX | S00 | `design/**` zatwierdzone, decyzja D-16 | M |

### Faza 1 — Fundament (→ G1)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S10 **K** | Szkielet rozwiązania, Host z rolami, szablon `dotnet new ph-module` | module-implementer | S01–S05 (G0) | `src/`, `templates/ph-module/` | M |
| S11 | Testy architektury i bramki CI | module-implementer | S10 | `tests/ProcessHub.ArchitectureTests`, pipeline | S |
| S12 **K** | Building Blocks: potok, `Actor`, `ITenantContext`, `Permission`, middleware śladu, outbox/inbox/lease | module-implementer | S10 | `src/BuildingBlocks/**` | L |
| S13 | MSSQL: schematy, RLS, Ledger, partycje śladu, temporal, fixture Testcontainers | data-engineer | S10 | `db/**`, `tests/Shared/MsSqlFixture` | M |
| S14 | Harness Reqnroll: projekty `*.Specs`, interfejsy driverów, budowniczy świata testowego, asercje domenowe | bdd-tester | S10, S05 | `tests/*.Specs`, `tests/Shared/World` | M |
| S15 **K** | Kontrakty v1 wszystkich modułów + OpenAPI v1 | architect | S12 | `src/Modules/*/Contracts`, `api/openapi.v1.yaml` | L |
| S16 | Frontend: Nx, shell, motyw z tokenów (`core/theming`), ui-kit, katalog komponentów, i18n, mock server z OpenAPI — startuje po G1 (zamrożone OpenAPI, ADR-019) | frontend-developer + design-system-engineer | S15, S09 (G1) | `frontend/**` | M |
| S17 | Wtyczka bpmnlint `ph` + przykładowe procesy BPMN świata testowego | camunda-integrator | G0 | `bpmn/**` | S |
| S18 | BFF: OIDC z RHBK, ciasteczko, CSRF, wylogowanie | module-implementer | S12 | `src/ProcessHub.Host/Auth/**` | M |
| S19 | SDK rozszerzeń i rejestr profili: manifesty, walidacja, kompozycja modułów, kontrakt slotów UI | architect + module-implementer | S10, S15 | `ProcessHub.Extensibility`, moduł `ExtensionHost`, `extension-sdk` | L |

### Faza 2 — Domena dostępu, Camunda, audyt, formatki (równolegle po G1)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S20 | Party & Accountability: `Actor` z tokenu, migawka grup, `Absence` | module-implementer | G1 | moduł `PartyAccountability` | M |
| S21 | Autoryzacje jako kod: loader YAML, walidacja (R7, readOnly), reconciler (dry-run, apply, dryf) | module-implementer + camunda-integrator | G1 | moduł `PlatformAdministration`, adapter `IAuthorizationAdmin` | M |
| S22 **K** | Adaptery SDK dla wszystkich portów + fake + testy kontraktowe | camunda-integrator | G1 | `CamundaIntegration/**` | L |
| S23 **K** | Projekcja: instancje, zadania, odwiedziny elementów, incydenty, katalog elementów z XML | camunda-integrator + data-engineer | S22 | `CamundaIntegration` + schematy `task`, `insight` | L |
| S24 **K** | Access Policy: uprawnienia efektywne, R1–R11, `TaskAccess`, generowana macierz autoryzacji | module-implementer | S20, S21, S23 | moduł `AccessPolicy` | L |
| S25 | Audyt: dziennik dwufazowy, uzgadnianie, API przeglądu, test kompletności | module-implementer + data-engineer | G1 | moduł `Audit` | M |
| S26 | Form Management: formatki Camunda Forms, cykl życia wersji, R8, R11, publikacja z kontraktem i katalogiem pól, wycofanie, import i eksport | module-implementer | G1 | moduł `FormManagement` | L |
| S27 | Izolacja profili: schemat i użytkownik bazy per profil, widoki `platform_api`, role projektowe w reconcilerze, testy architektury profili | data-engineer + security-reviewer | S13, S19, S21 | migracje, reguły R10, testy izolacji | M |
| S28 | Schemat `form`: wersje, przeglądy, wycofania, unikalność i klucze per proces, historia przypięć | data-engineer | S13, S15 (G1) | migracje `form`, test klucza obcego przypięcia | S |
| S29 | Powiązania formatek z procesem: referencje `ph:form` i kontrakt danych z katalogu elementów, kontrola spójności, reguła bpmnlint `ph/form-reference` | camunda-integrator + module-implementer | S17, S23, S26 | `CamundaIntegration`, `FormManagement` (powiązania), `bpmnlint-plugin-ph` | M |

### Faza 3 — Funkcje rdzenia (→ G2 po S30)

| Krok | Cel | Agent | Zależy od | Wynik | R. |
| --- | --- | --- | --- | --- | --- |
| S30 **K** | Task Work: przejęcie, zwolnienie, szkic, zakończenie, idempotencja | module-implementer | S24, S25 | moduł `TaskWork` | L |
| S31 | Process Lifecycle: katalog startowy, start, moje procesy | module-implementer | S30 (G2), S37 | moduł `ProcessLifecycle` | M |
| S32 | Przekazywanie: osoba, grupa, partia (saga) z wznowieniem | module-implementer | S30 (G2) | `TaskWork` (+ `ReassignmentBatch`) | M |
| S33 | Zastępstwa: worker task listenera (fail-open), uzgadnianie | camunda-integrator | S20, S22, S25 | rola `worker`, `Substitution*` | M |
| S34 **K** | Mapa etapów: agregat, API edytora, dziedziczenie wersji, algorytm stanu | module-implementer | S23, S24, S30 (G2) | moduł `ProcessInsight` | L |
| S35 | Eskalacje: wykrywanie, zakres, lista, „po terminie” | module-implementer | S34 | `ProcessInsight` | M |
| S36 **K** | Dashboard: agregaty, metryki `IProcessMetric`, progi zdrowia, świeżość | module-implementer + data-engineer | S34 | `ProcessInsight` | L |
| S37 | Form Runtime: schemat przypiętej wersji, walidacja danych na serwerze (reguły Camunda Forms, FEEL przez `IExpressionEvaluator`), przypięcie wersji | module-implementer | S26, S29, S08 | moduł `FormRuntime`, port `IExpressionEvaluator` | M |
| S38 | Potok operacji profili (zadanie, sprawa, dane profilu — ADR-017), wzbogacenia, zdarzenia; profil przykładowy i testy zgodności SDK | module-implementer + bdd-tester | S27, S30 | `ExtensionHost`, `ProcessHub.Extensibility.Testing` | M |
| S39 | Wycofanie formatek w toku: przepięcie zadań (saga ze wznowieniem), zadania bez formatki, powiadomienia | module-implementer + bdd-tester | S28, S30, S37 | `FormManagement`, `TaskWork` | M |

### Faza 4 — Frontend funkcjonalny (na mockach od S16, na API po odpowiednim kroku backendu)

| Krok | Cel | Agent | Zależy od | R. |
| --- | --- | --- | --- | --- |
| S40 | Skrzynka zadań + renderer formatek Camunda Forms (interpretacja schematu, FEEL, układ, rejestr komponentów pól) | frontend-developer + ui-reviewer | S16 (mock), S49 → S30, S37 (API) | L |
| S41 | Start procesu, moje procesy | frontend-developer | S16 → S31 | M |
| S42 **K** | Dashboard, eskalacje, instancja z mapą etapów | frontend-developer | S16 → S34, S35, S36 | L |
| S43 | Przekazywanie (pojedyncze, masowe), zastępstwa | frontend-developer | S16 → S32, S33 | M |
| S44 | Edytor mapy etapów (bpmn-js viewer dla `Bpmn.ViewTechnical`) | frontend-developer | S16 → S34 | M |
| S45 | Projektant formatek: osadzony edytor form-js z paletą z katalogu pól, cykl życia, wersje i porównanie, wycofanie, import i eksport, podgląd jak u wykonawcy | frontend-developer + ui-reviewer | S16, S40 → S26 | L |
| S46 | Widoki audytora i przegląd audytu | frontend-developer | S16 → S25 | S |
| S47 | Sloty UI i trasy profili w powłoce (panel zadania i sprawy, widżet, pole formatki, nawigacja) | frontend-developer | S16, S19, S40 | M |
| S48 | Onboarding zespołów profili: szablon, przewodnik, kwalifikacja agentów profilu (E08), przegląd manifestów | architect + docs-writer | S38 | S |
| S49 | Komponenty pól formatek w `ui-kit` wg katalogu pól, katalog komponentów, regresja wizualna i axe | design-system-engineer + ui-reviewer | S16, S07, S09 | M |

### Faza 5 — Integracja i hardening (→ G3) oraz Faza 6 — pilotaż

| Krok | Cel | Agent | Zależy od | R. |
| --- | --- | --- | --- | --- |
| S50 **K** | Wszystkie `@integration` zielone na dev; ścieżki Playwright per rola i profil | bdd-tester | S06, S32, S33, S38, S39, S40–S47 | L |
| S51 **K** | Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacja tenantów, kompletność audytu, DAST, skan zależności | bdd-tester + security-reviewer (recenzja, tylko odczyt) | S50 | M |
| S52 | Wydajność i pojemność: `TaskAccess`, dashboard, opóźnienie projektora, wolumen śladu | data-engineer | S50 | M |
| S53 | Dostępność (WCAG) i przegląd UX | frontend-developer + ui-reviewer + projektant UX | S50 | S |
| S55 | Zgodność formatek z Camunda Forms i spójność wizualna w CI: zestaw zgodności z form-js, schemat `.form`, parytet katalogu pól, regresja wizualna | frontend-developer + ui-reviewer | S50 | S |
| S54 **K** | Pentest, przegląd compliance, Deklaracja Dostępności | ludzie | S51, S52, S53, S55 | M |
| S60 **K** | Pilotaż jednego obszaru (profil `kredyty`): wdrożenie, odcięcie użytkowników od webapp Tasklist, monitoring | ludzie + DevOps + zespół profilu | G3, S48 | M |

## Zasady wykonania (dla Orkiestratora)

1. Krok jest gotowy, gdy wszystkie `depends_on` mają status `done` i `merged`, a bramka `gate_before` jest zatwierdzona. Bramkę zatwierdza człowiek dopiero po scaleniu kroków z jej pola `after` (`plan_status.py --approve-gate` to sprawdza).
2. Równolegle najwyżej tyle agentów implementujących, ile ustawiono w `backlog.yaml` (`parallelism`); kroki **K** mają pierwszeństwo. Kroków z nakładającym się zakresem zapisu nie prowadzi się jednocześnie — lista: `python3 tools/plan/validate_plan.py`, kontrola przed startem: `--conflicts <krok> <krok>`.
3. Dla kroku: `tools/agents/prepare_step.py` tworzy osobny worktree `../wt-<krok>`, plik `.agent-scope` z polem `writes` (dla kroku profilu z dyrektywą `@profile <id>`) i pakiet roboczy wg `plan/work-packet-template.md` — z oczekiwanym wynikiem (`outcome`), wskazówkami startowymi (`notes`), materiałami do wyszukiwania punktowego (`refs`), wejściem od poprzedników i podziałem pracy w parze.
4. Wykonawca pracuje w osobnej sesji OpenCode uruchomionej w worktree kroku (`opencode run --dir ../wt-<krok> --agent <rola> …`) — tylko tam strażnik widzi `.agent-scope`. Na koniec zatwierdza zmiany na gałęzi kroku (`git add`, `git commit`); wypychanie i scalanie należą do człowieka.
5. Jeśli krok ma `pair: bdd-tester`, Tester pisze kroki i drivery przed implementacją w tym samym worktree; implementer nie edytuje `tests/*.Specs/**`. `pair: ui-reviewer` i `pair: security-reviewer` oznaczają obowiązkowy przegląd po zielonych bramkach (tylko odczyt); wzorce regresji wizualnej zmienia się tylko za zgodą projektanta UX. Pozostałe pary wykonują część opisaną w `pair_task`.
6. Bramki deterministyczne (pole `dod`) przed recenzją LLM; pierwszą jest zawsze bramka zakresu (`enforce_write_scope.py --verify-diff main`), która obejmuje także zmiany zrobione komendą, a nie edytorem. Recenzent bezpieczeństwa, gdy diff dotyka ścieżek z `security_sensitive` w `backlog.yaml`. Kryteria, których nie sprawdzi komenda, są w polu `acceptance` — potwierdza je człowiek.
7. Ponowienia: 2 próby. Eskalacja na wyższy wariant rozumowania modelu GLM 5.3 Flash dotyczy tylko ról T3 (wariant `low` → `high`); role T0–T2 mają już wariant najwyższy, więc po dwóch próbach następuje jedna sesja od zera z diagnozą recenzenta, a potem człowiek.
8. Kroki profili prowadzą agenci profilu (`<profil>-<rola>`) w planie zespołu profilu; agenci platformy nie zapisują w `profiles/<id>/**`, agenci profili — poza nim.
9. Zmiana kontraktu lub scenariusza = RFC w `docs/rfc/` (plik `RFC-<krok>-<temat>.md` wolno utworzyć w każdym kroku), decyzja Architekta i człowieka, podbicie wersji kontraktu, ponowne uruchomienie zależnych kroków.
10. Po zakończeniu kroku: przekazanie JSON zapisane do `plan/progress/<krok>.json`; Orkiestrator aktualizuje `plan/progress/STATUS.md`.
11. Rzeczywista praca ludzi trafia do `plan/progress/<krok>.effort.json`; `tools/plan/estimate.py` przelicza prognozę (metoda: `plan/estimation.md`).
12. Narzędzia: skrypty `tools/*.py` albo ich odpowiedniki .NET `ph` (`tools/dotnet`) — identyczne wyniki; `ph step dod` sam zamienia polecenia Pythona w Definition of Done, gdy Pythona brak. Wyjątek: `tools/plan/validate_plan.py` jest na razie tylko w Pythonie.

## Uwagi do zależności (przegląd planu)

- **S16 po G1.** Diagram ścieżki krytycznej prowadzi S16 za bramką G1; backlog ma teraz `gate_before: G1`, więc także S49 (komponenty pól) nie ruszy przed przyjęciem ADR-019.
- **S19 przed workspace Nx.** S19 pisze `frontend/libs/platform/extension-sdk` bez zależności od S16 — biblioteka powstaje jako samodzielny pakiet typów, a do workspace włącza ją S16 albo S47. Jeśli kontrakt slotów ma być budowany i testowany w Nx, dodaj `S16` do `depends_on` kroku S19 (decyzja architekta; łańcuch profili ma zapas).
- **S21 równolegle z S22.** Oba kroki piszą w `CamundaIntegration` (S21: adapter `IAuthorizationAdmin`). Wspólne pliki projektu i rejestracji DI grożą konfliktem scalania — prowadź je po kolei albo uzgodnij podział.
- **Frontend a backend.** Kroki S40–S46 mają w `depends_on` kroki backendu, choć nagłówek fazy 4 mówi o pracy na mockach od S16. Dziś narzędzia traktują to jako twardą zależność (krok nie wystartuje przed scaleniem backendu). Skrócenie ścieżki S36 → S42 wymagałoby podziału kroków UI na część „na mockach” i część „na API” — to decyzja planistyczna zmieniająca wycenę.
- **Pilotaż a plan profilu.** S60 wymaga ukończenia planu `kredyty`; narzędzia nie znają zależności platforma → profil, więc warunek jest w `acceptance` kroku S60.
- **Kroki w tym samym module.** S32 i S39 (`TaskWork`), S35 i S36 (`ProcessInsight`), S53 i S55 (`frontend`), S27 i kroki ze schematami w `db/**` mogą być gotowe jednocześnie — `validate_plan.py` wypisuje je jako ostrzeżenia.

## Otwarte decyzje biznesowe (do G0)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-01 | Definicja „grupy uprawnień” dla widoczności uczestnika | grupy kandydujące zadania ∪ grupy inicjatora |
| D-02 | Czy menadżer może przekazać zadanie osobie spoza grup kandydujących | tak, jeśli ma rolę Uczestnika w procesie (R6) |
| D-03 | Kto mapuje elementy BPMN na etapy | administrator procesu; menadżer — gdy dostanie `StageMap.MapElements` w konfiguracji |
| D-04 | Zastępstwa: tylko nowe zadania czy także istniejące | nowe automatycznie; istniejące — propozycja przekazania masowego dla menadżera |
| D-05 | Szkic przy przekazaniu | przechodzi z zadaniem, z adnotacją i audytem |
| D-06 | Czy anulowanie instancji liczyć jako „błąd” na dashboardzie | osobny licznik „anulowane”, nie błąd |
| D-07 | Czy audytor widzi techniczny BPMN | nie domyślnie; osobna rola „audytor techniczny”, jeśli potrzebna |

## Decyzje dotyczące profili projektów (przed S19 i S27)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-08 | Domyślny model integracji profili | in-process; remote na wniosek zespołu |
| D-09 | Monorepo z `CODEOWNERS` czy osobne repozytoria profili | monorepo na start |
| D-10 | Rytm pociągu wydań dla profili in-process | co dwa tygodnie, razem z wydaniem platformy |
| D-11 | Zakres danych platformy w widokach `platform_api` | zadania, instancje i stany etapów procesów profilu |

## Decyzje dotyczące formatek i warstwy wizualnej (przed S09 i S26)

| ID | Pytanie | Rekomendacja |
| --- | --- | --- |
| D-12 | Cztery oczy przy formatkach: autor ostatniej zmiany czy każdy współautor szkicu | autor ostatniej zmiany (R8); lista współautorów widoczna dla zatwierdzającego |
| D-13 | Czy wycofanie wersji formatki wymaga drugiej osoby | nie — operacja awaryjna jednej osoby z powodem, powiadomieniem i wpisem w dzienniku |
| D-14 | Domyślny skutek wycofania dla zadań w toku | zadania pozostają na wycofanej wersji; przepięcie jako świadomy wybór |
| D-15 | Załączniki w formatkach: magazyn dokumentów dla pól plikowych | obsługa dokumentów Camunda albo magazyn banku; do decyzji typy plikowe poza katalogiem pól |
| D-16 | Właściciel biblioteki w Figma i tryb przenoszenia zmian wyglądu | projektant UX banku; eksport jako pull request w `design/**`, najwyżej raz na wydanie |

Rozstrzygnięcia techniczne z PoC: ADR-019 (S07 — renderer na design systemie) i ADR-020 (S08 — FEEL przez silnik) — przed G1.

## Plany zespołów profili

Każdy profil ma własny plan (`profiles/<id>/backlog.yaml`) prowadzony tymi samymi narzędziami (`plan_status.py`, `prepare_step.py`, `run_dod.py` z `--backlog`, komenda `/profil <id> <krok>`). Kroki profilu mogą zależeć od kroków platformy; postęp zapisuje się w `profiles/<id>/progress/`. Plan pilotażowego profilu `kredyty` (KRE-01…KRE-04) musi być ukończony przed S60. Profil `flota` (FLO-01…FLO-05) jest przykładem dedykowanych elementów jednego projektu — katalog samochodów z operacjami na danych profilu (ADR-017) i opinie komórek banku — i nie blokuje pilotażu.
