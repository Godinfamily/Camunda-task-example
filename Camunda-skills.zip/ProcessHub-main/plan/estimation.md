# Szacowanie złożoności i czasochłonności (hybryda AI + ludzie)

**Wynik modelu:** pierwszy obszar biznesowy po pilotażu za ok. **28 tygodni** (P80: 31) przy zespole 6,2 FTE z rojem agentów, wobec ok. **38 tygodni** (P80: 43) dla tego samego zespołu bez AI. Pracy ludzi ubywa o ok. 23% (459 zamiast 597 osobodni). Kalendarz hybrydy wyznacza ścieżka krytyczna, którą wydłużają kroki, w których AI pomaga mało: PoC na nieznanej wersji 8.9, decyzje przy bramkach, pentest i pilotaż; bez AI wąskim gardłem staje się zespół backendu (192 dni robocze). Moduł zarządzania formatkami z warstwą wizualną (v4) dodał 8 kroków i ok. 59 osobodni pracy ludzi, nie zmieniając kalendarza.

To są szacunki z modelu, nie z historii projektu. Po PoC (S01–S04) i pierwszych trzech krokach budowy (S10–S12) trzeba je skalibrować rzeczywistymi danymi — mechanizm jest opisany na końcu. Pełne tabele per krok: `plan/estimation-report.md` (generowany przez `tools/plan/estimate.py`).

## 1. Jak liczymy

Każdy krok ma cztery oceny 1–5 w `plan/estimates.yaml`:

| Wymiar | 1 | 3 | 5 |
| --- | --- | --- | --- |
| **T** — technika | szablon, CRUD | kilka mechanizmów, nietrywialna logika | algorytm, spójność rozproszona, bezpieczeństwo |
| **N** — niepewność | wszystko znane | część do odkrycia | zależne od nieznanego zachowania Camunda 8.9/SDK lub decyzji zewnętrznych |
| **I** — integracje | jeden moduł | 2–3 systemy | Camunda + RHBK + MSSQL + AD + CI naraz |
| **B** — biznes i regulacje | brak decyzji | decyzje zespołu | decyzje biznesu, compliance, formalne akceptacje |

- **Indeks złożoności** C = 0,35·T + 0,30·N + 0,20·I + 0,15·B. Klasy: niska ≤ 2,2 · średnia ≤ 3,0 · wysoka ≤ 3,7 · bardzo wysoka > 3,7.
- **Pracochłonność bez AI**: trzy punkty (optymistyczny, najbardziej prawdopodobny, pesymistyczny) w osobodniach doświadczonego zespołu, średnia PERT.
- **Pracochłonność ludzi w hybrydzie** = bez AI × [(1 − udział AI) + udział AI × koszt przeglądu]. Przykład: szkielet S10 — agenci robią 80% pracy, przegląd kosztuje 25% → ludzie robią 40% pracy bez AI.
- **Narzuty**: nadzór roju 12% (pakiety, eskalacje, scalanie) i koordynacja 10% (dla wariantu bez AI tylko koordynacja).
- **Kalendarz** = większa z dwóch wartości: ścieżka krytyczna (z oczekiwaniem na bramki) albo czas najbardziej obciążonej roli. P80 liczone ostrożnie — ryzyka kroków traktujemy jako skorelowane.

Parametry (wagi, zespół, narzuty, oczekiwanie na bramki) są w `plan/estimation-params.yaml` — zmiana i ponowne uruchomienie skryptu daje nowy raport.

## 2. Najtrudniejsze elementy

Kroki o najwyższym indeksie skupiają się w czterech obszarach. Wspólna cecha: trudność bierze się z niewiadomych i decyzji, a nie z ilości kodu — dlatego tam agenci oszczędzają najmniej.

| Krok | C | Dlaczego trudny | Udział AI | Bez AI → hybryda (osobodni) |
| --- | --- | --- | --- | --- |
| **Camunda 8.9 i oficjalne SDK** | | | | |
| S02 PoC autoryzacji zasobów i tożsamości wywołań | 4,15 | semantyka autoryzacji, token delegowany, decyzja bezpieczeństwa | 35% | 8,7 → 7,1 |
| S23 Projekcja read modelu | 3,85 | kolejność, duplikaty, wznowienie po awarii, katalog elementów z XML | 55% | 18,7 → 13,0 |
| S21 Autoryzacje jako kod (reconciler) | 3,85 | stan docelowy vs faktyczny w Camunda, dryf, rozdział obowiązków | 55% | 12,3 → 8,6 |
| S22 Adaptery SDK + testy kontraktowe | 3,55 | 7 portów, fake i Testcontainers, luki w SDK | 60% | 14,7 → 9,4 |
| S01 PoC oficjalnego SDK | 3,50 | nieznane pokrycie SDK dla 8.9 decyduje o ADR-003 | 40% | 8,5 → 6,8 |
| **Rdzeń bezpieczeństwa** | | | | |
| S24 Access Policy (R1–R11, `TaskAccess`) | 3,65 | reguły widoczności i materializacja — błąd = wyciek danych | 55% | 15,3 → 11,1 |
| S27 Izolacja profili (schemat i użytkownik bazy per profil, widoki `platform_api`) | 3,65 | `EXECUTE AS USER` z pulą połączeń, RLS widoków, R10 — błąd = wyciek danych między projektami | 40% | 9,5 → 8,2 |
| S18 BFF z RHBK (OIDC, ciasteczka, CSRF) | 3,55 | integracja z bankowym IdP, wylogowanie globalne | 50% | 8,2 → 6,1 |
| **Algorytmy domenowe** | | | | |
| S34 Mapa etapów i stan etapów | 3,65 | równoległość, pętle, call activity, wersje mapy; uzgodnienia z biznesem | 60% | 15,3 → 9,8 |
| **Środowisko i organizacja** | | | | |
| S50 Testy integracyjne end-to-end | 3,90 | pierwsze zderzenie całości z prawdziwym środowiskiem, niestabilne testy | 50% | 15,8 → 11,9 |
| S60 Pilotaż | 3,80 | wdrożenie, szkolenia, dual-run, wsparcie — praca ludzi | 10% | 20,8 → 20,8 |
| S06 Środowisko dev w banku | 3,70 | dostępy (AD, sieć, RHBK), procedury — czas zależy od organizacji | 30% | 16,7 → 14,7 |

Poza czołówką warto pilnować **S19 SDK rozszerzeń** (C 3,20, 12,3 → 10,1 osobodni) — publiczny kontrakt dla wszystkich zespołów profili, którego błąd projektu kosztuje każdy zespół — oraz **formatek w interfejsie**: S40 renderer Camunda Forms (C 3,50, 18,5 → 10,7 osobodni) i S45 projektant formatek (C 3,35, 17,7 → 10,8) to największy blok frontendu, a o ich powodzeniu rozstrzygają PoC S07 (C 3,30) i S08 (C 3,15) — i **S12 Building Blocks**: indeks tylko „średni” (2,70), ale każdy błąd w potoku audytu i autoryzacji powiela się w dziesięciu modułach — tu oszczędzanie na przeglądzie jest najdroższe.

## 3. Najprostsze elementy

| Krok | C | Dlaczego prosty | Udział AI | Oszczędność pracy ludzi |
| --- | --- | --- | --- | --- |
| S41 Start procesu i moje procesy (UI) | 1,50 | formularze i listy na gotowym API i makiecie | 80% | 60% |
| S46 Widoki audytora (UI) | 1,50 | tabele tylko do odczytu | 80% | 60% |
| S10 Szkielet rozwiązania | 1,55 | powtarzalny układ modułów z szablonu | 80% | 60% |
| S17 Wtyczka bpmnlint i przykładowe BPMN | 1,65 | małe, dobrze określone reguły | 75% | 53% |
| S43 Przekazywanie i zastępstwa (UI) | 1,85 | okna dialogowe i kreator na gotowych komendach | 75% | 56% |
| S11 Testy architektury i bramki CI | 1,85 | reguły deklaratywne | 75% | 53% |

To kandydaci na pierwsze pakiety pilotażowe roju i na niższy wariant rozumowania modelu (`config/models.yaml`) — ryzyko jest małe, a wynik łatwo zweryfikować bramkami. Równie prosty jest S48 (onboarding zespołów profili, C 1,60), ale to głównie praca ludzi.

## 4. Gdzie AI daje najwięcej, a gdzie najmniej

| Faza | Bez AI (osobodni) | Hybryda (osobodni) | Oszczędność | Okno w harmonogramie (tydzień) |
| --- | --- | --- | --- | --- |
| 0 — przygotowanie i PoC (w tym PoC formatek i warstwa wizualna) | 78 | 64 | 19% | 1 – 3,5 |
| 1 — fundament (w tym SDK rozszerzeń, motyw i ui-kit) | 77 | 48 | 37% | 3 – 8 |
| 2 — dostęp, Camunda, audyt, formatki, izolacja profili | 112 | 76 | 32% | 7 – 12 |
| 3 — funkcje rdzenia, Form Runtime i operacje profili | 96 | 61 | 36% | 9 – 15,5 |
| 4 — frontend funkcjonalny, komponenty pól, sloty profili, onboarding zespołów | 99 | 56 | 43% | 8 – 16 |
| 5 — integracja i hardening (w tym zgodność formatek) | 61 | 51 | 17% | 17 – 22,5 |
| 6 — pilotaż | 21 | 21 | 0% | 23 – 28 |

Okna to najwcześniejsze możliwe terminy wg zależności (bez dat kalendarzowych). Fazy 3 i 4 zaczynają się w tygodniu 9, bo część kroków (formatki, UI na mockach) nie czeka na ścieżkę krytyczną.

## 5. Ścieżka krytyczna i co ją skraca

S00 → S01 → S02 → **G0** → S10 → S12 → S15 → **G1** → S22 → S23 → S24 → S30 → **G2** → S34 → S36 → S42 → S50 → S51 → S54 → **G3** → S60

Najdłużej trwa wgląd menadżera (mapa etapów → dashboard → jego UI), a nie skrzynka zadań. Wrażliwość modelu:

| Scenariusz | Praca ludzi (osobodni) | Kalendarz | P80 |
| --- | --- | --- | --- |
| Bazowy | 459 | 27,6 tyg. | 30,8 tyg. |
| A: agenci słabsi (udział AI −20 pkt, np. słabsze wyniki kwalifikacji GLM) | 529 | 30,3 tyg. | 33,9 tyg. |
| B: droższy przegląd (+15 pkt) | 512 | 29,6 tyg. | 33,1 tyg. |
| C: wolne procedury banku (bramki ×2, środowisko i pentest pesymistycznie) | 475 | 32,5 tyg. | 36,3 tyg. |
| D: większy zespół (+1 backend, PO 0,75, bezpieczeństwo 0,3) | 459 | 27,6 tyg. | 30,8 tyg. |
| E: dwie osoby na krokach ścieżki krytycznej (podział na podpakiety) | 459 | 25,6 tyg. | 28,7 tyg. |

Wnioski:

- **Dokładanie ludzi ogólnie nie skraca projektu** (D) — ogranicza go ścieżka krytyczna, nie liczba rąk.
- **Kroki profili nie leżą na ścieżce krytycznej** (S19, S27, S38, S47, S48 mają zapas 1–8 tygodni): zwiększają pracę ludzi o ok. 39 osobodni, ale nie wydłużają kalendarza — pod warunkiem, że backend (najbardziej obciążona rola, 128 dni) nie zostanie dodatkowo obciążony.
- **Moduł formatek jest drugą ścieżką do pilnowania.** Łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma tylko ok. 2,6 dnia zapasu: poślizg PoC (S07, S08), decyzji o warstwie wizualnej (S09) albo renderera przesuwa testy end-to-end. Moduł dokłada też pracy backendowi (S08, S26, S29, S37, S39): jego obciążenie rośnie ze 114 do 128 dni roboczych i to ono — a nie ścieżka krytyczna (22,4 tyg. po podziale kroków) — ogranicza scenariusz E do 25,6 tygodnia zamiast wcześniejszych 22,8.
- **Najsilniejsza dźwignia to dzielenie kroków ścieżki krytycznej** (S23, S24, S34, S36) na podpakiety wykonywane równolegle przez dwie osoby z agentami (E: około −2 tygodnie; dalej ogranicza już obciążenie backendu — podział kroków razem z dodatkową osobą w backendzie daje ok. 24,8 tyg.). Orkiestrator może to zrobić bez zmiany architektury, bo kontrakty są zamrożone od G1.
- **Największe ryzyko zewnętrzne to procedury banku** (C: około +5 tygodni). Środowisko (S06), decyzje G0 i termin pentestu warto uruchomić w pierwszym tygodniu, równolegle do PoC.
- **Jakość modeli ma umiarkowany wpływ na kalendarz** (A: około +3 tygodnie), ale wyraźny na koszt pracy ludzi (+61 osobodni). Kwalifikacja z `evals/agents` chroni przed tym scenariuszem.
- **Role bliskie przeciążenia:** backend (128 dni), architekt (124), PO/analityk (0,5 FTE, 116) i bezpieczeństwo (0,2 FTE, 106) mają obciążenie zbliżone do długości ścieżki krytycznej (138 dni). Projektant UX (0,5 FTE, 37 dni) ma zapas, ale jego praca skupia się na początku (S09) i przy komponentach pól (S49). Każde opóźnienie decyzji z ich strony przesuwa projekt, więc dostępność tych osób trzeba zarezerwować z góry.

## 6. Czego model nie obejmuje

- Utrzymania po pilotażu i wdrażania kolejnych obszarów biznesowych (każdy kolejny obszar to głównie konfiguracja: autoryzacje, mapy etapów, formatki).
- Pracy zespołów profili nad częścią specyficzną (`profiles/<id>/backlog.yaml`) — wycenia ją każdy zespół projektu; plan platformy obejmuje SDK, izolację, sloty UI i onboarding (S19, S27, S38, S47, S48).
- Środowisk test i prod, procesu zakupu licencji Kendo i infrastruktury modelu GLM w banku.
- Kosztu tokenów — zmierzymy go na krokach S10–S12 i dopiszemy do raportu.
- Materiałów szkoleniowych i zmian organizacyjnych poza pilotażem.
- Urlopy i prace utrzymaniowe uwzględnia tylko globalnie wykorzystanie zespołu na poziomie 75%.

## 7. Kalibracja w trakcie prac

1. Po każdym kroku Orkiestrator (lub tech lead) zapisuje `plan/progress/<krok>.effort.json`: `{"step": "S10", "actual_human_pd": 3.5}`.
2. `python3 tools/plan/estimate.py` liczy współczynnik k = średnia(rzeczywistość / szacunek) i stosuje go do pozostałych kroków; zakończone kroki wchodzą do sumy z wartością rzeczywistą.
3. Po PoC (S01–S04) zespół aktualizuje oceny **N** w `plan/estimates.yaml` — niepewność Camunda i SDK spada albo rośnie, co zmienia pracochłonność S21–S23 i S33.
4. Raport `plan/estimation-report.md` jest generowany i sprawdzany w CI (`estimate.py --check`), więc plan i liczby nie rozjadą się w repozytorium.
