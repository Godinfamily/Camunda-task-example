<!-- WYGENEROWANE przez tools/plan/estimate.py — nie edytuj ręcznie -->
# Raport szacowania (generowany)

Kalibracja: brak danych rzeczywistych, k = 1,0. Zespół referencyjny: 6,2 FTE, wykorzystanie 75%. P80 liczone ostrożnie: odchylenia kroków sumowane liniowo (ryzyka skorelowane).

## Podsumowanie

| Wielkość | Bez AI: oczekiwane | Bez AI: P80 | Hybryda: oczekiwane | Hybryda: P80 |
| --- | --- | --- | --- | --- |
| Praca ludzi w krokach (osobodni) | 543 | 608 | 376 | 422 |
| Praca ludzi z narzutami (osobodni) | 597 | 669 | 459 | 515 |
| Ścieżka krytyczna z bramkami (dni robocze) | 177 | 197 | 138 | 154 |
| Najbardziej obciążona rola (dni robocze) | 192 (Backend .NET) | — | 128 (Backend .NET) | — |
| **Czas kalendarzowy** (większa z dwóch powyższych) | **38 tyg.** | **43 tyg.** | **28 tyg.** | **31 tyg.** |

Narzuty: hybryda = nadzór roju + koordynacja; bez AI = koordynacja. Czas pracy agentów nie jest wąskim gardłem — ogranicza go przegląd i decyzje ludzi.

## Kroki

| Krok | Tytuł | C | Klasa | T/N/I/B | AI | Bez AI (od) | Hybryda (od) | Oszczędność | Dni kal. | Ścieżka kryt. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S00 | Repozytorium, harness agentów, skrypt worktree, pusty pipeline CI | 1,85 | niska | 2/2/2/1 | 30% | 3,2 | 2,7 | 15% | 2,7 | tak |
| S01 | PoC oficjalnego SDK Camunda na 8.9 (lista kontrolna) | 3,50 | wysoka | 3/5/4/1 | 40% | 8,5 | 6,8 | 20% | 6,8 | tak |
| S02 | PoC autoryzacji zasobów, roli audytora i tożsamości wywołań | 4,15 | bardzo wysoka | 4/5/4/3 | 35% | 8,7 | 7,1 | 18% | 7,1 | tak |
| S03 | PoC task listenera zastępstw (korekty, czas odpowiedzi, fail-open) | 3,00 | średnia | 3/4/3/1 | 50% | 4,2 | 2,9 | 30% | 2,9 |  |
| S04 | PoC zasilania read modelu (wyszukiwanie przyrostowe vs eksporter) | 3,00 | średnia | 3/4/3/1 | 50% | 5,3 | 3,7 | 30% | 3,7 |  |
| S05 | Przegląd scenariuszy z biznesem, decyzje D-01..D-07 | 2,20 | niska | 1/3/1/5 | 40% | 8,7 | 7,3 | 16% | 7,3 |  |
| S06 | Środowisko dev — Camunda 8.9 na K8s, realm RHBK z federacją AD, MSSQL, | 3,70 | wysoka | 3/4/5/3 | 30% | 16,7 | 14,7 | 12% | 9,8 |  |
| S07 | PoC formatek w UI — edytor form-js w Angularze, renderer na design sys | 3,30 | wysoka | 4/4/2/2 | 50% | 8,3 | 6,0 | 28% | 6,0 |  |
| S08 | PoC walidacji formatek na serwerze — reguły schematu w .NET, ewaluacja | 3,15 | wysoka | 3/4/3/2 | 50% | 5,3 | 3,9 | 28% | 3,9 |  |
| S09 | Warstwa wizualna — biblioteka w Figma, tokeny, katalog pól i specyfika | 2,40 | średnia | 2/3/1/4 | 30% | 9,5 | 8,4 | 12% | 8,4 |  |
| S10 | Szkielet rozwiązania, Host z rolami, szablon dotnet new ph-module | 1,55 | niska | 2/1/2/1 | 80% | 4,2 | 1,7 | 60% | 7,2 | tak |
| S11 | Testy architektury i bramki CI | 1,85 | niska | 2/2/2/1 | 75% | 3,2 | 1,5 | 53% | 1,5 |  |
| S12 | Building Blocks — potok, Actor, ITenantContext, Permission, middleware | 2,70 | średnia | 4/2/2/2 | 65% | 12,3 | 7,5 | 39% | 5,0 | tak |
| S13 | MSSQL — schematy, RLS, Ledger, partycje śladu, temporal, fixture Testc | 2,65 | średnia | 3/3/2/2 | 60% | 7,3 | 4,7 | 36% | 4,7 |  |
| S14 | Harness Reqnroll — projekty Specs, drivery, świat testowy, asercje | 2,20 | niska | 3/2/2/1 | 70% | 6,2 | 3,1 | 49% | 3,1 |  |
| S15 | Kontrakty v1 wszystkich modułów i OpenAPI v1 | 3,35 | wysoka | 4/3/3/3 | 55% | 9,3 | 6,8 | 28% | 4,5 | tak |
| S16 | Frontend — Nx, shell, motyw z tokenów (core/theming), ui-kit, katalog  | 2,20 | niska | 3/2/2/1 | 70% | 10,3 | 5,3 | 49% | 7,4 |  |
| S17 | Wtyczka bpmnlint ph i procesy BPMN świata testowego | 1,65 | niska | 2/2/1/1 | 75% | 3,2 | 1,5 | 53% | 7,0 |  |
| S18 | BFF — OIDC z RHBK, ciasteczko __Host-, CSRF, wylogowanie | 3,55 | wysoka | 4/3/4/3 | 50% | 8,2 | 6,1 | 25% | 6,1 |  |
| S19 | SDK rozszerzeń i rejestr profili — manifesty, walidacja, kompozycja mo | 3,20 | wysoka | 4/3/3/2 | 45% | 12,3 | 10,1 | 18% | 6,7 |  |
| S20 | Party & Accountability — Actor z tokenu, migawka grup, Absence | 2,50 | średnia | 3/2/2/3 | 70% | 7,2 | 3,9 | 45% | 6,1 |  |
| S21 | Autoryzacje jako kod — loader YAML, walidacja R7/readOnly, reconciler | 3,85 | bardzo wysoka | 4/4/4/3 | 55% | 12,3 | 8,6 | 30% | 10,8 |  |
| S22 | Adaptery oficjalnego SDK dla wszystkich portów, fake, testy kontraktow | 3,55 | wysoka | 4/4/4/1 | 60% | 14,7 | 9,4 | 36% | 8,4 | tak |
| S23 | Projekcja — instancje, zadania, odwiedziny elementów, incydenty, katal | 3,85 | bardzo wysoka | 5/4/3/2 | 55% | 18,7 | 13,0 | 30% | 8,7 | tak |
| S24 | Access Policy — uprawnienia efektywne, R1–R11, TaskAccess, generowana  | 3,65 | wysoka | 5/3/2/4 | 55% | 15,3 | 11,1 | 28% | 7,4 | tak |
| S25 | Audyt — dziennik dwufazowy, uzgadnianie, API przeglądu, test kompletno | 3,00 | średnia | 4/2/2/4 | 60% | 10,3 | 6,9 | 33% | 9,1 |  |
| S26 | Form Management — formatki Camunda Forms, cykl życia wersji, R8, R11,  | 3,00 | średnia | 4/2/2/4 | 65% | 14,3 | 8,7 | 39% | 8,0 |  |
| S27 | Izolacja profili — schemat i użytkownik bazy per profil, widoki platfo | 3,65 | wysoka | 4/4/3/3 | 40% | 9,5 | 8,2 | 14% | 8,2 |  |
| S28 | Schemat form — wersje, przeglądy, wycofania, unikalność i klucze per p | 1,80 | niska | 2/2/1/2 | 70% | 3,2 | 1,7 | 45% | 3,9 |  |
| S29 | Powiązania formatek z procesem — referencje ph:form i kontrakt danych  | 2,85 | średnia | 3/3/3/2 | 60% | 6,2 | 3,9 | 36% | 3,9 |  |
| S30 | Task Work — przejęcie, zwolnienie, szkic, zakończenie, idempotencja | 3,35 | wysoka | 4/3/3/3 | 60% | 12,3 | 7,9 | 36% | 5,3 | tak |
| S31 | Process Lifecycle — katalog startowy, start, moje procesy | 2,35 | średnia | 3/2/2/2 | 70% | 6,2 | 3,4 | 45% | 4,7 |  |
| S32 | Przekazywanie — osoba, grupa, partia z wznowieniem | 3,15 | wysoka | 4/3/2/3 | 60% | 9,3 | 6,0 | 36% | 7,3 |  |
| S33 | Zastępstwa — worker task listenera (fail-open), uzgadnianie | 3,50 | wysoka | 4/4/3/2 | 55% | 8,2 | 5,7 | 30% | 5,7 |  |
| S34 | Mapa etapów — agregat, API edytora, dziedziczenie wersji, algorytm sta | 3,65 | wysoka | 5/3/2/4 | 60% | 15,3 | 9,8 | 36% | 7,9 | tak |
| S35 | Eskalacje — wykrywanie, zakres, lista, kategoria po terminie | 2,80 | średnia | 3/3/2/3 | 65% | 6,2 | 3,6 | 42% | 3,6 |  |
| S36 | Dashboard — agregaty, IProcessMetric, progi zdrowia, świeżość | 3,30 | wysoka | 4/3/2/4 | 60% | 12,3 | 7,9 | 36% | 5,3 | tak |
| S37 | Form Runtime — schemat przypiętej wersji, walidacja danych na serwerze | 3,35 | wysoka | 4/3/3/3 | 60% | 10,3 | 6,6 | 36% | 8,8 |  |
| S38 | Potok operacji profili (zadanie, sprawa, dane profilu), wzbogacenia i  | 2,85 | średnia | 3/3/3/2 | 55% | 9,2 | 6,6 | 28% | 6,6 |  |
| S39 | Wycofanie formatek w toku — przepięcie zadań (saga ze wznowieniem), za | 2,85 | średnia | 4/2/2/3 | 60% | 6,2 | 3,9 | 36% | 3,9 |  |
| S40 | Skrzynka zadań i renderer formatek Camunda Forms (interpretacja schema | 3,50 | wysoka | 5/3/2/3 | 65% | 18,5 | 10,7 | 42% | 7,1 |  |
| S41 | Start procesu i moje procesy | 1,50 | niska | 2/1/1/2 | 80% | 5,3 | 2,1 | 60% | 2,1 |  |
| S42 | Dashboard, eskalacje, instancja z mapą etapów | 2,30 | średnia | 3/2/1/3 | 70% | 11,3 | 5,8 | 49% | 3,9 | tak |
| S43 | Przekazywanie pojedyncze i masowe, zastępstwa | 1,85 | niska | 3/1/1/2 | 75% | 7,2 | 3,1 | 56% | 3,1 |  |
| S44 | Edytor mapy etapów (bpmn-js viewer) | 3,15 | wysoka | 4/3/2/3 | 60% | 11,3 | 6,9 | 39% | 6,9 |  |
| S45 | Projektant formatek — osadzony edytor form-js z paletą z katalogu pól, | 3,35 | wysoka | 4/3/3/3 | 60% | 17,7 | 10,8 | 39% | 7,2 |  |
| S46 | Widoki audytora i przegląd audytu | 1,50 | niska | 2/1/1/2 | 80% | 4,2 | 1,7 | 60% | 1,7 |  |
| S47 | Sloty UI i trasy profili w powłoce | 2,35 | średnia | 3/2/2/2 | 65% | 7,3 | 4,7 | 36% | 4,7 |  |
| S48 | Onboarding zespołów profili: szablon, przewodnik, kwalifikacja agentów | 1,60 | niska | 1/2/1/3 | 50% | 4,0 | 2,8 | 30% | 2,8 |  |
| S49 | Komponenty pól formatek w ui-kit wg katalogu pól, katalog komponentów, | 2,30 | średnia | 3/2/1/3 | 65% | 12,3 | 7,5 | 39% | 7,5 |  |
| S50 | Wszystkie @integration zielone na dev; Playwright per rola | 3,90 | bardzo wysoka | 4/4/5/2 | 50% | 15,8 | 11,9 | 25% | 7,9 | tak |
| S51 | Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacja, kompletność  | 3,50 | wysoka | 4/3/3/4 | 45% | 9,3 | 7,7 | 18% | 7,7 | tak |
| S52 | Wydajność i pojemność | 3,50 | wysoka | 4/4/3/2 | 45% | 8,5 | 6,8 | 20% | 6,8 |  |
| S53 | Dostępność i UX | 1,95 | niska | 2/2/1/3 | 40% | 6,3 | 5,3 | 16% | 5,3 |  |
| S54 | Pentest, compliance, Deklaracja Dostępności | 3,40 | wysoka | 3/4/2/5 | 10% | 15,8 | 15,8 | 0% | 15,8 | tak |
| S55 | Zgodność formatek z Camunda Forms i spójność wizualna w CI — zestaw zg | 2,65 | średnia | 3/3/2/2 | 60% | 5,2 | 3,3 | 36% | 3,3 |  |
| S60 | Pilotaż jednego obszaru; odcięcie użytkowników od webapp Tasklist | 3,80 | bardzo wysoka | 3/4/4/5 | 10% | 20,8 | 20,8 | 0% | 26,3 | tak |

## Fazy

| Faza | Bez AI (od) | Hybryda (od) | Oszczędność |
| --- | --- | --- | --- |
| 0 | 78,3 | 63,5 | 19% |
| 1 | 76,5 | 48,3 | 37% |
| 2 | 111,7 | 75,5 | 32% |
| 3 | 95,5 | 61,4 | 36% |
| 4 | 99,2 | 56,1 | 43% |
| 5 | 61,0 | 50,8 | 17% |
| 6 | 20,8 | 20,8 | 0% |

## Obciążenie ról (z narzutami)

| Rola | FTE | Praca (od) | Dni robocze przy wykorzystaniu |
| --- | --- | --- | --- |
| Backend .NET | 2,0 | 191,9 | 128 |
| Architekt / tech lead | 1,0 | 92,9 | 124 |
| PO / analityk | 0,5 | 43,5 | 116 |
| Bezpieczeństwo | 0,2 | 15,9 | 106 |
| Frontend Angular | 1,0 | 66,2 | 88 |
| DevOps | 0,5 | 22,1 | 59 |
| Projektant UX | 0,5 | 14,0 | 37 |
| QA / BDD | 0,5 | 12,8 | 34 |

## Ścieżka krytyczna

S00 → S01 → S02 → S10 → S12 → S15 → S22 → S23 → S24 → S30 → S34 → S36 → S42 → S50 → S51 → S54 → S60

## Ranking złożoności

| Miejsce | Krok | C | Główny czynnik |
| --- | --- | --- | --- |
| 1 | S02 PoC autoryzacji zasobów, roli audytora i tożsamości wyw | 4,15 | semantyka autoryzacji zasobów i token delegowany; decyzja bezpieczeństwa |
| 2 | S50 Wszystkie @integration zielone na dev; Playwright per r | 3,90 | pierwsze spotkanie wszystkiego z prawdziwym środowiskiem; niestabilne testy |
| 3 | S23 Projekcja — instancje, zadania, odwiedziny elementów, i | 3,85 | spójność ostateczna: kolejność, duplikaty, wznowienie, katalog z XML |
| 4 | S21 Autoryzacje jako kod — loader YAML, walidacja R7/readOn | 3,85 | reconciler stanu docelowego autoryzacji, dryf, rozdział obowiązków |
| 5 | S60 Pilotaż jednego obszaru; odcięcie użytkowników od webap | 3,80 | wdrożenie, szkolenia, praca równoległa z Tasklist, wsparcie użytkowników |
| 6 | S06 Środowisko dev — Camunda 8.9 na K8s, realm RHBK z feder | 3,70 | dostępy w banku (AD, sieć, RHBK, rejestry), Camunda na K8s; czas zależy od procedur |
| 7 | S24 Access Policy — uprawnienia efektywne, R1–R11, TaskAcce | 3,65 | reguły R1–R11 i materializacja widoczności — serce bezpieczeństwa |
| 8 | S27 Izolacja profili — schemat i użytkownik bazy per profil | 3,65 | EXECUTE AS USER w transakcji z pulą połączeń, RLS widoków platform_api, reguły R10 w reconcilerze — bezpieczeństwo danych |
| 9 | S34 Mapa etapów — agregat, API edytora, dziedziczenie wersj | 3,65 | algorytm stanu etapów (równoległość, pętle, call activity), wersje mapy |
| 10 | S18 BFF — OIDC z RHBK, ciasteczko __Host-, CSRF, wylogowani | 3,55 | OIDC z RHBK, ciasteczka, CSRF, wylogowanie globalne — bezpieczeństwo |
| 11 | S22 Adaptery oficjalnego SDK dla wszystkich portów, fake, t | 3,55 | 7 portów na SDK (w tym ewaluacja wyrażeń) + fake + testy kontraktowe na Testcontainers |
| 12 | S01 PoC oficjalnego SDK Camunda na 8.9 (lista kontrolna) | 3,50 | pokrycie oficjalnego SDK dla 8.9 nieznane; wynik decyduje o ADR-003 |
| 13 | S33 Zastępstwa — worker task listenera (fail-open), uzgadni | 3,50 | worker na ścieżce silnika; fail-open i uzgadnianie |
| 14 | S40 Skrzynka zadań i renderer formatek Camunda Forms (inter | 3,50 | skrzynka zadań i własny renderer Camunda Forms (FEEL, układ, listy powtarzane) — najczęściej używany ekran |
| 15 | S51 Bezpieczeństwo: macierz autoryzacji przez HTTP, izolacj | 3,50 | macierz obejść, izolacja, DAST — wyniki wymagają oceny człowieka |
| 16 | S52 Wydajność i pojemność | 3,50 | wolumeny, plany zapytań, opóźnienie projektora |
| 17 | S54 Pentest, compliance, Deklaracja Dostępności | 3,40 | zewnętrzny pentest i formalne akceptacje |
| 18 | S15 Kontrakty v1 wszystkich modułów i OpenAPI v1 | 3,35 | decyzje projektowe dla 10 modułów naraz; pomyłka kosztuje RFC później |
| 19 | S30 Task Work — przejęcie, zwolnienie, szkic, zakończenie,  | 3,35 | pierwsza pełna ścieżka przez potok, SDK i read model; wyścigi przejęcia |
| 20 | S37 Form Runtime — schemat przypiętej wersji, walidacja dan | 3,35 | walidacja schematu Camunda Forms na serwerze, FEEL przez silnik, przypięcie wersji — błąd przepuszcza złe dane do procesu |
| 21 | S45 Projektant formatek — osadzony edytor form-js z paletą  | 3,35 | osadzenie edytora form-js i ograniczenie go do katalogu pól, porównanie wersji, wycofanie, import i eksport, podgląd |
| 22 | S07 PoC formatek w UI — edytor form-js w Angularze, rendere | 3,30 | edytor form-js (Preact) w Angularze, własny renderer kontra viewer, pomiar rozbieżności zachowania |
| 23 | S36 Dashboard — agregaty, IProcessMetric, progi zdrowia, św | 3,30 | definicje metryk uzgadniane z biznesem, agregaty, percentyle |
| 24 | S19 SDK rozszerzeń i rejestr profili — manifesty, walidacja | 3,20 | nowy publiczny kontrakt SDK — błąd projektu kosztuje wszystkie zespoły profili |
| 25 | S08 PoC walidacji formatek na serwerze — reguły schematu w  | 3,15 | endpoint ewaluacji wyrażeń 8.9 przez SDK, różnice FEEL przeglądarka–silnik, wariant zapasowy |
| 26 | S32 Przekazywanie — osoba, grupa, partia z wznowieniem | 3,15 | saga partii z wznowieniem; przekazanie osobie i grupie |
| 27 | S44 Edytor mapy etapów (bpmn-js viewer) | 3,15 | bpmn-js, interakcja na diagramie, walidacja mapy |
| 28 | S03 PoC task listenera zastępstw (korekty, czas odpowiedzi, | 3,00 | korekty w task listenerze i fail-open do potwierdzenia na 8.9 |
| 29 | S04 PoC zasilania read modelu (wyszukiwanie przyrostowe vs  | 3,00 | pomiar opóźnienia i kompletności zasilania read modelu |
| 30 | S25 Audyt — dziennik dwufazowy, uzgadnianie, API przeglądu, | 3,00 | audyt dwufazowy, uzgadnianie, test kompletności; wymogi compliance |
| 31 | S26 Form Management — formatki Camunda Forms, cykl życia we | 3,00 | maszyna stanów wersji, cztery oczy, wycofanie z wersją zastępczą, separacja per proces, walidacja katalogu i kontraktu |
| 32 | S29 Powiązania formatek z procesem — referencje ph:form i k | 2,85 | referencje i kontrakt z katalogu elementów per wersja definicji, kontrola spójności, reguła bpmnlint |
| 33 | S38 Potok operacji profili (zadanie, sprawa, dane profilu), | 2,85 | potok operacji używa istniejących zachowań; ryzyko w limitach czasu, idempotencji i izolacji awarii profilu |
| 34 | S39 Wycofanie formatek w toku — przepięcie zadań (saga ze w | 2,85 | saga przepięcia zadań ze wznowieniem, przeniesienie szkicu danych, zadania bez formatki |
| 35 | S35 Eskalacje — wykrywanie, zakres, lista, kategoria po ter | 2,80 | wykrywanie eskalacji i ich zakresu |
| 36 | S12 Building Blocks — potok, Actor, ITenantContext, Permiss | 2,70 | fundament: potok, audyt, outbox, lease — błąd tu powiela się w każdym module |
| 37 | S13 MSSQL — schematy, RLS, Ledger, partycje śladu, temporal | 2,65 | RLS, Ledger, partycje; uprawnienia DBA w banku |
| 38 | S55 Zgodność formatek z Camunda Forms i spójność wizualna w | 2,65 | zestaw zgodności z form-js i regresja wizualna w CI; niestabilne zrzuty |
| 39 | S20 Party & Accountability — Actor z tokenu, migawka grup,  | 2,50 | model Party, przypisania ról, nieobecności z regułami czasowymi |
| 40 | S09 Warstwa wizualna — biblioteka w Figma, tokeny, katalog  | 2,40 | biblioteka w Figma, księga znaku banku, uzgodnienie katalogu pól — głównie praca projektanta UX |
| 41 | S31 Process Lifecycle — katalog startowy, start, moje proce | 2,35 | start z formatką i zmiennymi inicjatora |
| 42 | S47 Sloty UI i trasy profili w powłoce | 2,35 | rejestr slotów i leniwe ładowanie — znany wzorzec; ryzyko w granicach Nx i widoczności slotów |
| 43 | S42 Dashboard, eskalacje, instancja z mapą etapów | 2,30 | wykresy, wstęga etapów, dostępność wykresów |
| 44 | S49 Komponenty pól formatek w ui-kit wg katalogu pól, katal | 2,30 | komponenty pól w kompletach stanów, oba motywy, regresja wizualna i axe; wzorce zatwierdza projektant UX |
| 45 | S05 Przegląd scenariuszy z biznesem, decyzje D-01..D-07 | 2,20 | warsztaty z biznesem i decyzje D-01..D-07; tempo zależy od dostępności ludzi |
| 46 | S14 Harness Reqnroll — projekty Specs, drivery, świat testo | 2,20 | Reqnroll z dwoma driverami i wspólnym światem testowym |
| 47 | S16 Frontend — Nx, shell, motyw z tokenów (core/theming), u | 2,20 | Nx, Kendo (licencja, prywatny rejestr), motyw z tokenów, katalog komponentów, mock server |
| 48 | S53 Dostępność i UX | 1,95 | testy z czytnikiem ekranu i klawiaturą to praca człowieka |
| 49 | S00 Repozytorium, harness agentów, skrypt worktree, pusty p | 1,85 | CI, sekrety, worktree i hooki — głównie konfiguracja człowieka |
| 50 | S11 Testy architektury i bramki CI | 1,85 | reguły architektury i pipeline; specyfika CI banku |
| 51 | S43 Przekazywanie pojedyncze i masowe, zastępstwa | 1,85 | okna przekazania i kreator partii |
| 52 | S28 Schemat form — wersje, przeglądy, wycofania, unikalność | 1,80 | tabele wersji i wycofań, indeksy filtrowane, klucz obcy przypięcia z procesem |
| 53 | S17 Wtyczka bpmnlint ph i procesy BPMN świata testowego | 1,65 | wtyczka bpmnlint i przykładowe modele |
| 54 | S48 Onboarding zespołów profili: szablon, przewodnik, kwali | 1,60 | przewodnik, szablon i przegląd manifestów z zespołami — głównie praca ludzi |
| 55 | S10 Szkielet rozwiązania, Host z rolami, szablon dotnet new | 1,55 | szablonowy szkielet — agenci robią to dobrze |
| 56 | S41 Start procesu i moje procesy | 1,50 | proste formularze i listy |
| 57 | S46 Widoki audytora i przegląd audytu | 1,50 | tabele tylko do odczytu |
