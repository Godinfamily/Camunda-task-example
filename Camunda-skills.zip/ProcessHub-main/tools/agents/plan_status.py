#!/usr/bin/env python3
"""Stan planu: scalone kroki, kroki gotowe do startu, blokady; zatwierdzanie bramek i oznaczanie scaleń.

  python3 tools/agents/plan_status.py                                     # plan platformy
  python3 tools/agents/plan_status.py --backlog profiles/kredyty/backlog.yaml
  python3 tools/agents/plan_status.py --merged S10                        # człowiek scalił krok S10
  python3 tools/agents/plan_status.py --approve-gate G0 --by "Jan Kowalski" --evidence "ADR-003, ADR-004 przyjęte"
Bramkę można zatwierdzić dopiero po scaleniu kroków z jej pola `after` (inaczej: --force, decyzja człowieka).
"""
from __future__ import annotations

import argparse
import sys

from steplib import Plan, today, write_json


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backlog", default=None)
    ap.add_argument("--merged")
    ap.add_argument("--approve-gate")
    ap.add_argument("--by")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--force", action="store_true", help="zatwierdź bramkę mimo niescalonych kroków z pola after")
    args = ap.parse_args()
    plan = Plan(args.backlog)

    if args.merged:
        if args.merged not in plan.steps:
            sys.exit(f"Nie ma kroku {args.merged} w {plan.path.name}")
        p = plan.progress(args.merged) or {"step": args.merged}
        p.update({"status": "done", "merged": True, "merged_on": today()})
        write_json(plan.progress_dir / f"{args.merged}.json", p)
        print(f"{args.merged}: oznaczono jako scalony")
        return 0
    if args.approve_gate:
        if not args.by:
            sys.exit("Podaj --by (kto zatwierdza bramkę).")
        gate = plan.data.get("gates", {}).get(args.approve_gate)
        if gate is None:
            sys.exit(f"Nie ma bramki {args.approve_gate} w {plan.path.name}")
        missing = [s for s in gate.get("after", []) if not plan.is_merged(s)]
        if missing and not args.force:
            print(f"{args.approve_gate}: nie można zatwierdzić — niescalone kroki: {', '.join(missing)}")
            return 1
        g = plan.gates()
        g[args.approve_gate] = {"approved_by": args.by, "date": today(), "evidence": args.evidence}
        write_json(plan.gates_file, g)
        print(f"{args.approve_gate}: zatwierdzona przez {args.by}")
        return 0

    merged, in_progress, ready, blocked = [], [], [], []
    for s in plan.data["steps"]:
        p = plan.progress(s["id"])
        if plan.is_merged(s["id"]):
            merged.append(s)
        elif p:
            in_progress.append((s, p.get("status", "w toku")))
        else:
            ok, reasons = plan.readiness(s)
            (ready if ok else blocked).append((s, reasons))
    ready.sort(key=lambda x: (not x[0].get("critical"), {"L": 0, "M": 1, "S": 2}.get(x[0].get("size"), 3)))

    title = f"Plan profilu „{plan.profile}”" if plan.profile else "Plan platformy"
    print(f"{title} — scalone: {len(merged)}/{len(plan.steps)} · w toku: {len(in_progress)} · gotowe: {len(ready)} · zablokowane: {len(blocked)}")
    print(f"Bramki zatwierdzone: {', '.join(plan.gates()) or 'brak'}")
    if in_progress:
        print("\nW toku:")
        for s, st in in_progress:
            print(f"  {s['id']:7} {st:10} {s['title']}")
    print("\nGotowe do startu (krytyczne najpierw):")
    for s, _ in ready:
        print(f"  {s['id']:7} {'K' if s.get('critical') else ' '} {s.get('size', '-')} {plan.agent_name(s['agent']):28} {s['title']}")
    print(f"\nRównolegle wolno prowadzić: {plan.data.get('parallelism', 1)} kroki")
    external = sorted({r.split()[0] for _, rs in blocked for r in rs if r.endswith("nie jest scalony") and r.split()[0] not in plan.steps})
    if external:
        print("Czekają na kroki platformy: " + ", ".join(external))
    waiting_gates = sorted({r.split()[1] for _, rs in blocked for r in rs if r.startswith("bramka")})
    if waiting_gates:
        print("Czekają na bramki: " + ", ".join(waiting_gates))
    return 0


if __name__ == "__main__":
    sys.exit(main())
