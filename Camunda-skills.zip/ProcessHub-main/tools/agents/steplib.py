"""Wspólne funkcje skryptów prowadzenia kroków: plan (platformy albo profilu), postęp, bramki."""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
PLATFORM_BACKLOG = ROOT / "plan/backlog.yaml"


class Plan:
    """Plan kroków: platformy (plan/backlog.yaml) albo zespołu profilu (profiles/<id>/backlog.yaml).

    Postęp planu platformy: plan/progress/; planu profilu: profiles/<id>/progress/.
    Zależność spoza planu (np. krok profilu zależny od S38) sprawdzana jest w postępie planu platformy.
    """

    def __init__(self, backlog: str | Path | None = None):
        self.path = (ROOT / backlog) if backlog else PLATFORM_BACKLOG
        self.data = yaml.safe_load(self.path.read_text(encoding="utf-8"))
        self.profile = self.data.get("profile")
        self.progress_dir = (self.path.parent / "progress") if self.profile else ROOT / "plan/progress"
        self.steps = {s["id"]: s for s in self.data["steps"]}
        self._platform = None if not self.profile else Plan(None)

    @property
    def gates_file(self) -> Path:
        return self.progress_dir / "gates.json"

    def progress(self, step_id: str) -> dict:
        if step_id not in self.steps and self._platform:
            return self._platform.progress(step_id)
        f = self.progress_dir / f"{step_id}.json"
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}

    def origin(self, step_id: str) -> "Plan":
        """Plan, do którego należy krok: ten albo — dla zależności kroku profilu — plan platformy."""
        return self._platform if step_id not in self.steps and self._platform else self

    def is_merged(self, step_id: str) -> bool:
        p = self.progress(step_id)
        return p.get("status") == "done" and bool(p.get("merged"))

    def gates(self) -> dict:
        return json.loads(self.gates_file.read_text(encoding="utf-8")) if self.gates_file.exists() else {}

    def readiness(self, step: dict) -> tuple[bool, list[str]]:
        reasons = [f"{d} nie jest scalony" for d in step.get("depends_on", []) if not self.is_merged(d)]
        gate = step.get("gate_before")
        if gate and gate not in self.gates():
            reasons.append(f"bramka {gate} niezatwierdzona")
        return (not reasons, reasons)

    def agent_name(self, agent: str) -> str:
        return f"{self.profile}-{agent}" if self.profile and agent != "human" else agent


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def today() -> str:
    return date.today().isoformat()
