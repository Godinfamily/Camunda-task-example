#!/usr/bin/env python3
"""Przygotowuje krok planu do pracy agenta: worktree, .agent-scope i pakiet roboczy.

Deterministyczna część pracy orkiestratora — bez modelu, więc bez kosztu tokenów.

  python3 tools/agents/prepare_step.py S10                                        # plan platformy
  python3 tools/agents/prepare_step.py KRE-02 --backlog profiles/kredyty/backlog.yaml   # plan zespołu profilu
  python3 tools/agents/prepare_step.py S10 --no-worktree   # pakiet i .agent-scope w bieżącym katalogu
  python3 tools/agents/prepare_step.py S10 --force         # pomiń kontrolę zależności i bramki (decyzja człowieka)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from steplib import ROOT, Plan

HUMAN = "human"


def git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True)


def ensure_worktree(step_id: str, branch: str, root: Path) -> Path:
    path = (root / f"wt-{step_id}").resolve()
    if path.exists():
        return path
    if git("rev-parse", "--is-inside-work-tree").returncode != 0:
        sys.exit("Repozytorium nie jest repozytorium git — użyj --no-worktree albo wykonaj git init.")
    has_branch = git("rev-parse", "--verify", branch).returncode == 0
    res = git("worktree", "add", str(path), branch) if has_branch else git("worktree", "add", "-b", branch, str(path), "HEAD")
    if res.returncode != 0:
        sys.exit(f"git worktree add nie powiódł się: {res.stderr.strip()}")
    return path


def contracts_of(step: dict) -> list[str]:
    return [r for r in step.get("reads", []) if r.rstrip("/").endswith("Contracts")]


# Podział pracy w parze, gdy krok nie podaje własnego (`pair_task`).
PAIR_DEFAULT = {
    "bdd-tester": "pisze kroki Reqnroll i drivery w projektach testów, zanim powstanie implementacja; wykonawca nie edytuje `tests/*.Specs/**`",
    "security-reviewer": "obowiązkowy przegląd bezpieczeństwa po zielonych bramkach (tylko odczyt)",
    "ui-reviewer": "obowiązkowy przegląd warstwy wizualnej po zielonych bramkach (tylko odczyt)",
}
PAIR_OTHER = "współwykonawca w tym samym worktree i zakresie — wykonuje część wskazaną przez wykonawcę"


def section(title: str, items: list[str]) -> list[str]:
    """Sekcja pakietu z listą punktów; pusta lista = brak sekcji (pakiet ma być krótki)."""
    return ["", f"## {title}"] + [f"- {i}" for i in items] if items else []


def packet(step: dict, plan: Plan) -> str:
    dod = step.get("dod") or plan.data.get("common_dod", [])
    reads = [r for r in step.get("reads", []) if r not in contracts_of(step)]
    if "AGENTS.md" not in reads:
        reads.insert(0, "AGENTS.md")
    if plan.profile and f"profiles/{plan.profile}/AGENTS.md" not in reads:
        reads.insert(1, f"profiles/{plan.profile}/AGENTS.md")
    human = step["agent"] == HUMAN
    agent = plan.agent_name(step["agent"])
    pair = plan.agent_name(step["pair"]) if step.get("pair") else None
    inputs = []
    for dep in step.get("depends_on", []):
        owner = plan.origin(dep)
        title = owner.steps[dep]["title"] if dep in owner.steps else "krok spoza planu"
        inputs.append(f"`{dep}` {title} — przekazanie: `{owner.progress_dir.relative_to(ROOT)}/{dep}.json`")
    lines = [f"# Pakiet roboczy — {step['id']}: {step['title']}", "",
             "> Wygenerowany przez tools/agents/prepare_step.py. Czytaj tylko ten plik i pliki z sekcji „Czytaj”.", "",
             "## Cel", step["title"] + ".", "",
             (f"Profil projektu: `{plan.profile}` — zapis wyłącznie w `profiles/{plan.profile}/**`.\n" if plan.profile else "")
             + f"Wykonawca: `{agent}`" + (f" · para: `{pair}`" if pair else "")
             + f" · rozmiar: {step.get('size', '—')} · ścieżka krytyczna: {'tak' if step.get('critical') else 'nie'}"]
    lines += section("Wynik (co ma powstać)", step.get("outcome", []))
    lines += section("Wskazówki startowe", step.get("notes", []))
    lines += ["", "## Czytaj (w tej kolejności)"] + [f"{i}. `{r}`" for i, r in enumerate(reads, 1)]
    lines += section("Sięgaj punktowo (wyszukuj fragment, nie czytaj w całości)", step.get("refs", []))
    lines += section("Wejście od poprzedników (czytaj pytania otwarte i listę zmienionych plików)", inputs)
    lines += ["", "## Wolno zapisywać (`.agent-scope`)"] + [f"- `{w}`" for w in step.get("writes", [])]
    lines += [f"- `docs/rfc/RFC-{step['id']}-<temat>.md` — wniosek o zmianę poza zakresem (dozwolony zawsze)"]
    if pair:
        lines += section("Para", [f"`{pair}`: " + (step.get("pair_task") or PAIR_DEFAULT.get(step["pair"], PAIR_OTHER))])
    lines += ["", "## Scenariusze do zaliczenia"] + ([f"- `{s}`" for s in step.get("specs", [])] or ["- brak (krok techniczny)"])
    lines += ["", "## Kontrakty zależności (tylko do odczytu)"] + ([f"- `{c}`" for c in contracts_of(step)] or ["- brak"])
    lines += ["", "## Definition of Done"] + [f"- [ ] `{c}` kończy się kodem 0" for c in dod]
    lines += ["- [ ] brak nowych ostrzeżeń analizatorów",
              "- [ ] każda nowa komenda lub operacja ma deskryptor audytu; każdy endpoint — politykę autoryzacji",
              "- [ ] `AGENTS.md` modułu lub profilu zaktualizowany (cel, inwarianty, komendy)"]
    lines += section("Kryteria akceptacji człowieka (poza bramkami)", step.get("acceptance", []))
    lines += ["", "## Budżet", "Próby: 2 · potem jedna sesja od zera z diagnozą recenzenta (albo wyższy wariant rozumowania, jeśli rola go ma) "
              "· potem człowiek · zakaz zmian poza `.agent-scope` (zmiana kontraktu, scenariusza platformy lub SDK → RFC w docs/rfc/)", "",
              "## Przekazanie"]
    if not human:
        lines += [f"Przed przekazaniem zatwierdź zmiany na gałęzi kroku: `git add -A`, potem `git commit -m \"{step['id']}: <opis>\"` (bez `push`)."]
    lines += [f"Ostatnia wiadomość: JSON wg `AGENTS.md` → `{plan.progress_dir.relative_to(ROOT)}/{step['id']}.json`", ""]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("step")
    ap.add_argument("--backlog", default=None, help="plan zespołu profilu, np. profiles/kredyty/backlog.yaml")
    ap.add_argument("--worktree-root", default=str(ROOT.parent), help="katalog, w którym powstaje wt-<krok>")
    ap.add_argument("--no-worktree", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    plan = Plan(args.backlog)
    step = plan.steps.get(args.step)
    if not step:
        sys.exit(f"Nie ma kroku {args.step} w {plan.path.relative_to(ROOT)}")
    ok, reasons = plan.readiness(step)
    if not ok and not args.force:
        print(f"Krok {step['id']} nie jest gotowy: " + "; ".join(reasons))
        print("Uzupełnij postęp (scalenie poprzedników, zatwierdzenie bramki) albo uruchom z --force decyzją człowieka.")
        return 1

    if step["agent"] == HUMAN:
        target = ROOT
        print(f"Krok {step['id']} wykonuje człowiek — powstaje tylko pakiet (bez worktree i .agent-scope).")
    else:
        branch = f"profile/{plan.profile}/{step['id']}" if plan.profile else f"step/{step['id']}"
        target = ROOT if args.no_worktree else ensure_worktree(step["id"], branch, Path(args.worktree_root))
        scope = [f"# Wygenerowane przez prepare_step.py — zakres zapisu kroku {step['id']}"]
        if plan.profile:
            scope.append(f"@profile {plan.profile}")
        scope += step.get("writes", [])
        (target / ".agent-scope").write_text("\n".join(scope) + "\n", encoding="utf-8")

    out = target / "plan/packets" / f"{step['id']}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(packet(step, plan), encoding="utf-8")
    print(f"worktree: {target}")
    print(f"pakiet:   {out}")
    if step["agent"] != HUMAN:
        agent = plan.agent_name(step["agent"])
        print(f"zakres:   {target / '.agent-scope'}" + (f"  (profil: {plan.profile})" if plan.profile else ""))
        print(f"agent:    {agent}" + (f" + {plan.agent_name(step['pair'])}" if step.get("pair") else ""))
        print(f"start:    opencode run --dir {target} --agent {agent} \"Wykonaj pakiet plan/packets/{step['id']}.md\"")
        print(f"          (interaktywnie: cd {target} && opencode, potem: @{agent} Wykonaj pakiet plan/packets/{step['id']}.md)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
