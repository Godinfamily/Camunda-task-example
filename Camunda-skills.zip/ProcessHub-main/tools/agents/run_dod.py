#!/usr/bin/env python3
"""Uruchamia bramki deterministyczne (Definition of Done) kroku i zapisuje wynik <postęp>/<krok>.gates.json.

  python3 tools/agents/run_dod.py S10 --dir ../wt-S10
  python3 tools/agents/run_dod.py KRE-02 --backlog profiles/kredyty/backlog.yaml --dir ../wt-KRE-02
Kod wyjścia 1, gdy którakolwiek komenda się nie powiedzie. Pełne logi: <postęp>/logs/ (poza repozytorium git).
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

from steplib import ROOT, Plan, today, write_json

TAIL = 40


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("step")
    ap.add_argument("--backlog", default=None)
    ap.add_argument("--dir", default=".", help="katalog roboczy kroku (worktree)")
    ap.add_argument("--timeout", type=int, default=1800)
    args = ap.parse_args()

    plan = Plan(args.backlog)
    step = plan.steps.get(args.step)
    if not step:
        sys.exit(f"Nie ma kroku {args.step}")
    commands = step.get("dod") or plan.data.get("common_dod", [])
    workdir = Path(args.dir).resolve()
    logs = plan.progress_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)

    results = []
    for i, cmd in enumerate(commands, 1):
        t0 = time.time()
        try:
            res = subprocess.run(cmd, shell=True, cwd=workdir, capture_output=True, text=True, timeout=args.timeout)
            code, output = res.returncode, (res.stdout or "") + (res.stderr or "")
        except subprocess.TimeoutExpired:
            code, output = 124, f"przekroczono limit czasu {args.timeout} s"
        log = logs / f"{args.step}-{i}.log"
        log.write_text(output, encoding="utf-8")
        results.append({"command": cmd, "exit_code": code, "passed": code == 0, "seconds": round(time.time() - t0, 1),
                        "log": str(log.relative_to(ROOT)),
                        "tail": "" if code == 0 else "\n".join(output.strip().splitlines()[-TAIL:])})
        print(f"[{'OK ' if code == 0 else 'BŁĄD'}] {cmd}  ({results[-1]['seconds']} s)")
        if code != 0:
            break  # kolejne bramki zwykle zależą od poprzednich; oszczędza czas i tokeny triage

    passed = all(r["passed"] for r in results) and len(results) == len(commands)
    out = plan.progress_dir / f"{args.step}.gates.json"
    write_json(out, {"step": args.step, "date": today(), "workdir": str(workdir), "passed": passed, "results": results})
    print(f"wynik: {'zielone' if passed else 'czerwone'} → {out.relative_to(ROOT)}")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
