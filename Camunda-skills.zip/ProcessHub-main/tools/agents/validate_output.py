#!/usr/bin/env python3
"""Waliduje wynik agenta (JSON) względem schematu roli. Użycie: validate_output.py <schemat> <plik.json|->"""
import json
import sys

try:
    import jsonschema
except ImportError:  # pragma: no cover
    sys.exit("Zainstaluj pakiet jsonschema: pip install jsonschema")

schema = json.load(open(sys.argv[1], encoding="utf-8"))
raw = sys.stdin.read() if sys.argv[2] == "-" else open(sys.argv[2], encoding="utf-8").read()
try:
    jsonschema.validate(json.loads(raw), schema)
except (json.JSONDecodeError, jsonschema.ValidationError) as e:
    print(f"NIEZGODNE: {e.__class__.__name__}: {str(e).splitlines()[0]}", file=sys.stderr)
    sys.exit(1)
print("ZGODNE")
