#!/usr/bin/env python3
"""Zakłada nowy profil projektu z szablonu profiles/_template.

  python3 tools/profiles/new_profile.py lizing --name "Lizing" --team "@bank/zespol-lizing" --process umowa-lizingowa
Potem: uzupełnij profile.yaml i authorization.yaml, uruchom validate_profiles.py --write-codeowners i render_agents.py.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEMPLATE = ROOT / "profiles/_template"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("id")
    ap.add_argument("--name", required=True)
    ap.add_argument("--team", required=True, help="grupa w systemie kontroli wersji, np. @bank/zespol-lizing")
    ap.add_argument("--process", required=True, help="bpmnProcessId pierwszego procesu profilu")
    ap.add_argument("--po", default="Właściciel produktu")
    ap.add_argument("--description", default="Opis projektu do uzupełnienia.")
    args = ap.parse_args()

    if not re.fullmatch(r"[a-z][a-z0-9]{1,23}", args.id):
        sys.exit("id: małe litery i cyfry, 2–24 znaki, bez myślników (przestrzeń nazw i schemat prj_<id>)")
    target = ROOT / "profiles" / args.id
    if target.exists():
        sys.exit(f"profil {args.id} już istnieje")
    shutil.copytree(TEMPLATE, target)
    values = {"__ID__": args.id, "__NAME__": args.name, "__TEAM__": args.team, "__PROCESS__": args.process,
              "__PO__": args.po, "__OPIS__": args.description, "__GROUP__": args.id.upper(),
              "__PREFIX__": args.id[:3].upper()}
    for f in target.rglob("*"):
        if f.is_file() and f.suffix in {".yaml", ".md"}:
            text = f.read_text(encoding="utf-8")
            for k, v in values.items():
                text = text.replace(k, v)
            f.write_text(text, encoding="utf-8")
    print(f"utworzono profiles/{args.id}/ — uzupełnij profile.yaml i authorization.yaml, potem:")
    print("  python3 tools/profiles/validate_profiles.py --write-codeowners")
    print("  python3 tools/agents/render_agents.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
