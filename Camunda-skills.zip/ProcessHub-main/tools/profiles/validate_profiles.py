#!/usr/bin/env python3
"""Walidacja profili projektów i generowanie CODEOWNERS.

  python3 tools/profiles/validate_profiles.py                     # raport
  python3 tools/profiles/validate_profiles.py --check             # bramka CI: błędy lub nieaktualny CODEOWNERS → kod 1
  python3 tools/profiles/validate_profiles.py --write-codeowners  # zapisuje CODEOWNERS

Sprawdza schemat (profiles/profile.schema.json) i reguły międzyprofilowe: przestrzenie nazw (R10), wyłączną własność
procesów i grup kandydujących, spójność ról, operacji, slotów UI, klas danych i zakresów zapisu w planie zespołu.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
PROFILES = ROOT / "profiles"
CLASS_RANK = {"internal": 0, "confidential": 1, "restricted": 2}
WRITE_KINDS = {"task-action", "case-action", "profile-action"}
GENERATED = "# WYGENEROWANE przez tools/profiles/validate_profiles.py --write-codeowners — źródła: config/ownership.yaml, profiles/*/profile.yaml"


def platform_permissions() -> set[str]:
    roles = yaml.safe_load((ROOT / "config/authorization/roles.example.yaml").read_text(encoding="utf-8"))["roles"]
    return {p for r in roles for p in r.get("permissions", [])}


def load_profiles():
    out = []
    for d in sorted(p for p in PROFILES.iterdir() if p.is_dir() and not p.name.startswith("_")):
        manifest = d / "profile.yaml"
        if not manifest.exists():
            out.append((d.name, None, None, [f"{d.name}: brak profile.yaml"]))
            continue
        prof = yaml.safe_load(manifest.read_text(encoding="utf-8"))
        authz_path = d / "authorization.yaml"
        authz = yaml.safe_load(authz_path.read_text(encoding="utf-8")) if authz_path.exists() else None
        out.append((d.name, prof, authz, []))
    return out


def validate(profiles) -> list[str]:
    schema = json.loads((PROFILES / "profile.schema.json").read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    platform_perms = platform_permissions()
    errors: list[str] = []
    process_owner: dict[str, str] = {}
    candidate_owner: dict[str, str] = {}
    group_owner: dict[str, str] = {}

    for name, prof, authz, errs in profiles:
        errors += errs
        if prof is None:
            continue
        for e in validator.iter_errors(prof):
            errors.append(f"{name}: schemat — {'/'.join(map(str, e.path)) or '(korzeń)'}: {e.message}")
        pid = prof.get("id")
        if pid != name:
            errors.append(f"{name}: id „{pid}” musi być równe nazwie katalogu")
        ns = f"{pid}."
        if prof.get("data", {}).get("schema") != f"prj_{pid}":
            errors.append(f"{name}: schemat danych musi nazywać się prj_{pid}")
        own_processes = {p["bpmnProcessId"] for p in prof.get("processes", [])}
        for proc in own_processes:
            if proc in process_owner:
                errors.append(f"{name}: proces {proc} należy już do profilu {process_owner[proc]} (proces ma jednego właściciela)")
            process_owner[proc] = name
        perms = {p["id"]: p for p in prof.get("permissions", [])}
        for pid_ in perms:
            if not pid_.startswith(ns):
                errors.append(f"{name}: uprawnienie {pid_} spoza przestrzeni nazw {ns} (R10)")
        roles = {r["id"]: r for r in prof.get("roles", [])}
        for r in roles.values():
            for p in r.get("permissions", []):
                if p not in perms:
                    errors.append(f"{name}: rola {r['id']} używa nieznanego uprawnienia {p}")
            for proc in r.get("processes", []):
                if proc not in own_processes:
                    errors.append(f"{name}: rola {r['id']} obejmuje proces {proc} spoza profilu (R9)")
        for op in prof.get("operations", []):
            if not op["id"].startswith(ns):
                errors.append(f"{name}: operacja {op['id']} spoza przestrzeni nazw {ns} (R10)")
            if op["permission"] not in perms and op["permission"] not in platform_perms:
                errors.append(f"{name}: operacja {op['id']} — nieznane uprawnienie {op['permission']}")
            proc = op.get("appliesTo", {}).get("process")
            if proc and proc not in own_processes:
                errors.append(f"{name}: operacja {op['id']} na procesie {proc} spoza profilu (R9)")
            if op["kind"] in WRITE_KINDS and "requiresAssignee" not in op:
                errors.append(f"{name}: operacja zapisu {op['id']} musi jawnie deklarować requiresAssignee")
            if op["kind"] == "task-action" and op.get("requiresAssignee") is False:
                errors.append(f"{name}: task-action {op['id']} bez wymogu assignee łamie R1")
            if op["kind"] == "profile-action":          # zapis danych profilu bez zadania i sprawy (ADR-017)
                if op.get("requiresAssignee"):
                    errors.append(f"{name}: profile-action {op['id']} nie dotyczy zadania — requiresAssignee musi być false")
                if op.get("appliesTo"):
                    errors.append(f"{name}: profile-action {op['id']} działa na danych profilu — bez appliesTo (R9)")
                if perms.get(op["permission"], {}).get("kind") != "write":
                    errors.append(f"{name}: profile-action {op['id']} wymaga uprawnienia projektu rodzaju write")
            kind = perms.get(op["permission"], {}).get("kind")
            if kind == "sensitive-read" and not op.get("sensitive"):
                errors.append(f"{name}: operacja {op['id']} z uprawnieniem odczytu wrażliwego musi mieć sensitive: true")
        ui = prof.get("ui", {})
        for route in ui.get("routes", []):
            if not route["path"].startswith(f"/p/{pid}/"):
                errors.append(f"{name}: trasa {route['path']} musi zaczynać się od /p/{pid}/")
        for slot in ui.get("slots", []):
            if slot.get("permission") and slot["permission"] not in perms and slot["permission"] not in platform_perms:
                errors.append(f"{name}: slot {slot['component']} — nieznane uprawnienie {slot['permission']}")
            proc = slot.get("appliesTo", {}).get("process")
            if proc and proc not in own_processes:
                errors.append(f"{name}: slot {slot['component']} na procesie {proc} spoza profilu (R9)")
        for jt in prof.get("integrations", {}).get("jobTypes", []):
            if not jt.startswith(ns):
                errors.append(f"{name}: typ zadania {jt} musi zaczynać się od {ns}")
        dev = prof.get("dev", {})
        data_class = prof.get("data", {}).get("classification", "internal")
        if CLASS_RANK.get(dev.get("dataClass", data_class), 0) < CLASS_RANK.get(data_class, 0):
            errors.append(f"{name}: dev.dataClass słabsza niż klasyfikacja danych profilu ({data_class})")
        backlog = dev.get("backlog")
        if backlog:
            bpath = ROOT / backlog
            if not bpath.exists():
                errors.append(f"{name}: brak planu zespołu {backlog}")
            else:
                b = yaml.safe_load(bpath.read_text(encoding="utf-8"))
                if b.get("profile") != pid:
                    errors.append(f"{name}: {backlog} musi mieć profile: {pid}")
                for step in b.get("steps", []):
                    for w in step.get("writes", []):
                        if not w.startswith(f"profiles/{pid}/"):
                            errors.append(f"{name}: krok {step['id']} zapisuje poza profiles/{pid}/ ({w})")
        if authz is None:
            errors.append(f"{name}: brak authorization.yaml")
            continue
        if authz.get("profile") != pid:
            errors.append(f"{name}: authorization.yaml musi mieć profile: {pid}")
        for a in authz.get("assignments", []):
            for r in a.get("roles", []):
                if r not in roles:
                    errors.append(f"{name}: grupa {a['group']} dostaje nieznaną rolę {r}")
            if a["group"] in group_owner and group_owner[a["group"]] != name:
                errors.append(f"{name}: grupa {a['group']} jest już przypisana w profilu {group_owner[a['group']]} — użyj osobnej grupy AD per profil")
            group_owner[a["group"]] = name
        for cg in (authz.get("candidateGroups") or {}):
            if cg in candidate_owner:
                errors.append(f"{name}: grupa kandydująca {cg} należy już do profilu {candidate_owner[cg]}")
            candidate_owner[cg] = name
    return errors


def codeowners(profiles) -> str:
    own = yaml.safe_load((ROOT / "config/ownership.yaml").read_text(encoding="utf-8"))
    handle = {k: own[k] for k in ("platform", "architects", "security", "design")}
    lines = [GENERATED, "", f"*  {own['platform']}"]
    for entry in own["paths"]:
        lines.append(f"{entry['path']}  " + " ".join(handle[o] for o in entry["owners"]))
    lines.append("")
    for name, prof, _, _ in profiles:
        if prof is None:
            continue
        team = prof["owner"]["team"]
        lines.append(f"/profiles/{name}/  {team}")
        lines.append(f"/profiles/{name}/profile.yaml  {team} {handle['architects']}")
        lines.append(f"/profiles/{name}/authorization.yaml  {team} {handle['architects']} {handle['security']}")
    return "\n".join(lines) + "\n"


def self_test() -> int:
    """Złe manifesty muszą zostać odrzucone — test reguł bez plików na dysku."""
    import copy
    base = {name: (prof, authz) for name, prof, authz, _ in load_profiles() if prof}
    k, ka = base["kredyty"]
    a, aa = base["aml"]

    def run(mut):
        kk, kka, am, ama = copy.deepcopy(k), copy.deepcopy(ka), copy.deepcopy(a), copy.deepcopy(aa)
        mut(kk, kka, am, ama)
        return validate([("kredyty", kk, kka, []), ("aml", am, ama, [])])

    cases = {
        "proces w dwóch profilach": lambda kk, kka, am, ama: am["processes"].append({"bpmnProcessId": "wniosek-kredytowy"}),
        "uprawnienie w cudzej przestrzeni": lambda kk, kka, am, ama: am["permissions"].append({"id": "kredyty.Case.Export", "kind": "read", "description": "x"}),
        "operacja na cudzym procesie": lambda kk, kka, am, ama: am["operations"][0]["appliesTo"].update({"process": "wniosek-kredytowy"}),
        "task-action bez assignee": lambda kk, kka, am, ama: kk["operations"][0].update({"requiresAssignee": False}),
        "odczyt wrażliwy bez oznaczenia": lambda kk, kka, am, ama: kk["operations"][2].pop("sensitive"),
        "grupa kandydująca w dwóch profilach": lambda kk, kka, am, ama: ama["candidateGroups"].update({"kre-analitycy": "PH-AML-ANALITYCY"}),
        "rola z nieznanym uprawnieniem": lambda kk, kka, am, ama: kk["roles"][0]["permissions"].append("aml.Party.View"),
        "trasa poza /p/<id>/": lambda kk, kka, am, ama: kk["ui"]["routes"][0].update({"path": "/portfel"}),
        "słabsza klasa danych agentów": lambda kk, kka, am, ama: am["dev"].update({"dataClass": "confidential"}),
        "profile-action z uprawnieniem platformy": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "Task.ViewOwn", "requiresAssignee": False}),
        "profile-action przypięta do procesu": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "kredyty.Limit.Override", "requiresAssignee": False,
             "appliesTo": {"process": "wniosek-kredytowy"}}),
        "profile-action z wymogiem assignee": lambda kk, kka, am, ama: kk["operations"].append(
            {"id": "kredyty.SaveProduct", "kind": "profile-action", "permission": "kredyty.Limit.Override", "requiresAssignee": True}),
    }
    failed = [name for name, mut in cases.items() if not run(mut)]
    ok_errors = validate([("kredyty", k, ka, []), ("aml", a, aa, [])])
    for name in failed:
        print(f"self-test FAIL: nie wykryto „{name}”", file=sys.stderr)
    if ok_errors:
        print("self-test FAIL: poprawne profile zgłaszają błędy", file=sys.stderr)
    print("self-test OK" if not failed and not ok_errors else "self-test FAILED")
    return 1 if failed or ok_errors else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--write-codeowners", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    profiles = load_profiles()
    errors = validate(profiles)
    for name, prof, authz, _ in profiles:
        if prof:
            print(f"{name:10} procesy: {', '.join(p['bpmnProcessId'] for p in prof['processes'])} · role: {len(prof['roles'])} · "
                  f"operacje: {len(prof.get('operations', []))} · dane: {prof['data']['schema']} ({prof['data']['classification']}) · "
                  f"integracja: {prof.get('integration', 'in-process')} · zespół: {prof['owner']['team']}")
    for e in errors:
        print(f"BŁĄD: {e}", file=sys.stderr)
    content = codeowners(profiles)
    path = ROOT / "CODEOWNERS"
    if args.write_codeowners and not errors:
        path.write_text(content, encoding="utf-8")
        print("zapisano CODEOWNERS")
    stale = not path.exists() or path.read_text(encoding="utf-8") != content
    if args.check and stale:
        print("NIEAKTUALNE: CODEOWNERS — uruchom --write-codeowners", file=sys.stderr)
    return 1 if errors or (args.check and stale) else 0


if __name__ == "__main__":
    sys.exit(main())
