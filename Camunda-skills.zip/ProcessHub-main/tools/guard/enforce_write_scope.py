#!/usr/bin/env python3
"""Strażnik zakresu zapisu dla agentów Process Hub (OpenCode i CI).

Tryby:
  (domyślny)                 stdin: {"tool": "write", "path": "<plik>"} — kod 0 = dozwolone, 2 = blokada (powód na stderr).
                             Wywołuje go plugin OpenCode `.opencode/plugin/write-scope.js` przed każdym zapisem.
  --check <ścieżka>...       sprawdza podane ścieżki względem `.agent-scope` (skrypty, ręczna weryfikacja).
  --verify-diff <base>       bramka CI i DoD: wszystkie pliki zmienione względem <base> — zatwierdzone, niezatwierdzone
                             i nieśledzone — muszą mieścić się w zakresie (łapie też zmiany zrobione komendą, nie edytorem).
      [--profile <id>]       bramka CI dla PR zespołu profilu: zmiany wyłącznie w profiles/<id>/** (bez .agent-scope).
  --self-test                test reguł.

`.agent-scope` (katalog główny worktree) tworzy `tools/agents/prepare_step.py` z pola `writes` kroku:
  - jeden glob w linii; `#` — komentarz;
  - `@profile <id>` — krok zespołu profilu: każdy zapis musi leżeć w profiles/<id>/, niezależnie od globów.
Brak pliku = sesja człowieka: zapis dozwolony (z PH_STRICT=1 — bez ścieżek chronionych).
Wniosek RFC (`docs/rfc/RFC-*.md`) wolno złożyć zawsze — także w kroku profilu; to jedyna droga zmiany poza zakresem.
"""
from __future__ import annotations

import fnmatch
import json
import os
import subprocess
import sys

# Ścieżki chronione: zmiana tylko, gdy glob w .agent-scope wprost je wymienia (marker); inaczej — RFC w docs/rfc/.
PROTECTED = {
    "specs/**": "specs/",
    "**/Contracts/**": "/Contracts",
    "docs/adr/**": "docs/adr",
    "config/authorization/**": "config/authorization",
    "plan/backlog.yaml": "plan/backlog.yaml",
    "AGENTS.md": "AGENTS.md",                                   # tylko plik główny; AGENTS.md modułów i profili są wolne
    "CODEOWNERS": "CODEOWNERS",
    "src/Platform/ProcessHub.Extensibility/**": "ProcessHub.Extensibility",   # SDK rozszerzeń = kontrakt z profilami
    "frontend/libs/platform/extension-sdk/**": "extension-sdk",
    "profiles/*/profile.yaml": "profile.yaml",                 # kontrakt profilu z platformą
    "profiles/*/authorization.yaml": "authorization.yaml",
}

# Wniosek o zmianę poza zakresem kroku: dozwolony w każdym kroku (AGENTS.md, zasada 8).
RFC_GLOB = "docs/rfc/RFC-*.md"


def project_root() -> str:
    return os.environ.get("PH_PROJECT_DIR") or os.getcwd()


def load_scope(root: str):
    """Zwraca (globy, profil) albo (None, None), gdy brak .agent-scope."""
    path = os.path.join(root, ".agent-scope")
    if not os.path.exists(path):
        return None, None
    globs, profile = [], None
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("@profile "):
                profile = line.split(None, 1)[1].strip()
            else:
                globs.append(line)
    return globs, profile


def matches(rel: str, globs) -> bool:
    return any(fnmatch.fnmatchcase(rel, g) or fnmatch.fnmatchcase(rel, g.rstrip("/*")) for g in globs)


def normalize(rel: str) -> str:
    rel = rel.replace("\\", "/")
    while rel.startswith("./"):
        rel = rel[2:]
    return rel


def decide(rel: str, scope, profile: str | None = None):
    rel = normalize(rel)
    if rel.startswith("../") or rel == ".." or os.path.isabs(rel):
        return False, f"zapis poza repozytorium: {rel}"
    if fnmatch.fnmatchcase(rel, RFC_GLOB) and "/" not in rel[len("docs/rfc/"):]:
        return True, ""
    if profile:
        own = f"profiles/{profile}/"
        if rel.startswith("profiles/") and not rel.startswith(own):
            other = rel.split("/")[1]
            return False, f"{rel} należy do profilu „{other}” — krok profilu „{profile}” zmienia tylko {own}**"
        if not rel.startswith(own):
            return False, f"{rel} to część platformy — krok profilu „{profile}” zmienia tylko {own}** (zmiana platformy: RFC w docs/rfc/)"
    if scope is None:
        if os.environ.get("PH_STRICT") == "1" and matches(rel, list(PROTECTED)):
            return False, f"ścieżka chroniona bez .agent-scope: {rel}"
        return True, ""
    for pattern, marker in PROTECTED.items():
        if fnmatch.fnmatchcase(rel, pattern):
            explicit = any(marker in g and matches(rel, [g]) for g in scope) or scope == ["**"]
            if not explicit:
                return False, f"ścieżka chroniona ({rel}) — złóż RFC w docs/rfc/ zamiast edytować"
    if not matches(rel, scope):
        return False, f"{rel} jest poza zakresem kroku; dozwolone: {', '.join(scope)}"
    return True, ""


def relative(target: str, root: str) -> str:
    return os.path.relpath(os.path.abspath(os.path.join(root, target)), root)


def stdin_mode() -> int:
    data = json.load(sys.stdin)
    target = data.get("path")
    if not target:
        return 0
    root = project_root()
    scope, profile = load_scope(root)
    ok, why = decide(relative(target, root), scope, profile)
    if ok:
        return 0
    print(f"BLOCKED: {why}", file=sys.stderr)
    return 2


def check_paths(paths) -> int:
    root = project_root()
    scope, profile = load_scope(root)
    bad = 0
    for p in paths:
        ok, why = decide(relative(p, root), scope, profile)
        print(("OK       " if ok else "BLOCKED  ") + (p if ok else why))
        bad += 0 if ok else 1
    return 1 if bad else 0


def verify_diff(base: str, profile_arg: str | None) -> int:
    root = project_root()
    scope, profile = load_scope(root)
    profile = profile_arg or profile
    if profile and scope is None:
        scope = [f"profiles/{profile}/**"]
    res = subprocess.run(["git", "diff", "--name-only", f"{base}...HEAD"], capture_output=True, text=True, cwd=root)
    if res.returncode != 0:
        print(f"BŁĄD: nie udało się porównać z {base}: {res.stderr.strip()}", file=sys.stderr)
        return 2
    files = res.stdout.split()
    # Zmiany jeszcze niezatwierdzone i pliki nieśledzone (np. powstałe z komendy) — ten sam zakres.
    for extra in (["diff", "--name-only", "HEAD"], ["ls-files", "--others", "--exclude-standard"]):
        more = subprocess.run(["git", *extra], capture_output=True, text=True, cwd=root)
        if more.returncode == 0:
            files += [f for f in more.stdout.split() if f not in files]
    bad = [(f, why) for f in files for ok, why in [decide(f, scope, profile)] if not ok]
    for f, why in bad:
        print(f"SCOPE VIOLATION: {why}", file=sys.stderr)
    return 1 if bad else 0


def self_test() -> int:
    module = ["src/Modules/TaskWork/**", "tests/TaskWork.*/**"]
    prof = ["profiles/kredyty/**"]
    cases = [
        # (ścieżka, globy, profil, oczekiwany wynik)
        ("src/Modules/TaskWork/Domain/WorkItem.cs", module, None, True),
        ("src/Modules/TaskWork/Contracts/ITaskWork.cs", module, None, False),
        ("src/Modules/Audit/Domain/JournalEntry.cs", module, None, False),
        ("tests/TaskWork.Specs/Steps/ClaimSteps.cs", module, None, True),
        ("specs/tasks/claim-and-complete.feature", module, None, False),
        ("../outside.txt", module, None, False),
        ("src/Modules/TaskWork/AGENTS.md", module, None, True),
        ("src/Modules/TaskWork/Contracts/X.cs", ["src/Modules/*/Contracts/**"], None, True),
        ("profiles/kredyty/backend/Kredyty.Extension/Scoring/RecalculateScoring.cs", prof, "kredyty", True),
        ("profiles/kredyty/specs/scoring.feature", prof, "kredyty", True),
        ("profiles/kredyty/AGENTS.md", prof, "kredyty", True),
        ("profiles/kredyty/profile.yaml", prof, "kredyty", False),
        ("profiles/aml/backend/Aml.Extension/Sanctions.cs", prof, "kredyty", False),
        ("profiles/aml/backend/Aml.Extension/Sanctions.cs", ["profiles/**"], "kredyty", False),
        ("src/Modules/TaskWork/Domain/WorkItem.cs", ["**"], "kredyty", False),
        ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", ["src/Platform/**"], None, False),
        ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", ["src/Platform/ProcessHub.Extensibility/**"], None, True),
        ("docs/rfc/RFC-S30-kontrakt.md", module, None, True),
        ("docs/rfc/RFC-KRE-02-sdk.md", prof, "kredyty", True),
        ("docs/rfc/notatki.md", module, None, False),
        ("docs/rfc/RFC-S30/zalacznik.md", module, None, False),
    ]
    failed = [(p, exp) for p, g, pr, exp in cases if decide(p, g, pr)[0] != exp]
    for p, exp in failed:
        print(f"self-test FAIL: {p} oczekiwano {'dozwolone' if exp else 'blokada'}", file=sys.stderr)
    print("self-test OK" if not failed else "self-test FAILED")
    return 1 if failed else 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if args[:1] == ["--self-test"]:
        sys.exit(self_test())
    if args[:1] == ["--check"]:
        sys.exit(check_paths(args[1:]))
    if args[:1] == ["--verify-diff"] and len(args) >= 2:
        prof = args[args.index("--profile") + 1] if "--profile" in args else None
        sys.exit(verify_diff(args[1], prof))
    sys.exit(stdin_mode())
