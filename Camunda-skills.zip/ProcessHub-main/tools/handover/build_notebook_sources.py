#!/usr/bin/env python3
"""Składa pliki repozytorium w kilka tematycznych plików Markdown do wgrania jako źródła w notesie LLM.

Notesy zwykle ograniczają liczbę źródeł i typy plików (YAML, JSON, .feature, .py bywają nieobsługiwane),
dlatego każdy plik trafia do pakietu jako sekcja z pełną ścieżką i — dla plików nie-Markdown — w bloku kodu.
Wyjście: docs/handover/notes/zrodla/*.md. Uruchom po każdej zmianie repozytorium.
"""
from __future__ import annotations

import argparse
import glob
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "docs/handover/notes/zrodla"
LANG = {".yaml": "yaml", ".yml": "yaml", ".json": "json", ".feature": "gherkin", ".py": "python", ".js": "javascript", ".md": None, ".txt": "text"}

BUNDLES = [
    ("01-wejscie-i-architektura", "Wejście do repozytorium, zasady dla agentów i ludzi, słownik i architektura (docs/architecture 00–14)",
     ["README.md", "AGENTS.md", "docs/glossary.md", "docs/architecture/*.md"]),
    ("02-decyzje-i-uprawnienia", "Decyzje architektoniczne (ADR-001…020), wnioski RFC, uprawnienia jako kod i własność kodu",
     ["docs/adr/README.md", "docs/adr/ADR-*.md", "docs/rfc/*.md", "config/authorization/*.yaml", "config/ownership.yaml", "CODEOWNERS"]),
    ("03-specyfikacje-bdd", "Świat testowy i scenariusze Gherkin platformy (Reqnroll, # language: pl)",
     ["specs/README.md", "specs/**/*.feature"]),
    ("04-plan-i-wycena", "Plan wykonawczy platformy, backlog maszynowy, szablon pakietu, model i raport wyceny",
     ["plan/execution-plan.md", "plan/backlog.yaml", "plan/work-packet-template.md", "plan/estimation.md",
      "plan/estimation-report.md", "plan/estimates.yaml", "plan/estimation-params.yaml", "plan/progress/README.md"]),
    ("05-profile-projektow", "Profile projektów: przewodnik i instrukcja dedykowanych elementów, schemat manifestu, szablon, profile kredyty, aml i flota (manifesty, plany, scenariusze)",
     ["profiles/README.md", "docs/guides/*.md", "profiles/profile.schema.json", "profiles/_template/*.yaml", "profiles/_template/AGENTS.md",
      "profiles/*/profile.yaml", "profiles/*/authorization.yaml", "profiles/*/README.md", "profiles/*/AGENTS.md", "profiles/*/backlog.yaml",
      "profiles/*/specs/*.feature"]),
    ("06-roj-agentow", "Rój agentów w OpenCode z modelem GLM w banku: instrukcja startu, przewodnik, skille, komendy, rejestr ról, model i polityka, kwalifikacja, narzędzia .NET",
     ["docs/opencode/start.md", "docs/agents/multi-model-guide.md", ".opencode/README.md", ".opencode/skills/*/SKILL.md",
      ".opencode/command/*.md", "agents/registry.yaml", "agents/runtime-policy.yaml", "agents/schemas/*.json",
      "config/models.yaml", "evals/agents/README.md", "evals/agents/cases/*.yaml", "tools/dotnet/README.md"]),
    ("07-ui-i-dashboard", "Propozycja UI, tokeny, formatki (założenia wizualne i katalog pól), dashboard harmonogramu: rejestr ryzyk i decyzji oraz dane",
     ["design/README.md", "design/tokens.json", "design/forms/README.md", "design/forms/field-catalog.yaml", "plan/dashboard/README.md", "plan/dashboard/register.yaml",
      "plan/dashboard/data/summary.json", "plan/dashboard/data/phases.json", "plan/dashboard/data/gates.json",
      "plan/dashboard/data/roles.json", "plan/dashboard/data/scenarios.json", "plan/dashboard/data/risks.json",
      "plan/dashboard/data/decisions.json"]),
    ("08-artefakty-i-podsumowanie", "Artefakty projektowe (plan systemu, aktorzy, założenia, wytyczne UI) i podsumowanie projektu z rejestrem wymagań W-01…W-48",
     ["docs/artifacts/01-plan-systemu.md", "docs/artifacts/02-aktorzy.md", "docs/artifacts/03-zalozenia.md", "docs/artifacts/04-wytyczne-ui.md", "docs/artifacts/05-agenci.md", "docs/handover/podsumowanie.md"]),
    ("09-narzedzia-kod", "Kod narzędzi repozytorium (opcjonalne źródło): wycena, eksport, artefakty, generator agentów, prowadzenie kroków, strażnik, profile",
     ["tools/plan/estimate.py", "tools/plan/export_dashboard_data.py", "tools/artifacts/render_artifacts.py",
      "tools/agents/render_agents.py", "tools/agents/steplib.py", "tools/agents/prepare_step.py", "tools/agents/run_dod.py",
      "tools/agents/plan_status.py", "tools/agents/validate_output.py", "tools/guard/enforce_write_scope.py",
      "tools/profiles/validate_profiles.py", "tools/profiles/new_profile.py", ".opencode/plugin/write-scope.js",
      ".opencode/lib/write-scope-core.js"]),
]


def files_for(patterns):
    seen, out = set(), []
    for pat in patterns:
        for f in sorted(glob.glob(str(ROOT / pat), recursive=True)):
            p = Path(f)
            if p.is_file() and p not in seen:
                seen.add(p)
                out.append(p)
    return out


def steps_table():
    """Zwięzła tabela kroków z danych dashboardu (pełny steps.json jest zbyt duży dla notesu)."""
    rows = json.loads((ROOT / "plan/dashboard/data/steps.json").read_text(encoding="utf-8"))
    head = ("| Krok | Nazwa | Faza | Krytyczny | Tydz. start–koniec | Zapas (dni) | Złożoność | Udział AI | Bez AI (od) | Z AI (od) | "
            "Zakres | Rola wiodąca | Ryzyko | Bloker zewnętrzny |\n| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    lines = [head]
    for s in rows:
        lines.append(f"| {s['id']} | {s['short']} | {s['phase']} {s['phase_name']} | {'tak' if s['critical'] else ''} | "
                     f"{s['start_week']}–{s['end_week']} | {s['float_days']} | {s['complexity_class']} ({s['complexity']}) | "
                     f"{round(s['ai_share']*100)}% | {s['trad_pd']} | {s['hyb_pd']} | {s['scopes']} | {s['lead_role']} | "
                     f"{s['risk_label']} | {s['external_blocker']} |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="nie zapisuj; kod 1, gdy źródła notesu są nieaktualne")
    args = ap.parse_args()
    outputs: dict[Path, str] = {}
    index = ["# 00 — Indeks źródeł Process Hub", "",
             "Każdy plik źródłowy to pakiet plików repozytorium. Sekcja `## Plik: <ścieżka>` oznacza oryginalną ścieżkę w repozytorium — "
             "cytuj ją w odpowiedziach. Pliki wygenerowane (raport wyceny, dane dashboardu, AGENTS.md, agents/dist) są pochodne: "
             "zmienia się ich źródła i uruchamia generator.", "", "| Źródło | Zawartość | Pliki |", "| --- | --- | --- |"]
    for name, desc, patterns in BUNDLES:
        fs = files_for(patterns)
        parts = [f"# {name} — {desc}", "",
                 f"Pakiet zawiera {len(fs)} plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.", ""]
        if name == "07-ui-i-dashboard":
            count = len(json.loads((ROOT / "plan/dashboard/data/steps.json").read_text(encoding="utf-8")))
            parts += ["## Plik: plan/dashboard/data/steps.json (skrót tabelaryczny)", "",
                      f"Liczba rekordów w pełnym zbiorze: {count} (każdy z kilkudziesięcioma polami); poniżej najważniejsze kolumny.", "", steps_table(), ""]
        for p in fs:
            rel = p.relative_to(ROOT).as_posix()
            text = p.read_text(encoding="utf-8").rstrip()
            lang = LANG.get(p.suffix, "text")
            parts.append(f"## Plik: {rel}")
            parts.append("")
            parts.append(text if lang is None else f"````{lang}\n{text}\n````")
            parts.append("")
        content = "\n".join(parts) + "\n"
        outputs[OUT / f"{name}.md"] = content
        size = len(content.encode("utf-8"))
        index.append(f"| `{name}.md` | {desc} | {len(fs)} ({round(size/1024)} KB) |")
    index += ["", "Nie ma w źródłach stron do oglądania (`design/mockups/index.html`, `plan/dashboard/index.html`, `docs/artifacts/index.html`) "
              "ani pierwotnych dokumentów v1 z projektu (można je wgrać osobno jako tło)."]
    outputs[OUT / "00-indeks.md"] = "\n".join(index) + "\n"
    existing = {p for p in OUT.glob("*.md")} if OUT.exists() else set()
    stale = [p for p, c in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != c]
    orphans = sorted(existing - set(outputs))
    if args.check:
        for p in stale + orphans:
            print(f"NIEAKTUALNE: {p.relative_to(ROOT)}", file=sys.stderr)
        return 1 if stale or orphans else 0
    OUT.mkdir(parents=True, exist_ok=True)
    for p in orphans:
        p.unlink()
    for p, c in outputs.items():
        p.write_text(c, encoding="utf-8")
    print("\n".join(index[6:6 + len(BUNDLES)]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
