#!/usr/bin/env python3
"""Eksport danych planu do zbiorów dashboardu harmonogramu (plan/dashboard/data/*.json).

Źródła: plan/backlog.yaml, plan/estimates.yaml, plan/estimation-params.yaml, plan/dashboard/register.yaml
oraz model z tools/plan/estimate.py. Uruchom po każdej zmianie planu lub szacunków, potem podmień pliki w dashboardzie.
"""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "plan/dashboard/data"
spec = importlib.util.spec_from_file_location("est", ROOT / "tools/plan/estimate.py")
est = importlib.util.module_from_spec(spec)
spec.loader.exec_module(est)

PHASES = {0: "Przygotowanie i PoC", 1: "Fundament", 2: "Dostęp, Camunda, audyt, formatki", 3: "Funkcje rdzenia",
          4: "Frontend funkcjonalny", 5: "Integracja i hardening", 6: "Pilotaż"}
AGENT_LABEL = {"human": "Ludzie", "module-implementer": "Implementer modułu", "camunda-integrator": "Agent Camunda",
               "data-engineer": "Agent danych", "frontend-developer": "Agent frontendu", "bdd-tester": "Tester BDD",
               "bdd-analyst": "Analityk BDD", "architect": "Architekt", "security-reviewer": "Recenzent bezpieczeństwa",
               "docs-writer": "Dokumentalista", "ux-designer": "Agent UX", "design-system-engineer": "Agent design systemu",
               "ui-reviewer": "Recenzent UI"}
SCOPES = {  # zakres główny, zakresy dodatkowe
    "S00": ["Infrastruktura"], "S01": ["Camunda", "Backend"], "S02": ["Bezpieczeństwo", "Camunda"], "S03": ["Camunda"],
    "S04": ["Camunda", "Dane"], "S05": ["Biznes", "Testy"], "S06": ["Infrastruktura", "Camunda", "Dane", "Bezpieczeństwo"],
    "S07": ["Frontend", "Camunda"], "S08": ["Camunda", "Backend"], "S09": ["Frontend", "Biznes"],
    "S10": ["Backend"], "S11": ["Testy", "Infrastruktura"], "S12": ["Backend", "Bezpieczeństwo"], "S13": ["Dane", "Bezpieczeństwo"],
    "S14": ["Testy"], "S15": ["Backend", "Frontend"], "S16": ["Frontend"], "S17": ["Camunda"], "S18": ["Bezpieczeństwo", "Backend"], "S19": ["Backend", "Frontend"],
    "S20": ["Backend"], "S21": ["Bezpieczeństwo", "Camunda"], "S22": ["Camunda", "Backend"], "S23": ["Camunda", "Dane"],
    "S24": ["Bezpieczeństwo", "Backend", "Dane"], "S25": ["Bezpieczeństwo", "Dane"], "S26": ["Backend", "Biznes"], "S27": ["Bezpieczeństwo", "Dane"],
    "S28": ["Dane"], "S29": ["Camunda", "Backend"], "S39": ["Backend"], "S49": ["Frontend"], "S55": ["Frontend", "Testy"],
    "S30": ["Backend", "Camunda"], "S31": ["Backend", "Camunda"], "S32": ["Backend"], "S33": ["Camunda"],
    "S34": ["Backend", "Biznes"], "S35": ["Backend"], "S36": ["Dane", "Biznes"], "S37": ["Backend", "Frontend"], "S38": ["Backend", "Testy"],
    "S40": ["Frontend"], "S41": ["Frontend"], "S42": ["Frontend"], "S43": ["Frontend"], "S44": ["Frontend", "Camunda"],
    "S45": ["Frontend"], "S46": ["Frontend"], "S47": ["Frontend"], "S48": ["Biznes"], "S50": ["Testy", "Infrastruktura"], "S51": ["Bezpieczeństwo", "Testy"],
    "S52": ["Dane", "Testy"], "S53": ["Frontend", "Testy"], "S54": ["Bezpieczeństwo", "Biznes"], "S60": ["Biznes", "Infrastruktura"]}
EXTERNAL = {"S02": "decyzja zespołu bezpieczeństwa", "S05": "dostępność biznesu na warsztatach", "S06": "dostępy i procedury IT banku",
            "S09": "dostępność projektanta UX i księgi znaku banku", "S16": "licencja Kendo UI i dostęp do rejestru npm", "S54": "termin zewnętrznego pentestu i akceptacje compliance",
            "S48": "dostępność zespołów profili projektów",
            "S60": "gotowość obszaru biznesowego, szkolenia i profilu pilotażowego (zespół projektu)"}
RISK_LABEL = {1: "niskie", 2: "niskie", 3: "średnie", 4: "wysokie", 5: "krytyczne"}
APPROVER = {"architect-human": "Architekt", "product-owner": "Product Owner", "tech-lead": "Tech lead",
            "security": "Bezpieczeństwo", "compliance": "Compliance"}
SHORT = {"S00": "Repozytorium i harness", "S01": "PoC SDK Camunda", "S02": "PoC autoryzacji", "S03": "PoC task listenera",
         "S04": "PoC zasilania read modelu", "S05": "Scenariusze z biznesem", "S06": "Środowisko dev w banku",
         "S07": "PoC formatek w UI", "S08": "PoC walidacji i FEEL", "S09": "Warstwa wizualna i Figma",
         "S10": "Szkielet rozwiązania", "S11": "Testy architektury i CI", "S12": "Building Blocks", "S13": "Baza MSSQL",
         "S14": "Harness BDD", "S15": "Kontrakty v1 i OpenAPI", "S16": "Frontend: shell i ui-kit", "S17": "bpmnlint i modele BPMN",
         "S18": "BFF i logowanie RHBK", "S19": "SDK rozszerzeń i rejestr profili", "S20": "Party i zastępstwa", "S21": "Autoryzacje jako kod", "S22": "Adaptery SDK",
         "S23": "Projekcja read modelu", "S24": "Polityka dostępu R1–R11", "S25": "Audyt", "S26": "Formatki: cykl życia", "S27": "Izolacja profili",
         "S28": "Formatki: schemat bazy", "S29": "Formatki: powiązania z BPMN", "S39": "Formatki: wycofanie i przepięcie",
         "S49": "UI: komponenty pól", "S55": "Zgodność i spójność formatek",
         "S30": "Praca na zadaniach", "S31": "Start procesu", "S32": "Przekazywanie zadań", "S33": "Zastępstwa (listener)",
         "S34": "Mapa etapów", "S35": "Eskalacje", "S36": "Dashboard menadżera", "S37": "Form Runtime", "S38": "Operacje profili",
         "S40": "UI: zadania i renderer formatek", "S41": "UI: start i moje procesy", "S42": "UI: dashboard i etapy", "S43": "UI: przekazywanie",
         "S44": "UI: edytor mapy etapów", "S45": "UI: projektant formatek", "S46": "UI: audytor", "S47": "UI: sloty profili", "S48": "Onboarding zespołów profili", "S50": "Testy end-to-end",
         "S51": "Testy bezpieczeństwa", "S52": "Wydajność", "S53": "Dostępność i UX", "S54": "Pentest i compliance", "S60": "Pilotaż"}


def schedule(rows):
    order, seen = [], set()

    def visit(s):
        if s in seen:
            return
        seen.add(s)
        for d in rows[s]["deps"]:
            visit(d)
        order.append(s)
    for s in rows:
        visit(s)
    es, ef = {}, {}
    for s in order:
        es[s] = max([ef[d] for d in rows[s]["deps"]], default=0.0)
        ef[s] = es[s] + rows[s]["dur"]
    end = max(ef.values())
    succ = {s: [t for t in rows if s in rows[t]["deps"]] for s in rows}
    lf, ls = {}, {}
    for s in reversed(order):
        lf[s] = min([ls[t] for t in succ[s]], default=end)
        ls[s] = lf[s] - rows[s]["dur"]
    return es, ef, ls, lf, end, succ


def scenario_runs(backlog, estimates, params, actuals):
    def run(b, e, p):
        rows, cp, _, rd, _, _ = est.compute(b, e, p, actuals)
        hyb = sum(r["hyb_final"] for r in rows.values())
        hs = sum(r["hyb_final_s"] for r in rows.values())
        ov = p["overheads"]
        mult = 1 + ov["swarm_supervision"] + ov["coordination"]
        bn = max(rd, key=rd.get)
        z = p["percentile_z"]
        return {"effort_pd": round(hyb * mult, 1), "cal_weeks": round(max(cp[0], rd[bn]) / 5, 1),
                "cal_p80_weeks": round(max(cp[0] + z * cp[1], rd[bn] * (1 + z * hs / hyb)) / 5, 1)}
    out = []
    base = run(backlog, estimates, params)
    defs = [("bazowy", "Bazowy", "plan i szacunki bez zmian", lambda e, p: None)]

    def weaker(e, p):
        for v in e.values():
            v["ai_share"] = max(0.1, v["ai_share"] - 0.2)

    def review(e, p):
        for v in e.values():
            v["review"] = min(1.0, v["review"] + 0.15)

    def slow(e, p):
        for g in p["calendar"]["gate_wait_days"]:
            p["calendar"]["gate_wait_days"][g] = [x * 2 for x in p["calendar"]["gate_wait_days"][g]]
        e["S06"]["trad_pd"] = [20, 30, 45]
        e["S54"]["external_calendar_days"] = [15, 25, 40]

    def team(e, p):
        p["team_fte"]["backend_dotnet"] = 3.0
        p["team_fte"]["product_owner_analityk"] = 0.75
        p["team_fte"]["bezpieczenstwo"] = 0.3

    def split(e, p):
        p["calendar"]["parallel_factor"]["L"] = 2.0
        p["calendar"]["parallel_factor"]["M"] = 1.3

    defs += [("slabsi_agenci", "Słabsi agenci", "udział AI niższy o 20 pkt, np. słabsze wyniki kwalifikacji modelu", weaker),
             ("drozszy_przeglad", "Droższy przegląd", "przegląd pracy agentów droższy o 15 pkt", review),
             ("wolne_procedury", "Wolne procedury banku", "oczekiwanie na bramki ×2, środowisko i pentest pesymistycznie", slow),
             ("wiekszy_zespol", "Większy zespół", "+1 backend, PO 0,75 etatu, bezpieczeństwo 0,3 etatu", team),
             ("podzial_krytycznych", "Podział kroków krytycznych", "dwie osoby z agentami na krokach ścieżki krytycznej", split)]
    for sid, name, desc, fn in defs:
        e, p = copy.deepcopy(estimates), copy.deepcopy(params)
        fn(e, p)
        r = run(backlog, e, p)
        r.update({"id": sid, "name": name, "description": desc,
                  "delta_weeks": round(r["cal_weeks"] - base["cal_weeks"], 1),
                  "delta_effort_pd": round(r["effort_pd"] - base["effort_pd"], 1)})
        out.append(r)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="nie zapisuj; kod 1, gdy dane dashboardu są nieaktualne")
    args = ap.parse_args()
    backlog, estimates, params, actuals = est.load()
    rows, cp, role_load, role_days, k, done = est.compute(backlog, estimates, params, actuals)
    _, t_cp, _, t_role_days, _, _ = est.compute(backlog, estimates, params, actuals, mode="trad")
    es, ef, ls, lf, end, succ = schedule(rows)
    register = yaml.safe_load((ROOT / "plan/dashboard/register.yaml").read_text(encoding="utf-8"))
    bl = {s["id"]: s for s in backlog["steps"]}
    z = params["percentile_z"]
    ov = params["overheads"]
    gates_cfg = backlog["gates"]

    steps = []
    for sid, r in sorted(rows.items(), key=lambda x: (es[x[0]], x[0])):
        e = r["e"]
        split = est.ROLE_SPLIT.get(sid) or {est.ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        wait = est.pert(*params["calendar"]["gate_wait_days"][r["gate"]])[0] if r["gate"] else 0.0
        risk = round((e["N"] + max(e["T"], e["B"])) / 2)
        sc = SCOPES[sid]
        blockers = [f"po {d}" for d in r["deps"]] + ([f"bramka {r['gate']}"] if r["gate"] else []) + ([EXTERNAL[sid]] if sid in EXTERNAL else [])
        steps.append({
            "id": sid, "short": SHORT[sid], "title": r["title"], "phase": r["phase"], "phase_name": PHASES[r["phase"]],
            "agent": AGENT_LABEL.get(r["agent"], r["agent"]), "size": r["size"],
            "scope": sc[0], "scopes": ", ".join(sc),
            "roles": ", ".join(est.ROLE_LABEL[x] for x in split), "lead_role": est.ROLE_LABEL[max(split, key=split.get)],
            "role_split": ", ".join(f"{est.ROLE_LABEL[x]} {round(v*100)}%" for x, v in split.items()),
            "critical": sid in cp[2], "complexity": round(r["C"], 2), "complexity_class": r["cls"],
            "t": e["T"], "n": e["N"], "i": e["I"], "b": e["B"],
            "ai_share": e["ai_share"], "review": e["review"],
            "trad_pd": round(r["trad"], 1), "trad_o": e["trad_pd"][0], "trad_p": e["trad_pd"][2],
            "hyb_pd": round(r["hyb_final"], 1), "saving": round(1 - r["hyb_final"] / r["trad"], 2),
            "start_week": round(es[sid] / 5, 1), "work_start_week": round((es[sid] + wait) / 5, 1),
            "end_week": round(ef[sid] / 5, 1), "late_end_week": round(lf[sid] / 5, 1),
            "float_days": round(ls[sid] - es[sid], 1), "duration_days": round(r["dur"], 1),
            "gate": r["gate"] or "", "gate_wait_days": round(wait, 1),
            "depends_on": ", ".join(r["deps"]), "unblocks": ", ".join(sorted(succ[sid])),
            "blockers": "; ".join(blockers), "external_blocker": EXTERNAL.get(sid, ""),
            "risk_level": risk, "risk_label": RISK_LABEL[risk], "risk_driver": e["driver"],
            "status": "Planowany", "progress": 0,
            "dod": "; ".join(bl[sid].get("dod", []))[:300]})

    gates = []
    for g, cfg in gates_cfg.items():
        gw = est.pert(*params["calendar"]["gate_wait_days"][g])
        decided = max(ef[s] for s in cfg["after"])
        gates.append({"gate": g, "week": round(decided / 5, 1), "wait_days": round(gw[0], 1), "after": ", ".join(cfg["after"]),
                      "approver": ", ".join(APPROVER.get(a, a) for a in cfg["approver"]), "condition": register["gate_conditions"][g]})

    trad = sum(r["trad"] for r in rows.values())
    trad_s = sum(r["trad_s"] for r in rows.values())
    hyb = sum(r["hyb_final"] for r in rows.values())
    hyb_s = sum(r["hyb_final_s"] for r in rows.values())
    mh, mt = 1 + ov["swarm_supervision"] + ov["coordination"], 1 + ov["coordination"]
    bn, tbn = max(role_days, key=role_days.get), max(t_role_days, key=t_role_days.get)
    cal = max(cp[0], role_days[bn]) / 5
    cal80 = max(cp[0] + z * cp[1], role_days[bn] * (1 + z * hyb_s / hyb)) / 5
    tcal = max(t_cp[0], t_role_days[tbn]) / 5
    tcal80 = max(t_cp[0] + z * t_cp[1], t_role_days[tbn] * (1 + z * trad_s / trad)) / 5
    summary = [{"cal_hyb_weeks": round(cal, 1), "cal_hyb_p80_weeks": round(cal80, 1), "cal_trad_weeks": round(tcal, 1),
                "cal_trad_p80_weeks": round(tcal80, 1), "cal_saving_weeks": round(tcal - cal, 1),
                "effort_hyb_pd": round(hyb * mh), "effort_hyb_p80_pd": round((hyb + z * hyb_s) * mh),
                "effort_trad_pd": round(trad * mt), "effort_trad_p80_pd": round((trad + z * trad_s) * mt),
                "effort_saving": round(1 - (hyb * mh) / (trad * mt), 2), "cp_days": round(cp[0]),
                "team_fte": round(sum(params["team_fte"].values()), 1), "steps_total": len(rows),
                "steps_critical": len(cp[2]), "gates_total": len(gates_cfg),
                "bottleneck_role": est.ROLE_LABEL[bn], "calibration_k": round(k, 2), "steps_with_actuals": len(done)}]

    phases = []
    for ph, name in PHASES.items():
        ids = [s for s in rows if rows[s]["phase"] == ph]
        t = sum(rows[s]["trad"] for s in ids)
        h = sum(rows[s]["hyb_final"] for s in ids)
        phases.append({"phase": ph, "name": name, "trad_pd": round(t, 1), "hyb_pd": round(h, 1), "saving": round(1 - h / t, 2),
                       "start_week": round(min(es[s] for s in ids) / 5, 1), "end_week": round(max(ef[s] for s in ids) / 5, 1),
                       "steps": len(ids)})

    util = params["utilization"]
    roles = [{"role": r, "role_label": est.ROLE_LABEL[r], "fte": params["team_fte"][r], "load_pd": round(role_load[r], 1),
              "days_needed": round(role_days[r]), "cp_days": round(cp[0]),
              "load_vs_cp": round(role_days[r] / cp[0], 2)} for r in params["team_fte"]]

    weeks = math.ceil(end / 5)
    daily = {r: [0.0] * (weeks * 5) for r in params["team_fte"]}
    for sid, r in rows.items():
        split = est.ROLE_SPLIT.get(sid) or {est.ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        wait = est.pert(*params["calendar"]["gate_wait_days"][r["gate"]])[0] if r["gate"] else 0.0
        a, b = es[sid] + wait, ef[sid]
        span = max(b - a, 0.5)
        for role, share in split.items():
            per_day = r["hyb_final"] * share / span
            for d in range(int(a), min(int(math.ceil(b)), weeks * 5)):
                overlap = min(b, d + 1) - max(a, d)
                if overlap > 0:
                    daily[role][d] += per_day * overlap
    base = sum(r["hyb_final"] for r in rows.values())
    over = {"architekt_tech_lead": base * (ov["swarm_supervision"] + ov["coordination"] * 0.4),
            "product_owner_analityk": base * ov["coordination"] * 0.6}
    for role, total in over.items():
        for d in range(int(math.ceil(end))):
            daily[role][d] += total / end
    role_weekly = []
    for role in params["team_fte"]:
        for w in range(weeks):
            fte_needed = sum(daily[role][w * 5:(w + 1) * 5]) / 5
            avail = params["team_fte"][role] * util
            role_weekly.append({"key": f"{role}-{w+1}", "week": w + 1, "role": role, "role_label": est.ROLE_LABEL[role],
                                "fte_needed": round(fte_needed, 2), "fte_available": round(avail, 2),
                                "utilization": round(fte_needed / avail, 2) if avail else 0})

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data = {"steps": steps, "gates": gates, "summary": summary, "phases": phases, "roles": roles,
            "role_weekly": role_weekly, "scenarios": scenario_runs(backlog, estimates, params, actuals),
            "risks": register["risks"], "decisions": register["decisions"]}
    week_of = {s["id"]: s["start_week"] for s in steps}
    for d in data["decisions"]:
        d["needed_by_week"] = round(min(week_of.get(x, 0) for x in d["before_steps"].split(", ")), 1)
    for r in data["risks"]:
        r["score"] = r["probability"] * r["impact"]
    outputs = {OUT / f"{name}.json": json.dumps(rows_, ensure_ascii=False, indent=1) + "\n" for name, rows_ in data.items()}
    # Ten sam komplet danych dla strony otwieranej z dysku (bez serwera i bez fetch).
    outputs[OUT.parent / "data.js"] = ("// WYGENEROWANE przez tools/plan/export_dashboard_data.py — nie edytuj ręcznie\nwindow.PH_DATA = "
                                       + json.dumps(data, ensure_ascii=False) + ";\n")
    stale = [p for p, c in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != c]
    if args.check:
        for p in stale:
            print(f"NIEAKTUALNE: {p.relative_to(ROOT)}", file=sys.stderr)
        return 1 if stale else 0
    OUT.mkdir(parents=True, exist_ok=True)
    for p, c in outputs.items():
        p.write_text(c, encoding="utf-8")
    (OUT / "_generated.json").write_text(json.dumps({"at": stamp, "files": sorted(data)}, indent=1) + "\n", encoding="utf-8")
    print(f"zapisano {len(data)} zbiorów do {OUT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
