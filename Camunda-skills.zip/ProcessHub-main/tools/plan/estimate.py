#!/usr/bin/env python3
"""Model szacowania pracochłonności planu (hybryda AI + ludzie).

Wejście:  plan/backlog.yaml (kroki, zależności, bramki), plan/estimates.yaml (oceny), plan/estimation-params.yaml
          opcjonalnie plan/progress/<krok>.effort.json: {"step": "S10", "actual_human_pd": 3.5} (kalibracja)
Wyjście:  plan/estimation-report.md (generowany) albo --check (kod 1, gdy raport nieaktualny)

Model (opis w plan/estimation.md):
  C        = Σ waga × ocena (T, N, I, B)                                indeks złożoności 1–5
  E_trad   = (O + 4M + P) / 6,  σ = (P − O) / 6                         PERT, osobodni bez AI
  f        = (1 − ai_share) + ai_share × review                         udział pracy ludzi w hybrydzie
  E_hyb    = E_trad × f × k                                             k = współczynnik kalibracji (domyślnie 1)
  dni_kal  = E_hyb / parallel_factor[rozmiar] (+ oczekiwanie na bramkę), dla S54 max z kalendarzem zewnętrznym
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
ROLE_OF_AGENT = {"module-implementer": "backend_dotnet", "camunda-integrator": "backend_dotnet", "data-engineer": "backend_dotnet",
                 "frontend-developer": "frontend_angular", "bdd-tester": "qa_bdd", "bdd-analyst": "product_owner_analityk",
                 "architect": "architekt_tech_lead", "security-reviewer": "bezpieczenstwo", "orchestrator": "architekt_tech_lead",
                 "ux-designer": "ux_designer", "design-system-engineer": "frontend_angular", "ui-reviewer": "ux_designer"}
ROLE_SPLIT = {  # kroki prowadzone przez ludzi lub z wyraźnym podziałem ról
    "S00": {"architekt_tech_lead": 0.6, "devops": 0.4},
    "S01": {"backend_dotnet": 0.6, "devops": 0.2, "architekt_tech_lead": 0.2},
    "S02": {"backend_dotnet": 0.4, "bezpieczenstwo": 0.3, "architekt_tech_lead": 0.3},
    "S06": {"devops": 0.7, "backend_dotnet": 0.15, "architekt_tech_lead": 0.15},
    "S07": {"frontend_angular": 0.65, "ux_designer": 0.2, "architekt_tech_lead": 0.15},
    "S09": {"ux_designer": 0.7, "frontend_angular": 0.15, "product_owner_analityk": 0.15},
    "S16": {"frontend_angular": 0.85, "ux_designer": 0.15},
    "S19": {"architekt_tech_lead": 0.4, "backend_dotnet": 0.45, "frontend_angular": 0.15},
    "S27": {"backend_dotnet": 0.5, "bezpieczenstwo": 0.25, "architekt_tech_lead": 0.15, "devops": 0.1},
    "S40": {"frontend_angular": 0.9, "ux_designer": 0.1},
    "S45": {"frontend_angular": 0.9, "ux_designer": 0.1},
    "S48": {"architekt_tech_lead": 0.5, "product_owner_analityk": 0.3, "qa_bdd": 0.2},
    "S49": {"frontend_angular": 0.75, "ux_designer": 0.25},
    "S50": {"qa_bdd": 0.5, "backend_dotnet": 0.3, "devops": 0.2},
    "S51": {"bezpieczenstwo": 0.5, "qa_bdd": 0.3, "backend_dotnet": 0.2},
    "S53": {"frontend_angular": 0.7, "ux_designer": 0.3},
    "S54": {"bezpieczenstwo": 0.5, "architekt_tech_lead": 0.3, "product_owner_analityk": 0.2},
    "S55": {"frontend_angular": 0.6, "qa_bdd": 0.25, "ux_designer": 0.15},
    "S60": {"product_owner_analityk": 0.4, "devops": 0.3, "architekt_tech_lead": 0.3},
}
ROLE_LABEL = {"architekt_tech_lead": "Architekt / tech lead", "backend_dotnet": "Backend .NET", "frontend_angular": "Frontend Angular",
              "devops": "DevOps", "qa_bdd": "QA / BDD", "product_owner_analityk": "PO / analityk", "bezpieczenstwo": "Bezpieczeństwo",
              "ux_designer": "Projektant UX"}


def pert(o, m, p):
    return (o + 4 * m + p) / 6, (p - o) / 6


def load():
    backlog = yaml.safe_load((ROOT / "plan/backlog.yaml").read_text(encoding="utf-8"))
    est = yaml.safe_load((ROOT / "plan/estimates.yaml").read_text(encoding="utf-8"))["steps"]
    params = yaml.safe_load((ROOT / "plan/estimation-params.yaml").read_text(encoding="utf-8"))
    actuals = {}
    for f in sorted(glob.glob(str(ROOT / "plan/progress/*.effort.json"))):
        try:
            d = json.loads(Path(f).read_text(encoding="utf-8"))
            if "actual_human_pd" in d:
                actuals[d["step"]] = float(d["actual_human_pd"])
        except (ValueError, KeyError):
            continue
    return backlog, est, params, actuals


def compute(backlog, est, params, actuals, mode="hyb"):
    steps = {s["id"]: s for s in backlog["steps"]}
    missing = sorted(set(steps) - set(est)) + sorted(set(est) - set(steps))
    if missing:
        raise SystemExit(f"Niespójność backlog.yaml ↔ estimates.yaml: {missing}")
    w = params["weights"]
    rows = {}
    for sid, s in steps.items():
        e = est[sid]
        c = sum(w[k] * e[k] for k in "TNIB")
        cls = next(x["name"] for x in params["classes"] if c <= x["max"])
        tm, ts = pert(*e["trad_pd"])
        f = (1 - e["ai_share"]) + e["ai_share"] * e["review"]
        rows[sid] = {"id": sid, "title": s["title"], "phase": s.get("phase"), "size": s.get("size", "M"), "agent": s.get("agent"),
                     "C": c, "cls": cls, "e": e, "trad": tm, "trad_s": ts, "f": f, "hyb": tm * f, "hyb_s": ts * f,
                     "deps": s.get("depends_on", []), "gate": s.get("gate_before"), "critical_flag": bool(s.get("critical"))}
    # kalibracja: średni stosunek rzeczywistość / szacunek dla zakończonych kroków
    done = [sid for sid in actuals if sid in rows and rows[sid]["hyb"] > 0]
    k = (sum(actuals[s] / rows[s]["hyb"] for s in done) / len(done)) if done else 1.0
    for sid, r in rows.items():
        if mode == "trad":
            r["hyb_final"], r["hyb_final_s"] = r["trad"], r["trad_s"]
        elif sid in actuals:
            r["hyb_final"], r["hyb_final_s"] = actuals[sid], 0.0
        else:
            r["hyb_final"], r["hyb_final_s"] = r["hyb"] * k, r["hyb_s"] * k
        pf = params["calendar"]["parallel_factor"].get(r["size"], 1.0)
        dur, dur_s = r["hyb_final"] / pf, r["hyb_final_s"] / pf
        ext = r["e"].get("external_calendar_days")
        if ext:
            em, es = pert(*ext)
            if em > dur:
                dur, dur_s = em, es
        if r["gate"]:
            gm, gs = pert(*params["calendar"]["gate_wait_days"][r["gate"]])
            dur += gm
            dur_s = math.sqrt(dur_s ** 2 + gs ** 2)
        r["dur"], r["dur_s"] = dur, dur_s
    # ścieżka krytyczna (najdłuższa wg kalendarza)
    memo = {}

    def finish(sid):
        if sid not in memo:
            r = rows[sid]
            best = max(r["deps"], key=lambda d: finish(d)[0], default=None)
            base = (0.0, 0.0, []) if best is None else finish(best)
            memo[sid] = (base[0] + r["dur"], base[1] + r["dur_s"], base[2] + [sid])  # σ sumowane liniowo: ryzyka skorelowane
        return memo[sid]

    end = max(rows, key=lambda s: finish(s)[0])
    cp_days, cp_sig, cp_path = finish(end)
    # obciążenie ról
    ov = params["overheads"]
    role_load = {r: 0.0 for r in params["team_fte"]}
    for sid, r in rows.items():
        split = ROLE_SPLIT.get(sid) or {ROLE_OF_AGENT.get(r["agent"], "architekt_tech_lead"): 1.0}
        for role, share in split.items():
            role_load[role] += r["hyb_final"] * share
    base_hyb = sum(r["hyb_final"] for r in rows.values())
    sup = 0.0 if mode == "trad" else ov["swarm_supervision"]
    role_load["architekt_tech_lead"] += base_hyb * (sup + ov["coordination"] * 0.4)
    role_load["product_owner_analityk"] += base_hyb * ov["coordination"] * 0.6
    util = params["utilization"]
    role_days = {role: (load / (params["team_fte"][role] * util) if params["team_fte"][role] else float("inf"))
                 for role, load in role_load.items()}
    return rows, (cp_days, cp_sig, cp_path), role_load, role_days, k, done


def fmt(x, n=1):
    return f"{x:,.{n}f}".replace(",", " ").replace(".", ",")


def report(rows, cp, role_load, role_days, k, done, params, trad_view):
    z = params["percentile_z"]
    ov = params["overheads"]
    mult_h = 1 + ov["swarm_supervision"] + ov["coordination"]
    mult_t = 1 + ov["coordination"]
    trad = sum(r["trad"] for r in rows.values())
    trad_s = sum(r["trad_s"] for r in rows.values())            # ostrożnie: ryzyka skorelowane
    hyb = sum(r["hyb_final"] for r in rows.values())
    hyb_s = sum(r["hyb_final_s"] for r in rows.values())
    cp_days, cp_s, cp_path = cp
    t_cp, t_role_days = trad_view
    fte = sum(params["team_fte"].values())
    bn = max(role_days, key=role_days.get)
    t_bn = max(t_role_days, key=t_role_days.get)
    cal = max(cp_days, role_days[bn])
    cal80 = max(cp_days + z * cp_s, role_days[bn] * (1 + z * hyb_s / hyb))
    t_cal = max(t_cp[0], t_role_days[t_bn])
    t_cal80 = max(t_cp[0] + z * t_cp[1], t_role_days[t_bn] * (1 + z * trad_s / trad))
    util = params["utilization"]
    out = ["<!-- WYGENEROWANE przez tools/plan/estimate.py — nie edytuj ręcznie -->",
           "# Raport szacowania (generowany)", "",
           f"Kalibracja: {'brak danych rzeczywistych, k = 1,0' if not done else f'k = {fmt(k, 2)} z {len(done)} zakończonych kroków'}. "
           f"Zespół referencyjny: {fmt(fte)} FTE, wykorzystanie {int(util*100)}%. P80 liczone ostrożnie: odchylenia kroków sumowane liniowo (ryzyka skorelowane).", "",
           "## Podsumowanie", "",
           "| Wielkość | Bez AI: oczekiwane | Bez AI: P80 | Hybryda: oczekiwane | Hybryda: P80 |", "| --- | --- | --- | --- | --- |",
           f"| Praca ludzi w krokach (osobodni) | {fmt(trad, 0)} | {fmt(trad + z * trad_s, 0)} | {fmt(hyb, 0)} | {fmt(hyb + z * hyb_s, 0)} |",
           f"| Praca ludzi z narzutami (osobodni) | {fmt(trad * mult_t, 0)} | {fmt((trad + z * trad_s) * mult_t, 0)} | {fmt(hyb * mult_h, 0)} | {fmt((hyb + z * hyb_s) * mult_h, 0)} |",
           f"| Ścieżka krytyczna z bramkami (dni robocze) | {fmt(t_cp[0], 0)} | {fmt(t_cp[0] + z * t_cp[1], 0)} | {fmt(cp_days, 0)} | {fmt(cp_days + z * cp_s, 0)} |",
           f"| Najbardziej obciążona rola (dni robocze) | {fmt(t_role_days[t_bn], 0)} ({ROLE_LABEL[t_bn]}) | — | {fmt(role_days[bn], 0)} ({ROLE_LABEL[bn]}) | — |",
           f"| **Czas kalendarzowy** (większa z dwóch powyższych) | **{fmt(t_cal / 5, 0)} tyg.** | **{fmt(t_cal80 / 5, 0)} tyg.** | **{fmt(cal / 5, 0)} tyg.** | **{fmt(cal80 / 5, 0)} tyg.** |",
           "", "Narzuty: hybryda = nadzór roju + koordynacja; bez AI = koordynacja. Czas pracy agentów nie jest wąskim gardłem — ogranicza go przegląd i decyzje ludzi.", "",
           "## Kroki", "",
           "| Krok | Tytuł | C | Klasa | T/N/I/B | AI | Bez AI (od) | Hybryda (od) | Oszczędność | Dni kal. | Ścieżka kryt. |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for r in sorted(rows.values(), key=lambda r: (r["phase"], r["id"])):
        e = r["e"]
        out.append(f"| {r['id']} | {r['title'][:70]} | {fmt(r['C'], 2)} | {r['cls']} | {e['T']}/{e['N']}/{e['I']}/{e['B']} | {int(e['ai_share']*100)}% | "
                   f"{fmt(r['trad'])} | {fmt(r['hyb_final'])} | {int(round((1 - r['hyb_final']/r['trad'])*100))}% | {fmt(r['dur'])} | {'tak' if r['id'] in cp_path else ''} |")
    out += ["", "## Fazy", "", "| Faza | Bez AI (od) | Hybryda (od) | Oszczędność |", "| --- | --- | --- | --- |"]
    for ph in sorted({r["phase"] for r in rows.values()}):
        t = sum(r["trad"] for r in rows.values() if r["phase"] == ph)
        h = sum(r["hyb_final"] for r in rows.values() if r["phase"] == ph)
        out.append(f"| {ph} | {fmt(t)} | {fmt(h)} | {int(round((1-h/t)*100))}% |")
    out += ["", "## Obciążenie ról (z narzutami)", "", "| Rola | FTE | Praca (od) | Dni robocze przy wykorzystaniu |", "| --- | --- | --- | --- |"]
    for role in sorted(role_load, key=lambda x: -role_days[x]):
        out.append(f"| {ROLE_LABEL[role]} | {fmt(params['team_fte'][role])} | {fmt(role_load[role])} | {fmt(role_days[role], 0)} |")
    out += ["", "## Ścieżka krytyczna", "", " → ".join(cp_path), "",
            "## Ranking złożoności", "", "| Miejsce | Krok | C | Główny czynnik |", "| --- | --- | --- | --- |"]
    for i, r in enumerate(sorted(rows.values(), key=lambda r: -r["C"]), 1):
        out.append(f"| {i} | {r['id']} {r['title'][:55]} | {fmt(r['C'], 2)} | {r['e']['driver']} |")
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--json", action="store_true", help="wypisz podsumowanie jako JSON")
    a = ap.parse_args()
    backlog, est, params, actuals = load()
    rows, cp, role_load, role_days, k, done = compute(backlog, est, params, actuals)
    _, t_cp, _, t_role_days, _, _ = compute(backlog, est, params, actuals, mode="trad")
    text = report(rows, cp, role_load, role_days, k, done, params, (t_cp, t_role_days))
    path = ROOT / "plan/estimation-report.md"
    if a.json:
        print(json.dumps({"cp_days": cp[0], "cp_sigma": cp[1], "cp_path": cp[2], "role_days": role_days, "trad_cp": t_cp[:2], "trad_role_days": t_role_days,
                          "trad": sum(r["trad"] for r in rows.values()), "hyb": sum(r["hyb_final"] for r in rows.values())},
                         ensure_ascii=False, indent=1))
        return 0
    if a.check:
        ok = path.exists() and path.read_text(encoding="utf-8") == text
        print("aktualny" if ok else "NIEAKTUALNY: uruchom python3 tools/plan/estimate.py", file=sys.stderr)
        return 0 if ok else 1
    path.write_text(text, encoding="utf-8")
    print(f"zapisano {path.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
