#!/usr/bin/env python3
"""Sprawdza spójność planów (platformy i profili) z repozytorium i konfiguracją agentów — zanim krok trafi do agenta.

  python3 tools/plan/validate_plan.py                 # wszystkie plany: błędy i ostrzeżenia
  python3 tools/plan/validate_plan.py --check         # bramka CI: kod 1, gdy są błędy
  python3 tools/plan/validate_plan.py --conflicts S32 S39   # czy te kroki mogą iść równolegle (kod 1 = nakładający się zapis)
  python3 tools/plan/validate_plan.py --backlog profiles/kredyty/backlog.yaml

Błędy (krok nie wystartuje poprawnie): nieznana zależność, cykl, nieznany agent, wykonawca bez prawa zapisu,
zapis poza ścieżkami roli, plik z `reads` nie istnieje i nie tworzy go żaden poprzednik, brak scenariusza lub tagu,
brak bramki zakresu w `dod`, krok bez wyceny, identyfikator niezgodny ze schematem przekazania.
Ostrzeżenia (do decyzji człowieka): budżet kontekstu, poziom inny niż w rejestrze, krok poza bramką swojej fazy,
kroki z nakładającym się zapisem, które mogą być gotowe jednocześnie.

Na razie tylko w Pythonie — odpowiednik `ph plan validate` nie istnieje (tools/dotnet/README.md).
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
SCOPE_GATE = "enforce_write_scope.py --verify-diff"
WRITE_TOOLS = {"edit_file", "write_file"}
RUNNERS = ("dotnet ", "npx ", "npm ", "python3 ", "ph ", "test ")
BYTES_PER_TOKEN = 3.0          # tekst polski i kod, zaokrąglone w dół (ostrożnie)
READS_WARN = 0.35              # część kontekstu modelu, powyżej której `reads` są ostrzeżeniem
PHASE_GATES = {1: ["G0"], 2: ["G0", "G1"], 3: ["G0", "G1"], 4: ["G0", "G1"], 5: ["G0", "G1", "G2"], 6: ["G0", "G1", "G2", "G3"]}


def load_yaml(rel: str):
    return yaml.safe_load((ROOT / rel).read_text(encoding="utf-8"))


def seg_overlap(a: str, b: str) -> bool:
    """Czy istnieje nazwa pasująca do obu wzorców jednego segmentu ścieżki."""
    if a == b or a == "*" or b == "*":
        return True
    plain_a, plain_b = a.replace("*", ""), b.replace("*", "")
    candidates = {plain_a, plain_b, a.replace("*", plain_b), b.replace("*", plain_a)}
    return any(fnmatch.fnmatchcase(c, a) and fnmatch.fnmatchcase(c, b) for c in candidates)


def glob_overlap(a: str, b: str) -> bool:
    """Czy dwa globy zakresu zapisu mogą wskazać ten sam plik.

    Wzorzec dzielimy na początek (segmenty przed pierwszym `**`) i katalogi wymienione po nim. Początki muszą się
    zgadzać; jeśli oba wzorce wymieniają katalog po `**` (np. `db/**/task/**` i `db/**/audit/**`), muszą się zgadzać także one.
    """
    def parts(g: str) -> tuple[list[str], list[str], bool]:
        segs = g.split("/")
        if "**" not in segs:
            return segs, [], False
        cut = segs.index("**")
        return segs[:cut], [x for x in segs[cut:] if x != "**"], True

    head_a, tail_a, deep_a = parts(a)
    head_b, tail_b, deep_b = parts(b)
    if not all(seg_overlap(x, y) for x, y in zip(head_a, head_b)):
        return False
    if len(head_a) != len(head_b) and not (deep_a if len(head_a) < len(head_b) else deep_b):
        return False
    if len(head_a) == len(head_b) and deep_a != deep_b:
        return False
    return not (tail_a and tail_b) or seg_overlap(tail_a[0], tail_b[0])


def covered(path: str, globs: list[str]) -> bool:
    """Czy ścieżka (albo katalog) leży w zakresie globów — do sprawdzania `reads` względem `writes` poprzedników."""
    return any(fnmatch.fnmatchcase(path, g) or fnmatch.fnmatchcase(path + "/x", g) for g in globs)


class PlanCheck:
    def __init__(self, backlog: str, registry: dict, models: dict, platform: "PlanCheck | None" = None):
        self.rel = backlog
        self.data = load_yaml(backlog)
        self.profile = self.data.get("profile")
        self.steps = {s["id"]: s for s in self.data["steps"]}
        self.gates = self.data.get("gates") or {}
        self.roles = {r["name"]: r for r in registry["roles"]}
        self.platform = platform
        prof = models["profiles"][models["default_profile"]]
        self.context = prof.get("context_limit_tokens") or 0
        self.errors: list[str] = []
        self.warnings: list[str] = []

    # --- graf -------------------------------------------------------------------------------------------------
    def step(self, sid: str) -> dict | None:
        return self.steps.get(sid) or (self.platform.steps.get(sid) if self.platform else None)

    def ancestors(self, sid: str, seen: set | None = None) -> set:
        seen = set() if seen is None else seen
        for dep in (self.step(sid) or {}).get("depends_on", []):
            if dep not in seen and self.step(dep):
                seen.add(dep)
                self.ancestors(dep, seen)
        return seen

    def behind_gate(self, sid: str, gate: str) -> bool:
        return any((self.step(x) or {}).get("gate_before") == gate for x in {sid} | self.ancestors(sid))

    def ordered(self, a: str, b: str) -> bool:
        """Kroki nie mogą być gotowe jednocześnie: jeden zależy od drugiego albo dzieli je bramka."""
        if a in self.ancestors(b) or b in self.ancestors(a):
            return True
        for gate, cfg in self.gates.items():
            after = set(cfg.get("after", []))
            before = {x for g in after for x in self.ancestors(g)} | after
            if (a in before and self.behind_gate(b, gate)) or (b in before and self.behind_gate(a, gate)):
                return True
        return False

    def conflicts(self, ids: list[str] | None = None) -> list[tuple[str, str, str, str]]:
        ids = ids or [i for i, s in self.steps.items() if s["agent"] != "human"]
        found = []
        for n, a in enumerate(ids):
            for b in ids[n + 1:]:
                if self.ordered(a, b):
                    continue
                hit = next(((x, y) for x in self.steps[a].get("writes", []) for y in self.steps[b].get("writes", []) if glob_overlap(x, y)), None)
                if hit:
                    found.append((a, b, hit[0], hit[1]))
        return found

    # --- kontrole ---------------------------------------------------------------------------------------------
    def err(self, sid: str, msg: str) -> None:
        self.errors.append(f"{sid}: {msg}")

    def warn(self, sid: str, msg: str) -> None:
        self.warnings.append(f"{sid}: {msg}")

    def run(self, handoff_pattern: str, estimates: dict | None, dev_agents: list[str] | None) -> None:
        for gate, cfg in self.gates.items():
            for sid in cfg.get("after", []):
                if sid not in self.steps:
                    self.err(gate, f"bramka wskazuje nieznany krok {sid}")
        for sid, s in self.steps.items():
            if not re.match(handoff_pattern, sid):
                self.err(sid, f"identyfikator niezgodny ze schematem przekazania ({handoff_pattern})")
            for dep in s.get("depends_on", []):
                if not self.step(dep):
                    self.err(sid, f"nieznana zależność {dep}")
                elif dep in self.steps and self.steps[dep].get("phase", 0) > s.get("phase", 0):
                    self.warn(sid, f"zależy od kroku {dep} z późniejszej fazy")
            if sid in self.ancestors(sid):
                self.err(sid, "cykl zależności")
            gate = s.get("gate_before")
            if gate and gate not in self.gates:
                self.err(sid, f"nieznana bramka {gate}")
            if not self.profile:
                for g in PHASE_GATES.get(s.get("phase", 0), []):
                    if g in self.gates and not self.behind_gate(sid, g):
                        self.warn(sid, f"faza {s['phase']}, ale krok może ruszyć przed bramką {g}")
            self.check_agents(sid, s, dev_agents)
            self.check_reads(sid, s)
            self.check_specs(sid, s)
            self.check_dod(sid, s)
            if self.profile:
                own = f"profiles/{self.profile}/"
                for w in s.get("writes", []):
                    if not w.startswith(own):
                        self.err(sid, f"zapis poza profilem: {w}")
        if estimates is not None:
            for sid in sorted(set(self.steps) ^ set(estimates)):
                self.err(sid, "brak pary krok ↔ wycena (plan/estimates.yaml)")
        for a, b, x, y in self.conflicts():
            self.warn(a, f"może być gotowy równocześnie z {b}, a zakresy zapisu się nakładają ({x} ↔ {y}) — prowadź po kolei albo zawęź `writes`")

    def check_agents(self, sid: str, s: dict, dev_agents: list[str] | None) -> None:
        agent = s["agent"]
        if agent == "human":
            return
        for field in ("agent", "pair"):
            name = s.get(field)
            if name and name not in self.roles:
                self.err(sid, f"{field}: nieznana rola {name}")
            elif name and dev_agents is not None and name not in dev_agents and field == "agent":
                self.err(sid, f"rola {name} nie jest na liście dev.agents profilu {self.profile}")
        role = self.roles.get(agent)
        if not role:
            return
        if s.get("writes") and not WRITE_TOOLS & set(role["tools"]):
            self.err(sid, f"wykonawca {agent} nie ma narzędzi zapisu, a krok ma `writes`")
        if s.get("tier") and s["tier"] != role["tier"]:
            self.warn(sid, f"poziom {s['tier']} inny niż w rejestrze roli {agent} ({role['tier']}) — obowiązuje rejestr")
        if role.get("writes") and not self.profile:
            for w in s.get("writes", []):
                if not any(glob_overlap(w, allowed) for allowed in role["writes"]):
                    self.err(sid, f"rola {agent} nie może zapisywać w {w} (agents/registry.yaml: writes)")

    def check_reads(self, sid: str, s: dict) -> None:
        produced = [w for dep in self.ancestors(sid) for w in (self.step(dep) or {}).get("writes", [])]
        size = 0
        for r in s.get("reads", []):
            p = ROOT / r
            if p.is_file():
                size += p.stat().st_size
            elif p.is_dir():
                size += sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
            elif not covered(r, produced):
                self.err(sid, f"`reads`: {r} nie istnieje i nie tworzy go żaden poprzednik")
        tokens = int(size / BYTES_PER_TOKEN)
        if self.context and tokens > READS_WARN * self.context:
            self.warn(sid, f"`reads` to ok. {tokens // 1000} tys. tokenów ({round(100 * tokens / self.context)}% kontekstu) — przenieś duże pliki do `refs`")

    def check_specs(self, sid: str, s: dict) -> None:
        for spec in s.get("specs", []):
            path = spec.split()[0]
            f = ROOT / path
            if not f.is_file():
                self.err(sid, f"`specs`: brak pliku {path}")
                continue
            text = f.read_text(encoding="utf-8")
            for tag in re.findall(r"@[\w-]+", spec):
                if tag not in text:
                    self.err(sid, f"`specs`: {path} nie ma tagu {tag}")

    def check_dod(self, sid: str, s: dict) -> None:
        dod = s.get("dod") or self.data.get("common_dod", [])
        for cmd in dod:
            if not cmd.startswith(RUNNERS):
                self.err(sid, f"`dod`: „{cmd}” nie jest komendą — kryteria dla człowieka wpisz w `acceptance`")
        if s["agent"] != "human" and not any(SCOPE_GATE in c for c in dod):
            self.err(sid, "`dod` nie zawiera bramki zakresu (enforce_write_scope.py --verify-diff)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backlog", default=None, help="tylko ten plan (domyślnie: platforma i wszystkie profile)")
    ap.add_argument("--check", action="store_true", help="kod 1, gdy są błędy; ostrzeżenia tylko wypisuje")
    ap.add_argument("--conflicts", nargs="+", metavar="KROK", help="sprawdź, czy podane kroki mogą iść równolegle")
    args = ap.parse_args()

    registry = load_yaml("agents/registry.yaml")
    models = load_yaml("config/models.yaml")
    handoff = json.loads((ROOT / "agents/schemas/handoff.schema.json").read_text(encoding="utf-8"))["properties"]["step"]["pattern"]
    platform = PlanCheck("plan/backlog.yaml", registry, models)

    if args.conflicts:
        plan = PlanCheck(args.backlog, registry, models, platform) if args.backlog else platform
        unknown = [i for i in args.conflicts if i not in plan.steps]
        if unknown:
            sys.exit(f"Nie ma kroków: {', '.join(unknown)}")
        found = plan.conflicts(args.conflicts)
        for a, b, x, y in found:
            print(f"KONFLIKT: {a} i {b} zapisują w tym samym miejscu ({x} ↔ {y}) — prowadź po kolei")
        print("brak konfliktów zapisu" if not found else f"konfliktów: {len(found)}")
        return 1 if found else 0

    plans = []
    if args.backlog in (None, "plan/backlog.yaml"):
        platform.run(handoff, load_yaml("plan/estimates.yaml")["steps"], None)
        plans.append(platform)
    backlogs = [args.backlog] if args.backlog and args.backlog != "plan/backlog.yaml" else \
        ([] if args.backlog else sorted(str(p.relative_to(ROOT)) for p in ROOT.glob("profiles/*/backlog.yaml") if not p.parent.name.startswith("_")))
    for rel in backlogs:
        plan = PlanCheck(rel, registry, models, platform)
        manifest = ROOT / Path(rel).parent / "profile.yaml"
        dev = (yaml.safe_load(manifest.read_text(encoding="utf-8")).get("dev", {}).get("agents") if manifest.exists() else None)
        plan.run(handoff, None, dev)
        plans.append(plan)

    errors = warnings = 0
    for plan in plans:
        print(f"{plan.rel}: kroków {len(plan.steps)} · błędów {len(plan.errors)} · ostrzeżeń {len(plan.warnings)}")
        for e in plan.errors:
            print(f"  BŁĄD        {e}")
        if not args.check:
            for w in plan.warnings:
                print(f"  OSTRZEŻENIE {w}")
        errors += len(plan.errors)
        warnings += len(plan.warnings)
    if args.check and warnings:
        print(f"ostrzeżeń: {warnings} (szczegóły bez --check)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
