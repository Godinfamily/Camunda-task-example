using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Tests;

/// <summary>Zgodność z Pythonem: round(), formatowanie, repr, json.dumps, PyYAML, fnmatch.</summary>
public static class InfrastructureTests
{
    [Test]
    public static void Round_PolowkiDoParzystejNaDokladnejWartosciBinarnej()
    {
        Check.Equal(0.12, PyFloat.Round(0.125, 2), "round(0.125, 2)");
        Check.Equal(2.67, PyFloat.Round(2.675, 2), "round(2.675, 2) — 2.675 to binarnie 2.67499…");
        Check.Equal(0.1, PyFloat.Round(0.15, 1), "round(0.15, 1)");
        Check.Equal(2L, PyFloat.RoundToInt(2.5), "round(2.5)");
        Check.Equal(4L, PyFloat.RoundToInt(3.5), "round(3.5)");
        Check.Equal(-2L, PyFloat.RoundToInt(-2.5), "round(-2.5)");
        Check.Equal(27.6, PyFloat.Round(27.649999, 1), "round(27.649999, 1)");
    }

    [Test]
    public static void Repr_JakWPythonie()
    {
        Check.Equal("10.0", PyFloat.Repr(10.0));
        Check.Equal("0.1", PyFloat.Repr(0.1));
        Check.Equal("1e-05", PyFloat.Repr(0.00001));
        Check.Equal("0.0001", PyFloat.Repr(0.0001));
        Check.Equal("1e+16", PyFloat.Repr(1e16));
        Check.Equal("1000000000000000.0", PyFloat.Repr(1e15));
        Check.Equal("-0.0", PyFloat.Repr(-0.0));
        Check.Equal("474.4999999999999", PyFloat.Repr(474.4999999999999));
    }

    [Test]
    public static void Fixed_FormatF_ZSeparatoremTysiecy()
    {
        Check.Equal("1,234.6", PyFloat.Fixed(1234.56, 1, thousands: true));
        Check.Equal("0.2", PyFloat.Fixed(0.25, 1), "f'{0.25:.1f}' — połówka do parzystej");
        Check.Equal("-0.0", PyFloat.Fixed(-0.04, 1), "f'{-0.04:.1f}'");
        Check.Equal("400", PyFloat.Fixed(399.5, 0), "f'{399.5:.0f}'");
    }

    [Test]
    public static void Sum_SumowanieZKompensacjaJakPython312()
    {
        var values = Enumerable.Repeat(0.1, 10).ToList();
        Check.Equal(1.0, Py.Sum(values), "sum([0.1] * 10)");
        Check.Equal(0.6, Py.Sum(new[] { 0.1, 0.2, 0.3 }), "sum([0.1, 0.2, 0.3])");
    }

    [Test]
    public static void Json_JakJsonDumps()
    {
        var d = new PyDict { ["a"] = 1L, ["b"] = 1.0, ["c"] = new List<object?> { "ł", null, true }, ["d"] = new PyDict() };
        Check.Equal("{\"a\": 1, \"b\": 1.0, \"c\": [\"ł\", null, true], \"d\": {}}", PyJson.Dumps(d));
        Check.Equal("{\n \"a\": 1,\n \"b\": 1.0,\n \"c\": [\n  \"ł\",\n  null,\n  true\n ],\n \"d\": {}\n}", PyJson.Dumps(d, indent: 1));
        Check.Equal("\"\\u0142\"", PyJson.Dumps("ł", ensureAscii: true));
        Check.Equal("\"a\\\"b\\\\c\\n\"", PyJson.Dumps("a\"b\\c\n"));
        Check.True(PyJson.Loads("{\"x\": 0}") is PyDict p && p["x"] is long, "liczba bez części ułamkowej wczytuje się jako int");
    }

    [Test]
    public static void Yaml_SkalaryJakPyYaml()
    {
        var d = Py.Dict(MiniYaml.Load("a: yes\nb: off\nc: 010\nd: 1.0\ne: 1.19.5\nf: ~\ng: 'x''y'\nh: \"q\\tw\"\ni: 08\n"));
        Check.Equal(true, d["a"]);
        Check.Equal(false, d["b"]);
        Check.Equal(8L, d["c"], "ósemkowo jak YAML 1.1");
        Check.Equal(1.0, d["d"]);
        Check.Equal("1.19.5", d["e"]);
        Check.Equal(null, d["f"]);
        Check.Equal("x'y", d["g"]);
        Check.Equal("q\tw", d["h"]);
        Check.Equal("08", d["i"]);
    }

    [Test]
    public static void Yaml_StrukturyKotwiceIWielowierszowe()
    {
        const string text = "base: &b\n  - x\n  - y\nuse: *b\nflow: {k: [1, 2], m: {n: v}}\nlong: pierwszy\n  drugi\nlist:\n- a: 1\n  b: 2\n- [3, 4]\nfold: >\n  ala\n  ma\n\n  kota\nmulti: [a,\n  b]\n";
        var d = Py.Dict(MiniYaml.Load(text));
        Check.Equal("x,y", string.Join(",", Py.Strings(d["use"])), "alias");
        Check.Equal(2L, Py.List(Py.Dict(d["flow"])["k"])[1], "flow");
        Check.Equal("pierwszy drugi", d["long"], "skalar wielowierszowy");
        Check.Equal(2L, Py.Dict(Py.List(d["list"])[0])["b"], "sekwencja bez wcięcia z mapowaniem");
        Check.Equal("ala ma\nkota\n", d["fold"], "skalar >");
        Check.Equal("a,b", string.Join(",", Py.Strings(d["multi"])), "flow wielowierszowy");
    }

    [Test]
    public static void FnMatch_JakFnmatchcase()
    {
        Check.True(Glob.FnMatch("src/Modules/TaskWork/Domain/X.cs", "src/Modules/TaskWork/**"), "** obejmuje podkatalogi");
        Check.True(Glob.FnMatch("a/b/c", "a/*"), "* w fnmatch obejmuje także /");
        Check.True(!Glob.FnMatch("profiles/kredyty/profile.yaml", "profiles/aml/*"), "inny profil");
        Check.True(Glob.FnMatch("tests/TaskWork.Specs/x", "tests/TaskWork.*/**"), "kropka dosłownie");
        Check.True(Glob.FnMatch("a1", "a[0-9]") && !Glob.FnMatch("ab", "a[0-9]"), "klasa znaków");
    }
}
