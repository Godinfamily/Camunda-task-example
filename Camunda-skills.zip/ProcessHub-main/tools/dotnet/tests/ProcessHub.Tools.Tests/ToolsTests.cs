using ProcessHub.Tools.Commands;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Tests;

/// <summary>Zachowanie narzędzi: strażnik, profile, tłumaczenie poleceń oraz zgodność wygenerowanych plików z repozytorium.</summary>
public static class ToolsTests
{
    [Test]
    public static void Strażnik_AutotestReguł() => Check.Equal(0, Quiet(Guard.SelfTest).Code, "ph guard --self-test");

    [Test]
    public static void Strażnik_KrokProfiluNieZmieniaCudzegoProfiluAniPlatformy()
    {
        var scope = new List<string> { "profiles/kredyty/**" };
        Check.True(Guard.Decide("profiles/kredyty/backend/A.cs", scope, "kredyty").Ok, "własny profil");
        Check.True(!Guard.Decide("profiles/aml/AGENTS.md", scope, "kredyty").Ok, "cudzy profil");
        Check.True(!Guard.Decide("src/Modules/TaskWork/Domain/WorkItem.cs", scope, "kredyty").Ok, "platforma");
        Check.True(!Guard.Decide("../poza.txt", scope, "kredyty").Ok, "poza repozytorium");
    }

    [Test]
    public static void Profile_AutotestWykrywaNaruszenia() => Check.Equal(0, Quiet(Profiles.SelfTest).Code, "ph profiles validate --self-test");

    [Test]
    public static void Profile_ManifestyRepozytoriumSaPoprawne() => Check.Equal(0, Profiles.Check(Profiles.Load()).Count, "błędy walidacji profili");

    [Test]
    public static void Kroki_PoleceniaPythonaZamienianeNaPh()
    {
        var translated = Steps.Translate("python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty");
        Check.True(translated.EndsWith(" guard --verify-diff origin/main --profile kredyty", StringComparison.Ordinal), $"tłumaczenie: {translated}");
        Check.Equal("dotnet build -warnaserror", Steps.Translate("dotnet build -warnaserror"), "inne polecenia bez zmian");
    }

    [Test]
    public static void Wycena_IndeksZlozonosciIsciezkaKrytyczna()
    {
        var inp = Estimate.Load();
        var res = Estimate.Compute(inp);
        Check.Equal(4.15, PyFloat.Round(res.Rows["S02"].C, 2), "C dla S02");
        Check.Equal("S00", res.CpPath[0], "ścieżka krytyczna zaczyna się od S00");
        Check.Equal("S60", res.CpPath[res.CpPath.Count - 1], "ścieżka krytyczna kończy się pilotażem");
    }

    /// <summary>Uruchamia polecenie z wyciszonym wyjściem; zwraca kod wyjścia i komunikaty błędów.</summary>
    private static (int Code, string Err) Quiet(Func<int> action)
    {
        var (o, e) = (Console.Out, Console.Error);
        var err = new StringWriter();
        Console.SetOut(TextWriter.Null);
        Console.SetError(err);
        try
        {
            return (action(), err.ToString());
        }
        finally
        {
            Console.SetOut(o);
            Console.SetError(e);
        }
    }

    private static void GeneratorAktualny(string name, Func<string[], int> run, params string[] args)
    {
        var (code, err) = Quiet(() => run(args.Concat(new[] { "--check" }).ToArray()));
        Check.Equal(0, code, $"{name} --check: pliki w repozytorium (wygenerowane Pythonem) są identyczne z wynikiem C# {err.Trim()}");
    }

    [Test]
    public static void Zgodnosc_Agenci() => GeneratorAktualny("ph agents render", Agents.Render);

    [Test]
    public static void Zgodnosc_Wycena() => GeneratorAktualny("ph plan estimate", Estimate.Run);

    [Test]
    public static void Zgodnosc_DaneDashboardu() => GeneratorAktualny("ph plan export", ExportDashboard.Run);

    [Test]
    public static void Zgodnosc_Artefakty() => GeneratorAktualny("ph artifacts render", Artifacts.Run);

    [Test]
    public static void Zgodnosc_ZrodlaNotesu() => GeneratorAktualny("ph notes build", Notes.Build);

    [Test]
    public static void Zgodnosc_Codeowners() => GeneratorAktualny("ph profiles validate", Profiles.Validate);

    [Test]
    public static void Yaml_WszystkiePlikiRepozytoriumWczytujaSie()
    {
        foreach (var f in Glob.Find(Repo.Root, "**/*.yaml"))
        {
            _ = MiniYaml.LoadFile(f);
        }
    }
}
