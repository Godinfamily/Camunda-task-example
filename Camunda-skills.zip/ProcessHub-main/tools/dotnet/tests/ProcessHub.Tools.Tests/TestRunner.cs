using System.Diagnostics;
using System.Reflection;

namespace ProcessHub.Tools.Tests;

[AttributeUsage(AttributeTargets.Method)]
public sealed class TestAttribute : Attribute
{
}

public sealed class AssertionException : Exception
{
    public AssertionException(string message) : base(message)
    {
    }
}

/// <summary>Asercje w stylu „oczekiwano / jest” — bez zewnętrznych bibliotek.</summary>
public static class Check
{
    public static void Equal<T>(T expected, T actual, string? what = null)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
        {
            throw new AssertionException($"{what ?? "wartość"}: oczekiwano «{expected}», jest «{actual}»");
        }
    }

    public static void True(bool condition, string what)
    {
        if (!condition)
        {
            throw new AssertionException($"niespełnione: {what}");
        }
    }

    public static void Throws<TException>(Action action, string what) where TException : Exception
    {
        try
        {
            action();
        }
        catch (TException)
        {
            return;
        }

        throw new AssertionException($"oczekiwano wyjątku {typeof(TException).Name}: {what}");
    }
}

/// <summary>Uruchamia wszystkie metody [Test] z tego zestawu; kod wyjścia 1, gdy którykolwiek test nie przejdzie.</summary>
public static class TestRunner
{
    public static int Main(string[] args)
    {
        var filter = args.Length > 0 ? args[0] : null;
        var tests = typeof(TestRunner).Assembly.GetTypes()
            .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static))
            .Where(m => m.GetCustomAttribute<TestAttribute>() != null)
            .Where(m => filter == null || $"{m.DeclaringType!.Name}.{m.Name}".Contains(filter, StringComparison.OrdinalIgnoreCase))
            .OrderBy(m => m.DeclaringType!.Name, StringComparer.Ordinal).ThenBy(m => m.Name, StringComparer.Ordinal)
            .ToList();
        var failed = 0;
        var sw = Stopwatch.StartNew();
        foreach (var t in tests)
        {
            var name = $"{t.DeclaringType!.Name}.{t.Name}";
            try
            {
                t.Invoke(null, null);
                Console.WriteLine($"  OK    {name}");
            }
            catch (TargetInvocationException e)
            {
                failed++;
                Console.WriteLine($"  BŁĄD  {name}: {e.InnerException?.Message}");
            }
        }

        Console.WriteLine($"\n{tests.Count - failed}/{tests.Count} testów zaliczonych ({sw.Elapsed.TotalSeconds:F1} s)");
        return failed == 0 ? 0 : 1;
    }
}
