using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>
/// Czytnik YAML w zakresie używanym przez repozytorium, zwracający te same wartości co PyYAML (safe_load, YAML 1.1):
/// mapowania i sekwencje blokowe (także sekwencje bez wcięcia), kolekcje flow (także wielowierszowe), skalary zwykłe
/// (wielowierszowe), w cudzysłowach i blokowe (| i >), kotwice i aliasy, komentarze. Rozpoznawanie typów jak w PyYAML:
/// null, bool (yes/no/on/off/true/false), int (także 0x, 0b, ósemkowe), float.
/// </summary>
public static class MiniYaml
{
    public static object? Load(string text) => new Parser(text).Document();

    public static object? LoadFile(string path) => Load(File.ReadAllText(path, Encoding.UTF8));

    private static readonly Regex NullRe = new("^(?:~|null|Null|NULL|)$", RegexOptions.Compiled);
    private static readonly Regex BoolRe = new("^(?:yes|Yes|YES|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|Off|OFF)$", RegexOptions.Compiled);
    private static readonly Regex IntRe = new(
        "^(?:[-+]?0b[0-1_]+|[-+]?0[0-7_]+|[-+]?(?:0|[1-9][0-9_]*)|[-+]?0x[0-9a-fA-F_]+|[-+]?[1-9][0-9_]*(?::[0-5]?[0-9])+)$", RegexOptions.Compiled);
    private static readonly Regex FloatRe = new(
        "^(?:[-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+][0-9]+)?|\\.[0-9_]+(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$",
        RegexOptions.Compiled);

    /// <summary>Rozpoznanie typu skalara zwykłego (bez cudzysłowów) jak w resolverze PyYAML.</summary>
    public static object? Resolve(string v)
    {
        if (NullRe.IsMatch(v))
        {
            return null;
        }

        if (BoolRe.IsMatch(v))
        {
            return v.ToLowerInvariant() is "yes" or "true" or "on";
        }

        if (IntRe.IsMatch(v))
        {
            return ParseInt(v);
        }

        if (FloatRe.IsMatch(v))
        {
            return ParseFloat(v);
        }

        return v;
    }

    private static long ParseInt(string v)
    {
        v = v.Replace("_", string.Empty);
        var sign = 1L;
        if (v[0] is '-' or '+')
        {
            sign = v[0] == '-' ? -1 : 1;
            v = v.Substring(1);
        }

        if (v == "0")
        {
            return 0;
        }

        if (v.StartsWith("0b", StringComparison.Ordinal))
        {
            return sign * System.Convert.ToInt64(v.Substring(2), 2);
        }

        if (v.StartsWith("0x", StringComparison.Ordinal))
        {
            return sign * long.Parse(v.Substring(2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
        }

        if (v[0] == '0')
        {
            return sign * System.Convert.ToInt64(v, 8);
        }

        if (v.Contains(':'))
        {
            long value = 0;
            foreach (var part in v.Split(':'))
            {
                value = value * 60 + long.Parse(part, CultureInfo.InvariantCulture);
            }

            return sign * value;
        }

        return sign * long.Parse(v, CultureInfo.InvariantCulture);
    }

    private static double ParseFloat(string v)
    {
        v = v.Replace("_", string.Empty).ToLowerInvariant();
        var sign = 1.0;
        if (v[0] is '-' or '+')
        {
            sign = v[0] == '-' ? -1 : 1;
            v = v.Substring(1);
        }

        if (v == ".inf")
        {
            return sign * double.PositiveInfinity;
        }

        if (v == ".nan")
        {
            return double.NaN;
        }

        if (v.Contains(':'))
        {
            var parts = v.Split(':');
            double value = 0;
            foreach (var part in parts)
            {
                value = value * 60 + double.Parse(part, CultureInfo.InvariantCulture);
            }

            return sign * value;
        }

        return sign * double.Parse(v, CultureInfo.InvariantCulture);
    }

    private sealed class Parser
    {
        private readonly List<string> _lines;
        private readonly Dictionary<string, object?> _anchors = new(StringComparer.Ordinal);
        private int _i;

        public Parser(string text)
        {
            text = text.Replace("\r\n", "\n").Replace('\r', '\n');
            if (text.Length > 0 && text[0] == '\uFEFF')
            {
                text = text.Substring(1);
            }

            _lines = text.Split('\n').ToList();
        }

        public object? Document()
        {
            var idx = NextSignificant(_i);
            if (idx < 0)
            {
                return null;
            }

            return BlockNode(Indent(_lines[idx]));
        }

        private static int Indent(string line)
        {
            var n = 0;
            while (n < line.Length && line[n] == ' ')
            {
                n++;
            }

            return n;
        }

        private static bool IsBlankOrComment(string line)
        {
            var t = line.TrimStart(' ', '\t');
            return t.Length == 0 || t[0] == '#';
        }

        private int NextSignificant(int from)
        {
            for (var k = from; k < _lines.Count; k++)
            {
                var line = _lines[k];
                if (IsBlankOrComment(line) || line == "---" || line == "...")
                {
                    continue;
                }

                return k;
            }

            return -1;
        }

        private static bool IsSeqItem(string text) => text == "-" || text.StartsWith("- ", StringComparison.Ordinal) || text.StartsWith("-\t", StringComparison.Ordinal);

        private object? BlockNode(int minIndent)
        {
            var idx = NextSignificant(_i);
            if (idx < 0)
            {
                return null;
            }

            var col = Indent(_lines[idx]);
            if (col < minIndent)
            {
                return null;
            }

            var text = _lines[idx].Substring(col);
            if (IsSeqItem(text))
            {
                return BlockSeq(col);
            }

            if (KeySeparator(text) >= 0)
            {
                return BlockMap(col);
            }

            _i = idx + 1;
            return InlineValue(text, col - 1, idx);
        }

        /// <summary>Pozycja dwukropka kończącego klucz mapowania w tekście linii albo -1.</summary>
        private static int KeySeparator(string text)
        {
            if (text.Length == 0 || text[0] is '[' or '{' or '#' or '|' or '>' or '*' or '&' or '!' or '%' or '@' or '`')
            {
                return -1;
            }

            var p = 0;
            if (text[0] is '"' or '\'')
            {
                var q = text[0];
                p = 1;
                while (p < text.Length)
                {
                    if (q == '\'' && text[p] == '\'' && p + 1 < text.Length && text[p + 1] == '\'')
                    {
                        p += 2;
                        continue;
                    }

                    if (q == '"' && text[p] == '\\')
                    {
                        p += 2;
                        continue;
                    }

                    if (text[p] == q)
                    {
                        break;
                    }

                    p++;
                }

                p++;
                while (p < text.Length && text[p] == ' ')
                {
                    p++;
                }

                return p < text.Length && text[p] == ':' && (p + 1 == text.Length || text[p + 1] is ' ' or '\t') ? p : -1;
            }

            for (; p < text.Length; p++)
            {
                if (text[p] == '#' && p > 0 && text[p - 1] is ' ' or '\t')
                {
                    return -1;
                }

                if (text[p] == ':' && (p + 1 == text.Length || text[p + 1] is ' ' or '\t'))
                {
                    return p;
                }
            }

            return -1;
        }

        private string KeyText(string raw)
        {
            raw = raw.TrimEnd(' ', '\t');
            if (raw.Length >= 2 && raw[0] == '"')
            {
                return DoubleQuoted(raw.Substring(1, raw.Length - 2));
            }

            if (raw.Length >= 2 && raw[0] == '\'')
            {
                return raw.Substring(1, raw.Length - 2).Replace("''", "'");
            }

            var resolved = Resolve(raw);
            return resolved is string s ? s : Py.ToStr(resolved);
        }

        private PyDict BlockMap(int col)
        {
            var map = new PyDict();
            while (true)
            {
                var idx = NextSignificant(_i);
                if (idx < 0 || Indent(_lines[idx]) != col)
                {
                    break;
                }

                var text = _lines[idx].Substring(col);
                if (IsSeqItem(text))
                {
                    break;
                }

                var sep = KeySeparator(text);
                if (sep < 0)
                {
                    throw Error(idx, "oczekiwano klucza mapowania");
                }

                var key = KeyText(text.Substring(0, sep));
                var rest = sep + 1 < text.Length ? text.Substring(sep + 1).TrimStart(' ', '\t') : string.Empty;
                _i = idx + 1;
                map[key] = ValueAfterIndicator(rest, col, idx, allowIndentlessSeq: true);
            }

            return map;
        }

        private List<object?> BlockSeq(int col)
        {
            var list = new List<object?>();
            while (true)
            {
                var idx = NextSignificant(_i);
                if (idx < 0 || Indent(_lines[idx]) != col)
                {
                    break;
                }

                var line = _lines[idx];
                var text = line.Substring(col);
                if (!IsSeqItem(text))
                {
                    break;
                }

                var contentCol = col + 1;
                while (contentCol < line.Length && line[contentCol] is ' ' or '\t')
                {
                    contentCol++;
                }

                var content = contentCol < line.Length ? line.Substring(contentCol) : string.Empty;
                string? anchor = null;
                if (content.StartsWith("&", StringComparison.Ordinal))
                {
                    var end = content.IndexOf(' ');
                    anchor = end < 0 ? content.Substring(1) : content.Substring(1, end - 1);
                    var after = end < 0 ? string.Empty : content.Substring(end).TrimStart(' ');
                    contentCol = line.Length - after.Length;
                    content = after;
                }

                object? value;
                if (content.Length == 0 || content[0] == '#')
                {
                    _i = idx + 1;
                    var next = NextSignificant(_i);
                    value = next >= 0 && Indent(_lines[next]) > col ? BlockNode(Indent(_lines[next])) : null;
                }
                else if (IsSeqItem(content) || KeySeparator(content) >= 0)
                {
                    // Element sekwencji zaczynający zagnieżdżoną strukturę w tej samej linii: przesuwamy ją na kolumnę treści.
                    _lines[idx] = new string(' ', contentCol) + content;
                    _i = idx;
                    value = IsSeqItem(content) ? BlockSeq(contentCol) : BlockMap(contentCol);
                }
                else
                {
                    _i = idx + 1;
                    value = InlineValue(content, col, idx);
                }

                if (anchor != null)
                {
                    _anchors[anchor] = value;
                }

                list.Add(value);
            }

            return list;
        }

        /// <summary>Wartość po „klucz:” albo po „- ”: w tej samej linii albo w liniach poniżej.</summary>
        private object? ValueAfterIndicator(string rest, int parentCol, int lineIdx, bool allowIndentlessSeq)
        {
            string? anchor = null;
            if (rest.StartsWith("&", StringComparison.Ordinal))
            {
                var end = rest.IndexOf(' ');
                anchor = end < 0 ? rest.Substring(1) : rest.Substring(1, end - 1);
                rest = end < 0 ? string.Empty : rest.Substring(end).TrimStart(' ');
            }

            if (rest.StartsWith("!", StringComparison.Ordinal))
            {
                var end = rest.IndexOf(' ');
                rest = end < 0 ? string.Empty : rest.Substring(end).TrimStart(' ');
            }

            object? value;
            if (rest.Length == 0 || rest[0] == '#')
            {
                var next = NextSignificant(_i);
                if (next >= 0 && Indent(_lines[next]) > parentCol)
                {
                    value = BlockNode(Indent(_lines[next]));
                }
                else if (allowIndentlessSeq && next >= 0 && Indent(_lines[next]) == parentCol && IsSeqItem(_lines[next].Substring(parentCol)))
                {
                    value = BlockSeq(parentCol);
                }
                else
                {
                    value = null;
                }
            }
            else
            {
                value = InlineValue(rest, parentCol, lineIdx);
            }

            if (anchor != null)
            {
                _anchors[anchor] = value;
            }

            return value;
        }

        /// <summary>Wartość zaczynająca się w bieżącej linii (linia już skonsumowana): alias, blok, flow, cudzysłów, skalar zwykły.</summary>
        private object? InlineValue(string rest, int parentCol, int lineIdx)
        {
            if (rest[0] == '*')
            {
                var name = rest.Substring(1).Split(' ', '\t')[0];
                return _anchors.TryGetValue(name, out var v) ? Py.Clone(v) : throw Error(lineIdx, $"nieznany alias *{name}");
            }

            if (rest[0] is '|' or '>')
            {
                return BlockScalar(rest, parentCol);
            }

            if (rest[0] is '[' or '{')
            {
                var text = new StringBuilder(rest);
                while (!Balanced(text.ToString()) && _i < _lines.Count)
                {
                    text.Append('\n').Append(_lines[_i]);
                    _i++;
                }

                var flow = new FlowParser(text.ToString(), _anchors);
                return flow.ParseTop();
            }

            if (rest[0] is '"' or '\'')
            {
                var text = new StringBuilder(rest);
                while (!QuoteClosed(text.ToString()) && _i < _lines.Count)
                {
                    text.Append('\n').Append(_lines[_i]);
                    _i++;
                }

                var flow = new FlowParser(text.ToString(), _anchors);
                return flow.ParseTop();
            }

            var first = StripComment(rest).TrimEnd(' ', '\t');
            var parts = new List<string> { first };
            var hasComment = first.Length != rest.TrimEnd(' ', '\t').Length;
            while (!hasComment && _i < _lines.Count)
            {
                var line = _lines[_i];
                if (line.Trim(' ', '\t').Length == 0)
                {
                    var next = NextSignificant(_i);
                    if (next < 0 || Indent(_lines[next]) <= parentCol || _lines[next].TrimStart(' ').StartsWith("#", StringComparison.Ordinal))
                    {
                        break;
                    }

                    parts.Add(string.Empty);
                    _i++;
                    continue;
                }

                if (Indent(line) <= parentCol || line.TrimStart(' ').StartsWith("#", StringComparison.Ordinal))
                {
                    break;
                }

                var piece = StripComment(line.Trim(' ', '\t'));
                hasComment = piece.Length != line.Trim(' ', '\t').Length;
                parts.Add(piece.TrimEnd(' ', '\t'));
                _i++;
            }

            return Resolve(Fold(parts));
        }

        private static string Fold(List<string> parts)
        {
            var sb = new StringBuilder();
            for (var k = 0; k < parts.Count; k++)
            {
                if (k == 0)
                {
                    sb.Append(parts[0]);
                    continue;
                }

                if (parts[k].Length == 0)
                {
                    sb.Append('\n');
                }
                else
                {
                    if (parts[k - 1].Length != 0)
                    {
                        sb.Append(' ');
                    }

                    sb.Append(parts[k]);
                }
            }

            return sb.ToString();
        }

        private static string StripComment(string s)
        {
            for (var p = 0; p < s.Length; p++)
            {
                if (s[p] == '#' && (p == 0 || s[p - 1] is ' ' or '\t'))
                {
                    return s.Substring(0, p);
                }
            }

            return s;
        }

        private object? BlockScalar(string header, int parentCol)
        {
            var literal = header[0] == '|';
            var chomp = 'c';
            var explicitIndent = 0;
            foreach (var c in header.Substring(1).Split('#')[0].Trim())
            {
                if (c is '-' or '+')
                {
                    chomp = c;
                }
                else if (char.IsDigit(c))
                {
                    explicitIndent = c - '0';
                }
            }

            var raw = new List<string>();
            while (_i < _lines.Count)
            {
                var line = _lines[_i];
                if (line.Trim(' ').Length != 0 && Indent(line) <= parentCol)
                {
                    break;
                }

                raw.Add(line);
                _i++;
            }

            var indent = explicitIndent > 0 ? parentCol + explicitIndent : raw.Where(l => l.Trim(' ').Length != 0).Select(Indent).DefaultIfEmpty(parentCol + 1).First();
            var lines = raw.Select(l => l.Length >= indent ? l.Substring(indent) : string.Empty).ToList();
            var trailing = 0;
            while (lines.Count > 0 && lines[lines.Count - 1].Length == 0)
            {
                lines.RemoveAt(lines.Count - 1);
                trailing++;
            }

            string body;
            if (literal)
            {
                body = string.Join("\n", lines);
            }
            else
            {
                body = FoldBlankRuns(lines);
            }

            if (lines.Count == 0)
            {
                return chomp == '+' ? new string('\n', trailing) : string.Empty;
            }

            return chomp switch
            {
                '-' => body,
                '+' => body + new string('\n', trailing + 1),
                _ => body + "\n",
            };
        }

        /// <summary>Składanie wierszy w skalarze „>”: pojedynczy znak nowej linii → spacja, puste wiersze → nowe linie.</summary>
        private static string FoldBlankRuns(List<string> lines)
        {
            var sb = new StringBuilder();
            var pendingBreaks = 0;
            var started = false;
            var prevMore = false;
            foreach (var line in lines)
            {
                if (line.Length == 0)
                {
                    pendingBreaks++;
                    continue;
                }

                var more = line.StartsWith(" ", StringComparison.Ordinal) || line.StartsWith("\t", StringComparison.Ordinal);
                if (started)
                {
                    if (pendingBreaks > 0)
                    {
                        sb.Append('\n', (more || prevMore) ? pendingBreaks + 1 : pendingBreaks);
                    }
                    else
                    {
                        sb.Append(more || prevMore ? '\n' : ' ');
                    }
                }
                else if (pendingBreaks > 0)
                {
                    sb.Append('\n', pendingBreaks);
                }

                sb.Append(line);
                started = true;
                pendingBreaks = 0;
                prevMore = more;
            }

            return sb.ToString();
        }

        private static bool Balanced(string s)
        {
            var depth = 0;
            char quote = '\0';
            for (var p = 0; p < s.Length; p++)
            {
                var c = s[p];
                if (quote != '\0')
                {
                    if (quote == '"' && c == '\\')
                    {
                        p++;
                    }
                    else if (c == quote)
                    {
                        if (quote == '\'' && p + 1 < s.Length && s[p + 1] == '\'')
                        {
                            p++;
                        }
                        else
                        {
                            quote = '\0';
                        }
                    }

                    continue;
                }

                if (c == '#' && (p == 0 || s[p - 1] is ' ' or '\t' or '\n'))
                {
                    while (p < s.Length && s[p] != '\n')
                    {
                        p++;
                    }

                    continue;
                }

                if (c is '"' or '\'')
                {
                    quote = c;
                }
                else if (c is '[' or '{')
                {
                    depth++;
                }
                else if (c is ']' or '}')
                {
                    depth--;
                }
            }

            return depth <= 0 && quote == '\0';
        }

        private static bool QuoteClosed(string s)
        {
            var q = s[0];
            for (var p = 1; p < s.Length; p++)
            {
                if (q == '"' && s[p] == '\\')
                {
                    p++;
                    continue;
                }

                if (s[p] == q)
                {
                    if (q == '\'' && p + 1 < s.Length && s[p + 1] == '\'')
                    {
                        p++;
                        continue;
                    }

                    return true;
                }
            }

            return false;
        }

        private static InvalidDataException Error(int idx, string message) => new($"YAML, linia {idx + 1}: {message}");
    }

    /// <summary>Rozwija sekwencje ucieczki i składa wiersze w skalarze w cudzysłowie podwójnym.</summary>
    internal static string DoubleQuoted(string body)
    {
        var sb = new StringBuilder();
        var lines = FoldQuotedLines(body, doubleQuoted: true);
        for (var p = 0; p < lines.Length; p++)
        {
            var c = lines[p];
            if (c != '\\' || p + 1 >= lines.Length)
            {
                sb.Append(c);
                continue;
            }

            var e = lines[++p];
            switch (e)
            {
                case '0': sb.Append('\0'); break;
                case 'a': sb.Append('\a'); break;
                case 'b': sb.Append('\b'); break;
                case 't': case '\t': sb.Append('\t'); break;
                case 'n': sb.Append('\n'); break;
                case 'v': sb.Append('\v'); break;
                case 'f': sb.Append('\f'); break;
                case 'r': sb.Append('\r'); break;
                case 'e': sb.Append('\u001b'); break;
                case ' ': sb.Append(' '); break;
                case '"': sb.Append('"'); break;
                case '/': sb.Append('/'); break;
                case '\\': sb.Append('\\'); break;
                case 'N': sb.Append('\u0085'); break;
                case '_': sb.Append('\u00a0'); break;
                case 'L': sb.Append('\u2028'); break;
                case 'P': sb.Append('\u2029'); break;
                case 'x': sb.Append((char)int.Parse(lines.Substring(p + 1, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture)); p += 2; break;
                case 'u': sb.Append((char)int.Parse(lines.Substring(p + 1, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture)); p += 4; break;
                case 'U': sb.Append(char.ConvertFromUtf32(int.Parse(lines.Substring(p + 1, 8), NumberStyles.HexNumber, CultureInfo.InvariantCulture))); p += 8; break;
                case '\n': break;
                default: sb.Append('\\').Append(e); break;
            }
        }

        return sb.ToString();
    }

    /// <summary>Składanie wierszy skalara w cudzysłowie: pojedynczy podział → spacja, puste wiersze → nowe linie.</summary>
    internal static string FoldQuotedLines(string body, bool doubleQuoted)
    {
        if (!body.Contains('\n'))
        {
            return body;
        }

        var lines = body.Split('\n');
        var sb = new StringBuilder();
        for (var k = 0; k < lines.Length; k++)
        {
            var line = lines[k];
            if (k > 0)
            {
                line = line.TrimStart(' ', '\t');
            }

            if (k < lines.Length - 1)
            {
                var escapedBreak = doubleQuoted && line.EndsWith("\\", StringComparison.Ordinal) && !line.EndsWith("\\\\", StringComparison.Ordinal);
                line = escapedBreak ? line.Substring(0, line.Length - 1) : line.TrimEnd(' ', '\t');
                sb.Append(line);
                if (escapedBreak)
                {
                    continue;
                }

                var blanks = 0;
                while (k + 1 < lines.Length - 1 && lines[k + 1].Trim(' ', '\t').Length == 0)
                {
                    blanks++;
                    k++;
                }

                sb.Append(blanks > 0 ? new string('\n', blanks) : " ");
            }
            else
            {
                sb.Append(line);
            }
        }

        return sb.ToString();
    }

    /// <summary>Parser kolekcji flow ([…], {…}) i skalarów w cudzysłowach.</summary>
    private sealed class FlowParser
    {
        private readonly string _s;
        private readonly Dictionary<string, object?> _anchors;
        private int _p;

        public FlowParser(string s, Dictionary<string, object?> anchors)
        {
            _s = s;
            _anchors = anchors;
        }

        public object? ParseTop()
        {
            var v = Node(inFlow: false);
            SkipWs();
            if (_p < _s.Length)
            {
                throw new InvalidDataException($"YAML: nieoczekiwany tekst po wartości: „{_s.Substring(_p)}”");
            }

            return v;
        }

        private void SkipWs()
        {
            while (_p < _s.Length)
            {
                var c = _s[_p];
                if (c is ' ' or '\t' or '\n')
                {
                    _p++;
                }
                else if (c == '#' && (_p == 0 || _s[_p - 1] is ' ' or '\t' or '\n'))
                {
                    while (_p < _s.Length && _s[_p] != '\n')
                    {
                        _p++;
                    }
                }
                else
                {
                    break;
                }
            }
        }

        private object? Node(bool inFlow)
        {
            SkipWs();
            string? anchor = null;
            if (_p < _s.Length && _s[_p] == '&')
            {
                var start = ++_p;
                while (_p < _s.Length && _s[_p] is not (' ' or ',' or ']' or '}' or '\n'))
                {
                    _p++;
                }

                anchor = _s.Substring(start, _p - start);
                SkipWs();
            }

            object? value;
            if (_p >= _s.Length)
            {
                value = null;
            }
            else if (_s[_p] == '*')
            {
                var start = ++_p;
                while (_p < _s.Length && _s[_p] is not (' ' or ',' or ']' or '}' or '\n'))
                {
                    _p++;
                }

                var name = _s.Substring(start, _p - start);
                value = _anchors.TryGetValue(name, out var v) ? Py.Clone(v) : throw new InvalidDataException($"YAML: nieznany alias *{name}");
            }
            else if (_s[_p] == '[')
            {
                value = Seq();
            }
            else if (_s[_p] == '{')
            {
                value = Map();
            }
            else if (_s[_p] is '"' or '\'')
            {
                value = Quoted();
            }
            else
            {
                value = MiniYaml.Resolve(Plain(inFlow, isKey: false));
            }

            if (anchor != null)
            {
                _anchors[anchor] = value;
            }

            return value;
        }

        private List<object?> Seq()
        {
            _p++;
            var list = new List<object?>();
            while (true)
            {
                SkipWs();
                if (_p >= _s.Length)
                {
                    throw new InvalidDataException("YAML: niezamknięta sekwencja flow");
                }

                if (_s[_p] == ']')
                {
                    _p++;
                    return list;
                }

                list.Add(Node(inFlow: true));
                SkipWs();
                if (_p < _s.Length && _s[_p] == ',')
                {
                    _p++;
                }
            }
        }

        private PyDict Map()
        {
            _p++;
            var map = new PyDict();
            while (true)
            {
                SkipWs();
                if (_p >= _s.Length)
                {
                    throw new InvalidDataException("YAML: niezamknięte mapowanie flow");
                }

                if (_s[_p] == '}')
                {
                    _p++;
                    return map;
                }

                string key;
                if (_s[_p] is '"' or '\'')
                {
                    key = (string)Quoted()!;
                }
                else
                {
                    var raw = Plain(inFlow: true, isKey: true);
                    var resolved = MiniYaml.Resolve(raw);
                    key = resolved as string ?? Py.ToStr(resolved);
                }

                SkipWs();
                object? value = null;
                if (_p < _s.Length && _s[_p] == ':')
                {
                    _p++;
                    SkipWs();
                    value = _p < _s.Length && _s[_p] is ',' or '}' ? null : Node(inFlow: true);
                }

                map[key] = value;
                SkipWs();
                if (_p < _s.Length && _s[_p] == ',')
                {
                    _p++;
                }
            }
        }

        private string Plain(bool inFlow, bool isKey)
        {
            var start = _p;
            while (_p < _s.Length)
            {
                var c = _s[_p];
                if (inFlow && c is ',' or ']' or '}' or '[' or '{')
                {
                    break;
                }

                if (c == ':' && (_p + 1 >= _s.Length || _s[_p + 1] is ' ' or '\t' or '\n' || (inFlow && _s[_p + 1] is ',' or ']' or '}')))
                {
                    if (isKey || inFlow)
                    {
                        break;
                    }
                }

                if (c == '#' && _p > start && _s[_p - 1] is ' ' or '\t')
                {
                    break;
                }

                _p++;
            }

            var raw = _s.Substring(start, _p - start);
            var parts = raw.Split('\n').Select(x => x.Trim(' ', '\t')).ToList();
            var sb = new StringBuilder();
            for (var k = 0; k < parts.Count; k++)
            {
                if (k > 0)
                {
                    sb.Append(parts[k].Length == 0 ? "\n" : (parts[k - 1].Length == 0 ? string.Empty : " "));
                }

                sb.Append(parts[k]);
            }

            return sb.ToString().Trim(' ', '\t');
        }

        private string? Quoted()
        {
            var q = _s[_p++];
            var start = _p;
            while (_p < _s.Length)
            {
                if (q == '"' && _s[_p] == '\\')
                {
                    _p += 2;
                    continue;
                }

                if (_s[_p] == q)
                {
                    if (q == '\'' && _p + 1 < _s.Length && _s[_p + 1] == '\'')
                    {
                        _p += 2;
                        continue;
                    }

                    break;
                }

                _p++;
            }

            var body = _s.Substring(start, _p - start);
            _p++;
            return q == '"' ? MiniYaml.DoubleQuoted(body) : MiniYaml.FoldQuotedLines(body, doubleQuoted: false).Replace("''", "'");
        }
    }
}
