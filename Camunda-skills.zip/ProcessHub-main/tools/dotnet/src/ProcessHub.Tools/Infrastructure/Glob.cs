using System.Collections.Concurrent;
using System.Text;
using System.Text.RegularExpressions;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>Dopasowanie wzorców jak fnmatch.fnmatchcase i glob.glob(recursive=True) z Pythona.</summary>
public static class Glob
{
    private static readonly ConcurrentDictionary<string, Regex> Cache = new(StringComparer.Ordinal);

    /// <summary>fnmatchcase: „*” pasuje do dowolnych znaków (także „/”), „?” do jednego, […] do klasy znaków.</summary>
    public static bool FnMatch(string name, string pattern) => Cache.GetOrAdd(pattern, p => new Regex(Translate(p), RegexOptions.Singleline | RegexOptions.CultureInvariant)).IsMatch(name);

    public static string Translate(string pat)
    {
        var sb = new StringBuilder("^(?:");
        var i = 0;
        while (i < pat.Length)
        {
            var c = pat[i++];
            if (c == '*')
            {
                while (i < pat.Length && pat[i] == '*')
                {
                    i++;
                }

                sb.Append(".*");
            }
            else if (c == '?')
            {
                sb.Append('.');
            }
            else if (c == '[')
            {
                var j = i;
                if (j < pat.Length && pat[j] == '!')
                {
                    j++;
                }

                if (j < pat.Length && pat[j] == ']')
                {
                    j++;
                }

                while (j < pat.Length && pat[j] != ']')
                {
                    j++;
                }

                if (j >= pat.Length)
                {
                    sb.Append("\\[");
                }
                else
                {
                    var stuff = pat.Substring(i, j - i).Replace("\\", "\\\\");
                    i = j + 1;
                    if (stuff.StartsWith("!", StringComparison.Ordinal))
                    {
                        stuff = "^" + stuff.Substring(1);
                    }
                    else if (stuff.StartsWith("^", StringComparison.Ordinal))
                    {
                        stuff = "\\" + stuff;
                    }

                    sb.Append('[').Append(stuff).Append(']');
                }
            }
            else
            {
                sb.Append(Regex.Escape(c.ToString()));
            }
        }

        return sb.Append(")$").ToString();
    }

    private static bool HasMagic(string s) => s.IndexOfAny(new[] { '*', '?', '[' }) >= 0;

    /// <summary>glob.glob(root/pattern, recursive=True): pełne ścieżki pasujących plików i katalogów (bez ukrytych przy wzorcach).</summary>
    public static List<string> Find(string root, string pattern)
    {
        var parts = pattern.Replace('\\', '/').Split('/');
        var results = new List<string>();
        Walk(root, parts, 0, results);
        return results;
    }

    private static void Walk(string dir, string[] parts, int k, List<string> results)
    {
        if (k == parts.Length)
        {
            return;
        }

        var part = parts[k];
        var last = k == parts.Length - 1;
        if (part == "**")
        {
            foreach (var d in SelfAndSubdirs(dir))
            {
                if (last)
                {
                    results.Add(d);
                }
                else
                {
                    Walk(d, parts, k + 1, results);
                }
            }

            return;
        }

        if (!HasMagic(part))
        {
            var candidate = Path.Combine(dir, part);
            if (last)
            {
                if (File.Exists(candidate) || Directory.Exists(candidate))
                {
                    results.Add(candidate);
                }
            }
            else if (Directory.Exists(candidate))
            {
                Walk(candidate, parts, k + 1, results);
            }

            return;
        }

        if (!Directory.Exists(dir))
        {
            return;
        }

        foreach (var entry in Directory.EnumerateFileSystemEntries(dir))
        {
            var name = Path.GetFileName(entry);
            if (name.StartsWith(".", StringComparison.Ordinal) && !part.StartsWith(".", StringComparison.Ordinal))
            {
                continue;
            }

            if (!FnMatch(name, part))
            {
                continue;
            }

            if (last)
            {
                results.Add(entry);
            }
            else if (Directory.Exists(entry))
            {
                Walk(entry, parts, k + 1, results);
            }
        }
    }

    private static IEnumerable<string> SelfAndSubdirs(string dir)
    {
        if (!Directory.Exists(dir))
        {
            yield break;
        }

        yield return dir;
        foreach (var sub in Directory.EnumerateDirectories(dir).OrderBy(x => x, StringComparer.Ordinal))
        {
            if (Path.GetFileName(sub).StartsWith(".", StringComparison.Ordinal))
            {
                continue;
            }

            foreach (var d in SelfAndSubdirs(sub))
            {
                yield return d;
            }
        }
    }
}
