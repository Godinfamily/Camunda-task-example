using System.Text;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>Repozytorium Process Hub: katalog główny, odczyt i zapis plików tekstowych (UTF-8 bez BOM, „\n”).</summary>
public static class Repo
{
    private static string? _root;

    public static readonly UTF8Encoding Utf8 = new(encoderShouldEmitUTF8Identifier: false);

    /// <summary>Katalog główny: --repo, potem PH_REPO_ROOT, potem najbliższy katalog nadrzędny z AGENTS.md i plan/backlog.yaml.</summary>
    public static string Root
    {
        get
        {
            if (_root != null)
            {
                return _root;
            }

            var env = Environment.GetEnvironmentVariable("PH_REPO_ROOT");
            if (!string.IsNullOrEmpty(env))
            {
                return _root = Path.GetFullPath(env);
            }

            var dir = new DirectoryInfo(Directory.GetCurrentDirectory());
            while (dir != null)
            {
                if (File.Exists(Path.Combine(dir.FullName, "AGENTS.md")) && File.Exists(Path.Combine(dir.FullName, "plan", "backlog.yaml")))
                {
                    return _root = dir.FullName;
                }

                dir = dir.Parent;
            }

            throw new ToolException("nie znaleziono repozytorium Process Hub (AGENTS.md i plan/backlog.yaml) — uruchom w repozytorium albo podaj --repo / PH_REPO_ROOT", 2);
        }
    }

    public static void SetRoot(string path) => _root = Path.GetFullPath(path);

    public static string P(string relative) => Path.Combine(Root, relative.Replace('/', Path.DirectorySeparatorChar));

    public static string Read(string path) => File.ReadAllText(path, Encoding.UTF8);

    public static string ReadRel(string relative) => Read(P(relative));

    public static object? Yaml(string relative) => MiniYaml.Load(ReadRel(relative));

    public static void Write(string path, string content)
    {
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
        {
            Directory.CreateDirectory(dir);
        }

        File.WriteAllText(path, content, Utf8);
    }

    /// <summary>Ścieżka względna wobec katalogu głównego, z ukośnikami „/”.</summary>
    public static string Rel(string path) => Path.GetRelativePath(Root, path).Replace('\\', '/');

    public static bool SameContent(string path, string content) => File.Exists(path) && Read(path) == content;
}

/// <summary>Błąd narzędzia z kodem wyjścia (jak SystemExit w Pythonie).</summary>
public sealed class ToolException : Exception
{
    public ToolException(string message, int exitCode = 1) : base(message) => ExitCode = exitCode;

    public int ExitCode { get; }
}
