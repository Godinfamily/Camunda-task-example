namespace ProcessHub.Tools.Infrastructure;

/// <summary>Prosty parser argumentów o semantyce argparse: --flaga, --opcja wartość, --opcja=wartość, argumenty pozycyjne.</summary>
public sealed class Cli
{
    private readonly Dictionary<string, string?> _opts = new(StringComparer.Ordinal);
    private readonly HashSet<string> _flags = new(StringComparer.Ordinal);
    private readonly HashSet<string> _valued = new(StringComparer.Ordinal);
    private readonly List<string> _positional = new();
    private readonly string _usage;

    public Cli(string usage, string[] args, IEnumerable<string> flags, IEnumerable<string> valued, int minPositional = 0, int maxPositional = 0)
    {
        _usage = usage;
        foreach (var f in flags)
        {
            _flags.Add(f);
        }

        foreach (var v in valued)
        {
            _valued.Add(v);
        }

        for (var i = 0; i < args.Length; i++)
        {
            var a = args[i];
            if (a is "-h" or "--help")
            {
                throw new ToolException(usage, 0);
            }

            if (a.StartsWith("--", StringComparison.Ordinal))
            {
                var eq = a.IndexOf('=');
                var name = eq > 0 ? a.Substring(0, eq) : a;
                if (_flags.Contains(name))
                {
                    _opts[name] = null;
                }
                else if (_valued.Contains(name))
                {
                    if (eq > 0)
                    {
                        _opts[name] = a.Substring(eq + 1);
                    }
                    else if (i + 1 < args.Length)
                    {
                        _opts[name] = args[++i];
                    }
                    else
                    {
                        throw new ToolException($"{usage}\nbłąd: opcja {name} wymaga wartości", 2);
                    }
                }
                else
                {
                    throw new ToolException($"{usage}\nbłąd: nieznana opcja {name}", 2);
                }
            }
            else
            {
                _positional.Add(a);
            }
        }

        if (_positional.Count < minPositional || _positional.Count > Math.Max(minPositional, maxPositional))
        {
            throw new ToolException($"{usage}\nbłąd: nieprawidłowa liczba argumentów", 2);
        }
    }

    public bool Flag(string name) => _opts.ContainsKey(name) && _flags.Contains(name);

    public string? Opt(string name, string? fallback = null) => _opts.TryGetValue(name, out var v) && v != null ? v : fallback;

    public bool Has(string name) => _opts.ContainsKey(name);

    public string Pos(int i) => _positional[i];

    public IReadOnlyList<string> Positional => _positional;

    public string Usage => _usage;
}
