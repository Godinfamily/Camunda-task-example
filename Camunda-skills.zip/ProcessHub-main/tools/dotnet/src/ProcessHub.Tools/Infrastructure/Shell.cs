using System.Diagnostics;
using System.Text;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>Uruchamianie poleceń powłoki i gita z przechwyceniem wyjścia (jak subprocess.run(..., capture_output=True)).</summary>
public static class Shell
{
    public sealed record Result(int ExitCode, string StdOut, string StdErr, bool TimedOut);

    public static Result Run(string fileName, IEnumerable<string> args, string? cwd = null, string? stdin = null, int timeoutSeconds = 0,
        IDictionary<string, string>? env = null)
    {
        var psi = new ProcessStartInfo(fileName)
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = stdin != null,
            UseShellExecute = false,
            WorkingDirectory = cwd ?? Directory.GetCurrentDirectory(),
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };
        foreach (var a in args)
        {
            psi.ArgumentList.Add(a);
        }

        if (env != null)
        {
            foreach (var kv in env)
            {
                psi.Environment[kv.Key] = kv.Value;
            }
        }

        using var p = Process.Start(psi) ?? throw new ToolException($"nie udało się uruchomić {fileName}", 2);
        var stdout = p.StandardOutput.ReadToEndAsync();
        var stderr = p.StandardError.ReadToEndAsync();
        if (stdin != null)
        {
            p.StandardInput.Write(stdin);
            p.StandardInput.Close();
        }

        var finished = timeoutSeconds > 0 ? p.WaitForExit(timeoutSeconds * 1000) : WaitForever(p);
        if (!finished)
        {
            try
            {
                p.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException)
            {
            }

            return new Result(124, stdout.Result, stderr.Result, true);
        }

        p.WaitForExit();
        return new Result(p.ExitCode, stdout.Result, stderr.Result, false);
    }

    private static bool WaitForever(Process p)
    {
        p.WaitForExit();
        return true;
    }

    /// <summary>Polecenie przez powłokę systemową (shell=True): /bin/sh -c na Linuksie i macOS, cmd.exe /c na Windows.</summary>
    public static Result Sh(string command, string cwd, int timeoutSeconds) =>
        OperatingSystem.IsWindows()
            ? Run("cmd.exe", new[] { "/c", command }, cwd, timeoutSeconds: timeoutSeconds)
            : Run("/bin/sh", new[] { "-c", command }, cwd, timeoutSeconds: timeoutSeconds);

    public static Result Git(string cwd, params string[] args) => Run("git", args, cwd);

    /// <summary>Czy polecenie jest dostępne (np. python3).</summary>
    public static bool Available(string fileName, string versionArg = "--version")
    {
        try
        {
            return Run(fileName, new[] { versionArg }, timeoutSeconds: 10).ExitCode == 0;
        }
        catch (System.ComponentModel.Win32Exception)
        {
            return false;
        }
    }
}
