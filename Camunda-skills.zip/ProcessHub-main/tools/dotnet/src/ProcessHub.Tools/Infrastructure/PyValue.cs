using System.Collections;
using System.Globalization;
using System.Text;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>Słownik zachowujący kolejność wstawiania kluczy — odpowiednik dict z Pythona 3.7+.</summary>
public sealed class PyDict : IEnumerable<KeyValuePair<string, object?>>
{
    private readonly List<string> _keys = new();
    private readonly Dictionary<string, object?> _map = new(StringComparer.Ordinal);

    public object? this[string key]
    {
        get => _map.TryGetValue(key, out var v) ? v : throw new KeyNotFoundException($"brak klucza „{key}”");
        set
        {
            if (!_map.ContainsKey(key))
            {
                _keys.Add(key);
            }

            _map[key] = value;
        }
    }

    public IReadOnlyList<string> Keys => _keys;

    public IEnumerable<object?> Values => _keys.Select(k => _map[k]);

    public int Count => _keys.Count;

    public bool ContainsKey(string key) => _map.ContainsKey(key);

    public object? Get(string key, object? fallback = null) => _map.TryGetValue(key, out var v) ? v : fallback;

    public bool Remove(string key)
    {
        if (!_map.Remove(key))
        {
            return false;
        }

        _keys.Remove(key);
        return true;
    }

    public IEnumerator<KeyValuePair<string, object?>> GetEnumerator()
    {
        foreach (var k in _keys)
        {
            yield return new KeyValuePair<string, object?>(k, _map[k]);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

/// <summary>Operacje na wartościach o semantyce Pythona: str, int (long), float (double), bool, None, list, dict.</summary>
public static class Py
{
    public static PyDict Dict(object? v) => v as PyDict ?? throw new InvalidDataException($"oczekiwano słownika, jest {TypeName(v)}");

    public static List<object?> List(object? v) => v as List<object?> ?? throw new InvalidDataException($"oczekiwano listy, jest {TypeName(v)}");

    public static string Str(object? v) => v as string ?? throw new InvalidDataException($"oczekiwano tekstu, jest {TypeName(v)}");

    public static double Num(object? v) => v switch
    {
        long l => l,
        double d => d,
        bool b => b ? 1 : 0,
        _ => throw new InvalidDataException($"oczekiwano liczby, jest {TypeName(v)}"),
    };

    public static long Int(object? v) => v switch
    {
        long l => l,
        bool b => b ? 1 : 0,
        _ => throw new InvalidDataException($"oczekiwano liczby całkowitej, jest {TypeName(v)}"),
    };

    public static bool IsInt(object? v) => v is long;

    public static IEnumerable<string> Strings(object? v) => v is null ? Enumerable.Empty<string>() : List(v).Select(Str);

    /// <summary>
    /// sum() z Pythona 3.12+ dla liczb zmiennoprzecinkowych: pierwszy składnik dodawany do 0, kolejne sumowane
    /// algorytmem Neumaiera (Kahan–Babuška) z korektą na końcu — wynik identyczny co do bitu.
    /// </summary>
    public static double Sum(IEnumerable<double> values)
    {
        var first = true;
        double f = 0, c = 0;
        foreach (var x in values)
        {
            if (first)
            {
                f = 0.0 + x;
                first = false;
                continue;
            }

            var t = f + x;
            if (Math.Abs(f) >= Math.Abs(x))
            {
                c += (f - t) + x;
            }
            else
            {
                c += (x - t) + f;
            }

            f = t;
        }

        if (c != 0 && double.IsFinite(c))
        {
            f += c;
        }

        return f;
    }

    /// <summary>Prawdziwość wartości jak w Pythonie (bool(x)).</summary>
    public static bool Truthy(object? v) => v switch
    {
        null => false,
        bool b => b,
        long l => l != 0,
        double d => d != 0,
        string s => s.Length > 0,
        List<object?> l => l.Count > 0,
        PyDict d => d.Count > 0,
        _ => true,
    };

    public static object? Clone(object? v) => v switch
    {
        PyDict d => CloneDict(d),
        List<object?> l => l.Select(Clone).ToList(),
        _ => v,
    };

    private static PyDict CloneDict(PyDict d)
    {
        var copy = new PyDict();
        foreach (var kv in d)
        {
            copy[kv.Key] = Clone(kv.Value);
        }

        return copy;
    }

    /// <summary>str(x) z Pythona — dla wartości używanych w f-stringach.</summary>
    public static string ToStr(object? v) => v switch
    {
        null => "None",
        string s => s,
        bool b => b ? "True" : "False",
        long l => l.ToString(CultureInfo.InvariantCulture),
        double d => PyFloat.Repr(d),
        List<object?> l => "[" + string.Join(", ", l.Select(Repr)) + "]",
        PyDict d => "{" + string.Join(", ", d.Select(kv => Repr(kv.Key) + ": " + Repr(kv.Value))) + "}",
        _ => v.ToString() ?? string.Empty,
    };

    /// <summary>repr(x) z Pythona (teksty w apostrofach).</summary>
    public static string Repr(object? v)
    {
        if (v is not string s)
        {
            return ToStr(v);
        }

        var quote = s.Contains('\'') && !s.Contains('"') ? '"' : '\'';
        var sb = new StringBuilder();
        sb.Append(quote);
        foreach (var c in s)
        {
            if (c == quote || c == '\\')
            {
                sb.Append('\\').Append(c);
            }
            else if (c == '\n')
            {
                sb.Append("\\n");
            }
            else if (c == '\t')
            {
                sb.Append("\\t");
            }
            else
            {
                sb.Append(c);
            }
        }

        sb.Append(quote);
        return sb.ToString();
    }

    public static string TypeName(object? v) => v switch
    {
        null => "None",
        string => "str",
        long => "int",
        double => "float",
        bool => "bool",
        List<object?> => "list",
        PyDict => "dict",
        _ => v.GetType().Name,
    };
}
