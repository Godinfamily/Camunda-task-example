using System.Globalization;
using System.Numerics;
using System.Text;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>
/// Liczby zmiennoprzecinkowe dokładnie jak w Pythonie: round() (bankierskie na dokładnej wartości binarnej),
/// format 'f' i repr(). Dzięki temu pliki generowane przez narzędzia .NET są identyczne z wersją Python.
/// </summary>
public static class PyFloat
{
    /// <summary>round(x, n) z Pythona — wynik jako double.</summary>
    public static double Round(double x, int ndigits)
    {
        if (double.IsNaN(x) || double.IsInfinity(x) || x == 0)
        {
            return x;
        }

        var (neg, q) = RoundScaled(x, ndigits);
        var text = Place(q.ToString(CultureInfo.InvariantCulture), ndigits);
        var value = double.Parse(text, CultureInfo.InvariantCulture);
        return neg ? -value : value;
    }

    /// <summary>round(x) z Pythona — wynik jako liczba całkowita.</summary>
    public static long RoundToInt(double x)
    {
        if (double.IsNaN(x) || double.IsInfinity(x))
        {
            throw new OverflowException("nie można zaokrąglić NaN ani nieskończoności");
        }

        if (x == 0)
        {
            return 0;
        }

        var (neg, q) = RoundScaled(x, 0);
        return neg ? -(long)q : (long)q;
    }

    /// <summary>f"{x:.{n}f}" albo f"{x:,.{n}f}" (z separatorem tysięcy) z Pythona.</summary>
    public static string Fixed(double x, int digits, bool thousands = false)
    {
        if (double.IsNaN(x))
        {
            return "nan";
        }

        if (double.IsInfinity(x))
        {
            return x > 0 ? "inf" : "-inf";
        }

        var neg = x < 0 || (x == 0 && double.IsNegative(x));
        var q = x == 0 ? BigInteger.Zero : RoundScaled(x, digits).Q;
        var s = q.ToString(CultureInfo.InvariantCulture).PadLeft(digits + 1, '0');
        var intPart = s.Substring(0, s.Length - digits);
        var frac = digits > 0 ? s.Substring(s.Length - digits) : string.Empty;
        if (thousands)
        {
            intPart = Group(intPart);
        }

        var body = digits > 0 ? intPart + "." + frac : intPart;
        return (neg ? "-" : string.Empty) + body;
    }

    /// <summary>repr(x) z Pythona (najkrótszy zapis, który wczytuje się z powrotem do tej samej liczby).</summary>
    public static string Repr(double x)
    {
        if (double.IsNaN(x))
        {
            return "nan";
        }

        if (double.IsInfinity(x))
        {
            return x > 0 ? "inf" : "-inf";
        }

        if (x == 0)
        {
            return double.IsNegative(x) ? "-0.0" : "0.0";
        }

        var (digits, decpt) = ShortestDigits(Math.Abs(x).ToString("R", CultureInfo.InvariantCulture));
        var sb = new StringBuilder();
        if (x < 0)
        {
            sb.Append('-');
        }

        if (decpt > -4 && decpt <= 16)
        {
            if (decpt <= 0)
            {
                sb.Append("0.").Append('0', -decpt).Append(digits);
            }
            else if (decpt >= digits.Length)
            {
                sb.Append(digits).Append('0', decpt - digits.Length).Append(".0");
            }
            else
            {
                sb.Append(digits, 0, decpt).Append('.').Append(digits, decpt, digits.Length - decpt);
            }
        }
        else
        {
            sb.Append(digits[0]);
            if (digits.Length > 1)
            {
                sb.Append('.').Append(digits, 1, digits.Length - 1);
            }

            var exp = decpt - 1;
            sb.Append('e').Append(exp < 0 ? '-' : '+').Append(Math.Abs(exp).ToString("00", CultureInfo.InvariantCulture));
        }

        return sb.ToString();
    }

    /// <summary>Cyfry znaczące i pozycja przecinka (wartość = 0.cyfry × 10^decpt) z zapisu „R” platformy .NET.</summary>
    private static (string Digits, int Decpt) ShortestDigits(string r)
    {
        var exp = 0;
        var e = r.IndexOfAny(new[] { 'E', 'e' });
        if (e >= 0)
        {
            exp = int.Parse(r.Substring(e + 1), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture);
            r = r.Substring(0, e);
        }

        var dot = r.IndexOf('.');
        var intPart = dot >= 0 ? r.Substring(0, dot) : r;
        var fracPart = dot >= 0 ? r.Substring(dot + 1) : string.Empty;
        var all = intPart + fracPart;
        var decpt = intPart.Length + exp;
        var lead = 0;
        while (lead < all.Length - 1 && all[lead] == '0')
        {
            lead++;
        }

        all = all.Substring(lead);
        decpt -= lead;
        all = all.TrimEnd('0');
        if (all.Length == 0)
        {
            all = "0";
        }

        return (all, decpt);
    }

    /// <summary>|x| × 10^n zaokrąglone do liczby całkowitej (połówki do parzystej) na dokładnej wartości binarnej.</summary>
    private static (bool Neg, BigInteger Q) RoundScaled(double x, int ndigits)
    {
        var bits = BitConverter.DoubleToInt64Bits(x);
        var neg = bits < 0;
        var exponent = (int)((bits >> 52) & 0x7FF);
        var fraction = bits & 0xFFFFFFFFFFFFFL;
        BigInteger mant;
        int e2;
        if (exponent == 0)
        {
            mant = fraction;
            e2 = -1074;
        }
        else
        {
            mant = fraction | (1L << 52);
            e2 = exponent - 1075;
        }

        BigInteger num = mant, den = BigInteger.One;
        if (e2 >= 0)
        {
            num <<= e2;
        }
        else
        {
            den <<= -e2;
        }

        if (ndigits >= 0)
        {
            num *= BigInteger.Pow(10, ndigits);
        }
        else
        {
            den *= BigInteger.Pow(10, -ndigits);
        }

        var q = BigInteger.DivRem(num, den, out var rem);
        var cmp = (rem * 2).CompareTo(den);
        if (cmp > 0 || (cmp == 0 && !q.IsEven))
        {
            q += 1;
        }

        if (ndigits < 0)
        {
            q *= BigInteger.Pow(10, -ndigits);
        }

        return (neg, q);
    }

    private static string Place(string digits, int ndigits)
    {
        if (ndigits <= 0)
        {
            return digits;
        }

        digits = digits.PadLeft(ndigits + 1, '0');
        return digits.Substring(0, digits.Length - ndigits) + "." + digits.Substring(digits.Length - ndigits);
    }

    private static string Group(string intPart)
    {
        var sb = new StringBuilder();
        for (var i = 0; i < intPart.Length; i++)
        {
            if (i > 0 && (intPart.Length - i) % 3 == 0)
            {
                sb.Append(',');
            }

            sb.Append(intPart[i]);
        }

        return sb.ToString();
    }
}
