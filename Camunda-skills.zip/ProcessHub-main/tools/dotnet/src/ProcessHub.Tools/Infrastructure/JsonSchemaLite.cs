using System.Text.RegularExpressions;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>
/// Walidacja JSON Schema (draft 2020-12) w zakresie słów kluczowych używanych w repozytorium: type, required, properties,
/// additionalProperties, items, enum, const, pattern, minLength, minItems, minimum. Komunikaty jak w pakiecie jsonschema.
/// </summary>
public static class JsonSchemaLite
{
    public sealed record SchemaError(IReadOnlyList<object> Path, string Message);

    public static List<SchemaError> Validate(PyDict schema, object? instance)
    {
        var errors = new List<SchemaError>();
        Check(schema, instance, new List<object>(), errors);
        return errors;
    }

    private static void Check(PyDict s, object? v, List<object> path, List<SchemaError> errors)
    {
        void Add(string message) => errors.Add(new SchemaError(path.ToList(), message));

        var types = s.Get("type") switch
        {
            string t => new List<string> { t },
            List<object?> l => l.OfType<string>().ToList(),
            _ => null,
        };
        if (types != null && !types.Any(t => IsType(v, t)))
        {
            Add($"{Py.Repr(v)} is not of type {string.Join(", ", types.Select(t => "'" + t + "'"))}");
            return;
        }

        if (s.ContainsKey("const") && !Equal(s["const"], v))
        {
            Add($"{Py.Repr(s["const"])} was expected");
        }

        if (s.Get("enum") is List<object?> options && !options.Any(o => Equal(o, v)))
        {
            Add($"{Py.Repr(v)} is not one of {Py.ToStr(options)}");
        }

        if (v is string str)
        {
            if (s.Get("pattern") is string pattern && !Regex.IsMatch(str, pattern))
            {
                Add($"{Py.Repr(str)} does not match {Py.Repr(pattern)}");
            }

            if (s.Get("minLength") is long minLength && new System.Globalization.StringInfo(str).LengthInTextElements < minLength)
            {
                Add(minLength == 1 ? $"{Py.Repr(str)} should be non-empty" : $"{Py.Repr(str)} is too short");
            }
        }

        if (v is long or double && s.Get("minimum") is long or double && Py.Num(v) < Py.Num(s["minimum"]))
        {
            Add($"{Py.ToStr(v)} is less than the minimum of {Py.ToStr(s["minimum"])}");
        }

        if (v is long or double && s.Get("maximum") is long or double && Py.Num(v) > Py.Num(s["maximum"]))
        {
            Add($"{Py.ToStr(v)} is greater than the maximum of {Py.ToStr(s["maximum"])}");
        }

        if (v is List<object?> list)
        {
            if (s.Get("minItems") is long minItems && list.Count < minItems)
            {
                Add(minItems == 1 ? $"{Py.ToStr(list)} should be non-empty" : $"{Py.ToStr(list)} is too short");
            }

            if (s.Get("maxItems") is long maxItems && list.Count > maxItems)
            {
                Add($"{Py.ToStr(list)} is too long");
            }

            if (s.Get("items") is PyDict itemSchema)
            {
                for (var i = 0; i < list.Count; i++)
                {
                    path.Add((long)i);
                    Check(itemSchema, list[i], path, errors);
                    path.RemoveAt(path.Count - 1);
                }
            }
        }

        if (v is PyDict obj)
        {
            var props = s.Get("properties") as PyDict;
            if (s.Get("additionalProperties") is false)
            {
                var extra = obj.Keys.Where(k => props == null || !props.ContainsKey(k)).ToList();
                if (extra.Count > 0)
                {
                    Add($"Additional properties are not allowed ({string.Join(", ", extra.Select(Py.Repr))} {(extra.Count == 1 ? "was" : "were")} unexpected)");
                }
            }

            if (props != null)
            {
                foreach (var kv in props)
                {
                    if (obj.ContainsKey(kv.Key) && kv.Value is PyDict sub)
                    {
                        path.Add(kv.Key);
                        Check(sub, obj[kv.Key], path, errors);
                        path.RemoveAt(path.Count - 1);
                    }
                }
            }

            if (s.Get("required") is List<object?> required)
            {
                foreach (var r in required.OfType<string>())
                {
                    if (!obj.ContainsKey(r))
                    {
                        Add($"{Py.Repr(r)} is a required property");
                    }
                }
            }
        }
    }

    private static bool IsType(object? v, string type) => type switch
    {
        "object" => v is PyDict,
        "array" => v is List<object?>,
        "string" => v is string,
        "integer" => v is long || (v is double d && Math.Floor(d) == d),
        "number" => v is long or double,
        "boolean" => v is bool,
        "null" => v is null,
        _ => true,
    };

    private static bool Equal(object? a, object? b) => (a, b) switch
    {
        (null, null) => true,
        (long x, double y) => x == y,
        (double x, long y) => x == y,
        _ => Equals(a, b),
    };
}
