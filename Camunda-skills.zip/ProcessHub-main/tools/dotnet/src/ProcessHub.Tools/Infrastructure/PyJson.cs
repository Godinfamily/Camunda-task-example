using System.Globalization;
using System.Text;
using System.Text.Json;

namespace ProcessHub.Tools.Infrastructure;

/// <summary>JSON zapisywany bajt w bajt jak json.dumps z Pythona (indent, ensure_ascii) i wczytywany do modelu Py.</summary>
public static class PyJson
{
    public static string Dumps(object? value, int? indent = null, bool ensureAscii = false)
    {
        var sb = new StringBuilder();
        Write(sb, value, indent, ensureAscii, 0);
        return sb.ToString();
    }

    public static string Quote(string s, bool ensureAscii = false)
    {
        var sb = new StringBuilder();
        WriteString(sb, s, ensureAscii);
        return sb.ToString();
    }

    private static void Write(StringBuilder sb, object? v, int? indent, bool ascii, int level)
    {
        switch (v)
        {
            case null:
                sb.Append("null");
                break;
            case bool b:
                sb.Append(b ? "true" : "false");
                break;
            case long l:
                sb.Append(l.ToString(CultureInfo.InvariantCulture));
                break;
            case int i:
                sb.Append(i.ToString(CultureInfo.InvariantCulture));
                break;
            case double d:
                sb.Append(double.IsNaN(d) ? "NaN" : double.IsPositiveInfinity(d) ? "Infinity" : double.IsNegativeInfinity(d) ? "-Infinity" : PyFloat.Repr(d));
                break;
            case string s:
                WriteString(sb, s, ascii);
                break;
            case PyDict dict:
                WriteContainer(sb, dict.Select(kv => ((string?)kv.Key, kv.Value)).ToList(), true, indent, ascii, level);
                break;
            case List<object?> list:
                WriteContainer(sb, list.Select(x => ((string?)null, x)).ToList(), false, indent, ascii, level);
                break;
            default:
                throw new InvalidDataException($"nieobsługiwany typ w JSON: {v.GetType().Name}");
        }
    }

    private static void WriteContainer(StringBuilder sb, List<(string? Key, object? Value)> items, bool isDict, int? indent, bool ascii, int level)
    {
        var open = isDict ? '{' : '[';
        var close = isDict ? '}' : ']';
        if (items.Count == 0)
        {
            sb.Append(open).Append(close);
            return;
        }

        sb.Append(open);
        var first = true;
        foreach (var (key, value) in items)
        {
            if (indent is int n)
            {
                sb.Append(first ? string.Empty : ",").Append('\n').Append(' ', n * (level + 1));
            }
            else if (!first)
            {
                sb.Append(", ");
            }

            first = false;
            if (isDict)
            {
                WriteString(sb, key ?? string.Empty, ascii);
                sb.Append(": ");
            }

            Write(sb, value, indent, ascii, level + 1);
        }

        if (indent is int m)
        {
            sb.Append('\n').Append(' ', m * level);
        }

        sb.Append(close);
    }

    private static void WriteString(StringBuilder sb, string s, bool ascii)
    {
        sb.Append('"');
        foreach (var c in s)
        {
            switch (c)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                case '\b': sb.Append("\\b"); break;
                case '\f': sb.Append("\\f"); break;
                default:
                    if (c < 0x20 || (ascii && c > 0x7E))
                    {
                        sb.Append("\\u").Append(((int)c).ToString("x4", CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        sb.Append(c);
                    }

                    break;
            }
        }

        sb.Append('"');
    }

    /// <summary>json.loads z Pythona: liczby bez części ułamkowej i wykładnika jako int, pozostałe jako float.</summary>
    public static object? Loads(string text)
    {
        using var doc = JsonDocument.Parse(text);
        return Convert(doc.RootElement);
    }

    private static object? Convert(JsonElement e) => e.ValueKind switch
    {
        JsonValueKind.Object => ToDict(e),
        JsonValueKind.Array => e.EnumerateArray().Select(Convert).ToList(),
        JsonValueKind.String => e.GetString(),
        JsonValueKind.Number => NumberOf(e.GetRawText()),
        JsonValueKind.True => true,
        JsonValueKind.False => false,
        _ => null,
    };

    private static object NumberOf(string raw)
    {
        // Uwaga: osobne gałęzie — wyrażenie warunkowe zamieniłoby long na double.
        if (raw.IndexOfAny(new[] { '.', 'e', 'E' }) >= 0)
        {
            return double.Parse(raw, CultureInfo.InvariantCulture);
        }

        return long.Parse(raw, CultureInfo.InvariantCulture);
    }

    private static PyDict ToDict(JsonElement e)
    {
        var d = new PyDict();
        foreach (var p in e.EnumerateObject())
        {
            d[p.Name] = Convert(p.Value);
        }

        return d;
    }
}
