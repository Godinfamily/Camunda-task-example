using ProcessHub.Tools.Commands;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools;

/// <summary>ph — narzędzia repozytorium Process Hub w .NET (odpowiedniki skryptów z tools/*.py).</summary>
public static class Program
{
    public static int Main(string[] args)
    {
        Console.OutputEncoding = Repo.Utf8;
        try
        {
            return Run(args);
        }
        catch (ToolException e)
        {
            Console.Error.WriteLine(e.Message);
            return e.ExitCode;
        }
        catch (InvalidDataException e)
        {
            Console.Error.WriteLine($"BŁĄD DANYCH: {e.Message}");
            return 2;
        }
    }

    public static int Run(string[] args)
    {
        var list = args.ToList();
        var repoIdx = list.IndexOf("--repo");
        if (repoIdx >= 0 && repoIdx + 1 < list.Count)
        {
            Repo.SetRoot(list[repoIdx + 1]);
            list.RemoveRange(repoIdx, 2);
        }

        if (list.Count == 0 || list[0] is "-h" or "--help" or "help")
        {
            Console.WriteLine(Commands.Help.Text);
            return 0;
        }

        return Dispatcher.Dispatch(list);
    }
}
