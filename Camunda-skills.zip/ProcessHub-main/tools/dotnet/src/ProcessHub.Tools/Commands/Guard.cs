using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>
/// Strażnik zakresu zapisu — odpowiednik tools/guard/enforce_write_scope.py (te same reguły i komunikaty).
/// stdin {"tool","path"} (kod 2 = blokada) · --check ścieżki · --verify-diff base [--profile id] · --self-test.
/// </summary>
public static class Guard
{
    /// <summary>Ścieżki chronione i znacznik, który musi wystąpić w globie .agent-scope, by zapis był dozwolony.</summary>
    public static readonly (string Pattern, string Marker)[] Protected =
    {
        ("specs/**", "specs/"),
        ("**/Contracts/**", "/Contracts"),
        ("docs/adr/**", "docs/adr"),
        ("config/authorization/**", "config/authorization"),
        ("plan/backlog.yaml", "plan/backlog.yaml"),
        ("AGENTS.md", "AGENTS.md"),
        ("CODEOWNERS", "CODEOWNERS"),
        ("src/Platform/ProcessHub.Extensibility/**", "ProcessHub.Extensibility"),
        ("frontend/libs/platform/extension-sdk/**", "extension-sdk"),
        ("profiles/*/profile.yaml", "profile.yaml"),
        ("profiles/*/authorization.yaml", "authorization.yaml"),
    };

    /// <summary>Wniosek o zmianę poza zakresem kroku: dozwolony w każdym kroku (AGENTS.md, zasada 8).</summary>
    public const string RfcGlob = "docs/rfc/RFC-*.md";

    public static int Run(string[] args)
    {
        if (args.Length > 0 && args[0] == "--self-test")
        {
            return SelfTest();
        }

        if (args.Length > 0 && args[0] == "--check")
        {
            return CheckPaths(args.Skip(1));
        }

        if (args.Length >= 2 && args[0] == "--verify-diff")
        {
            var idx = Array.IndexOf(args, "--profile");
            return VerifyDiff(args[1], idx >= 0 && idx + 1 < args.Length ? args[idx + 1] : null);
        }

        return StdinMode();
    }

    public static string ProjectRoot()
    {
        var env = Environment.GetEnvironmentVariable("PH_PROJECT_DIR");
        return string.IsNullOrEmpty(env) ? Directory.GetCurrentDirectory() : env;
    }

    /// <summary>(globy, profil) z .agent-scope albo (null, null), gdy plik nie istnieje (sesja człowieka).</summary>
    public static (List<string>? Globs, string? Profile) LoadScope(string root)
    {
        var path = Path.Combine(root, ".agent-scope");
        if (!File.Exists(path))
        {
            return (null, null);
        }

        var globs = new List<string>();
        string? profile = null;
        foreach (var raw in Repo.Read(path).Split('\n'))
        {
            var line = raw.Trim();
            if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
            {
                continue;
            }

            if (line.StartsWith("@profile ", StringComparison.Ordinal))
            {
                profile = line.Substring("@profile ".Length).Trim();
            }
            else
            {
                globs.Add(line);
            }
        }

        return (globs, profile);
    }

    private static bool Matches(string rel, IEnumerable<string> globs) =>
        globs.Any(g => Glob.FnMatch(rel, g) || Glob.FnMatch(rel, g.TrimEnd('/', '*')));

    private static string Normalize(string rel)
    {
        rel = rel.Replace('\\', '/');
        while (rel.StartsWith("./", StringComparison.Ordinal))
        {
            rel = rel.Substring(2);
        }

        return rel;
    }

    public static (bool Ok, string Why) Decide(string rel, List<string>? scope, string? profile = null)
    {
        rel = Normalize(rel);
        if (rel.StartsWith("../", StringComparison.Ordinal) || rel == ".." || Path.IsPathRooted(rel))
        {
            return (false, $"zapis poza repozytorium: {rel}");
        }

        if (Glob.FnMatch(rel, RfcGlob) && !rel.Substring("docs/rfc/".Length).Contains('/'))
        {
            return (true, string.Empty);
        }

        if (profile != null)
        {
            var own = $"profiles/{profile}/";
            if (rel.StartsWith("profiles/", StringComparison.Ordinal) && !rel.StartsWith(own, StringComparison.Ordinal))
            {
                var other = rel.Split('/')[1];
                return (false, $"{rel} należy do profilu „{other}” — krok profilu „{profile}” zmienia tylko {own}**");
            }

            if (!rel.StartsWith(own, StringComparison.Ordinal))
            {
                return (false, $"{rel} to część platformy — krok profilu „{profile}” zmienia tylko {own}** (zmiana platformy: RFC w docs/rfc/)");
            }
        }

        if (scope == null)
        {
            if (Environment.GetEnvironmentVariable("PH_STRICT") == "1" && Matches(rel, Protected.Select(p => p.Pattern)))
            {
                return (false, $"ścieżka chroniona bez .agent-scope: {rel}");
            }

            return (true, string.Empty);
        }

        foreach (var (pattern, marker) in Protected)
        {
            if (Glob.FnMatch(rel, pattern))
            {
                var isExplicit = scope.Any(g => g.Contains(marker, StringComparison.Ordinal) && Matches(rel, new[] { g })) || (scope.Count == 1 && scope[0] == "**");
                if (!isExplicit)
                {
                    return (false, $"ścieżka chroniona ({rel}) — złóż RFC w docs/rfc/ zamiast edytować");
                }
            }
        }

        if (!Matches(rel, scope))
        {
            return (false, $"{rel} jest poza zakresem kroku; dozwolone: {string.Join(", ", scope)}");
        }

        return (true, string.Empty);
    }

    private static string Relative(string target, string root) =>
        Path.GetRelativePath(root, Path.GetFullPath(Path.Combine(root, target))).Replace('\\', '/');

    private static int StdinMode()
    {
        var text = Console.In.ReadToEnd();
        var data = PyJson.Loads(text) as PyDict ?? new PyDict();
        if (data.Get("path") is not string target || target.Length == 0)
        {
            return 0;
        }

        var root = ProjectRoot();
        var (scope, profile) = LoadScope(root);
        var (ok, why) = Decide(Relative(target, root), scope, profile);
        if (ok)
        {
            return 0;
        }

        Console.Error.WriteLine($"BLOCKED: {why}");
        return 2;
    }

    private static int CheckPaths(IEnumerable<string> paths)
    {
        var root = ProjectRoot();
        var (scope, profile) = LoadScope(root);
        var bad = 0;
        foreach (var p in paths)
        {
            var (ok, why) = Decide(Relative(p, root), scope, profile);
            Console.WriteLine((ok ? "OK       " : "BLOCKED  ") + (ok ? p : why));
            bad += ok ? 0 : 1;
        }

        return bad > 0 ? 1 : 0;
    }

    private static int VerifyDiff(string baseRef, string? profileArg)
    {
        var root = ProjectRoot();
        var (scope, profile) = LoadScope(root);
        profile = profileArg ?? profile;
        if (profile != null && scope == null)
        {
            scope = new List<string> { $"profiles/{profile}/**" };
        }

        var res = Shell.Git(root, "diff", "--name-only", $"{baseRef}...HEAD");
        if (res.ExitCode != 0)
        {
            Console.Error.WriteLine($"BŁĄD: nie udało się porównać z {baseRef}: {res.StdErr.Trim()}");
            return 2;
        }

        var separators = new[] { '\n', ' ', '\t', '\r' };
        var files = res.StdOut.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
        foreach (var extra in new[] { new[] { "diff", "--name-only", "HEAD" }, new[] { "ls-files", "--others", "--exclude-standard" } })
        {
            var more = Shell.Git(root, extra);
            if (more.ExitCode == 0)
            {
                files.AddRange(more.StdOut.Split(separators, StringSplitOptions.RemoveEmptyEntries).Where(f => !files.Contains(f)).ToList());
            }
        }

        var bad = 0;
        foreach (var f in files)
        {
            var (ok, why) = Decide(f, scope, profile);
            if (!ok)
            {
                Console.Error.WriteLine($"SCOPE VIOLATION: {why}");
                bad++;
            }
        }

        return bad > 0 ? 1 : 0;
    }

    public static int SelfTest()
    {
        var module = new List<string> { "src/Modules/TaskWork/**", "tests/TaskWork.*/**" };
        var prof = new List<string> { "profiles/kredyty/**" };
        var cases = new (string Path, List<string> Globs, string? Profile, bool Expected)[]
        {
            ("src/Modules/TaskWork/Domain/WorkItem.cs", module, null, true),
            ("src/Modules/TaskWork/Contracts/ITaskWork.cs", module, null, false),
            ("src/Modules/Audit/Domain/JournalEntry.cs", module, null, false),
            ("tests/TaskWork.Specs/Steps/ClaimSteps.cs", module, null, true),
            ("specs/tasks/claim-and-complete.feature", module, null, false),
            ("../outside.txt", module, null, false),
            ("src/Modules/TaskWork/AGENTS.md", module, null, true),
            ("src/Modules/TaskWork/Contracts/X.cs", new List<string> { "src/Modules/*/Contracts/**" }, null, true),
            ("profiles/kredyty/backend/Kredyty.Extension/Scoring/RecalculateScoring.cs", prof, "kredyty", true),
            ("profiles/kredyty/specs/scoring.feature", prof, "kredyty", true),
            ("profiles/kredyty/AGENTS.md", prof, "kredyty", true),
            ("profiles/kredyty/profile.yaml", prof, "kredyty", false),
            ("profiles/aml/backend/Aml.Extension/Sanctions.cs", prof, "kredyty", false),
            ("profiles/aml/backend/Aml.Extension/Sanctions.cs", new List<string> { "profiles/**" }, "kredyty", false),
            ("src/Modules/TaskWork/Domain/WorkItem.cs", new List<string> { "**" }, "kredyty", false),
            ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", new List<string> { "src/Platform/**" }, null, false),
            ("src/Platform/ProcessHub.Extensibility/ITaskOperation.cs", new List<string> { "src/Platform/ProcessHub.Extensibility/**" }, null, true),
            ("docs/rfc/RFC-S30-kontrakt.md", module, null, true),
            ("docs/rfc/RFC-KRE-02-sdk.md", prof, "kredyty", true),
            ("docs/rfc/notatki.md", module, null, false),
            ("docs/rfc/RFC-S30/zalacznik.md", module, null, false),
        };
        var failed = cases.Where(c => Decide(c.Path, c.Globs, c.Profile).Ok != c.Expected).ToList();
        foreach (var f in failed)
        {
            Console.Error.WriteLine($"self-test FAIL: {f.Path} oczekiwano {(f.Expected ? "dozwolone" : "blokada")}");
        }

        Console.WriteLine(failed.Count == 0 ? "self-test OK" : "self-test FAILED");
        return failed.Count == 0 ? 0 : 1;
    }
}
