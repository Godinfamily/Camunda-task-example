using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Źródła notesu LLM: pakiety plików repozytorium w Markdown (= tools/handover/build_notebook_sources.py).</summary>
public static class Notes
{
    private static readonly Dictionary<string, string?> Lang = new()
    {
        [".yaml"] = "yaml", [".yml"] = "yaml", [".json"] = "json", [".feature"] = "gherkin", [".py"] = "python", [".js"] = "javascript", [".md"] = null, [".txt"] = "text",
    };

    private static readonly (string Name, string Desc, string[] Patterns)[] Bundles =
    {
        ("01-wejscie-i-architektura", "Wejście do repozytorium, zasady dla agentów i ludzi, słownik i architektura (docs/architecture 00–14)",
            new[] { "README.md", "AGENTS.md", "docs/glossary.md", "docs/architecture/*.md" }),
        ("02-decyzje-i-uprawnienia", "Decyzje architektoniczne (ADR-001…020), wnioski RFC, uprawnienia jako kod i własność kodu",
            new[] { "docs/adr/README.md", "docs/adr/ADR-*.md", "docs/rfc/*.md", "config/authorization/*.yaml", "config/ownership.yaml", "CODEOWNERS" }),
        ("03-specyfikacje-bdd", "Świat testowy i scenariusze Gherkin platformy (Reqnroll, # language: pl)",
            new[] { "specs/README.md", "specs/**/*.feature" }),
        ("04-plan-i-wycena", "Plan wykonawczy platformy, backlog maszynowy, szablon pakietu, model i raport wyceny",
            new[] { "plan/execution-plan.md", "plan/backlog.yaml", "plan/work-packet-template.md", "plan/estimation.md",
                "plan/estimation-report.md", "plan/estimates.yaml", "plan/estimation-params.yaml", "plan/progress/README.md" }),
        ("05-profile-projektow", "Profile projektów: przewodnik i instrukcja dedykowanych elementów, schemat manifestu, szablon, profile kredyty, aml i flota (manifesty, plany, scenariusze)",
            new[] { "profiles/README.md", "docs/guides/*.md", "profiles/profile.schema.json", "profiles/_template/*.yaml", "profiles/_template/AGENTS.md",
                "profiles/*/profile.yaml", "profiles/*/authorization.yaml", "profiles/*/README.md", "profiles/*/AGENTS.md", "profiles/*/backlog.yaml", "profiles/*/specs/*.feature" }),
        ("06-roj-agentow", "Rój agentów w OpenCode z modelem GLM w banku: instrukcja startu, przewodnik, skille, komendy, rejestr ról, model i polityka, kwalifikacja, narzędzia .NET",
            new[] { "docs/opencode/start.md", "docs/agents/multi-model-guide.md", ".opencode/README.md", ".opencode/skills/*/SKILL.md",
                ".opencode/command/*.md", "agents/registry.yaml", "agents/runtime-policy.yaml", "agents/schemas/*.json",
                "config/models.yaml", "evals/agents/README.md", "evals/agents/cases/*.yaml", "tools/dotnet/README.md" }),
        ("07-ui-i-dashboard", "Propozycja UI, tokeny, formatki (założenia wizualne i katalog pól), dashboard harmonogramu: rejestr ryzyk i decyzji oraz dane",
            new[] { "design/README.md", "design/tokens.json", "design/forms/README.md", "design/forms/field-catalog.yaml", "plan/dashboard/README.md", "plan/dashboard/register.yaml",
                "plan/dashboard/data/summary.json", "plan/dashboard/data/phases.json", "plan/dashboard/data/gates.json",
                "plan/dashboard/data/roles.json", "plan/dashboard/data/scenarios.json", "plan/dashboard/data/risks.json",
                "plan/dashboard/data/decisions.json" }),
        ("08-artefakty-i-podsumowanie", "Artefakty projektowe (plan systemu, aktorzy, założenia, wytyczne UI) i podsumowanie projektu z rejestrem wymagań W-01…W-48",
            new[] { "docs/artifacts/01-plan-systemu.md", "docs/artifacts/02-aktorzy.md", "docs/artifacts/03-zalozenia.md", "docs/artifacts/04-wytyczne-ui.md", "docs/artifacts/05-agenci.md", "docs/handover/podsumowanie.md" }),
        ("09-narzedzia-kod", "Kod narzędzi repozytorium (opcjonalne źródło): wycena, eksport, artefakty, generator agentów, prowadzenie kroków, strażnik, profile",
            new[] { "tools/plan/estimate.py", "tools/plan/export_dashboard_data.py", "tools/artifacts/render_artifacts.py",
                "tools/agents/render_agents.py", "tools/agents/steplib.py", "tools/agents/prepare_step.py", "tools/agents/run_dod.py",
                "tools/agents/plan_status.py", "tools/agents/validate_output.py", "tools/guard/enforce_write_scope.py",
                "tools/profiles/validate_profiles.py", "tools/profiles/new_profile.py", ".opencode/plugin/write-scope.js",
                ".opencode/lib/write-scope-core.js" }),
    };

    private static List<string> FilesFor(IEnumerable<string> patterns)
    {
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var output = new List<string>();
        foreach (var pat in patterns)
        {
            foreach (var f in Glob.Find(Repo.Root, pat).OrderBy(x => x, StringComparer.Ordinal))
            {
                if (File.Exists(f) && seen.Add(f))
                {
                    output.Add(f);
                }
            }
        }

        return output;
    }

    private static string StepsTable(List<object?> rows)
    {
        var lines = new List<string>
        {
            "| Krok | Nazwa | Faza | Krytyczny | Tydz. start–koniec | Zapas (dni) | Złożoność | Udział AI | Bez AI (od) | Z AI (od) | "
                + "Zakres | Rola wiodąca | Ryzyko | Bloker zewnętrzny |\n| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
        };
        foreach (var s in rows.Select(Py.Dict))
        {
            lines.Add($"| {s["id"]} | {s["short"]} | {Py.ToStr(s["phase"])} {s["phase_name"]} | {(Py.Truthy(s["critical"]) ? "tak" : string.Empty)} | "
                + $"{Py.ToStr(s["start_week"])}–{Py.ToStr(s["end_week"])} | {Py.ToStr(s["float_days"])} | {s["complexity_class"]} ({Py.ToStr(s["complexity"])}) | "
                + $"{PyFloat.RoundToInt(Py.Num(s["ai_share"]) * 100)}% | {Py.ToStr(s["trad_pd"])} | {Py.ToStr(s["hyb_pd"])} | {s["scopes"]} | {s["lead_role"]} | "
                + $"{s["risk_label"]} | {s["external_blocker"]} |");
        }

        return string.Join("\n", lines);
    }

    public static int Build(string[] args)
    {
        var cli = new Cli("użycie: ph notes build [--check]", args, new[] { "--check" }, Array.Empty<string>());
        var outDir = Repo.P("docs/handover/notes/zrodla");
        var outputs = new List<(string Path, string Content)>();
        var index = new List<string>
        {
            "# 00 — Indeks źródeł Process Hub", string.Empty,
            "Każdy plik źródłowy to pakiet plików repozytorium. Sekcja `## Plik: <ścieżka>` oznacza oryginalną ścieżkę w repozytorium — "
                + "cytuj ją w odpowiedziach. Pliki wygenerowane (raport wyceny, dane dashboardu, AGENTS.md, agents/dist) są pochodne: "
                + "zmienia się ich źródła i uruchamia generator.",
            string.Empty, "| Źródło | Zawartość | Pliki |", "| --- | --- | --- |",
        };
        foreach (var (name, desc, patterns) in Bundles)
        {
            var fs = FilesFor(patterns);
            var parts = new List<string> { $"# {name} — {desc}", string.Empty, $"Pakiet zawiera {fs.Count} plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.", string.Empty };
            if (name == "07-ui-i-dashboard")
            {
                var rows = Py.List(PyJson.Loads(Repo.ReadRel("plan/dashboard/data/steps.json")));
                parts.AddRange(new[]
                {
                    "## Plik: plan/dashboard/data/steps.json (skrót tabelaryczny)", string.Empty,
                    $"Liczba rekordów w pełnym zbiorze: {rows.Count} (każdy z kilkudziesięcioma polami); poniżej najważniejsze kolumny.", string.Empty, StepsTable(rows), string.Empty,
                });
            }

            foreach (var p in fs)
            {
                var rel = Repo.Rel(p);
                var text = Repo.Read(p).TrimEnd();
                var ext = Path.GetExtension(p);
                var lang = Lang.TryGetValue(ext, out var l) ? l : "text";
                parts.Add($"## Plik: {rel}");
                parts.Add(string.Empty);
                parts.Add(lang == null ? text : $"````{lang}\n{text}\n````");
                parts.Add(string.Empty);
            }

            var content = string.Join("\n", parts) + "\n";
            outputs.Add((Path.Combine(outDir, $"{name}.md"), content));
            var size = Repo.Utf8.GetByteCount(content);
            index.Add($"| `{name}.md` | {desc} | {fs.Count} ({PyFloat.RoundToInt(size / 1024.0)} KB) |");
        }

        index.Add(string.Empty);
        index.Add("Nie ma w źródłach stron do oglądania (`design/mockups/index.html`, `plan/dashboard/index.html`, `docs/artifacts/index.html`) "
            + "ani pierwotnych dokumentów v1 z projektu (można je wgrać osobno jako tło).");
        outputs.Add((Path.Combine(outDir, "00-indeks.md"), string.Join("\n", index) + "\n"));
        var expected = new HashSet<string>(outputs.Select(o => o.Path), StringComparer.Ordinal);
        var orphans = Directory.Exists(outDir) ? Directory.GetFiles(outDir, "*.md").Where(f => !expected.Contains(f)).OrderBy(f => f, StringComparer.Ordinal).ToList() : new List<string>();
        var stale = outputs.Where(o => !Repo.SameContent(o.Path, o.Content)).ToList();
        if (cli.Flag("--check"))
        {
            foreach (var s in stale.Select(s => s.Path).Concat(orphans))
            {
                Console.Error.WriteLine($"NIEAKTUALNE: {Repo.Rel(s)}");
            }

            return stale.Count > 0 || orphans.Count > 0 ? 1 : 0;
        }

        foreach (var o in orphans)
        {
            File.Delete(o);
        }

        foreach (var (path, content) in outputs)
        {
            Repo.Write(path, content);
        }

        Console.WriteLine(string.Join("\n", index.Skip(6).Take(Bundles.Length)));
        return 0;
    }
}
