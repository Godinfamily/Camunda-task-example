using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Model szacowania pracochłonności (= tools/plan/estimate.py): PERT, hybryda AI + ludzie, ścieżka krytyczna, obciążenie ról.</summary>
public static class Estimate
{
    public static readonly Dictionary<string, string> RoleOfAgent = new()
    {
        ["module-implementer"] = "backend_dotnet", ["camunda-integrator"] = "backend_dotnet", ["data-engineer"] = "backend_dotnet",
        ["frontend-developer"] = "frontend_angular", ["bdd-tester"] = "qa_bdd", ["bdd-analyst"] = "product_owner_analityk",
        ["architect"] = "architekt_tech_lead", ["security-reviewer"] = "bezpieczenstwo", ["orchestrator"] = "architekt_tech_lead",
        ["ux-designer"] = "ux_designer", ["design-system-engineer"] = "frontend_angular", ["ui-reviewer"] = "ux_designer",
    };

    public static readonly Dictionary<string, List<(string Role, double Share)>> RoleSplit = new()
    {
        ["S00"] = new() { ("architekt_tech_lead", 0.6), ("devops", 0.4) },
        ["S01"] = new() { ("backend_dotnet", 0.6), ("devops", 0.2), ("architekt_tech_lead", 0.2) },
        ["S02"] = new() { ("backend_dotnet", 0.4), ("bezpieczenstwo", 0.3), ("architekt_tech_lead", 0.3) },
        ["S06"] = new() { ("devops", 0.7), ("backend_dotnet", 0.15), ("architekt_tech_lead", 0.15) },
        ["S07"] = new() { ("frontend_angular", 0.65), ("ux_designer", 0.2), ("architekt_tech_lead", 0.15) },
        ["S09"] = new() { ("ux_designer", 0.7), ("frontend_angular", 0.15), ("product_owner_analityk", 0.15) },
        ["S16"] = new() { ("frontend_angular", 0.85), ("ux_designer", 0.15) },
        ["S19"] = new() { ("architekt_tech_lead", 0.4), ("backend_dotnet", 0.45), ("frontend_angular", 0.15) },
        ["S27"] = new() { ("backend_dotnet", 0.5), ("bezpieczenstwo", 0.25), ("architekt_tech_lead", 0.15), ("devops", 0.1) },
        ["S40"] = new() { ("frontend_angular", 0.9), ("ux_designer", 0.1) },
        ["S45"] = new() { ("frontend_angular", 0.9), ("ux_designer", 0.1) },
        ["S48"] = new() { ("architekt_tech_lead", 0.5), ("product_owner_analityk", 0.3), ("qa_bdd", 0.2) },
        ["S49"] = new() { ("frontend_angular", 0.75), ("ux_designer", 0.25) },
        ["S50"] = new() { ("qa_bdd", 0.5), ("backend_dotnet", 0.3), ("devops", 0.2) },
        ["S51"] = new() { ("bezpieczenstwo", 0.5), ("qa_bdd", 0.3), ("backend_dotnet", 0.2) },
        ["S53"] = new() { ("frontend_angular", 0.7), ("ux_designer", 0.3) },
        ["S54"] = new() { ("bezpieczenstwo", 0.5), ("architekt_tech_lead", 0.3), ("product_owner_analityk", 0.2) },
        ["S55"] = new() { ("frontend_angular", 0.6), ("qa_bdd", 0.25), ("ux_designer", 0.15) },
        ["S60"] = new() { ("product_owner_analityk", 0.4), ("devops", 0.3), ("architekt_tech_lead", 0.3) },
    };

    public static readonly Dictionary<string, string> RoleLabel = new()
    {
        ["architekt_tech_lead"] = "Architekt / tech lead", ["backend_dotnet"] = "Backend .NET", ["frontend_angular"] = "Frontend Angular",
        ["devops"] = "DevOps", ["qa_bdd"] = "QA / BDD", ["product_owner_analityk"] = "PO / analityk", ["bezpieczenstwo"] = "Bezpieczeństwo",
        ["ux_designer"] = "Projektant UX",
    };

    public sealed class Row
    {
        public string Id = string.Empty;
        public string Title = string.Empty;
        public object? Phase;
        public string Size = "M";
        public string? Agent;
        public double C;
        public string Cls = string.Empty;
        public PyDict E = new();
        public double Trad, TradS, F, Hyb, HybS, HybFinal, HybFinalS, Dur, DurS;
        public List<string> Deps = new();
        public string? Gate;
    }

    public sealed class Result
    {
        public List<string> Order = new();
        public Dictionary<string, Row> Rows = new(StringComparer.Ordinal);
        public double CpDays, CpSig;
        public List<string> CpPath = new();
        public List<string> RoleOrder = new();
        public Dictionary<string, double> RoleLoad = new(StringComparer.Ordinal);
        public Dictionary<string, double> RoleDays = new(StringComparer.Ordinal);
        public double K;
        public List<string> Done = new();

        public IEnumerable<Row> RowList => Order.Select(id => Rows[id]);

        /// <summary>max(role_days, key=role_days.get) — pierwsza rola o największej wartości.</summary>
        public string Bottleneck()
        {
            var best = RoleOrder[0];
            foreach (var r in RoleOrder)
            {
                if (RoleDays[r] > RoleDays[best])
                {
                    best = r;
                }
            }

            return best;
        }
    }

    public sealed record Inputs(PyDict Backlog, PyDict Estimates, PyDict Params, List<(string Step, double Actual)> Actuals);

    public static Inputs Load()
    {
        var backlog = Py.Dict(Repo.Yaml("plan/backlog.yaml"));
        var est = Py.Dict(Py.Dict(Repo.Yaml("plan/estimates.yaml"))["steps"]);
        var parameters = Py.Dict(Repo.Yaml("plan/estimation-params.yaml"));
        var actuals = new List<(string, double)>();
        foreach (var f in Glob.Find(Repo.Root, "plan/progress/*.effort.json").OrderBy(x => x, StringComparer.Ordinal))
        {
            try
            {
                if (PyJson.Loads(Repo.Read(f)) is PyDict d && d.ContainsKey("actual_human_pd"))
                {
                    var step = Py.Str(d["step"]);
                    actuals.RemoveAll(a => a.Item1 == step);
                    actuals.Add((step, Py.Num(d["actual_human_pd"])));
                }
            }
            catch (Exception e) when (e is System.Text.Json.JsonException or InvalidDataException or KeyNotFoundException)
            {
            }
        }

        return new Inputs(backlog, est, parameters, actuals);
    }

    public static (double Mean, double Sigma) Pert(object? o, object? m, object? p)
    {
        if (o is long lo && m is long lm && p is long lp)
        {
            return ((double)(lo + 4 * lm + lp) / 6, (double)(lp - lo) / 6);
        }

        double oo = Py.Num(o), mm = Py.Num(m), pp = Py.Num(p);
        return ((oo + 4 * mm + pp) / 6, (pp - oo) / 6);
    }

    public static (double Mean, double Sigma) Pert(object? triple)
    {
        var l = Py.List(triple);
        return Pert(l[0], l[1], l[2]);
    }

    public static List<(string Role, double Share)> SplitOf(string sid, string? agent) =>
        RoleSplit.TryGetValue(sid, out var split) ? split : new List<(string, double)> { (agent != null && RoleOfAgent.TryGetValue(agent, out var r) ? r : "architekt_tech_lead", 1.0) };

    public static Result Compute(Inputs inp, string mode = "hyb")
    {
        var steps = Py.List(inp.Backlog["steps"]).Select(Py.Dict).ToList();
        var ids = steps.Select(s => Py.Str(s["id"])).ToList();
        var missing = ids.Where(i => !inp.Estimates.ContainsKey(i)).OrderBy(x => x, StringComparer.Ordinal)
            .Concat(inp.Estimates.Keys.Where(k => !ids.Contains(k)).OrderBy(x => x, StringComparer.Ordinal)).ToList();
        if (missing.Count > 0)
        {
            throw new ToolException($"Niespójność backlog.yaml ↔ estimates.yaml: {Py.ToStr(missing.Cast<object?>().ToList())}");
        }

        var w = Py.Dict(inp.Params["weights"]);
        var classes = Py.List(inp.Params["classes"]).Select(Py.Dict).ToList();
        var res = new Result();
        foreach (var s in steps)
        {
            var sid = Py.Str(s["id"]);
            var e = Py.Dict(inp.Estimates[sid]);
            var c = Py.Sum(new[] { "T", "N", "I", "B" }.Select(k => Py.Num(w[k]) * Py.Num(e[k])));

            var (tm, ts) = Pert(e["trad_pd"]);
            var ai = Py.Num(e["ai_share"]);
            var f = (1 - ai) + ai * Py.Num(e["review"]);
            var row = new Row
            {
                Id = sid,
                Title = Py.Str(s["title"]),
                Phase = s.Get("phase"),
                Size = s.Get("size") as string ?? "M",
                Agent = s.Get("agent") as string,
                C = c,
                Cls = Py.Str(classes.First(x => c <= Py.Num(x["max"]))["name"]),
                E = e,
                Trad = tm,
                TradS = ts,
                F = f,
                Hyb = tm * f,
                HybS = ts * f,
                Deps = Py.Strings(s.Get("depends_on")).ToList(),
                Gate = s.Get("gate_before") as string,
            };
            res.Order.Add(sid);
            res.Rows[sid] = row;
        }

        var actuals = inp.Actuals.Where(a => res.Rows.ContainsKey(a.Step)).ToList();
        res.Done = inp.Actuals.Where(a => res.Rows.ContainsKey(a.Step) && res.Rows[a.Step].Hyb > 0).Select(a => a.Step).ToList();
        if (res.Done.Count > 0)
        {
            res.K = Py.Sum(res.Done.Select(sid => inp.Actuals.Last(a => a.Step == sid).Actual / res.Rows[sid].Hyb)) / res.Done.Count;
        }
        else
        {
            res.K = 1.0;
        }

        var calendar = Py.Dict(inp.Params["calendar"]);
        var pfs = Py.Dict(calendar["parallel_factor"]);
        var gateWait = Py.Dict(calendar["gate_wait_days"]);
        foreach (var r in res.RowList)
        {
            var actual = inp.Actuals.Where(a => a.Step == r.Id).Select(a => (double?)a.Actual).LastOrDefault();
            if (mode == "trad")
            {
                (r.HybFinal, r.HybFinalS) = (r.Trad, r.TradS);
            }
            else if (actual is double act)
            {
                (r.HybFinal, r.HybFinalS) = (act, 0.0);
            }
            else
            {
                (r.HybFinal, r.HybFinalS) = (r.Hyb * res.K, r.HybS * res.K);
            }

            var pf = pfs.ContainsKey(r.Size) ? Py.Num(pfs[r.Size]) : 1.0;
            var dur = r.HybFinal / pf;
            var durS = r.HybFinalS / pf;
            if (Py.Truthy(r.E.Get("external_calendar_days")))
            {
                var (em, es) = Pert(r.E["external_calendar_days"]);
                if (em > dur)
                {
                    (dur, durS) = (em, es);
                }
            }

            if (!string.IsNullOrEmpty(r.Gate))
            {
                var (gm, gs) = Pert(gateWait[r.Gate]);
                dur += gm;
                durS = Math.Sqrt(Math.Pow(durS, 2) + Math.Pow(gs, 2));
            }

            (r.Dur, r.DurS) = (dur, durS);
        }

        var memo = new Dictionary<string, (double Days, double Sig, List<string> Path)>(StringComparer.Ordinal);
        (double Days, double Sig, List<string> Path) Finish(string sid)
        {
            if (memo.TryGetValue(sid, out var cached))
            {
                return cached;
            }

            var r = res.Rows[sid];
            string? best = null;
            foreach (var d in r.Deps)
            {
                if (best == null || Finish(d).Days > Finish(best).Days)
                {
                    best = d;
                }
            }

            var b = best == null ? (0.0, 0.0, new List<string>()) : Finish(best);
            var result = (b.Item1 + r.Dur, b.Item2 + r.DurS, b.Item3.Concat(new[] { sid }).ToList());
            memo[sid] = result;
            return result;
        }

        var end = res.Order[0];
        foreach (var sid in res.Order)
        {
            if (Finish(sid).Days > Finish(end).Days)
            {
                end = sid;
            }
        }

        (res.CpDays, res.CpSig, res.CpPath) = Finish(end);

        var ov = Py.Dict(inp.Params["overheads"]);
        var teamFte = Py.Dict(inp.Params["team_fte"]);
        res.RoleOrder = teamFte.Keys.ToList();
        foreach (var role in res.RoleOrder)
        {
            res.RoleLoad[role] = 0.0;
        }

        foreach (var r in res.RowList)
        {
            foreach (var (role, share) in SplitOf(r.Id, r.Agent))
            {
                res.RoleLoad[role] += r.HybFinal * share;
            }
        }

        var baseHyb = Py.Sum(res.RowList.Select(r => r.HybFinal));

        var sup = mode == "trad" ? 0.0 : Py.Num(ov["swarm_supervision"]);
        var coord = Py.Num(ov["coordination"]);
        res.RoleLoad["architekt_tech_lead"] += baseHyb * (sup + coord * 0.4);
        res.RoleLoad["product_owner_analityk"] += baseHyb * coord * 0.6;
        var util = Py.Num(inp.Params["utilization"]);
        foreach (var role in res.RoleOrder)
        {
            var fte = Py.Num(teamFte[role]);
            res.RoleDays[role] = fte != 0 ? res.RoleLoad[role] / (fte * util) : double.PositiveInfinity;
        }

        return res;
    }

    private static string Fmt(double x, int n = 1) => PyFloat.Fixed(x, n, thousands: true).Replace(",", " ").Replace(".", ",");

    public static string Report(Result res, Result trad, Inputs inp)
    {
        var p = inp.Params;
        var z = Py.Num(p["percentile_z"]);
        var ov = Py.Dict(p["overheads"]);
        var multH = 1 + Py.Num(ov["swarm_supervision"]) + Py.Num(ov["coordination"]);
        var multT = 1 + Py.Num(ov["coordination"]);
        var tradSum = Py.Sum(res.RowList.Select(r => r.Trad));
        var tradS = Py.Sum(res.RowList.Select(r => r.TradS));
        var hyb = Py.Sum(res.RowList.Select(r => r.HybFinal));
        var hybS = Py.Sum(res.RowList.Select(r => r.HybFinalS));
        var teamFte = Py.Dict(p["team_fte"]);
        var fte = Py.Sum(teamFte.Values.Select(Py.Num));

        var bn = res.Bottleneck();
        var tBn = trad.Bottleneck();
        var cal = Math.Max(res.CpDays, res.RoleDays[bn]);
        var cal80 = Math.Max(res.CpDays + z * res.CpSig, res.RoleDays[bn] * (1 + z * hybS / hyb));
        var tCal = Math.Max(trad.CpDays, trad.RoleDays[tBn]);
        var tCal80 = Math.Max(trad.CpDays + z * trad.CpSig, trad.RoleDays[tBn] * (1 + z * tradS / tradSum));
        var util = Py.Num(p["utilization"]);
        var calib = res.Done.Count == 0 ? "brak danych rzeczywistych, k = 1,0" : $"k = {Fmt(res.K, 2)} z {res.Done.Count} zakończonych kroków";
        var o = new List<string>
        {
            "<!-- WYGENEROWANE przez tools/plan/estimate.py — nie edytuj ręcznie -->",
            "# Raport szacowania (generowany)", string.Empty,
            $"Kalibracja: {calib}. Zespół referencyjny: {Fmt(fte)} FTE, wykorzystanie {(long)Math.Truncate(util * 100)}%. P80 liczone ostrożnie: odchylenia kroków sumowane liniowo (ryzyka skorelowane).",
            string.Empty, "## Podsumowanie", string.Empty,
            "| Wielkość | Bez AI: oczekiwane | Bez AI: P80 | Hybryda: oczekiwane | Hybryda: P80 |", "| --- | --- | --- | --- | --- |",
            $"| Praca ludzi w krokach (osobodni) | {Fmt(tradSum, 0)} | {Fmt(tradSum + z * tradS, 0)} | {Fmt(hyb, 0)} | {Fmt(hyb + z * hybS, 0)} |",
            $"| Praca ludzi z narzutami (osobodni) | {Fmt(tradSum * multT, 0)} | {Fmt((tradSum + z * tradS) * multT, 0)} | {Fmt(hyb * multH, 0)} | {Fmt((hyb + z * hybS) * multH, 0)} |",
            $"| Ścieżka krytyczna z bramkami (dni robocze) | {Fmt(trad.CpDays, 0)} | {Fmt(trad.CpDays + z * trad.CpSig, 0)} | {Fmt(res.CpDays, 0)} | {Fmt(res.CpDays + z * res.CpSig, 0)} |",
            $"| Najbardziej obciążona rola (dni robocze) | {Fmt(trad.RoleDays[tBn], 0)} ({RoleLabel[tBn]}) | — | {Fmt(res.RoleDays[bn], 0)} ({RoleLabel[bn]}) | — |",
            $"| **Czas kalendarzowy** (większa z dwóch powyższych) | **{Fmt(tCal / 5, 0)} tyg.** | **{Fmt(tCal80 / 5, 0)} tyg.** | **{Fmt(cal / 5, 0)} tyg.** | **{Fmt(cal80 / 5, 0)} tyg.** |",
            string.Empty, "Narzuty: hybryda = nadzór roju + koordynacja; bez AI = koordynacja. Czas pracy agentów nie jest wąskim gardłem — ogranicza go przegląd i decyzje ludzi.", string.Empty,
            "## Kroki", string.Empty,
            "| Krok | Tytuł | C | Klasa | T/N/I/B | AI | Bez AI (od) | Hybryda (od) | Oszczędność | Dni kal. | Ścieżka kryt. |",
            "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
        };
        foreach (var r in res.RowList.OrderBy(r => Py.Num(r.Phase)).ThenBy(r => r.Id, StringComparer.Ordinal))
        {
            var e = r.E;
            o.Add($"| {r.Id} | {Cut(r.Title, 70)} | {Fmt(r.C, 2)} | {r.Cls} | {Py.ToStr(e["T"])}/{Py.ToStr(e["N"])}/{Py.ToStr(e["I"])}/{Py.ToStr(e["B"])} | {(long)Math.Truncate(Py.Num(e["ai_share"]) * 100)}% | "
                + $"{Fmt(r.Trad)} | {Fmt(r.HybFinal)} | {PyFloat.RoundToInt((1 - r.HybFinal / r.Trad) * 100)}% | {Fmt(r.Dur)} | {(res.CpPath.Contains(r.Id) ? "tak" : string.Empty)} |");
        }

        o.AddRange(new[] { string.Empty, "## Fazy", string.Empty, "| Faza | Bez AI (od) | Hybryda (od) | Oszczędność |", "| --- | --- | --- | --- |" });
        foreach (var ph in res.RowList.Select(r => r.Phase).Distinct().OrderBy(Py.Num))
        {
            var t = Py.Sum(res.RowList.Where(r => Equals(r.Phase, ph)).Select(r => r.Trad));
            var h = Py.Sum(res.RowList.Where(r => Equals(r.Phase, ph)).Select(r => r.HybFinal));

            o.Add($"| {Py.ToStr(ph)} | {Fmt(t)} | {Fmt(h)} | {PyFloat.RoundToInt((1 - h / t) * 100)}% |");
        }

        o.AddRange(new[] { string.Empty, "## Obciążenie ról (z narzutami)", string.Empty, "| Rola | FTE | Praca (od) | Dni robocze przy wykorzystaniu |", "| --- | --- | --- | --- |" });
        foreach (var role in res.RoleOrder.OrderBy(r => -res.RoleDays[r]))
        {
            o.Add($"| {RoleLabel[role]} | {Fmt(Py.Num(teamFte[role]))} | {Fmt(res.RoleLoad[role])} | {Fmt(res.RoleDays[role], 0)} |");
        }

        o.AddRange(new[] { string.Empty, "## Ścieżka krytyczna", string.Empty, string.Join(" → ", res.CpPath), string.Empty,
            "## Ranking złożoności", string.Empty, "| Miejsce | Krok | C | Główny czynnik |", "| --- | --- | --- | --- |" });
        var i = 1;
        foreach (var r in res.RowList.OrderBy(r => -r.C))
        {
            o.Add($"| {i++} | {r.Id} {Cut(r.Title, 55)} | {Fmt(r.C, 2)} | {Py.Str(r.E["driver"])} |");
        }

        return string.Join("\n", o) + "\n";
    }

    private static string Cut(string s, int n) => s.Length <= n ? s : s.Substring(0, n);

    public static int Run(string[] args)
    {
        var cli = new Cli("użycie: ph plan estimate [--check] [--json]", args, new[] { "--check", "--json" }, Array.Empty<string>());
        var inp = Load();
        var res = Compute(inp);
        var trad = Compute(inp, "trad");
        var text = Report(res, trad, inp);
        var path = Repo.P("plan/estimation-report.md");
        if (cli.Flag("--json"))
        {
            var tradSum = Py.Sum(res.RowList.Select(r => r.Trad));
            var hyb = Py.Sum(res.RowList.Select(r => r.HybFinal));

            var roleDays = new PyDict();
            foreach (var role in res.RoleOrder)
            {
                roleDays[role] = res.RoleDays[role];
            }

            var tRoleDays = new PyDict();
            foreach (var role in trad.RoleOrder)
            {
                tRoleDays[role] = trad.RoleDays[role];
            }

            var doc = new PyDict
            {
                ["cp_days"] = res.CpDays,
                ["cp_sigma"] = res.CpSig,
                ["cp_path"] = res.CpPath.Cast<object?>().ToList(),
                ["role_days"] = roleDays,
                ["trad_cp"] = new List<object?> { trad.CpDays, trad.CpSig },
                ["trad_role_days"] = tRoleDays,
                ["trad"] = tradSum,
                ["hyb"] = hyb,
            };
            Console.WriteLine(PyJson.Dumps(doc, indent: 1));
            return 0;
        }

        if (cli.Flag("--check"))
        {
            var ok = Repo.SameContent(path, text);
            Console.Error.WriteLine(ok ? "aktualny" : "NIEAKTUALNY: uruchom python3 tools/plan/estimate.py (albo: ph plan estimate)");
            return ok ? 0 : 1;
        }

        Repo.Write(path, text);
        Console.WriteLine($"zapisano {Repo.Rel(path)}");
        return 0;
    }
}
