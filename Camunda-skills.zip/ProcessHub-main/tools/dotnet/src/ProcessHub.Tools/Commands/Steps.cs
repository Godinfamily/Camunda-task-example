using System.Diagnostics;
using System.Reflection;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Plan kroków (= tools/agents/steplib.py): platformy albo zespołu profilu, postęp, bramki.</summary>
public sealed class Plan
{
    private readonly Plan? _platform;

    public Plan(string? backlog)
    {
        PathFile = backlog != null ? Repo.P(backlog) : Repo.P("plan/backlog.yaml");
        Data = Py.Dict(MiniYaml.LoadFile(PathFile));
        Profile = Data.Get("profile") as string;
        ProgressDir = Profile != null ? Path.Combine(Path.GetDirectoryName(PathFile)!, "progress") : Repo.P("plan/progress");
        Steps = new Dictionary<string, PyDict>(StringComparer.Ordinal);
        foreach (var s in Py.List(Data["steps"]).Select(Py.Dict))
        {
            Steps[Py.Str(s["id"])] = s;
        }

        _platform = Profile != null ? new Plan(null) : null;
    }

    public string PathFile { get; }

    public PyDict Data { get; }

    public string? Profile { get; }

    public string ProgressDir { get; }

    public Dictionary<string, PyDict> Steps { get; }

    public IEnumerable<PyDict> Ordered => Py.List(Data["steps"]).Select(Py.Dict);

    public string GatesFile => Path.Combine(ProgressDir, "gates.json");

    public PyDict Progress(string stepId)
    {
        if (!Steps.ContainsKey(stepId) && _platform != null)
        {
            return _platform.Progress(stepId);
        }

        var f = Path.Combine(ProgressDir, $"{stepId}.json");
        return File.Exists(f) ? Py.Dict(PyJson.Loads(Repo.Read(f))) : new PyDict();
    }

    /// <summary>Plan, do którego należy krok: ten albo — dla zależności kroku profilu — plan platformy.</summary>
    public Plan Origin(string stepId) => !Steps.ContainsKey(stepId) && _platform != null ? _platform : this;

    public bool IsMerged(string stepId)
    {
        var p = Progress(stepId);
        return p.Get("status") as string == "done" && Py.Truthy(p.Get("merged"));
    }

    public PyDict Gates() => File.Exists(GatesFile) ? Py.Dict(PyJson.Loads(Repo.Read(GatesFile))) : new PyDict();

    public (bool Ok, List<string> Reasons) Readiness(PyDict step)
    {
        var reasons = Py.Strings(step.Get("depends_on")).Where(d => !IsMerged(d)).Select(d => $"{d} nie jest scalony").ToList();
        if (step.Get("gate_before") is string gate && gate.Length > 0 && !Gates().ContainsKey(gate))
        {
            reasons.Add($"bramka {gate} niezatwierdzona");
        }

        return (reasons.Count == 0, reasons);
    }

    public string AgentName(string agent) => Profile != null && agent != "human" ? $"{Profile}-{agent}" : agent;

    public static void WriteJson(string path, PyDict data) => Repo.Write(path, PyJson.Dumps(data, indent: 2) + "\n");

    public static string Today() => DateTime.Now.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
}

/// <summary>Prowadzenie kroków: ph step prepare | dod | status (= prepare_step.py, run_dod.py, plan_status.py).</summary>
public static class Steps
{
    public static int Prepare(string[] args)
    {
        var cli = new Cli("użycie: ph step prepare <krok> [--backlog plik] [--worktree-root katalog] [--no-worktree] [--force]", args,
            new[] { "--no-worktree", "--force" }, new[] { "--backlog", "--worktree-root" }, 1, 1);
        var plan = new Plan(cli.Opt("--backlog"));
        var stepId = cli.Pos(0);
        if (!plan.Steps.TryGetValue(stepId, out var step))
        {
            throw new ToolException($"Nie ma kroku {stepId} w {Repo.Rel(plan.PathFile)}");
        }

        var (ok, reasons) = plan.Readiness(step);
        if (!ok && !cli.Flag("--force"))
        {
            Console.WriteLine($"Krok {stepId} nie jest gotowy: " + string.Join("; ", reasons));
            Console.WriteLine("Uzupełnij postęp (scalenie poprzedników, zatwierdzenie bramki) albo uruchom z --force decyzją człowieka.");
            return 1;
        }

        var agent = Py.Str(step["agent"]);
        string target;
        if (agent == "human")
        {
            target = Repo.Root;
            Console.WriteLine($"Krok {stepId} wykonuje człowiek — powstaje tylko pakiet (bez worktree i .agent-scope).");
        }
        else
        {
            var branch = plan.Profile != null ? $"profile/{plan.Profile}/{stepId}" : $"step/{stepId}";
            target = cli.Flag("--no-worktree") ? Repo.Root : EnsureWorktree(stepId, branch, cli.Opt("--worktree-root") ?? Path.GetDirectoryName(Repo.Root)!);
            var scope = new List<string> { $"# Wygenerowane przez prepare_step.py — zakres zapisu kroku {stepId}" };
            if (plan.Profile != null)
            {
                scope.Add($"@profile {plan.Profile}");
            }

            scope.AddRange(Py.Strings(step.Get("writes")));
            Repo.Write(Path.Combine(target, ".agent-scope"), string.Join("\n", scope) + "\n");
        }

        var output = Path.Combine(target, "plan", "packets", $"{stepId}.md");
        Repo.Write(output, Packet(step, plan));
        Console.WriteLine($"worktree: {target}");
        Console.WriteLine($"pakiet:   {output}");
        if (agent != "human")
        {
            var name = plan.AgentName(agent);
            Console.WriteLine($"zakres:   {Path.Combine(target, ".agent-scope")}" + (plan.Profile != null ? $"  (profil: {plan.Profile})" : string.Empty));
            Console.WriteLine($"agent:    {name}" + (step.Get("pair") is string pair && pair.Length > 0 ? $" + {plan.AgentName(pair)}" : string.Empty));
            Console.WriteLine($"start:    opencode run --dir {target} --agent {name} \"Wykonaj pakiet plan/packets/{stepId}.md\"");
            Console.WriteLine($"          (interaktywnie: cd {target} && opencode, potem: @{name} Wykonaj pakiet plan/packets/{stepId}.md)");
        }

        return 0;
    }

    private static string EnsureWorktree(string stepId, string branch, string root)
    {
        var path = Path.GetFullPath(Path.Combine(root, $"wt-{stepId}"));
        if (Directory.Exists(path))
        {
            return path;
        }

        if (Shell.Git(Repo.Root, "rev-parse", "--is-inside-work-tree").ExitCode != 0)
        {
            throw new ToolException("Repozytorium nie jest repozytorium git — użyj --no-worktree albo wykonaj git init.");
        }

        var hasBranch = Shell.Git(Repo.Root, "rev-parse", "--verify", branch).ExitCode == 0;
        var res = hasBranch ? Shell.Git(Repo.Root, "worktree", "add", path, branch) : Shell.Git(Repo.Root, "worktree", "add", "-b", branch, path, "HEAD");
        if (res.ExitCode != 0)
        {
            throw new ToolException($"git worktree add nie powiódł się: {res.StdErr.Trim()}");
        }

        return path;
    }

    private static List<string> ContractsOf(PyDict step) => Py.Strings(step.Get("reads")).Where(r => r.TrimEnd('/').EndsWith("Contracts", StringComparison.Ordinal)).ToList();

    private static readonly Dictionary<string, string> PairDefault = new(StringComparer.Ordinal)
    {
        ["bdd-tester"] = "pisze kroki Reqnroll i drivery w projektach testów, zanim powstanie implementacja; wykonawca nie edytuje `tests/*.Specs/**`",
        ["security-reviewer"] = "obowiązkowy przegląd bezpieczeństwa po zielonych bramkach (tylko odczyt)",
        ["ui-reviewer"] = "obowiązkowy przegląd warstwy wizualnej po zielonych bramkach (tylko odczyt)",
    };

    private const string PairOther = "współwykonawca w tym samym worktree i zakresie — wykonuje część wskazaną przez wykonawcę";

    /// <summary>Sekcja pakietu z listą punktów; pusta lista = brak sekcji.</summary>
    private static List<string> Section(string title, List<string> items)
    {
        var lines = new List<string>();
        if (items.Count > 0)
        {
            lines.Add(string.Empty);
            lines.Add($"## {title}");
            lines.AddRange(items.Select(i => $"- {i}"));
        }

        return lines;
    }

    public static string Packet(PyDict step, Plan plan)
    {
        var dod = Py.Truthy(step.Get("dod")) ? Py.Strings(step["dod"]).ToList() : Py.Strings(plan.Data.Get("common_dod")).ToList();
        var contracts = ContractsOf(step);
        var reads = Py.Strings(step.Get("reads")).Where(r => !contracts.Contains(r)).ToList();
        if (!reads.Contains("AGENTS.md"))
        {
            reads.Insert(0, "AGENTS.md");
        }

        if (plan.Profile != null && !reads.Contains($"profiles/{plan.Profile}/AGENTS.md"))
        {
            reads.Insert(1, $"profiles/{plan.Profile}/AGENTS.md");
        }

        var id = Py.Str(step["id"]);
        var title = Py.Str(step["title"]);
        var human = Py.Str(step["agent"]) == "human";
        var agent = plan.AgentName(Py.Str(step["agent"]));
        var pairRole = step.Get("pair") is string p && p.Length > 0 ? p : null;
        var pair = pairRole != null ? plan.AgentName(pairRole) : null;
        var inputs = new List<string>();
        foreach (var dep in Py.Strings(step.Get("depends_on")))
        {
            var owner = plan.Origin(dep);
            var depTitle = owner.Steps.TryGetValue(dep, out var depStep) ? Py.Str(depStep["title"]) : "krok spoza planu";
            inputs.Add($"`{dep}` {depTitle} — przekazanie: `{Repo.Rel(owner.ProgressDir)}/{dep}.json`");
        }

        var lines = new List<string>
        {
            $"# Pakiet roboczy — {id}: {title}", string.Empty,
            "> Wygenerowany przez tools/agents/prepare_step.py. Czytaj tylko ten plik i pliki z sekcji „Czytaj”.", string.Empty,
            "## Cel", title + ".", string.Empty,
            (plan.Profile != null ? $"Profil projektu: `{plan.Profile}` — zapis wyłącznie w `profiles/{plan.Profile}/**`.\n" : string.Empty)
                + $"Wykonawca: `{agent}`" + (pair != null ? $" · para: `{pair}`" : string.Empty)
                + $" · rozmiar: {Py.ToStr(step.Get("size", "—"))} · ścieżka krytyczna: {(Py.Truthy(step.Get("critical")) ? "tak" : "nie")}",
        };
        lines.AddRange(Section("Wynik (co ma powstać)", Py.Strings(step.Get("outcome")).ToList()));
        lines.AddRange(Section("Wskazówki startowe", Py.Strings(step.Get("notes")).ToList()));
        lines.Add(string.Empty);
        lines.Add("## Czytaj (w tej kolejności)");
        lines.AddRange(reads.Select((r, i) => $"{i + 1}. `{r}`"));
        lines.AddRange(Section("Sięgaj punktowo (wyszukuj fragment, nie czytaj w całości)", Py.Strings(step.Get("refs")).ToList()));
        lines.AddRange(Section("Wejście od poprzedników (czytaj pytania otwarte i listę zmienionych plików)", inputs));
        lines.Add(string.Empty);
        lines.Add("## Wolno zapisywać (`.agent-scope`)");
        lines.AddRange(Py.Strings(step.Get("writes")).Select(w => $"- `{w}`"));
        lines.Add($"- `docs/rfc/RFC-{id}-<temat>.md` — wniosek o zmianę poza zakresem (dozwolony zawsze)");
        if (pair != null && pairRole != null)
        {
            var pairTask = step.Get("pair_task") is string pt && pt.Length > 0 ? pt : (PairDefault.TryGetValue(pairRole, out var known) ? known : PairOther);
            lines.AddRange(Section("Para", new List<string> { $"`{pair}`: " + pairTask }));
        }

        lines.Add(string.Empty);
        lines.Add("## Scenariusze do zaliczenia");
        var specs = Py.Strings(step.Get("specs")).Select(s => $"- `{s}`").ToList();
        lines.AddRange(specs.Count > 0 ? specs : new List<string> { "- brak (krok techniczny)" });
        lines.Add(string.Empty);
        lines.Add("## Kontrakty zależności (tylko do odczytu)");
        lines.AddRange(contracts.Count > 0 ? contracts.Select(c => $"- `{c}`") : new[] { "- brak" });
        lines.Add(string.Empty);
        lines.Add("## Definition of Done");
        lines.AddRange(dod.Select(c => $"- [ ] `{c}` kończy się kodem 0"));
        lines.AddRange(new[]
        {
            "- [ ] brak nowych ostrzeżeń analizatorów",
            "- [ ] każda nowa komenda lub operacja ma deskryptor audytu; każdy endpoint — politykę autoryzacji",
            "- [ ] `AGENTS.md` modułu lub profilu zaktualizowany (cel, inwarianty, komendy)",
        });
        lines.AddRange(Section("Kryteria akceptacji człowieka (poza bramkami)", Py.Strings(step.Get("acceptance")).ToList()));
        lines.AddRange(new[]
        {
            string.Empty,
            "## Budżet", "Próby: 2 · potem jedna sesja od zera z diagnozą recenzenta (albo wyższy wariant rozumowania, jeśli rola go ma) "
                + "· potem człowiek · zakaz zmian poza `.agent-scope` (zmiana kontraktu, scenariusza platformy lub SDK → RFC w docs/rfc/)", string.Empty,
            "## Przekazanie",
        });
        if (!human)
        {
            lines.Add($"Przed przekazaniem zatwierdź zmiany na gałęzi kroku: `git add -A`, potem `git commit -m \"{id}: <opis>\"` (bez `push`).");
        }

        lines.Add($"Ostatnia wiadomość: JSON wg `AGENTS.md` → `{Repo.Rel(plan.ProgressDir)}/{id}.json`");
        lines.Add(string.Empty);
        return string.Join("\n", lines);
    }

    /// <summary>ph step dod — bramki Definition of Done; polecenia „python3 tools/…” zamienia na ph, gdy Python jest niedostępny.</summary>
    public static int Dod(string[] args)
    {
        var cli = new Cli("użycie: ph step dod <krok> [--backlog plik] [--dir worktree] [--timeout s] [--tools auto|python|dotnet]", args,
            Array.Empty<string>(), new[] { "--backlog", "--dir", "--timeout", "--tools" }, 1, 1);
        var plan = new Plan(cli.Opt("--backlog"));
        var stepId = cli.Pos(0);
        if (!plan.Steps.TryGetValue(stepId, out var step))
        {
            throw new ToolException($"Nie ma kroku {stepId}");
        }

        var commands = Py.Truthy(step.Get("dod")) ? Py.Strings(step["dod"]).ToList() : Py.Strings(plan.Data.Get("common_dod")).ToList();
        var workdir = Path.GetFullPath(cli.Opt("--dir", ".")!);
        var timeout = int.Parse(cli.Opt("--timeout", "1800")!, System.Globalization.CultureInfo.InvariantCulture);
        var mode = cli.Opt("--tools", "auto")!;
        var useDotnet = mode == "dotnet" || (mode == "auto" && !Shell.Available("python3"));
        var logs = Path.Combine(plan.ProgressDir, "logs");
        Directory.CreateDirectory(logs);

        var results = new List<object?>();
        var passedAll = true;
        for (var i = 0; i < commands.Count; i++)
        {
            var cmd = commands[i];
            var actual = useDotnet ? Translate(cmd) : cmd;
            var sw = Stopwatch.StartNew();
            var res = Shell.Sh(actual, workdir, timeout);
            var code = res.TimedOut ? 124 : res.ExitCode;
            var output = res.TimedOut ? $"przekroczono limit czasu {timeout} s" : res.StdOut + res.StdErr;
            var seconds = PyFloat.Round(sw.Elapsed.TotalSeconds, 1);
            var log = Path.Combine(logs, $"{stepId}-{i + 1}.log");
            Repo.Write(log, output);
            var tail = code == 0 ? string.Empty : string.Join("\n", output.Trim().Split('\n').TakeLast(40));
            results.Add(new PyDict
            {
                ["command"] = cmd,
                ["exit_code"] = (long)code,
                ["passed"] = code == 0,
                ["seconds"] = seconds,
                ["log"] = Repo.Rel(log),
                ["tail"] = tail,
            });
            Console.WriteLine($"[{(code == 0 ? "OK " : "BŁĄD")}] {cmd}  ({PyFloat.Repr(seconds)} s)" + (actual != cmd ? $"  → {actual}" : string.Empty));
            if (code != 0)
            {
                passedAll = false;
                break;
            }
        }

        var passed = passedAll && results.Count == commands.Count;
        var outPath = Path.Combine(plan.ProgressDir, $"{stepId}.gates.json");
        Plan.WriteJson(outPath, new PyDict
        {
            ["step"] = stepId,
            ["date"] = Plan.Today(),
            ["workdir"] = workdir,
            ["passed"] = passed,
            ["results"] = results,
        });
        Console.WriteLine($"wynik: {(passed ? "zielone" : "czerwone")} → {Repo.Rel(outPath)}");
        return passed ? 0 : 1;
    }

    /// <summary>„python3 tools/x/y.py argumenty” → wywołanie ph z tym samym znaczeniem (gdy Pythona brak).</summary>
    public static string Translate(string command)
    {
        foreach (var e in Dispatcher.Entries.Where(e => e.PythonScript.Length > 0))
        {
            foreach (var python in new[] { "python3 ", "python " })
            {
                var prefix = python + e.PythonScript;
                if (command == prefix || command.StartsWith(prefix + " ", StringComparison.Ordinal))
                {
                    return SelfCommand() + " " + string.Join(" ", e.Words) + command.Substring(prefix.Length);
                }
            }
        }

        return command;
    }

    private static string SelfCommand()
    {
        var process = Environment.ProcessPath ?? "ph";
        var name = Path.GetFileNameWithoutExtension(process);
        if (name == "dotnet")
        {
            return $"\"{process}\" \"{Assembly.GetExecutingAssembly().Location}\"";
        }

        return $"\"{process}\"";
    }

    public static int Status(string[] args)
    {
        var cli = new Cli("użycie: ph step status [--backlog plik] [--merged krok] [--approve-gate G --by kto [--evidence opis] [--force]]", args,
            new[] { "--force" }, new[] { "--backlog", "--merged", "--approve-gate", "--by", "--evidence" });
        var plan = new Plan(cli.Opt("--backlog"));
        if (cli.Opt("--merged") is string merged)
        {
            if (!plan.Steps.ContainsKey(merged))
            {
                throw new ToolException($"Nie ma kroku {merged} w {Path.GetFileName(plan.PathFile)}");
            }

            var p = plan.Progress(merged);
            if (p.Count == 0)
            {
                p["step"] = merged;
            }

            p["status"] = "done";
            p["merged"] = true;
            p["merged_on"] = Plan.Today();
            Plan.WriteJson(Path.Combine(plan.ProgressDir, $"{merged}.json"), p);
            Console.WriteLine($"{merged}: oznaczono jako scalony");
            return 0;
        }

        if (cli.Opt("--approve-gate") is string gate)
        {
            var by = cli.Opt("--by") ?? throw new ToolException("Podaj --by (kto zatwierdza bramkę).");
            var gateCfg = (plan.Data.Get("gates") as PyDict)?.Get(gate) as PyDict
                ?? throw new ToolException($"Nie ma bramki {gate} w {Path.GetFileName(plan.PathFile)}");
            var missing = Py.Strings(gateCfg.Get("after")).Where(s => !plan.IsMerged(s)).ToList();
            if (missing.Count > 0 && !cli.Flag("--force"))
            {
                Console.WriteLine($"{gate}: nie można zatwierdzić — niescalone kroki: {string.Join(", ", missing)}");
                return 1;
            }

            var g = plan.Gates();
            g[gate] = new PyDict { ["approved_by"] = by, ["date"] = Plan.Today(), ["evidence"] = cli.Opt("--evidence", string.Empty) };
            Plan.WriteJson(plan.GatesFile, g);
            Console.WriteLine($"{gate}: zatwierdzona przez {by}");
            return 0;
        }

        var mergedSteps = new List<PyDict>();
        var inProgress = new List<(PyDict Step, string Status)>();
        var ready = new List<PyDict>();
        var blocked = new List<(PyDict Step, List<string> Reasons)>();
        foreach (var s in plan.Ordered)
        {
            var id = Py.Str(s["id"]);
            var p = plan.Progress(id);
            if (plan.IsMerged(id))
            {
                mergedSteps.Add(s);
            }
            else if (p.Count > 0)
            {
                inProgress.Add((s, p.Get("status", "w toku") as string ?? "w toku"));
            }
            else
            {
                var (ok, reasons) = plan.Readiness(s);
                if (ok)
                {
                    ready.Add(s);
                }
                else
                {
                    blocked.Add((s, reasons));
                }
            }
        }

        int SizeRank(PyDict s) => (s.Get("size") as string) switch { "L" => 0, "M" => 1, "S" => 2, _ => 3 };
        ready = ready.OrderBy(s => Py.Truthy(s.Get("critical")) ? 0 : 1).ThenBy(SizeRank).ToList();
        var title = plan.Profile != null ? $"Plan profilu „{plan.Profile}”" : "Plan platformy";
        Console.WriteLine($"{title} — scalone: {mergedSteps.Count}/{plan.Steps.Count} · w toku: {inProgress.Count} · gotowe: {ready.Count} · zablokowane: {blocked.Count}");
        Console.WriteLine($"Bramki zatwierdzone: {(plan.Gates().Count > 0 ? string.Join(", ", plan.Gates().Keys) : "brak")}");
        if (inProgress.Count > 0)
        {
            Console.WriteLine("\nW toku:");
            foreach (var (s, st) in inProgress)
            {
                Console.WriteLine($"  {Py.Str(s["id"]),-7} {st,-10} {Py.Str(s["title"])}");
            }
        }

        Console.WriteLine("\nGotowe do startu (krytyczne najpierw):");
        foreach (var s in ready)
        {
            Console.WriteLine($"  {Py.Str(s["id"]),-7} {(Py.Truthy(s.Get("critical")) ? "K" : " ")} {Py.ToStr(s.Get("size", "-"))} {plan.AgentName(Py.Str(s["agent"])),-28} {Py.Str(s["title"])}");
        }

        Console.WriteLine($"\nRównolegle wolno prowadzić: {Py.ToStr(plan.Data.Get("parallelism", 1L))} kroki");
        var external = blocked.SelectMany(b => b.Reasons).Where(r => r.EndsWith("nie jest scalony", StringComparison.Ordinal))
            .Select(r => r.Split(' ')[0]).Where(id => !plan.Steps.ContainsKey(id)).Distinct().OrderBy(x => x, StringComparer.Ordinal).ToList();
        if (external.Count > 0)
        {
            Console.WriteLine("Czekają na kroki platformy: " + string.Join(", ", external));
        }

        var waitingGates = blocked.SelectMany(b => b.Reasons).Where(r => r.StartsWith("bramka", StringComparison.Ordinal))
            .Select(r => r.Split(' ')[1]).Distinct().OrderBy(x => x, StringComparer.Ordinal).ToList();
        if (waitingGates.Count > 0)
        {
            Console.WriteLine("Czekają na bramki: " + string.Join(", ", waitingGates));
        }

        return 0;
    }
}
