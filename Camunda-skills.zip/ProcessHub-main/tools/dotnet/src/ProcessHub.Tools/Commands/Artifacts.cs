using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Artefakty projektowe: plan systemu, aktorzy, założenia i strona HTML (= tools/artifacts/render_artifacts.py).</summary>
public static class Artifacts
{
    private const string Generated = "<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->";

    private static readonly string[][] Split =
    {
        new[] { "Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4)", "Role projektowe z ról platformy i uprawnień projektu" },
        new[] { "Start procesu, moje procesy, przekazywanie, zastępstwa", "Operacje dedykowane na zadaniach i sprawach" },
        new[] { "Eskalacje, dashboard menadżera, mapa etapów, formatki", "Dane projektu w schemacie prj_<id>" },
        new[] { "Audyt każdej akcji, autoryzacje jako kod", "Sloty UI: panel zadania i sprawy, widżet, pole formatki, trasy /p/<id>/" },
        new[] { "Integracja z Camunda (wyłącznie platforma)", "Workery typów zadań <id>.* i integracje z systemami projektu" },
        new[] { "SDK rozszerzeń i jego zgodność wsteczna", "Model integracji in-process albo remote, własny plan i rytm wydań" },
    };

    private static readonly string[][] Layers =
    {
        new[] { "Repozytorium", "profiles/<id>/** z CODEOWNERS; kontrakt profilu zatwierdza też architekt platformy" },
        new[] { "Kompilacja", "profil zależy tylko od SDK; testy architektury i granice Nx" },
        new[] { "Uprawnienia", "przestrzeń nazw profilu; walidator i reconciler odrzucają naruszenia (R10)" },
        new[] { "Wykonanie", "operacje i dane profilu tylko w procesach profilu (R9)" },
        new[] { "Dane", "schemat i użytkownik bazy per profil; dane platformy przez widoki platform_api" },
        new[] { "Wdrożenie", "in-process w pociągu wydań; remote — niezależnie" },
        new[] { "CI", "filtry ścieżek per profil; strażnik zakresu zmian dla PR zespołu" },
        new[] { "Agenci AI", "agenci profilu zapisują tylko w swoim profilu; agenci platformy — nigdy w profilach" },
    };

    private static object? LoadData(string name) => PyJson.Loads(Repo.ReadRel($"plan/dashboard/data/{name}.json"));

    private static string N1(object? v) => PyFloat.Fixed(PyFloat.Round(Py.Num(v), 1), 1).Replace(".", ",");

    private static string RoundStr(object? v) => v is long l ? l.ToString(System.Globalization.CultureInfo.InvariantCulture) : PyFloat.RoundToInt(Py.Num(v)).ToString(System.Globalization.CultureInfo.InvariantCulture);

    private static List<object?> Profiles()
    {
        var output = new List<object?>();
        foreach (var d in Directory.GetDirectories(Repo.P("profiles")).OrderBy(x => x, StringComparer.Ordinal))
        {
            if (Path.GetFileName(d).StartsWith("_", StringComparison.Ordinal) || !File.Exists(Path.Combine(d, "profile.yaml")))
            {
                continue;
            }

            var p = Py.Dict(MiniYaml.LoadFile(Path.Combine(d, "profile.yaml")));
            var ops = (p.Get("operations") as List<object?> ?? new List<object?>()).Select(Py.Dict)
                .Where(o => Py.Str(o["kind"]) is "task-action" or "case-action" or "profile-action")
                .Select(o => Py.Truthy(o.Get("title")) ? Py.Str(o["title"]) : Py.Str(o["id"]).Split(new[] { '.' }, 2)[1]).Cast<object?>().ToList();
            output.Add(new PyDict
            {
                ["id"] = p["id"],
                ["name"] = Py.Str(p["name"]).Split(new[] { " (" }, StringSplitOptions.None)[0],
                ["integration"] = p.Get("integration", "in-process"),
                ["classification"] = Py.Dict(p["data"])["classification"],
                ["processes"] = Py.List(p["processes"]).Select(x => Py.Dict(x)["bpmnProcessId"]).ToList(),
                ["operations"] = ops.Count > 0 ? ops : new List<object?> { "—" },
                ["team"] = Py.Dict(p["owner"])["team"],
                ["roles"] = Py.List(p["roles"]).Select(r => Py.Dict(r)["name"]).ToList(),
            });
        }

        return output;
    }

    private static string PlanMd(PyDict s, List<object?> phases, List<object?> gates)
    {
        var tmpl = Repo.ReadRel("docs/artifacts/templates/01-plan-systemu.md.tmpl");
        var line = $"Według modelu wyceny pierwszy projekt kończy pilotaż po {N1(s["cal_hyb_weeks"])} tyg. z rojem agentów AI "
            + $"(ostrożnie {N1(s["cal_hyb_p80_weeks"])} tyg.), wobec {N1(s["cal_trad_weeks"])} tyg. bez AI, przy {RoundStr(s["effort_hyb_pd"])} "
            + $"osobodniach pracy ludzi zamiast {RoundStr(s["effort_trad_pd"])}.";
        var rows = new List<string> { "| Faza | Tygodnie (najwcześniej) | Kroki | Praca ludzi bez AI | Z AI | Oszczędność |", "| --- | --- | --- | --- | --- | --- |" };
        rows.AddRange(phases.Select(Py.Dict).Select(p =>
            $"| {Py.ToStr(p["phase"])} — {p["name"]} | {N1(p["start_week"])}–{N1(p["end_week"])} | {Py.ToStr(p["steps"])} | {N1(p["trad_pd"])} | {N1(p["hyb_pd"])} | {PyFloat.RoundToInt(Py.Num(p["saving"]) * 100)}% |"));
        var grows = new List<string> { "| Bramka | Tydzień | Warunek | Kto decyduje |", "| --- | --- | --- | --- |" };
        grows.AddRange(gates.Select(Py.Dict).Select(g => $"| {g["gate"]} | {N1(g["week"])} | {g["condition"]} | {g["approver"]} |"));
        return Generated + "\n" + tmpl.Replace("{{SUMMARY_LINE}}", line).Replace("{{PHASES_TABLE}}", string.Join("\n", rows)).Replace("{{GATES_TABLE}}", string.Join("\n", grows));
    }

    private static string Or(object? v) => Py.Truthy(v) ? Py.ToStr(v) : "—";

    private static string ActorsMd(PyDict actors)
    {
        var o = new List<string>
        {
            Generated, "# Aktorzy Process Hub", string.Empty,
            "Kto korzysta z systemu, kto go wytwarza i z jakimi systemami współpracuje. Osoby w kolumnie „Kto” to świat testowy ze scenariuszy BDD (`specs/README.md`). Źródło: `actors.yaml`.", string.Empty,
            "```mermaid", "flowchart LR",
            "  subgraph B[\"Użytkownicy biznesowi\"]", "    UB[\"Uczestnik · Inicjator · Menadżer procesu<br/>Administrator procesu · Audytor · Administrator platformy\"]",
            "    UP[\"Role projektowe z profili<br/>np. Analityk kredytowy, Underwriter, Analityk AML\"]", "  end",
            "  subgraph W[\"Wytwarzanie\"]", "    TP[\"Zespół platformy\"]", "    TPR[\"Zespoły profili projektów\"]", "    AI[\"Rój agentów AI<br/>OpenCode + GLM 5.3 Flash\"]", "  end",
            "  PH[\"Process Hub<br/>platforma + profile\"]", "  CAM[(\"Camunda 8.9\")]", "  IDP[(\"RHBK + AD\")]", "  DB[(\"MS SQL Server\")]", "  SYS[\"Systemy i usługi projektów\"]",
            "  UB --> PH", "  UP --> PH", "  TP -->|platforma, SDK| PH", "  TPR -->|profiles/&lt;id&gt;| PH", "  AI -.->|pakiety robocze, człowiek scala| PH",
            "  PH --> CAM", "  PH --> IDP", "  PH --> DB", "  PH --> SYS", "```", string.Empty,
        };
        foreach (var g in Py.List(actors["groups"]).Select(Py.Dict))
        {
            o.AddRange(new[] { $"## {g["name"]}", string.Empty, Py.Str(g["note"]), string.Empty, "| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |", "| --- | --- | --- | --- | --- | --- | --- |" });
            foreach (var a in Py.List(actors["actors"]).Select(Py.Dict).Where(a => Py.Str(a["group"]) == Py.Str(g["id"])))
            {
                o.Add($"| {a["id"]} | {a["name"]} | {Or(a.Get("persona"))} | {a["goal"]} | {a["does"]} | {Or(a.Get("rules"))} | {Or(a.Get("reqs"))} |");
            }

            o.Add(string.Empty);
        }

        return string.Join("\n", o);
    }

    private static string AssumptionsMd(PyDict data)
    {
        var items = Py.List(data["assumptions"]).Select(Py.Dict).ToList();
        int Count(string status) => items.Count(a => Py.Str(a["status"]) == status);
        var o = new List<string>
        {
            Generated, "# Założenia Process Hub", string.Empty,
            $"Rejestr {items.Count} założeń: {Count("przyjęte")} przyjętych, {Count("do weryfikacji")} do weryfikacji w PoC lub w trakcie prac, "
                + $"{Count("decyzja otwarta")} czekających na decyzję. Każde ma źródło, punkt sprawdzenia i skutek, jeśli okaże się nieprawdą. Źródło: `assumptions.yaml`.",
            string.Empty,
        };
        foreach (var cat in Py.Strings(data["categories"]))
        {
            var rows = items.Where(a => Py.Str(a["category"]) == cat).ToList();
            if (rows.Count == 0)
            {
                continue;
            }

            o.AddRange(new[] { $"## {cat}", string.Empty, "| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |", "| --- | --- | --- | --- | --- | --- |" });
            o.AddRange(rows.Select(a => $"| {a["id"]} | {a["statement"]} | {a["source"]} | {a["status"]} | {a["verify"]} | {a["impact"]} |"));
            o.Add(string.Empty);
        }

        return string.Join("\n", o);
    }

    private static string IndexHtml(PyDict summary, object? phases, object? gates, object? decisions, PyDict actors, PyDict assumptions, List<object?> profs, string stamp)
    {
        var data = new PyDict
        {
            ["summary"] = summary, ["phases"] = phases, ["gates"] = gates, ["decisions"] = decisions, ["actors"] = actors,
            ["assumptions"] = assumptions, ["profiles"] = profs,
            ["split"] = Split.Select(x => (object?)x.Cast<object?>().ToList()).ToList(),
            ["layers"] = Layers.Select(x => (object?)x.Cast<object?>().ToList()).ToList(),
            ["generated"] = stamp,
        };
        var blob = PyJson.Dumps(data).Replace("</", "<\\/");
        return Repo.ReadRel("docs/artifacts/templates/index.html.tmpl").Replace("/*__DATA__*/", blob);
    }

    private static string Readme() => string.Join("\n", new[]
    {
        "# Artefakty projektowe", string.Empty,
        "Plan systemu, aktorzy, przyjęte założenia i wytyczne UI — dla decydentów, zespołów platformy i profili oraz dla agentów AI. Pliki 01–03 i strona `index.html` są generowane; źródła edytujesz ręcznie.", string.Empty,
        "| Plik | Zawartość | Źródło |", "| --- | --- | --- |",
        "| `index.html` | strona do przeglądania (działa z dysku, jasny i ciemny motyw, telefon) | wszystkie poniższe |",
        "| `01-plan-systemu.md` | system w kontekście, część wspólna i specyficzna, przepływy, plan realizacji, wytwarzanie | `templates/01-plan-systemu.md.tmpl` + dane planu |",
        "| `02-aktorzy.md` | użytkownicy, role projektowe, zespoły, systemy | `actors.yaml` |",
        "| `03-zalozenia.md` | rejestr założeń ze statusem, źródłem, sprawdzeniem i skutkiem | `assumptions.yaml` |",
        "| `04-wytyczne-ui.md`, `wytyczne-ui.html` | wytyczne i założenia interfejsu dla osób zaczynających pracę nad UI (pisane ręcznie; strona działa z dysku) | `design/README.md`, `design/tokens.json`, `design/forms/` |", string.Empty,
        "Odświeżenie (po zmianie planu, profili lub rejestrów):", string.Empty, "```bash",
        "python3 tools/plan/estimate.py && python3 tools/plan/export_dashboard_data.py",
        "python3 tools/artifacts/render_artifacts.py",
        "# bez Pythona: ph plan estimate && ph plan export && ph artifacts render", "```", string.Empty,
    });

    public static int Run(string[] args)
    {
        var cli = new Cli("użycie: ph artifacts render [--check]", args, new[] { "--check" }, Array.Empty<string>());
        var summary = Py.Dict(Py.List(LoadData("summary"))[0]);
        var phases = Py.List(LoadData("phases"));
        var gates = Py.List(LoadData("gates"));
        var decisions = LoadData("decisions");
        var stamp = Py.Str(Py.Dict(LoadData("_generated"))["at"]);
        stamp = stamp.Length > 10 ? stamp.Substring(0, 10) : stamp;
        var actors = Py.Dict(Repo.Yaml("docs/artifacts/actors.yaml"));
        var assumptions = Py.Dict(Repo.Yaml("docs/artifacts/assumptions.yaml"));
        var outputs = new List<(string Path, string Content)>
        {
            (Repo.P("docs/artifacts/01-plan-systemu.md"), PlanMd(summary, phases, gates)),
            (Repo.P("docs/artifacts/02-aktorzy.md"), ActorsMd(actors)),
            (Repo.P("docs/artifacts/03-zalozenia.md"), AssumptionsMd(assumptions)),
            (Repo.P("docs/artifacts/index.html"), IndexHtml(summary, phases, gates, decisions, actors, assumptions, Profiles(), stamp)),
            (Repo.P("docs/artifacts/README.md"), Readme()),
        };
        var stale = outputs.Where(o => !Repo.SameContent(o.Path, o.Content)).ToList();
        if (cli.Flag("--check"))
        {
            foreach (var s in stale)
            {
                Console.Error.WriteLine($"NIEAKTUALNE: {Repo.Rel(s.Path)}");
            }

            return stale.Count > 0 ? 1 : 0;
        }

        foreach (var (path, content) in stale)
        {
            Repo.Write(path, content);
        }

        Console.WriteLine($"zapisano {stale.Count} plików artefaktów, bez zmian {outputs.Count - stale.Count}");
        return 0;
    }
}
