using System.Text;
using System.Text.RegularExpressions;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Walidacja profili projektów i CODEOWNERS (= tools/profiles/validate_profiles.py) oraz zakładanie profilu (= new_profile.py).</summary>
public static class Profiles
{
    private static readonly Dictionary<string, int> ClassRank = new() { ["internal"] = 0, ["confidential"] = 1, ["restricted"] = 2 };
    private static readonly HashSet<string> WriteKinds = new() { "task-action", "case-action", "profile-action" };
    private const string Generated = "# WYGENEROWANE przez tools/profiles/validate_profiles.py --write-codeowners — źródła: config/ownership.yaml, profiles/*/profile.yaml";

    public sealed record Loaded(string Name, PyDict? Profile, PyDict? Authz, List<string> Errors);

    public static int Validate(string[] args)
    {
        var cli = new Cli("użycie: ph profiles validate [--check] [--write-codeowners] [--self-test]", args, new[] { "--check", "--write-codeowners", "--self-test" }, Array.Empty<string>());
        if (cli.Flag("--self-test"))
        {
            return SelfTest();
        }

        var profiles = Load();
        var errors = Check(profiles);
        foreach (var p in profiles.Where(p => p.Profile != null))
        {
            var prof = p.Profile!;
            var data = Py.Dict(prof["data"]);
            Console.WriteLine($"{p.Name,-10} procesy: {string.Join(", ", Py.List(prof["processes"]).Select(x => Py.Str(Py.Dict(x)["bpmnProcessId"])))} · role: {Py.List(prof["roles"]).Count} · "
                + $"operacje: {(prof.Get("operations") is List<object?> ops ? ops.Count : 0)} · dane: {Py.Str(data["schema"])} ({Py.Str(data["classification"])}) · "
                + $"integracja: {prof.Get("integration", "in-process")} · zespół: {Py.Str(Py.Dict(prof["owner"])["team"])}");
        }

        foreach (var e in errors)
        {
            Console.Error.WriteLine($"BŁĄD: {e}");
        }

        var content = CodeOwners(profiles);
        var path = Repo.P("CODEOWNERS");
        if (cli.Flag("--write-codeowners") && errors.Count == 0)
        {
            Repo.Write(path, content);
            Console.WriteLine("zapisano CODEOWNERS");
        }

        var stale = !Repo.SameContent(path, content);
        if (cli.Flag("--check") && stale)
        {
            Console.Error.WriteLine("NIEAKTUALNE: CODEOWNERS — uruchom --write-codeowners");
        }

        return errors.Count > 0 || (cli.Flag("--check") && stale) ? 1 : 0;
    }

    public static List<Loaded> Load()
    {
        var root = Repo.P("profiles");
        var result = new List<Loaded>();
        foreach (var d in Directory.GetDirectories(root).OrderBy(x => x, StringComparer.Ordinal))
        {
            var name = Path.GetFileName(d);
            if (name.StartsWith("_", StringComparison.Ordinal))
            {
                continue;
            }

            var manifest = Path.Combine(d, "profile.yaml");
            if (!File.Exists(manifest))
            {
                result.Add(new Loaded(name, null, null, new List<string> { $"{name}: brak profile.yaml" }));
                continue;
            }

            var authzPath = Path.Combine(d, "authorization.yaml");
            result.Add(new Loaded(name, MiniYaml.LoadFile(manifest) as PyDict, File.Exists(authzPath) ? MiniYaml.LoadFile(authzPath) as PyDict : null, new List<string>()));
        }

        return result;
    }

    private static HashSet<string> PlatformPermissions()
    {
        var roles = Py.List(Py.Dict(Repo.Yaml("config/authorization/roles.example.yaml"))["roles"]);
        return new HashSet<string>(roles.SelectMany(r => Py.Strings(Py.Dict(r).Get("permissions"))), StringComparer.Ordinal);
    }

    private static PyDict D(object? v) => v as PyDict ?? new PyDict();

    private static List<object?> L(object? v) => v as List<object?> ?? new List<object?>();

    public static List<string> Check(List<Loaded> profiles)
    {
        var schema = Py.Dict(PyJson.Loads(Repo.ReadRel("profiles/profile.schema.json")));
        var platformPerms = PlatformPermissions();
        var errors = new List<string>();
        var processOwner = new Dictionary<string, string>(StringComparer.Ordinal);
        var candidateOwner = new Dictionary<string, string>(StringComparer.Ordinal);
        var groupOwner = new Dictionary<string, string>(StringComparer.Ordinal);

        foreach (var (name, prof, authz, errs) in profiles)
        {
            errors.AddRange(errs);
            if (prof == null)
            {
                continue;
            }

            foreach (var e in JsonSchemaLite.Validate(schema, prof))
            {
                var path = string.Join("/", e.Path.Select(Py.ToStr));
                errors.Add($"{name}: schemat — {(path.Length > 0 ? path : "(korzeń)")}: {e.Message}");
            }

            var pid = prof.Get("id") as string;
            if (pid != name)
            {
                errors.Add($"{name}: id „{Py.ToStr(prof.Get("id"))}” musi być równe nazwie katalogu");
            }

            var ns = $"{pid}.";
            if (D(prof.Get("data")).Get("schema") as string != $"prj_{pid}")
            {
                errors.Add($"{name}: schemat danych musi nazywać się prj_{pid}");
            }

            var ownProcesses = new HashSet<string>(L(prof.Get("processes")).Select(p => Py.Str(D(p)["bpmnProcessId"])), StringComparer.Ordinal);
            foreach (var proc in ownProcesses)
            {
                if (processOwner.TryGetValue(proc, out var owner))
                {
                    errors.Add($"{name}: proces {proc} należy już do profilu {owner} (proces ma jednego właściciela)");
                }

                processOwner[proc] = name;
            }

            var perms = new Dictionary<string, PyDict>(StringComparer.Ordinal);
            foreach (var p in L(prof.Get("permissions")))
            {
                perms[Py.Str(D(p)["id"])] = D(p);
            }

            foreach (var permId in perms.Keys)
            {
                if (!permId.StartsWith(ns, StringComparison.Ordinal))
                {
                    errors.Add($"{name}: uprawnienie {permId} spoza przestrzeni nazw {ns} (R10)");
                }
            }

            var roles = new Dictionary<string, PyDict>(StringComparer.Ordinal);
            foreach (var r in L(prof.Get("roles")))
            {
                roles[Py.Str(D(r)["id"])] = D(r);
            }

            foreach (var r in roles.Values)
            {
                foreach (var p in Py.Strings(r.Get("permissions")))
                {
                    if (!perms.ContainsKey(p))
                    {
                        errors.Add($"{name}: rola {r["id"]} używa nieznanego uprawnienia {p}");
                    }
                }

                foreach (var proc in Py.Strings(r.Get("processes")))
                {
                    if (!ownProcesses.Contains(proc))
                    {
                        errors.Add($"{name}: rola {r["id"]} obejmuje proces {proc} spoza profilu (R9)");
                    }
                }
            }

            foreach (var opObj in L(prof.Get("operations")))
            {
                var op = D(opObj);
                var opId = Py.Str(op["id"]);
                var perm = Py.Str(op["permission"]);
                var kind = Py.Str(op["kind"]);
                if (!opId.StartsWith(ns, StringComparison.Ordinal))
                {
                    errors.Add($"{name}: operacja {opId} spoza przestrzeni nazw {ns} (R10)");
                }

                if (!perms.ContainsKey(perm) && !platformPerms.Contains(perm))
                {
                    errors.Add($"{name}: operacja {opId} — nieznane uprawnienie {perm}");
                }

                if (D(op.Get("appliesTo")).Get("process") is string proc && proc.Length > 0 && !ownProcesses.Contains(proc))
                {
                    errors.Add($"{name}: operacja {opId} na procesie {proc} spoza profilu (R9)");
                }

                if (WriteKinds.Contains(kind) && !op.ContainsKey("requiresAssignee"))
                {
                    errors.Add($"{name}: operacja zapisu {opId} musi jawnie deklarować requiresAssignee");
                }

                if (kind == "task-action" && op.Get("requiresAssignee") is false)
                {
                    errors.Add($"{name}: task-action {opId} bez wymogu assignee łamie R1");
                }

                if (kind == "profile-action")
                {
                    // zapis danych profilu bez zadania i sprawy (ADR-017)
                    if (Py.Truthy(op.Get("requiresAssignee")))
                    {
                        errors.Add($"{name}: profile-action {opId} nie dotyczy zadania — requiresAssignee musi być false");
                    }

                    if (Py.Truthy(op.Get("appliesTo")))
                    {
                        errors.Add($"{name}: profile-action {opId} działa na danych profilu — bez appliesTo (R9)");
                    }

                    if (!(perms.TryGetValue(perm, out var wp) && wp.Get("kind") as string == "write"))
                    {
                        errors.Add($"{name}: profile-action {opId} wymaga uprawnienia projektu rodzaju write");
                    }
                }

                if (perms.TryGetValue(perm, out var pd) && pd.Get("kind") as string == "sensitive-read" && !Py.Truthy(op.Get("sensitive")))
                {
                    errors.Add($"{name}: operacja {opId} z uprawnieniem odczytu wrażliwego musi mieć sensitive: true");
                }
            }

            var ui = D(prof.Get("ui"));
            foreach (var route in L(ui.Get("routes")).Select(D))
            {
                if (!Py.Str(route["path"]).StartsWith($"/p/{pid}/", StringComparison.Ordinal))
                {
                    errors.Add($"{name}: trasa {route["path"]} musi zaczynać się od /p/{pid}/");
                }
            }

            foreach (var slot in L(ui.Get("slots")).Select(D))
            {
                if (slot.Get("permission") is string sp && sp.Length > 0 && !perms.ContainsKey(sp) && !platformPerms.Contains(sp))
                {
                    errors.Add($"{name}: slot {slot["component"]} — nieznane uprawnienie {sp}");
                }

                if (D(slot.Get("appliesTo")).Get("process") is string proc && proc.Length > 0 && !ownProcesses.Contains(proc))
                {
                    errors.Add($"{name}: slot {slot["component"]} na procesie {proc} spoza profilu (R9)");
                }
            }

            foreach (var jt in Py.Strings(D(prof.Get("integrations")).Get("jobTypes")))
            {
                if (!jt.StartsWith(ns, StringComparison.Ordinal))
                {
                    errors.Add($"{name}: typ zadania {jt} musi zaczynać się od {ns}");
                }
            }

            var dev = D(prof.Get("dev"));
            var dataClass = D(prof.Get("data")).Get("classification", "internal") as string ?? "internal";
            var devClass = dev.Get("dataClass", dataClass) as string ?? dataClass;
            if (ClassRank.GetValueOrDefault(devClass, 0) < ClassRank.GetValueOrDefault(dataClass, 0))
            {
                errors.Add($"{name}: dev.dataClass słabsza niż klasyfikacja danych profilu ({dataClass})");
            }

            if (dev.Get("backlog") is string backlog && backlog.Length > 0)
            {
                var bpath = Repo.P(backlog);
                if (!File.Exists(bpath))
                {
                    errors.Add($"{name}: brak planu zespołu {backlog}");
                }
                else
                {
                    var b = D(MiniYaml.LoadFile(bpath));
                    if (b.Get("profile") as string != pid)
                    {
                        errors.Add($"{name}: {backlog} musi mieć profile: {pid}");
                    }

                    foreach (var step in L(b.Get("steps")).Select(D))
                    {
                        foreach (var w in Py.Strings(step.Get("writes")))
                        {
                            if (!w.StartsWith($"profiles/{pid}/", StringComparison.Ordinal))
                            {
                                errors.Add($"{name}: krok {step["id"]} zapisuje poza profiles/{pid}/ ({w})");
                            }
                        }
                    }
                }
            }

            if (authz == null)
            {
                errors.Add($"{name}: brak authorization.yaml");
                continue;
            }

            if (authz.Get("profile") as string != pid)
            {
                errors.Add($"{name}: authorization.yaml musi mieć profile: {pid}");
            }

            foreach (var a in L(authz.Get("assignments")).Select(D))
            {
                var group = Py.Str(a["group"]);
                foreach (var r in Py.Strings(a.Get("roles")))
                {
                    if (!roles.ContainsKey(r))
                    {
                        errors.Add($"{name}: grupa {group} dostaje nieznaną rolę {r}");
                    }
                }

                if (groupOwner.TryGetValue(group, out var gOwner) && gOwner != name)
                {
                    errors.Add($"{name}: grupa {group} jest już przypisana w profilu {gOwner} — użyj osobnej grupy AD per profil");
                }

                groupOwner[group] = name;
            }

            foreach (var cg in D(authz.Get("candidateGroups")).Keys)
            {
                if (candidateOwner.TryGetValue(cg, out var cOwner))
                {
                    errors.Add($"{name}: grupa kandydująca {cg} należy już do profilu {cOwner}");
                }

                candidateOwner[cg] = name;
            }
        }

        return errors;
    }

    public static string CodeOwners(List<Loaded> profiles)
    {
        var own = Py.Dict(Repo.Yaml("config/ownership.yaml"));
        var handle = new Dictionary<string, string>
        {
            ["platform"] = Py.Str(own["platform"]),
            ["architects"] = Py.Str(own["architects"]),
            ["security"] = Py.Str(own["security"]),
            ["design"] = Py.Str(own["design"]),
        };
        var lines = new List<string> { Generated, string.Empty, $"*  {own["platform"]}" };
        foreach (var entry in Py.List(own["paths"]).Select(Py.Dict))
        {
            lines.Add($"{entry["path"]}  " + string.Join(" ", Py.Strings(entry["owners"]).Select(o => handle[o])));
        }

        lines.Add(string.Empty);
        foreach (var p in profiles.Where(p => p.Profile != null))
        {
            var team = Py.Str(Py.Dict(p.Profile!["owner"])["team"]);
            lines.Add($"/profiles/{p.Name}/  {team}");
            lines.Add($"/profiles/{p.Name}/profile.yaml  {team} {handle["architects"]}");
            lines.Add($"/profiles/{p.Name}/authorization.yaml  {team} {handle["architects"]} {handle["security"]}");
        }

        return string.Join("\n", lines) + "\n";
    }

    public static int SelfTest()
    {
        var baseProfiles = Load().Where(p => p.Profile != null).ToDictionary(p => p.Name);
        var k = baseProfiles["kredyty"];
        var a = baseProfiles["aml"];

        List<string> Run(Action<PyDict, PyDict, PyDict, PyDict> mutate)
        {
            var kk = (PyDict)Py.Clone(k.Profile)!;
            var kka = (PyDict)Py.Clone(k.Authz)!;
            var am = (PyDict)Py.Clone(a.Profile)!;
            var ama = (PyDict)Py.Clone(a.Authz)!;
            mutate(kk, kka, am, ama);
            return Check(new List<Loaded> { new("kredyty", kk, kka, new List<string>()), new("aml", am, ama, new List<string>()) });
        }

        PyDict Item(PyDict d, string list, int i) => Py.Dict(Py.List(d[list])[i]);
        var cases = new (string Name, Action<PyDict, PyDict, PyDict, PyDict> Mutate)[]
        {
            ("proces w dwóch profilach", (kk, kka, am, ama) => Py.List(am["processes"]).Add(new PyDict { ["bpmnProcessId"] = "wniosek-kredytowy" })),
            ("uprawnienie w cudzej przestrzeni", (kk, kka, am, ama) => Py.List(am["permissions"]).Add(new PyDict { ["id"] = "kredyty.Case.Export", ["kind"] = "read", ["description"] = "x" })),
            ("operacja na cudzym procesie", (kk, kka, am, ama) => Py.Dict(Item(am, "operations", 0)["appliesTo"])["process"] = "wniosek-kredytowy"),
            ("task-action bez assignee", (kk, kka, am, ama) => Item(kk, "operations", 0)["requiresAssignee"] = false),
            ("odczyt wrażliwy bez oznaczenia", (kk, kka, am, ama) => Item(kk, "operations", 2).Remove("sensitive")),
            ("grupa kandydująca w dwóch profilach", (kk, kka, am, ama) => Py.Dict(ama["candidateGroups"])["kre-analitycy"] = "PH-AML-ANALITYCY"),
            ("rola z nieznanym uprawnieniem", (kk, kka, am, ama) => Py.List(Item(kk, "roles", 0)["permissions"]).Add("aml.Party.View")),
            ("trasa poza /p/<id>/", (kk, kka, am, ama) => Py.Dict(Py.List(Py.Dict(kk["ui"])["routes"])[0])["path"] = "/portfel"),
            ("słabsza klasa danych agentów", (kk, kka, am, ama) => Py.Dict(am["dev"])["dataClass"] = "confidential"),
            ("profile-action z uprawnieniem platformy", (kk, kka, am, ama) => Py.List(kk["operations"]).Add(new PyDict
                { ["id"] = "kredyty.SaveProduct", ["kind"] = "profile-action", ["permission"] = "Task.ViewOwn", ["requiresAssignee"] = false })),
            ("profile-action przypięta do procesu", (kk, kka, am, ama) => Py.List(kk["operations"]).Add(new PyDict
                {
                    ["id"] = "kredyty.SaveProduct", ["kind"] = "profile-action", ["permission"] = "kredyty.Limit.Override", ["requiresAssignee"] = false,
                    ["appliesTo"] = new PyDict { ["process"] = "wniosek-kredytowy" },
                })),
            ("profile-action z wymogiem assignee", (kk, kka, am, ama) => Py.List(kk["operations"]).Add(new PyDict
                { ["id"] = "kredyty.SaveProduct", ["kind"] = "profile-action", ["permission"] = "kredyty.Limit.Override", ["requiresAssignee"] = true })),
        };
        var failed = cases.Where(c => Run(c.Mutate).Count == 0).Select(c => c.Name).ToList();
        var okErrors = Check(new List<Loaded> { k, a });
        foreach (var f in failed)
        {
            Console.Error.WriteLine($"self-test FAIL: nie wykryto „{f}”");
        }

        if (okErrors.Count > 0)
        {
            Console.Error.WriteLine("self-test FAIL: poprawne profile zgłaszają błędy");
        }

        Console.WriteLine(failed.Count == 0 && okErrors.Count == 0 ? "self-test OK" : "self-test FAILED");
        return failed.Count == 0 && okErrors.Count == 0 ? 0 : 1;
    }

    /// <summary>ph profiles new &lt;id&gt; --name … --team … --process … (= tools/profiles/new_profile.py).</summary>
    public static int New(string[] args)
    {
        var cli = new Cli("użycie: ph profiles new <id> --name NAZWA --team @grupa --process bpmnProcessId [--po …] [--description …]", args,
            Array.Empty<string>(), new[] { "--name", "--team", "--process", "--po", "--description" }, 1, 1);
        var id = cli.Pos(0);
        foreach (var required in new[] { "--name", "--team", "--process" })
        {
            if (!cli.Has(required))
            {
                throw new ToolException($"{cli.Usage}\nbłąd: wymagana opcja {required}", 2);
            }
        }

        if (!Regex.IsMatch(id, "^[a-z][a-z0-9]{1,23}$"))
        {
            throw new ToolException("id: małe litery i cyfry, 2–24 znaki, bez myślników (przestrzeń nazw i schemat prj_<id>)");
        }

        var target = Repo.P($"profiles/{id}");
        if (Directory.Exists(target))
        {
            throw new ToolException($"profil {id} już istnieje");
        }

        var values = new Dictionary<string, string>
        {
            ["__ID__"] = id,
            ["__NAME__"] = cli.Opt("--name")!,
            ["__TEAM__"] = cli.Opt("--team")!,
            ["__PROCESS__"] = cli.Opt("--process")!,
            ["__PO__"] = cli.Opt("--po", "Właściciel produktu")!,
            ["__OPIS__"] = cli.Opt("--description", "Opis projektu do uzupełnienia.")!,
            ["__GROUP__"] = id.ToUpperInvariant(),
            ["__PREFIX__"] = id.Substring(0, Math.Min(3, id.Length)).ToUpperInvariant(),
        };
        var template = Repo.P("profiles/_template");
        foreach (var src in Directory.GetFiles(template, "*", SearchOption.AllDirectories))
        {
            var dest = Path.Combine(target, Path.GetRelativePath(template, src));
            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            if (src.EndsWith(".yaml", StringComparison.Ordinal) || src.EndsWith(".md", StringComparison.Ordinal))
            {
                var text = Repo.Read(src);
                foreach (var kv in values)
                {
                    text = text.Replace(kv.Key, kv.Value, StringComparison.Ordinal);
                }

                Repo.Write(dest, text);
            }
            else
            {
                File.Copy(src, dest);
            }
        }

        var sb = new StringBuilder();
        sb.Append($"utworzono profiles/{id}/ — uzupełnij profile.yaml i authorization.yaml, potem:\n");
        sb.Append("  python3 tools/profiles/validate_profiles.py --write-codeowners   (albo: ph profiles validate --write-codeowners)\n");
        sb.Append("  python3 tools/agents/render_agents.py                            (albo: ph agents render)");
        Console.WriteLine(sb.ToString());
        return 0;
    }
}
