using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Eksport danych planu do dashboardu harmonogramu (= tools/plan/export_dashboard_data.py).</summary>
public static class ExportDashboard
{
    private static readonly List<(long Phase, string Name)> Phases = new()
    {
        (0, "Przygotowanie i PoC"), (1, "Fundament"), (2, "Dostęp, Camunda, audyt, formatki"), (3, "Funkcje rdzenia"),
        (4, "Frontend funkcjonalny"), (5, "Integracja i hardening"), (6, "Pilotaż"),
    };

    private static readonly Dictionary<string, string> AgentLabel = new()
    {
        ["human"] = "Ludzie", ["module-implementer"] = "Implementer modułu", ["camunda-integrator"] = "Agent Camunda",
        ["data-engineer"] = "Agent danych", ["frontend-developer"] = "Agent frontendu", ["bdd-tester"] = "Tester BDD",
        ["bdd-analyst"] = "Analityk BDD", ["architect"] = "Architekt", ["security-reviewer"] = "Recenzent bezpieczeństwa",
        ["docs-writer"] = "Dokumentalista", ["ux-designer"] = "Agent UX", ["design-system-engineer"] = "Agent design systemu",
        ["ui-reviewer"] = "Recenzent UI",
    };

    private static readonly Dictionary<string, string[]> Scopes = new()
    {
        ["S00"] = new[] { "Infrastruktura" }, ["S01"] = new[] { "Camunda", "Backend" }, ["S02"] = new[] { "Bezpieczeństwo", "Camunda" }, ["S03"] = new[] { "Camunda" },
        ["S04"] = new[] { "Camunda", "Dane" }, ["S05"] = new[] { "Biznes", "Testy" }, ["S06"] = new[] { "Infrastruktura", "Camunda", "Dane", "Bezpieczeństwo" },
        ["S07"] = new[] { "Frontend", "Camunda" }, ["S08"] = new[] { "Camunda", "Backend" }, ["S09"] = new[] { "Frontend", "Biznes" },
        ["S10"] = new[] { "Backend" }, ["S11"] = new[] { "Testy", "Infrastruktura" }, ["S12"] = new[] { "Backend", "Bezpieczeństwo" }, ["S13"] = new[] { "Dane", "Bezpieczeństwo" },
        ["S14"] = new[] { "Testy" }, ["S15"] = new[] { "Backend", "Frontend" }, ["S16"] = new[] { "Frontend" }, ["S17"] = new[] { "Camunda" }, ["S18"] = new[] { "Bezpieczeństwo", "Backend" },
        ["S19"] = new[] { "Backend", "Frontend" },
        ["S20"] = new[] { "Backend" }, ["S21"] = new[] { "Bezpieczeństwo", "Camunda" }, ["S22"] = new[] { "Camunda", "Backend" }, ["S23"] = new[] { "Camunda", "Dane" },
        ["S24"] = new[] { "Bezpieczeństwo", "Backend", "Dane" }, ["S25"] = new[] { "Bezpieczeństwo", "Dane" }, ["S26"] = new[] { "Backend", "Biznes" }, ["S27"] = new[] { "Bezpieczeństwo", "Dane" },
        ["S28"] = new[] { "Dane" }, ["S29"] = new[] { "Camunda", "Backend" }, ["S39"] = new[] { "Backend" }, ["S49"] = new[] { "Frontend" }, ["S55"] = new[] { "Frontend", "Testy" },
        ["S30"] = new[] { "Backend", "Camunda" }, ["S31"] = new[] { "Backend", "Camunda" }, ["S32"] = new[] { "Backend" }, ["S33"] = new[] { "Camunda" },
        ["S34"] = new[] { "Backend", "Biznes" }, ["S35"] = new[] { "Backend" }, ["S36"] = new[] { "Dane", "Biznes" }, ["S37"] = new[] { "Backend", "Frontend" }, ["S38"] = new[] { "Backend", "Testy" },
        ["S40"] = new[] { "Frontend" }, ["S41"] = new[] { "Frontend" }, ["S42"] = new[] { "Frontend" }, ["S43"] = new[] { "Frontend" }, ["S44"] = new[] { "Frontend", "Camunda" },
        ["S45"] = new[] { "Frontend" }, ["S46"] = new[] { "Frontend" }, ["S47"] = new[] { "Frontend" }, ["S48"] = new[] { "Biznes" }, ["S50"] = new[] { "Testy", "Infrastruktura" },
        ["S51"] = new[] { "Bezpieczeństwo", "Testy" },
        ["S52"] = new[] { "Dane", "Testy" }, ["S53"] = new[] { "Frontend", "Testy" }, ["S54"] = new[] { "Bezpieczeństwo", "Biznes" }, ["S60"] = new[] { "Biznes", "Infrastruktura" },
    };

    private static readonly Dictionary<string, string> External = new()
    {
        ["S02"] = "decyzja zespołu bezpieczeństwa", ["S05"] = "dostępność biznesu na warsztatach", ["S06"] = "dostępy i procedury IT banku",
        ["S09"] = "dostępność projektanta UX i księgi znaku banku", ["S16"] = "licencja Kendo UI i dostęp do rejestru npm", ["S54"] = "termin zewnętrznego pentestu i akceptacje compliance",
        ["S48"] = "dostępność zespołów profili projektów",
        ["S60"] = "gotowość obszaru biznesowego, szkolenia i profilu pilotażowego (zespół projektu)",
    };

    private static readonly Dictionary<long, string> RiskLabel = new() { [1] = "niskie", [2] = "niskie", [3] = "średnie", [4] = "wysokie", [5] = "krytyczne" };

    private static readonly Dictionary<string, string> Approver = new()
    {
        ["architect-human"] = "Architekt", ["product-owner"] = "Product Owner", ["tech-lead"] = "Tech lead", ["security"] = "Bezpieczeństwo", ["compliance"] = "Compliance",
    };

    private static readonly Dictionary<string, string> Short = new()
    {
        ["S00"] = "Repozytorium i harness", ["S01"] = "PoC SDK Camunda", ["S02"] = "PoC autoryzacji", ["S03"] = "PoC task listenera",
        ["S04"] = "PoC zasilania read modelu", ["S05"] = "Scenariusze z biznesem", ["S06"] = "Środowisko dev w banku",
        ["S07"] = "PoC formatek w UI", ["S08"] = "PoC walidacji i FEEL", ["S09"] = "Warstwa wizualna i Figma",
        ["S10"] = "Szkielet rozwiązania", ["S11"] = "Testy architektury i CI", ["S12"] = "Building Blocks", ["S13"] = "Baza MSSQL",
        ["S14"] = "Harness BDD", ["S15"] = "Kontrakty v1 i OpenAPI", ["S16"] = "Frontend: shell i ui-kit", ["S17"] = "bpmnlint i modele BPMN",
        ["S18"] = "BFF i logowanie RHBK", ["S19"] = "SDK rozszerzeń i rejestr profili", ["S20"] = "Party i zastępstwa", ["S21"] = "Autoryzacje jako kod", ["S22"] = "Adaptery SDK",
        ["S23"] = "Projekcja read modelu", ["S24"] = "Polityka dostępu R1–R11", ["S25"] = "Audyt", ["S26"] = "Formatki: cykl życia", ["S27"] = "Izolacja profili",
        ["S28"] = "Formatki: schemat bazy", ["S29"] = "Formatki: powiązania z BPMN", ["S39"] = "Formatki: wycofanie i przepięcie",
        ["S49"] = "UI: komponenty pól", ["S55"] = "Zgodność i spójność formatek",
        ["S30"] = "Praca na zadaniach", ["S31"] = "Start procesu", ["S32"] = "Przekazywanie zadań", ["S33"] = "Zastępstwa (listener)",
        ["S34"] = "Mapa etapów", ["S35"] = "Eskalacje", ["S36"] = "Dashboard menadżera", ["S37"] = "Form Runtime", ["S38"] = "Operacje profili",
        ["S40"] = "UI: zadania i renderer formatek", ["S41"] = "UI: start i moje procesy", ["S42"] = "UI: dashboard i etapy", ["S43"] = "UI: przekazywanie",
        ["S44"] = "UI: edytor mapy etapów", ["S45"] = "UI: projektant formatek", ["S46"] = "UI: audytor", ["S47"] = "UI: sloty profili", ["S48"] = "Onboarding zespołów profili",
        ["S50"] = "Testy end-to-end", ["S51"] = "Testy bezpieczeństwa", ["S52"] = "Wydajność", ["S53"] = "Dostępność i UX", ["S54"] = "Pentest i compliance", ["S60"] = "Pilotaż",
    };

    private static object R1(double x) => PyFloat.Round(x, 1);

    private static object R2(double x) => PyFloat.Round(x, 2);

    private static object RInt(double x) => PyFloat.RoundToInt(x);

    private sealed record Schedule(Dictionary<string, double> Es, Dictionary<string, double> Ef, Dictionary<string, double> Ls, Dictionary<string, double> Lf,
        double End, Dictionary<string, List<string>> Succ);

    private static Schedule Plan(Estimate.Result res)
    {
        var order = new List<string>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        void Visit(string s)
        {
            if (!seen.Add(s))
            {
                return;
            }

            foreach (var d in res.Rows[s].Deps)
            {
                Visit(d);
            }

            order.Add(s);
        }

        foreach (var s in res.Order)
        {
            Visit(s);
        }

        var es = new Dictionary<string, double>(StringComparer.Ordinal);
        var ef = new Dictionary<string, double>(StringComparer.Ordinal);
        foreach (var s in order)
        {
            var deps = res.Rows[s].Deps;
            var start = 0.0;
            if (deps.Count > 0)
            {
                start = ef[deps[0]];
                foreach (var d in deps.Skip(1))
                {
                    if (ef[d] > start)
                    {
                        start = ef[d];
                    }
                }
            }

            es[s] = start;
            ef[s] = start + res.Rows[s].Dur;
        }

        var end = ef[order[0]];
        foreach (var s in res.Order)
        {
            if (ef[s] > end)
            {
                end = ef[s];
            }
        }

        var succ = res.Order.ToDictionary(s => s, s => res.Order.Where(t => res.Rows[t].Deps.Contains(s)).ToList(), StringComparer.Ordinal);
        var ls = new Dictionary<string, double>(StringComparer.Ordinal);
        var lf = new Dictionary<string, double>(StringComparer.Ordinal);
        foreach (var s in Enumerable.Reverse(order))
        {
            var finish = end;
            if (succ[s].Count > 0)
            {
                finish = ls[succ[s][0]];
                foreach (var t in succ[s].Skip(1))
                {
                    if (ls[t] < finish)
                    {
                        finish = ls[t];
                    }
                }
            }

            lf[s] = finish;
            ls[s] = finish - res.Rows[s].Dur;
        }

        return new Schedule(es, ef, ls, lf, end, succ);
    }

    private static PyDict RunScenario(Estimate.Inputs inp)
    {
        var res = Estimate.Compute(inp);
        var hyb = Py.Sum(res.RowList.Select(r => r.HybFinal));
        var hs = Py.Sum(res.RowList.Select(r => r.HybFinalS));
        var ov = Py.Dict(inp.Params["overheads"]);
        var mult = 1 + Py.Num(ov["swarm_supervision"]) + Py.Num(ov["coordination"]);
        var bn = res.Bottleneck();
        var z = Py.Num(inp.Params["percentile_z"]);
        return new PyDict
        {
            ["effort_pd"] = R1(hyb * mult),
            ["cal_weeks"] = R1(Math.Max(res.CpDays, res.RoleDays[bn]) / 5),
            ["cal_p80_weeks"] = R1(Math.Max(res.CpDays + z * res.CpSig, res.RoleDays[bn] * (1 + z * hs / hyb)) / 5),
        };
    }

    private static List<object?> Scenarios(Estimate.Inputs inp)
    {
        var defs = new List<(string Id, string Name, string Desc, Action<PyDict, PyDict>? Fn)>
        {
            ("bazowy", "Bazowy", "plan i szacunki bez zmian", null),
            ("slabsi_agenci", "Słabsi agenci", "udział AI niższy o 20 pkt, np. słabsze wyniki kwalifikacji modelu", (e, p) =>
            {
                foreach (var v in e.Values.Select(Py.Dict))
                {
                    var x = Py.Num(v["ai_share"]) - 0.2;
                    v["ai_share"] = 0.1 >= x ? 0.1 : x;
                }
            }),
            ("drozszy_przeglad", "Droższy przegląd", "przegląd pracy agentów droższy o 15 pkt", (e, p) =>
            {
                foreach (var v in e.Values.Select(Py.Dict))
                {
                    var x = Py.Num(v["review"]) + 0.15;
                    v["review"] = 1.0 <= x ? 1.0 : x;
                }
            }),
            ("wolne_procedury", "Wolne procedury banku", "oczekiwanie na bramki ×2, środowisko i pentest pesymistycznie", (e, p) =>
            {
                var gw = Py.Dict(Py.Dict(p["calendar"])["gate_wait_days"]);
                foreach (var g in gw.Keys.ToList())
                {
                    gw[g] = Py.List(gw[g]).Select(x => x is long l ? (object)(l * 2) : Py.Num(x) * 2).ToList();
                }

                Py.Dict(e["S06"])["trad_pd"] = new List<object?> { 20L, 30L, 45L };
                Py.Dict(e["S54"])["external_calendar_days"] = new List<object?> { 15L, 25L, 40L };
            }),
            ("wiekszy_zespol", "Większy zespół", "+1 backend, PO 0,75 etatu, bezpieczeństwo 0,3 etatu", (e, p) =>
            {
                var t = Py.Dict(p["team_fte"]);
                t["backend_dotnet"] = 3.0;
                t["product_owner_analityk"] = 0.75;
                t["bezpieczenstwo"] = 0.3;
            }),
            ("podzial_krytycznych", "Podział kroków krytycznych", "dwie osoby z agentami na krokach ścieżki krytycznej", (e, p) =>
            {
                var pf = Py.Dict(Py.Dict(p["calendar"])["parallel_factor"]);
                pf["L"] = 2.0;
                pf["M"] = 1.3;
            }),
        };
        var baseRun = RunScenario(inp);
        var output = new List<object?>();
        foreach (var (id, name, desc, fn) in defs)
        {
            var e = (PyDict)Py.Clone(inp.Estimates)!;
            var p = (PyDict)Py.Clone(inp.Params)!;
            fn?.Invoke(e, p);
            var r = RunScenario(new Estimate.Inputs(inp.Backlog, e, p, inp.Actuals));
            r["id"] = id;
            r["name"] = name;
            r["description"] = desc;
            r["delta_weeks"] = R1(Py.Num(r["cal_weeks"]) - Py.Num(baseRun["cal_weeks"]));
            r["delta_effort_pd"] = R1(Py.Num(r["effort_pd"]) - Py.Num(baseRun["effort_pd"]));
            output.Add(r);
        }

        return output;
    }

    public static int Run(string[] args)
    {
        var cli = new Cli("użycie: ph plan export [--check]", args, new[] { "--check" }, Array.Empty<string>());
        var inp = Estimate.Load();
        var res = Estimate.Compute(inp);
        var trad = Estimate.Compute(inp, "trad");
        var sch = Plan(res);
        var register = Py.Dict(Repo.Yaml("plan/dashboard/register.yaml"));
        var bl = Py.List(inp.Backlog["steps"]).Select(Py.Dict).ToDictionary(s => Py.Str(s["id"]), StringComparer.Ordinal);
        var p = inp.Params;
        var z = Py.Num(p["percentile_z"]);
        var ov = Py.Dict(p["overheads"]);
        var gatesCfg = Py.Dict(inp.Backlog["gates"]);
        var gateWait = Py.Dict(Py.Dict(p["calendar"])["gate_wait_days"]);
        var teamFte = Py.Dict(p["team_fte"]);

        var steps = new List<object?>();
        foreach (var r in res.RowList.OrderBy(r => sch.Es[r.Id]).ThenBy(r => r.Id, StringComparer.Ordinal))
        {
            var sid = r.Id;
            var e = r.E;
            var split = Estimate.SplitOf(sid, r.Agent);
            var wait = string.IsNullOrEmpty(r.Gate) ? 0.0 : Estimate.Pert(gateWait[r.Gate]).Mean;
            var risk = PyFloat.RoundToInt((Py.Num(e["N"]) + Math.Max(Py.Num(e["T"]), Py.Num(e["B"]))) / 2);
            var sc = Scopes[sid];
            var blockers = r.Deps.Select(d => $"po {d}").Concat(string.IsNullOrEmpty(r.Gate) ? Array.Empty<string>() : new[] { $"bramka {r.Gate}" })
                .Concat(External.TryGetValue(sid, out var ext) ? new[] { ext } : Array.Empty<string>()).ToList();
            var lead = split[0];
            foreach (var x in split.Skip(1))
            {
                if (x.Share > lead.Share)
                {
                    lead = x;
                }
            }

            var dod = string.Join("; ", Py.Strings(bl[sid].Get("dod")));
            steps.Add(new PyDict
            {
                ["id"] = sid, ["short"] = Short[sid], ["title"] = r.Title, ["phase"] = r.Phase, ["phase_name"] = Phases.First(x => x.Phase == Py.Num(r.Phase)).Name,
                ["agent"] = r.Agent != null && AgentLabel.TryGetValue(r.Agent, out var al) ? al : r.Agent, ["size"] = r.Size,
                ["scope"] = sc[0], ["scopes"] = string.Join(", ", sc),
                ["roles"] = string.Join(", ", split.Select(x => Estimate.RoleLabel[x.Role])), ["lead_role"] = Estimate.RoleLabel[lead.Role],
                ["role_split"] = string.Join(", ", split.Select(x => $"{Estimate.RoleLabel[x.Role]} {PyFloat.RoundToInt(x.Share * 100)}%")),
                ["critical"] = res.CpPath.Contains(sid), ["complexity"] = R2(r.C), ["complexity_class"] = r.Cls,
                ["t"] = e["T"], ["n"] = e["N"], ["i"] = e["I"], ["b"] = e["B"],
                ["ai_share"] = e["ai_share"], ["review"] = e["review"],
                ["trad_pd"] = R1(r.Trad), ["trad_o"] = Py.List(e["trad_pd"])[0], ["trad_p"] = Py.List(e["trad_pd"])[2],
                ["hyb_pd"] = R1(r.HybFinal), ["saving"] = R2(1 - r.HybFinal / r.Trad),
                ["start_week"] = R1(sch.Es[sid] / 5), ["work_start_week"] = R1((sch.Es[sid] + wait) / 5),
                ["end_week"] = R1(sch.Ef[sid] / 5), ["late_end_week"] = R1(sch.Lf[sid] / 5),
                ["float_days"] = R1(sch.Ls[sid] - sch.Es[sid]), ["duration_days"] = R1(r.Dur),
                ["gate"] = r.Gate ?? string.Empty, ["gate_wait_days"] = R1(wait),
                ["depends_on"] = string.Join(", ", r.Deps), ["unblocks"] = string.Join(", ", sch.Succ[sid].OrderBy(x => x, StringComparer.Ordinal)),
                ["blockers"] = string.Join("; ", blockers), ["external_blocker"] = External.GetValueOrDefault(sid, string.Empty),
                ["risk_level"] = risk, ["risk_label"] = RiskLabel[risk], ["risk_driver"] = e["driver"],
                ["status"] = "Planowany", ["progress"] = 0L,
                ["dod"] = dod.Length > 300 ? dod.Substring(0, 300) : dod,
            });
        }

        var gates = new List<object?>();
        foreach (var kv in gatesCfg)
        {
            var cfg = Py.Dict(kv.Value);
            var gw = Estimate.Pert(gateWait[kv.Key]);
            var after = Py.Strings(cfg["after"]).ToList();
            var decided = sch.Ef[after[0]];
            foreach (var s in after.Skip(1))
            {
                if (sch.Ef[s] > decided)
                {
                    decided = sch.Ef[s];
                }
            }

            gates.Add(new PyDict
            {
                ["gate"] = kv.Key, ["week"] = R1(decided / 5), ["wait_days"] = R1(gw.Mean), ["after"] = string.Join(", ", after),
                ["approver"] = string.Join(", ", Py.Strings(cfg["approver"]).Select(a => Approver.GetValueOrDefault(a, a))),
                ["condition"] = Py.Dict(register["gate_conditions"])[kv.Key],
            });
        }

        var tradSum = Py.Sum(res.RowList.Select(r => r.Trad));
        var tradS = Py.Sum(res.RowList.Select(r => r.TradS));
        var hyb = Py.Sum(res.RowList.Select(r => r.HybFinal));
        var hybS = Py.Sum(res.RowList.Select(r => r.HybFinalS));
        var mh = 1 + Py.Num(ov["swarm_supervision"]) + Py.Num(ov["coordination"]);
        var mt = 1 + Py.Num(ov["coordination"]);
        var bn = res.Bottleneck();
        var tbn = trad.Bottleneck();
        var cal = Math.Max(res.CpDays, res.RoleDays[bn]) / 5;
        var cal80 = Math.Max(res.CpDays + z * res.CpSig, res.RoleDays[bn] * (1 + z * hybS / hyb)) / 5;
        var tcal = Math.Max(trad.CpDays, trad.RoleDays[tbn]) / 5;
        var tcal80 = Math.Max(trad.CpDays + z * trad.CpSig, trad.RoleDays[tbn] * (1 + z * tradS / tradSum)) / 5;
        var summary = new List<object?>
        {
            new PyDict
            {
                ["cal_hyb_weeks"] = R1(cal), ["cal_hyb_p80_weeks"] = R1(cal80), ["cal_trad_weeks"] = R1(tcal),
                ["cal_trad_p80_weeks"] = R1(tcal80), ["cal_saving_weeks"] = R1(tcal - cal),
                ["effort_hyb_pd"] = RInt(hyb * mh), ["effort_hyb_p80_pd"] = RInt((hyb + z * hybS) * mh),
                ["effort_trad_pd"] = RInt(tradSum * mt), ["effort_trad_p80_pd"] = RInt((tradSum + z * tradS) * mt),
                ["effort_saving"] = R2(1 - (hyb * mh) / (tradSum * mt)), ["cp_days"] = RInt(res.CpDays),
                ["team_fte"] = R1(Py.Sum(teamFte.Values.Select(Py.Num))), ["steps_total"] = (long)res.Order.Count,
                ["steps_critical"] = (long)res.CpPath.Count, ["gates_total"] = (long)gatesCfg.Count,
                ["bottleneck_role"] = Estimate.RoleLabel[bn], ["calibration_k"] = R2(res.K), ["steps_with_actuals"] = (long)res.Done.Count,
            },
        };

        var phases = new List<object?>();
        foreach (var (ph, name) in Phases)
        {
            var ids = res.Order.Where(s => Py.Num(res.Rows[s].Phase) == ph).ToList();
            var t = Py.Sum(ids.Select(s => res.Rows[s].Trad));
            var h = Py.Sum(ids.Select(s => res.Rows[s].HybFinal));
            phases.Add(new PyDict
            {
                ["phase"] = ph, ["name"] = name, ["trad_pd"] = R1(t), ["hyb_pd"] = R1(h), ["saving"] = R2(1 - h / t),
                ["start_week"] = R1(ids.Select(s => sch.Es[s]).Min() / 5), ["end_week"] = R1(ids.Select(s => sch.Ef[s]).Max() / 5),
                ["steps"] = (long)ids.Count,
            });
        }

        var util = Py.Num(p["utilization"]);
        var roles = res.RoleOrder.Select(r => (object?)new PyDict
        {
            ["role"] = r, ["role_label"] = Estimate.RoleLabel[r], ["fte"] = teamFte[r], ["load_pd"] = R1(res.RoleLoad[r]),
            ["days_needed"] = RInt(res.RoleDays[r]), ["cp_days"] = RInt(res.CpDays), ["load_vs_cp"] = R2(res.RoleDays[r] / res.CpDays),
        }).ToList();

        var end = sch.End;
        var weeks = (int)Math.Ceiling(end / 5);
        var daily = res.RoleOrder.ToDictionary(r => r, r => new double[weeks * 5], StringComparer.Ordinal);
        foreach (var r in res.RowList)
        {
            var split = Estimate.SplitOf(r.Id, r.Agent);
            var wait = string.IsNullOrEmpty(r.Gate) ? 0.0 : Estimate.Pert(gateWait[r.Gate]).Mean;
            var a = sch.Es[r.Id] + wait;
            var b = sch.Ef[r.Id];
            var span = Math.Max(b - a, 0.5);
            foreach (var (role, share) in split)
            {
                var perDay = r.HybFinal * share / span;
                for (var d = (int)Math.Truncate(a); d < Math.Min((int)Math.Ceiling(b), weeks * 5); d++)
                {
                    var overlap = Math.Min(b, d + 1) - Math.Max(a, d);
                    if (overlap > 0)
                    {
                        daily[role][d] += perDay * overlap;
                    }
                }
            }
        }

        var baseHyb = Py.Sum(res.RowList.Select(r => r.HybFinal));
        var over = new List<(string Role, double Total)>
        {
            ("architekt_tech_lead", baseHyb * (Py.Num(ov["swarm_supervision"]) + Py.Num(ov["coordination"]) * 0.4)),
            ("product_owner_analityk", baseHyb * Py.Num(ov["coordination"]) * 0.6),
        };
        foreach (var (role, total) in over)
        {
            for (var d = 0; d < (int)Math.Ceiling(end); d++)
            {
                daily[role][d] += total / end;
            }
        }

        var roleWeekly = new List<object?>();
        foreach (var role in res.RoleOrder)
        {
            for (var w = 0; w < weeks; w++)
            {
                var fteNeeded = Py.Sum(daily[role].Skip(w * 5).Take(5)) / 5;
                var avail = Py.Num(teamFte[role]) * util;
                roleWeekly.Add(new PyDict
                {
                    ["key"] = $"{role}-{w + 1}", ["week"] = (long)(w + 1), ["role"] = role, ["role_label"] = Estimate.RoleLabel[role],
                    ["fte_needed"] = R2(fteNeeded), ["fte_available"] = R2(avail),
                    ["utilization"] = avail != 0 ? R2(fteNeeded / avail) : 0L,
                });
            }
        }

        var data = new PyDict
        {
            ["steps"] = steps, ["gates"] = gates, ["summary"] = summary, ["phases"] = phases, ["roles"] = roles,
            ["role_weekly"] = roleWeekly, ["scenarios"] = Scenarios(inp),
            ["risks"] = Py.Clone(register["risks"]), ["decisions"] = Py.Clone(register["decisions"]),
        };
        var weekOf = steps.Select(Py.Dict).ToDictionary(s => Py.Str(s["id"]), s => s["start_week"], StringComparer.Ordinal);
        foreach (var d in Py.List(data["decisions"]).Select(Py.Dict))
        {
            object? min = null;
            foreach (var x in Py.Str(d["before_steps"]).Split(", "))
            {
                var v = weekOf.TryGetValue(x, out var wv) ? wv : 0L;
                if (min == null || Py.Num(v) < Py.Num(min))
                {
                    min = v;
                }
            }

            d["needed_by_week"] = min is long lm ? lm : R1(Py.Num(min));
        }

        foreach (var r in Py.List(data["risks"]).Select(Py.Dict))
        {
            r["score"] = Py.Int(r["probability"]) * Py.Int(r["impact"]);
        }

        var outDir = Repo.P("plan/dashboard/data");
        var outputs = data.Select(kv => (Path: Path.Combine(outDir, $"{kv.Key}.json"), Content: PyJson.Dumps(kv.Value, indent: 1) + "\n")).ToList();
        outputs.Add((Repo.P("plan/dashboard/data.js"), "// WYGENEROWANE przez tools/plan/export_dashboard_data.py — nie edytuj ręcznie\nwindow.PH_DATA = " + PyJson.Dumps(data) + ";\n"));
        var stale = outputs.Where(o => !Repo.SameContent(o.Path, o.Content)).ToList();
        if (cli.Flag("--check"))
        {
            foreach (var s in stale)
            {
                Console.Error.WriteLine($"NIEAKTUALNE: {Repo.Rel(s.Path)}");
            }

            return stale.Count > 0 ? 1 : 0;
        }

        foreach (var (path, content) in outputs)
        {
            Repo.Write(path, content);
        }

        var stamp = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", System.Globalization.CultureInfo.InvariantCulture);
        Repo.Write(Path.Combine(outDir, "_generated.json"), PyJson.Dumps(new PyDict
        {
            ["at"] = stamp,
            ["files"] = data.Keys.OrderBy(k => k, StringComparer.Ordinal).Cast<object?>().ToList(),
        }, indent: 1, ensureAscii: true) + "\n");
        Console.WriteLine($"zapisano {data.Count} zbiorów do {Repo.Rel(outDir)}");
        return 0;
    }
}
