# Narzędzia repozytorium w .NET (`ph`)

Te same narzędzia co w `tools/*.py`, przepisane na C# — dla stacji i potoków CI, na których Python albo `pip` są zablokowane. Wymagają tylko .NET 10 SDK; nie używają żadnych paczek NuGet (`nuget.config` czyści źródła), więc budują się bez dostępu do rejestru. Kod jest wewnętrzny i w całości w tym katalogu; język wymuszony na poziomie C# 10 (`Directory.Build.props`).

Wersja Python zostaje: obie implementacje dają **identyczne co do bajtu** pliki i przechodzą te same bramki `--check`, więc zespół może używać dowolnej z nich, także naprzemiennie.

## Budowanie i uruchamianie

```bash
dotnet build tools/dotnet/ProcessHub.Tools.sln -c Release                          # kompilacja + testy w jednym rozwiązaniu
dotnet publish tools/dotnet/src/ProcessHub.Tools -c Release -o tools/dotnet/publish   # plik wykonywalny ph (wymaga runtime .NET 10)
export PATH="$PWD/tools/dotnet/publish:$PATH"                                       # Windows: dodaj katalog publish do PATH
ph help
```

Bez publikacji: `dotnet run --project tools/dotnet/src/ProcessHub.Tools -c Release -- <polecenie>`. Katalog `tools/dotnet/publish/` jest w `.gitignore`.

`ph` działa w repozytorium (szuka w górę katalogu z `AGENTS.md` i `plan/backlog.yaml`); inaczej `--repo <ścieżka>` albo zmienna `PH_REPO_ROOT`. Dzięki temu katalog `tools/dotnet` można przenieść do osobnego repozytorium narzędzi bez zmian w kodzie.

## Odpowiedniki skryptów

| Python | .NET | Uwagi |
| --- | --- | --- |
| `python3 tools/guard/enforce_write_scope.py` | `ph guard` | stdin, `--check`, `--verify-diff <base> [--profile <id>]`, `--self-test` |
| `python3 tools/agents/render_agents.py` | `ph agents render` | `--profile`, `--targets`, `--check` |
| `python3 tools/agents/validate_output.py <schemat> <plik>` | `ph agents validate-output <schemat> <plik>` | |
| `python3 tools/agents/prepare_step.py <krok>` | `ph step prepare <krok>` | `--backlog`, `--worktree-root`, `--no-worktree`, `--force` |
| `python3 tools/agents/run_dod.py <krok>` | `ph step dod <krok>` | `--backlog`, `--dir`, `--timeout`, `--tools auto\|python\|dotnet` |
| `python3 tools/agents/plan_status.py` | `ph step status` | `--backlog`, `--merged`, `--approve-gate --by --evidence [--force]` |
| `python3 tools/profiles/validate_profiles.py` | `ph profiles validate` | `--check`, `--write-codeowners`, `--self-test` |
| `python3 tools/profiles/new_profile.py <id>` | `ph profiles new <id>` | `--name`, `--team`, `--process`, `--po`, `--description` |
| `python3 tools/plan/estimate.py` | `ph plan estimate` | `--check`, `--json` |
| `python3 tools/plan/export_dashboard_data.py` | `ph plan export` | `--check` |
| `python3 tools/artifacts/render_artifacts.py` | `ph artifacts render` | `--check` |
| `python3 tools/handover/build_notebook_sources.py` | `ph notes build` | `--check` |
| `python3 tools/plan/validate_plan.py` | — | spójność planów; na razie tylko Python (do uzupełnienia w `ph plan validate`) |
| — | `ph yaml <plik>` | podgląd YAML jako JSON (bez Pythona) |

## Praca bez Pythona

- **OpenCode.** Plugin strażnika zapisu wybiera implementację sam: zmienna `PH_GUARD` (np. `ph guard`), potem `tools/dotnet/publish/ph`, na końcu Python. Gdy żadna nie działa, zapis jest blokowany (fail-closed). Komendy `ph …` są na liście dozwolonych w `opencode.json`.
- **Definition of Done.** Plany zawierają polecenia `python3 tools/…`. `ph step dod` przy braku Pythona (albo z `--tools dotnet`) zamienia je na odpowiednie wywołania `ph` — plany nie wymagają zmian.
- **CI.** Te same bramki: `ph agents render --check`, `ph profiles validate --check`, `ph plan estimate --check`, `ph plan export --check`, `ph artifacts render --check`, `ph notes build --check`, `ph guard --verify-diff origin/main [--profile <id>]`.

## Zgodność z Pythonem — jak jest zapewniona

| Obszar | Rozwiązanie |
| --- | --- |
| Zaokrąglanie i formatowanie liczb | `round()` i format `f` liczone na dokładnej wartości binarnej (połówki do parzystej), `repr()` jak w Pythonie |
| Sumy | `sum()` jak w Pythonie 3.12+ (sumowanie z kompensacją Neumaiera) |
| JSON | zapis jak `json.dumps` (wcięcia, separatory, `ensure_ascii`), odczyt: liczby bez części ułamkowej jako całkowite |
| YAML | czytnik zgodny z PyYAML `safe_load` (YAML 1.1: `yes/no/on/off`, liczby ósemkowe, kotwice, skalary wielowierszowe, kolekcje flow) |
| Wzorce ścieżek | `fnmatch` i `glob(recursive=True)` z tymi samymi regułami |
| Kolejność | słowniki zachowują kolejność wstawiania; sortowanie stabilne jak w Pythonie |

Kontrola: `sh tools/dotnet/parity.sh` (gdy dostępne są obie implementacje) generuje pliki jedną i sprawdza drugą w obie strony. Wymaga Pythona 3.12 lub nowszego po stronie Python — starsze wersje sumują liczby bez kompensacji i mogą różnić się na ostatnich cyfrach.

## Testy

```bash
dotnet run --project tools/dotnet/tests/ProcessHub.Tools.Tests -c Release        # wszystkie testy
dotnet run --project tools/dotnet/tests/ProcessHub.Tools.Tests -c Release -- Yaml  # filtr nazwy
```

Testy nie używają zewnętrznych bibliotek (własny runner w `TestRunner.cs`). Obejmują zgodność infrastruktury z Pythonem (zaokrąglanie, `repr`, sumy, JSON, YAML, `fnmatch`), reguły strażnika i walidatora profili, zamianę poleceń w Definition of Done oraz testy zgodności: każdy generator w trybie `--check` musi odtworzyć pliki zapisane w repozytorium.

## Budowa kodu

```
src/ProcessHub.Tools/
  Program.cs                   wejście ph, opcja --repo
  Commands/Dispatcher.cs       mapa poleceń ph ↔ skrypty Pythona (używana też do zamiany poleceń w DoD)
  Commands/*.cs                Guard, Agents, Steps, Profiles, Estimate, ExportDashboard, Artifacts, Notes
  Infrastructure/
    PyValue.cs                 model wartości jak w Pythonie (dict z kolejnością, str/int/float/bool/None, sum)
    PyFloat.cs · PyJson.cs     liczby i JSON identyczne z Pythonem
    MiniYaml.cs                czytnik YAML zgodny z PyYAML
    Glob.cs · Cli.cs · Shell.cs · Repo.cs · JsonSchemaLite.cs
tests/ProcessHub.Tools.Tests/  runner i testy
parity.sh                      zgodność w obie strony
```

Ograniczenia: czytnik YAML obsługuje zakres używany w repozytorium (bez tagów niestandardowych, kluczy scalających `<<` i dat jako typu); walidator JSON Schema — słowa kluczowe używane w `profiles/profile.schema.json` i `agents/schemas/`. Komunikaty o błędnym JSON różnią się od Pythona treścią, nie skutkiem.
