#!/bin/sh
# Zgodność narzędzi Python i .NET: generuje pliki jedną implementacją i sprawdza drugą (--check), w obie strony.
# Wymaga: python3 (pyyaml, jsonschema) i dotnet. Uruchom z katalogu głównego repozytorium: sh tools/dotnet/parity.sh
set -eu
ROOT=$(pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
dotnet build "$ROOT/tools/dotnet/src/ProcessHub.Tools" -c Release -nologo -v q >/dev/null
PH="$ROOT/tools/dotnet/src/ProcessHub.Tools/bin/Release/net10.0/ph"

run_case() { # $1 = kierunek, $2 = generuj, $3 = sprawdź
  rm -rf "$TMP/repo" && cp -r "$ROOT" "$TMP/repo" && cd "$TMP/repo"
  eval "$2" >/dev/null
  if eval "$3" >/dev/null 2>&1; then echo "OK    $1"; else echo "BŁĄD  $1"; FAILED=1; fi
  cd "$ROOT"
}

FAILED=0
run_case "agenci: Python → ph"        "python3 tools/agents/render_agents.py"            "$PH agents render --check"
run_case "agenci: ph → Python"        "$PH agents render"                                "python3 tools/agents/render_agents.py --check"
run_case "wycena: Python → ph"        "python3 tools/plan/estimate.py"                   "$PH plan estimate --check"
run_case "wycena: ph → Python"        "$PH plan estimate"                                "python3 tools/plan/estimate.py --check"
run_case "dashboard: Python → ph"     "python3 tools/plan/export_dashboard_data.py"      "$PH plan export --check"
run_case "dashboard: ph → Python"     "$PH plan export"                                  "python3 tools/plan/export_dashboard_data.py --check"
run_case "artefakty: Python → ph"     "python3 tools/artifacts/render_artifacts.py"      "$PH artifacts render --check"
run_case "artefakty: ph → Python"     "$PH artifacts render"                             "python3 tools/artifacts/render_artifacts.py --check"
run_case "notes: Python → ph"         "python3 tools/handover/build_notebook_sources.py" "$PH notes build --check"
run_case "notes: ph → Python"         "$PH notes build"                                  "python3 tools/handover/build_notebook_sources.py --check"
run_case "CODEOWNERS: Python → ph"    "python3 tools/profiles/validate_profiles.py --write-codeowners" "$PH profiles validate --check"
run_case "CODEOWNERS: ph → Python"    "$PH profiles validate --write-codeowners"         "python3 tools/profiles/validate_profiles.py --check"
exit "$FAILED"
