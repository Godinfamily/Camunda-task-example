# Process Hub — własny TaskList dla Camunda 8.9

Repozytorium dokumentacji wykonywalnej (docs-as-code). Wszystko, czego potrzebują ludzie i agenci AI, leży tutaj jako tekst: architektura, decyzje (ADR), profile projektów, scenariusze BDD, plan wykonywalny, wycena i konfiguracja roju agentów (OpenCode z modelem GLM 5.3 Flash uruchomionym w infrastrukturze banku). Narzędzia repozytorium działają w Pythonie albo — gdy Python jest zablokowany — w .NET (`tools/dotnet/`, polecenie `ph`).

Wersja: **v4**. Platforma jest wspólna dla wszystkich projektów; każdy projekt ma **profil** z własnymi rolami, danymi i operacjami (`profiles/`), realizowany niezależnie przez zespół projektu. Wersja 4 dodaje **moduł zarządzania formatkami** w formacie Camunda Forms (wersje, akceptacja, wycofanie, separacja per proces, renderowanie komponentami design systemu — `docs/architecture/14-form-management.md`) i agentów warstwy wizualnej. Plan systemu, aktorzy, przyjęte założenia i wytyczne UI: `docs/artifacts/` (także jako strony `docs/artifacts/index.html` i `docs/artifacts/wytyczne-ui.html`).

## Kolejność czytania

| Kto | Najpierw | Potem |
| --- | --- | --- |
| Decydent, sponsor | `docs/artifacts/index.html` | `plan/dashboard/index.html` |
| Agent AI | `AGENTS.md` | pakiet kroku (`plan/packets/<krok>.md`) → pliki z sekcji „Czytaj” |
| Architekt / tech lead | `docs/architecture/00-overview.md` | `02-roles-and-authorization.md`, `13-project-profiles.md`, `docs/adr/` |
| Zespół profilu projektu | `profiles/README.md`, `docs/guides/dedykowane-elementy-profilu.md` | `profiles/<id>/AGENTS.md`, `profiles/<id>/profile.yaml`, przykład `profiles/flota/`, skill `profile-extension` |
| Biznes / Product Owner | `docs/architecture/01-requirements.md` | `specs/**/*.feature`, `profiles/<id>/specs/` |
| DevOps | `docs/adr/ADR-003…ADR-005`, `ADR-010`, `ADR-014`, `ADR-016` | `docs/opencode/start.md`, `tools/dotnet/README.md` |
| Zespół platformy AI | `docs/agents/multi-model-guide.md` | `config/models.yaml`, `evals/agents/` |
| Projektant UX / frontend | `docs/artifacts/04-wytyczne-ui.md` (start dla nowej osoby) | `design/README.md`, `design/forms/README.md`, `design/mockups/index.html`, `design/tokens.json` |
| Autor formatek, zespół formatek | `docs/architecture/14-form-management.md` | `docs/adr/ADR-018…ADR-020`, `design/forms/field-catalog.yaml`, `specs/forms/` |

## Mapa repozytorium

```
AGENTS.md                     zasady dla agentów i ludzi (czytane automatycznie przez OpenCode) + tabela agentów
CODEOWNERS                    własność kodu: platforma i zespoły profili (generowany)
docs/glossary.md              język wszechobecny (PL ↔ kod)
docs/artifacts/               plan systemu, aktorzy, założenia, wytyczne UI (Markdown + strony HTML)
docs/architecture/00..14      architektura v4 (13 — profile projektów, 14 — moduł zarządzania formatkami)
docs/adr/                     decyzje architektoniczne ADR-001…020
docs/rfc/                     wnioski o zmianę kontraktów, specyfikacji i SDK (np. RFC-FLO-03 → ADR-017)
docs/guides/                  przewodniki dla zespołów: dedykowane elementy procesów w profilu projektu
docs/opencode/start.md        start projektu z OpenCode krok po kroku
docs/agents/multi-model-guide.md  agenci w OpenCode z modelem GLM w banku: warianty, polityka danych, kwalifikacja
docs/handover/                podsumowanie; od-zera/ — prompty odtwarzające repozytorium; notes/ — prompt i źródła do notesu
specs/                        scenariusze Gherkin platformy (Reqnroll, # language: pl)
profiles/                     profile projektów: schemat manifestu, szablon, kredyty (in-process), aml (remote), flota (przykład dedykowanych elementów)
config/authorization/         role platformy i role globalne jako kod
config/models.yaml            model GLM na bramce banku, warianty rozumowania, limity, polityka danych
config/ownership.yaml         właściciele kodu platformy (źródło CODEOWNERS)
plan/execution-plan.md        plan wykonywalny: kroki, fazy, bramki, ścieżka krytyczna
plan/backlog.yaml             ten sam plan w formie maszynowej (orkiestrator)
plan/estimation.md            złożoność, pracochłonność hybrydy AI + ludzie, wrażliwość (+ estimates.yaml, estimation-report.md)
plan/dashboard/               interaktywny dashboard harmonogramu i wyceny (index.html działa z dysku)
.opencode/                    agenci (generowani), skille, komendy, plugin strażnika zapisu
opencode.json                 konfiguracja OpenCode (generowana)
agents/                       kanoniczne role (registry.yaml, prompts/), schematy wyjścia, polityka wykonania
tools/agents/                 generator agentów, prowadzenie kroków (prepare_step, run_dod, plan_status), walidator wyników
tools/guard/                  strażnik zakresu zapisu (OpenCode i CI)
tools/profiles/               walidacja manifestów profili i CODEOWNERS, zakładanie nowego profilu
tools/plan/                   model wyceny i eksport danych dashboardu
tools/dotnet/                 te same narzędzia w C# (.NET 10, bez zewnętrznych paczek) — polecenie `ph`, kod źródłowy i testy
evals/agents/                 kwalifikacja modeli do ról (E01–E11)
design/                       propozycja UI: README, tokens.json, mockups/index.html (klikalna makieta), forms/ (założenia wizualne formatek, katalog pól, formatka wzorcowa)
```

## Status decyzji

Decyzje oznaczone **Proponowana** rozstrzyga faza PoC: kroki S01–S04 (bramka G0 — do tego czasu agenci implementujący nie startują), kroki S07–S09 dla formatek i warstwy wizualnej (bramka G1 — do tego czasu kontrakty modułu formatek nie są zamrażane) oraz krok S27 (izolacja danych profili).
