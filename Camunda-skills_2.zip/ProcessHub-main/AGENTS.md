# AGENTS.md — zasady dla agentów i ludzi

Process Hub zastępuje natywny Tasklist Camunda 8.9: własne UI (Angular), BFF w .NET 10 (modularny monolit), MS SQL Server, SSO w RHBK. Camunda jest jedynym źródłem prawdy o stanie procesu; platforma decyduje, kto co widzi, dodaje warstwę etapów biznesowych, dashboard menadżera, formatki w formacie Camunda Forms (z wersjami, akceptacją i wycofaniem) i pełny audyt. Projekty biznesowe korzystają z platformy przez **profile projektów** (`profiles/<id>/`) — własne role, dane i operacje, realizowane niezależnie przez zespoły projektów.

Agenci działają w OpenCode z modelem uruchomionym wyłącznie w infrastrukturze banku (ADR-016). Model jest wymienny: obowiązuje profil z `config/models.yaml` (dziś GLM 5.3 Flash; kandydaci: Qwen 3.8 27B, Gemma 4 31B — ADR-021). Zasady i procedury w tym pliku nie zależą od modelu. Ten plik OpenCode wczytuje automatycznie.

## Jak pracujesz

1. Przeczytaj pakiet swojego kroku (`plan/packets/<krok>.md`): Cel, Wynik, Wskazówki startowe. Potem pliki z sekcji „Czytaj” — w podanej kolejności i nic poza nimi. Pliki z sekcji „Sięgaj punktowo” przeszukujesz, nie wczytujesz.
2. Pracuj tylko w ścieżkach z `.agent-scope`. Plugin `.opencode/plugin/write-scope.js` (logika: `tools/guard/enforce_write_scope.py`) zablokuje resztę.
3. Zrób dokładnie to, co w sekcji „Wynik” — bez dodatkowych funkcji, plików, zależności i refaktoryzacji „przy okazji”.
4. Zakończ dopiero, gdy przechodzą wszystkie komendy Definition of Done z pakietu; potem zatwierdź zmiany na gałęzi kroku (`git add`, `git commit` — nigdy `push` ani `merge`).
5. Oddaj wynik w formacie przekazania (niżej) — sam JSON. Nie wklejaj logów ani transkryptów.

## Fakty, nie domysły

- Nazwy pliku, klasy, interfejsu, uprawnienia, komendy albo klucza konfiguracji używasz tylko wtedy, gdy widziałeś ją w repozytorium w tej sesji (odczyt albo wyszukiwanie). Nie znalazłeś — nie istnieje; nie zakładaj jej z pamięci.
- Pojęcia tylko ze słownika `docs/glossary.md`; reguły R1–R11 i nazwy uprawnień dokładnie jak w `docs/architecture/02-roles-and-authorization.md`.
- Nowy plik wzorujesz na istniejącym pliku tego samego rodzaju albo na wzorcu ze skilla — nie tworzysz własnego układu.
- Brakuje informacji potrzebnej do wykonania (nazwy, decyzji, pliku) → pytanie w `open_questions` i status `blocked`. Luk nie wypełniasz założeniami.
- Wynik komendy podajesz tylko, jeśli ją uruchomiłeś i zobaczyłeś kod wyjścia; inaczej `skipped`.
- Wszystko, co da się sprawdzić skryptem, sprawdzasz skryptem (`validate_plan.py`, `validate_profiles.py`, `validate_forms.py`, `render_agents.py --check`) i poprawiasz do zielonego.

## Zasady nienaruszalne

1. **Camunda tylko przez moduł `CamundaIntegration`** i wyłącznie przez oficjalne SDK Camunda (ADR-003). Żaden inny moduł ani profil nie zna typów SDK ani adresów Camunda.
2. **Każda akcja jest audytowana** (ADR-005, `docs/architecture/10-audit-and-security.md`) — także operacje profili. Endpoint bez potoku komend/zapytań nie przejdzie testu architektury.
3. **Edycja i zakończenie zadania tylko przez assignee** (reguła R1). Menadżer procesu przekazuje zadania, ale nie edytuje ich treści.
4. **Uprawnienia, nie nazwy ról.** W kodzie sprawdzasz `Permission.TaskReassign` albo uprawnienie profilu (`kredyty.Scoring.Recalculate`), nigdy `role == "Manager"`. Role to dane w `config/authorization/` i `profiles/<id>/`.
5. **`TenantId` wszędzie**, choć dziś jest jeden tenant (`<default>`). Nigdy nie zakładaj jednego tenanta w zapytaniu.
6. **Deny by default.** Brak uprawnienia = odmowa + wpis audytu z wynikiem `Denied`.
7. **Platforma i profile są rozdzielone.** Kod profilu zależy wyłącznie od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); platforma nie zna kodu profili. Krok profilu zmienia tylko `profiles/<id>/**` (reguły R9, R10; ADR-012, ADR-013).
8. **Nie zmieniasz** `specs/**`, `**/Contracts/**`, `docs/adr/**`, `config/authorization/**`, SDK rozszerzeń ani `profiles/*/profile.yaml` i `profiles/*/authorization.yaml`, jeśli nie jesteś ich właścicielem. Potrzebujesz zmiany → plik `docs/rfc/RFC-<krok>-<temat>.md` (wolno go utworzyć w każdym kroku), status `needs-rfc` i stop.
9. **Zakazane zależności:** komercyjne wersje MediatR, AutoMapper, FluentAssertions; każda nowa paczka NuGet/npm wymaga ADR (platforma) albo zgody architekta platformy (profil).
10. **Język:** kod i identyfikatory po angielsku; dokumentacja, teksty UI i Gherkin po polsku (`# language: pl`).
11. **Formatka należy do jednego procesu** (reguła R11) i ma format Camunda Forms; typy pól wyłącznie z katalogu pól (`design/forms/field-catalog.yaml`). Formatek nie wdrażasz do silnika (ADR-018).
12. **Wygląd tylko z design systemu.** Wartości wizualne wyłącznie z `design/tokens.json`, widoki z komponentów `core/ui-kit`; schemat formatki ani renderer nie niosą stylów (ADR-019).

## Komendy

```bash
dotnet build ProcessHub.sln -warnaserror
dotnet test ProcessHub.sln --filter "Category!=integration"     # unit + BDD in-memory
dotnet test tests/ProcessHub.ArchitectureTests                   # granice modułów i profili
dotnet test ProcessHub.sln --filter "Category=integration"      # Testcontainers: MSSQL + Camunda
npx nx affected -t lint test build                               # frontend
npx bpmnlint "bpmn/**/*.bpmn" "profiles/*/bpmn/**/*.bpmn"        # modele procesów
python3 tools/profiles/validate_profiles.py --check              # manifesty profili, CODEOWNERS
python3 tools/plan/validate_plan.py --check                      # spójność planów z repozytorium i rolami agentów
python3 tools/forms/validate_forms.py --check                    # formatki .form ↔ katalog pól ↔ kontrakt ph:outputs
python3 tools/plan/place_step.py <szkic.yaml> [--backlog …]     # miejsce nowego kroku: zależności, bramka, konflikty
python3 tools/refresh.py                                         # wszystko, co generowane + wszystkie bramki repozytorium (--check: tylko sprawdź)
```

Gdy Python jest niedostępny, każde narzędzie z `tools/` ma odpowiednik .NET: `ph <polecenie>` (`tools/dotnet/README.md`), np. `ph profiles validate --check`, `ph guard --self-test`.

## Format przekazania (JSON, ostatnia wiadomość agenta)

```json
{
  "step": "S30",
  "status": "done | blocked | needs-rfc",
  "changed": ["src/Modules/TaskWork/..."],
  "gates": {"build": "pass", "unit": "pass", "bdd": "pass", "arch": "pass"},
  "specs_covered": ["specs/tasks/claim-and-complete.feature"],
  "open_questions": [],
  "rfc": null
}
```

## Gdzie szukać

- Słownik pojęć: `docs/glossary.md`; plan systemu, aktorzy i założenia: `docs/artifacts/`
- Role i uprawnienia: `docs/architecture/02-roles-and-authorization.md`; profile projektów: `docs/architecture/13-project-profiles.md`, `profiles/README.md`
- Dedykowane elementy procesów w profilu (własne menu, strony, dane, operacje): `docs/guides/dedykowane-elementy-profilu.md`; przykład kompletnego profilu: `profiles/flota/`
- Praktyki Camunda z uzasadnieniem: `docs/architecture/06-camunda-integration.md` i skill `camunda-practices`
- Szablon modułu DDD: skill `ddd-module`; rozszerzenie w profilu: skill `profile-extension`; konwencje BDD: skill `reqnroll-bdd`
- Formatki: `docs/architecture/14-form-management.md`, katalog pól `design/forms/field-catalog.yaml`, skill `camunda-forms`
- UI: wytyczne dla nowych osób `docs/artifacts/04-wytyczne-ui.md`, `design/README.md`, formatki `design/forms/README.md`, tokeny `design/tokens.json`, klikalna makieta `design/mockups/index.html`, skill `design-system`
- Nowy profil od zera (role, procesy, formatki, dedykowane widoki): skill `new-profile`; artefakty generowane i wzorce dokumentów (RFC, raport PoC, przekazanie): skill `project-artifacts`; nowy krok w planie platformy albo profilu (zależności, bramka, miejsce): skill `backlog-extension` i `tools/plan/place_step.py`; nowa rola agenta, komenda, skill: skill `plan-maintenance`
- Jak działają agenci, ich uprawnienia i harness (dla ludzi): `docs/artifacts/05-agenci.md`
- Agenci są generowani z `agents/registry.yaml` (`tools/agents/render_agents.py`) — nie edytuj `.opencode/agent/` ręcznie

<!-- ROLE:BEGIN — sekcję generuje tools/agents/render_agents.py; nie edytuj ręcznie -->
## Agenci (OpenCode)

| Agent | Zakres zapisu | Poziom | Model · wariant | Hosting | Klasa danych |
| --- | --- | --- | --- | --- | --- |
| `architect` | platforma (bez `profiles/<id>/**`) | T1 | `glm-5.3-flash` · high | on-prem | confidential |
| `bdd-analyst` | `specs/**`, `docs/rfc/RFC-*.md` | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `bdd-tester` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `camunda-integrator` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `ci-triage` | brak (tylko odczyt) | T3 | `glm-5.3-flash` · low | on-prem | internal |
| `data-engineer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `docs-writer` | `docs/guides/**`, `CHANGELOG.md`, `docs/rfc/RFC-*.md` | T3 | `glm-5.3-flash` · low | on-prem | internal |
| `frontend-developer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `module-implementer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `orchestrator` | `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `reviewer` | brak (tylko odczyt) | T1 | `glm-5.3-flash` · high | on-prem | confidential |
| `ux-designer` | `design/**`, `poc/forms-ui/**`, `docs/rfc/RFC-*.md` | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `design-system-engineer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `ui-reviewer` | brak (tylko odczyt) | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `security-reviewer` | brak (tylko odczyt) | T0 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-module-implementer` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-bdd-tester` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-frontend-developer` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `flota-module-implementer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-bdd-tester` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-frontend-developer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-data-engineer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-module-implementer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-bdd-tester` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-bdd-analyst` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-frontend-developer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-data-engineer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |

Model i warianty pochodzą z profilu modeli w `config/models.yaml` (ADR-021); poziom wybiera model i wariant rozumowania, eskalacja: wyższy wariant, potem człowiek. Wszystkie role używają modelu w infrastrukturze banku (ADR-016); klasa danych decyduje o przeglądzie bezpieczeństwa.
<!-- ROLE:END -->
