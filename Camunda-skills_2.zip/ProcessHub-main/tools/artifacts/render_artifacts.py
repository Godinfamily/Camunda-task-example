#!/usr/bin/env python3
"""Generuje artefakty projektowe: plan systemu, aktorów i założenia (Markdown) oraz stronę docs/artifacts/index.html.

Źródła: docs/artifacts/actors.yaml, docs/artifacts/assumptions.yaml, docs/artifacts/templates/*, profiles/*/profile.yaml,
plan/dashboard/data/*.json (najpierw: tools/plan/estimate.py i tools/plan/export_dashboard_data.py).

  python3 tools/artifacts/render_artifacts.py           # zapisuje pliki
  python3 tools/artifacts/render_artifacts.py --check   # bramka CI: kod 1, gdy pliki są nieaktualne
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / "docs/artifacts"
DATA = ROOT / "plan/dashboard/data"
GENERATED = "<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->"

SPLIT = [
    ("Skrzynka zadań, przejmowanie, szkic, zakończenie (R1–R4)", "Role projektowe z ról platformy i uprawnień projektu"),
    ("Start procesu, moje procesy, przekazywanie, zastępstwa", "Operacje dedykowane na zadaniach i sprawach"),
    ("Eskalacje, dashboard menadżera, mapa etapów, formatki", "Dane projektu w schemacie prj_<id>"),
    ("Audyt każdej akcji, autoryzacje jako kod", "Sloty UI: panel zadania i sprawy, widżet, pole formatki, trasy /p/<id>/"),
    ("Integracja z Camunda (wyłącznie platforma)", "Workery typów zadań <id>.* i integracje z systemami projektu"),
    ("SDK rozszerzeń i jego zgodność wsteczna", "Model integracji in-process albo remote, własny plan i rytm wydań"),
]
LAYERS = [
    ("Repozytorium", "profiles/<id>/** z CODEOWNERS; kontrakt profilu zatwierdza też architekt platformy"),
    ("Kompilacja", "profil zależy tylko od SDK; testy architektury i granice Nx"),
    ("Uprawnienia", "przestrzeń nazw profilu; walidator i reconciler odrzucają naruszenia (R10)"),
    ("Wykonanie", "operacje i dane profilu tylko w procesach profilu (R9)"),
    ("Dane", "schemat i użytkownik bazy per profil; dane platformy przez widoki platform_api"),
    ("Wdrożenie", "in-process w pociągu wydań; remote — niezależnie"),
    ("CI", "filtry ścieżek per profil; strażnik zakresu zmian dla PR zespołu"),
    ("Agenci AI", "agenci profilu zapisują tylko w swoim profilu; agenci platformy — nigdy w profilach"),
]


def load_json(name):
    return json.loads((DATA / f"{name}.json").read_text(encoding="utf-8"))


def n1(v) -> str:
    return f"{round(float(v), 1):.1f}".replace(".", ",")


def profiles():
    out = []
    for d in sorted(p for p in (ROOT / "profiles").iterdir() if p.is_dir() and not p.name.startswith("_")):
        if not (d / "profile.yaml").exists():
            continue
        p = yaml.safe_load((d / "profile.yaml").read_text(encoding="utf-8"))
        ops = [o.get("title") or o["id"].split(".", 1)[1] for o in p.get("operations", []) if o["kind"] in ("task-action", "case-action", "profile-action")]
        out.append({"id": p["id"], "name": p["name"].split(" (")[0], "integration": p.get("integration", "in-process"),
                    "classification": p["data"]["classification"], "processes": [x["bpmnProcessId"] for x in p["processes"]],
                    "operations": ops or ["—"], "team": p["owner"]["team"], "roles": [r["name"] for r in p["roles"]]})
    return out


def plan_md(summary, phases, gates) -> str:
    tmpl = (ART / "templates/01-plan-systemu.md.tmpl").read_text(encoding="utf-8")
    s = summary
    line = (f"Według modelu wyceny pierwszy projekt kończy pilotaż po {n1(s['cal_hyb_weeks'])} tyg. z rojem agentów AI "
            f"(ostrożnie {n1(s['cal_hyb_p80_weeks'])} tyg.), wobec {n1(s['cal_trad_weeks'])} tyg. bez AI, przy {round(s['effort_hyb_pd'])} "
            f"osobodniach pracy ludzi zamiast {round(s['effort_trad_pd'])}.")
    rows = ["| Faza | Tygodnie (najwcześniej) | Kroki | Praca ludzi bez AI | Z AI | Oszczędność |", "| --- | --- | --- | --- | --- | --- |"]
    rows += [f"| {p['phase']} — {p['name']} | {n1(p['start_week'])}–{n1(p['end_week'])} | {p['steps']} | {n1(p['trad_pd'])} | {n1(p['hyb_pd'])} | {round(p['saving'] * 100)}% |"
             for p in phases]
    grows = ["| Bramka | Tydzień | Warunek | Kto decyduje |", "| --- | --- | --- | --- |"]
    grows += [f"| {g['gate']} | {n1(g['week'])} | {g['condition']} | {g['approver']} |" for g in gates]
    return (GENERATED + "\n" + tmpl.replace("{{SUMMARY_LINE}}", line).replace("{{PHASES_TABLE}}", "\n".join(rows))
            .replace("{{GATES_TABLE}}", "\n".join(grows)))


def actors_md(actors) -> str:
    out = [GENERATED, "# Aktorzy Process Hub", "",
           "Kto korzysta z systemu, kto go wytwarza i z jakimi systemami współpracuje. Osoby w kolumnie „Kto” to świat testowy ze scenariuszy BDD (`specs/README.md`). Źródło: `actors.yaml`.", "",
           "```mermaid", "flowchart LR",
           '  subgraph B["Użytkownicy biznesowi"]', '    UB["Uczestnik · Inicjator · Menadżer procesu<br/>Administrator procesu · Audytor · Administrator platformy"]',
           '    UP["Role projektowe z profili<br/>np. Analityk kredytowy, Underwriter, Analityk AML"]', "  end",
           '  subgraph W["Wytwarzanie"]', '    TP["Zespół platformy"]', '    TPR["Zespoły profili projektów"]', '    AI["Rój agentów AI<br/>OpenCode + model w banku"]', "  end",
           '  PH["Process Hub<br/>platforma + profile"]', '  CAM[("Camunda 8.9")]', '  IDP[("RHBK + AD")]', '  DB[("MS SQL Server")]', '  SYS["Systemy i usługi projektów"]',
           "  UB --> PH", "  UP --> PH", "  TP -->|platforma, SDK| PH", "  TPR -->|profiles/&lt;id&gt;| PH", "  AI -.->|pakiety robocze, człowiek scala| PH",
           "  PH --> CAM", "  PH --> IDP", "  PH --> DB", "  PH --> SYS", "```", ""]
    for g in actors["groups"]:
        out += [f"## {g['name']}", "", g["note"], "", "| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |", "| --- | --- | --- | --- | --- | --- | --- |"]
        for a in actors["actors"]:
            if a["group"] == g["id"]:
                out.append(f"| {a['id']} | {a['name']} | {a.get('persona') or '—'} | {a['goal']} | {a['does']} | {a.get('rules') or '—'} | {a.get('reqs') or '—'} |")
        out.append("")
    return "\n".join(out)


def assumptions_md(data) -> str:
    items = data["assumptions"]
    counts = {s: sum(1 for a in items if a["status"] == s) for s in ("przyjęte", "do weryfikacji", "decyzja otwarta")}
    out = [GENERATED, "# Założenia Process Hub", "",
           f"Rejestr {len(items)} założeń: {counts['przyjęte']} przyjętych, {counts['do weryfikacji']} do weryfikacji w PoC lub w trakcie prac, "
           f"{counts['decyzja otwarta']} czekających na decyzję. Każde ma źródło, punkt sprawdzenia i skutek, jeśli okaże się nieprawdą. Źródło: `assumptions.yaml`.", ""]
    for cat in data["categories"]:
        rows = [a for a in items if a["category"] == cat]
        if not rows:
            continue
        out += [f"## {cat}", "", "| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |", "| --- | --- | --- | --- | --- | --- |"]
        out += [f"| {a['id']} | {a['statement']} | {a['source']} | {a['status']} | {a['verify']} | {a['impact']} |" for a in rows]
        out.append("")
    return "\n".join(out)


def index_html(summary, phases, gates, decisions, actors, assumptions, profs, stamp) -> str:
    data = {"summary": summary, "phases": phases, "gates": gates, "decisions": decisions, "actors": actors,
            "assumptions": assumptions, "profiles": profs, "split": SPLIT, "layers": LAYERS, "generated": stamp}
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    return (ART / "templates/index.html.tmpl").read_text(encoding="utf-8").replace("/*__DATA__*/", blob)


def readme() -> str:
    return "\n".join([
        "# Artefakty projektowe", "",
        "Plan systemu, aktorzy, przyjęte założenia i wytyczne UI — dla decydentów, zespołów platformy i profili oraz dla agentów AI. Pliki 01–03 i strona `index.html` są generowane; źródła edytujesz ręcznie.", "",
        "| Plik | Zawartość | Źródło |", "| --- | --- | --- |",
        "| `index.html` | strona do przeglądania (działa z dysku, jasny i ciemny motyw, telefon) | wszystkie poniższe |",
        "| `01-plan-systemu.md` | system w kontekście, część wspólna i specyficzna, przepływy, plan realizacji, wytwarzanie | `templates/01-plan-systemu.md.tmpl` + dane planu |",
        "| `02-aktorzy.md` | użytkownicy, role projektowe, zespoły, systemy | `actors.yaml` |",
        "| `03-zalozenia.md` | rejestr założeń ze statusem, źródłem, sprawdzeniem i skutkiem | `assumptions.yaml` |",
        "| `04-wytyczne-ui.md`, `wytyczne-ui.html` | wytyczne i założenia interfejsu dla osób zaczynających pracę nad UI (pisane ręcznie; strona działa z dysku) | `design/README.md`, `design/tokens.json`, `design/forms/` |", "",
        "Odświeżenie (po zmianie planu, profili lub rejestrów):", "", "```bash",
        "python3 tools/plan/estimate.py && python3 tools/plan/export_dashboard_data.py",
        "python3 tools/artifacts/render_artifacts.py",
        "# bez Pythona: ph plan estimate && ph plan export && ph artifacts render", "```", ""])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    summary = load_json("summary")[0]
    phases, gates, decisions = load_json("phases"), load_json("gates"), load_json("decisions")
    stamp = json.loads((DATA / "_generated.json").read_text(encoding="utf-8"))["at"][:10]
    actors = yaml.safe_load((ART / "actors.yaml").read_text(encoding="utf-8"))
    assumptions = yaml.safe_load((ART / "assumptions.yaml").read_text(encoding="utf-8"))
    profs = profiles()
    outputs = {
        ART / "01-plan-systemu.md": plan_md(summary, phases, gates),
        ART / "02-aktorzy.md": actors_md(actors),
        ART / "03-zalozenia.md": assumptions_md(assumptions),
        ART / "index.html": index_html(summary, phases, gates, decisions, actors, assumptions, profs, stamp),
        ART / "README.md": readme(),
    }
    stale = [p for p, c in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != c]
    if args.check:
        for p in stale:
            print(f"NIEAKTUALNE: {p.relative_to(ROOT)}", file=sys.stderr)
        return 1 if stale else 0
    for p in stale:
        p.write_text(outputs[p], encoding="utf-8")
    print(f"zapisano {len(stale)} plików artefaktów, bez zmian {len(outputs) - len(stale)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
