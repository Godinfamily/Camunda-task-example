using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>
/// Formatki .form (Camunda Forms) względem katalogu pól i kontraktu ph:outputs z BPMN (= tools/forms/validate_forms.py).
/// Formatki wzorcowe: design/forms/examples; formatki profilu do importu: profiles/&lt;id&gt;/forms/&lt;bpmnProcessId&gt;/&lt;klucz&gt;.form.
/// </summary>
public static class Forms
{
    private const string StartForm = "start";
    private static readonly HashSet<string> TopLevel = new()
    {
        "type", "id", "schemaVersion", "executionPlatform", "executionPlatformVersion", "exporter", "components", "versionTag",
    };

    private static readonly HashSet<string> StyleKeys = new()
    {
        "style", "styles", "class", "className", "css", "color", "background", "font", "fontSize", "margin", "padding", "border",
    };

    private static readonly Regex KeyRe = new("^\\w+(\\.\\w+)*$", RegexOptions.Compiled);
    private static readonly XNamespace Bpmn = "http://www.omg.org/spec/BPMN/20100524/MODEL";
    private static readonly XNamespace Zeebe = "http://camunda.org/schema/zeebe/1.0";

    /// <summary>Wszystkie komponenty schematu z prefiksem klucza danych (kontenery z `path` dodają segment).</summary>
    private static void Walk(object? components, string prefix, List<(PyDict Component, string Prefix)> result)
    {
        if (components is not List<object?> list)
        {
            return;
        }

        foreach (var item in list)
        {
            if (item is not PyDict c)
            {
                continue;
            }

            result.Add((c, prefix));
            if (c.Get("components") is List<object?>)
            {
                var path = c.Get("path") as string;
                Walk(c["components"], string.IsNullOrEmpty(path) ? prefix : $"{prefix}{path}.", result);
            }
        }
    }

    private static string Label(PyDict c)
    {
        foreach (var key in new[] { "id", "key", "type" })
        {
            if (Py.Truthy(c.Get(key)))
            {
                return Py.ToStr(c.Get(key));
            }
        }

        return "None";
    }

    public static (List<string> Errors, HashSet<string> Keys) CheckForm(string file, PyDict catalog, PyDict? profile)
    {
        var errors = new List<string>();
        var keys = new HashSet<string>(StringComparer.Ordinal);
        PyDict doc;
        try
        {
            doc = Py.Dict(PyJson.Loads(Repo.Read(file)));
        }
        catch (JsonException e)
        {
            return (new List<string> { $"niepoprawny JSON: {e.Message}" }, keys);
        }
        catch (InvalidDataException e)
        {
            return (new List<string> { $"niepoprawny JSON: {e.Message}" }, keys);
        }

        var stem = Path.GetFileNameWithoutExtension(file);
        var lib = Py.Dict(catalog["library"]);
        var types = new Dictionary<string, PyDict>(StringComparer.Ordinal);
        foreach (var t in Py.List(catalog["types"]).Select(Py.Dict))
        {
            types[Py.Str(t["type"])] = t;
        }

        foreach (var extra in doc.Keys.Where(k => !TopLevel.Contains(k)).OrderBy(k => k, StringComparer.Ordinal))
        {
            errors.Add($"pole najwyższego poziomu „{extra}” nie należy do formatu Camunda Forms");
        }

        if (doc.Get("type") as string != "default")
        {
            errors.Add("type musi mieć wartość \"default\"");
        }

        if (doc.Get("id") as string != stem && profile != null && stem != StartForm)
        {
            errors.Add($"id „{Py.ToStr(doc.Get("id"))}” musi być równe nazwie pliku „{stem}” (klucz formatki)");
        }

        var schemaMax = Py.Int(lib["schema_version_max"]);
        if (doc.Get("schemaVersion") is not long schemaVersion || schemaVersion > schemaMax)
        {
            errors.Add($"schemaVersion musi być liczbą ≤ {schemaMax}");
        }

        var platform = Py.Str(lib["execution_platform"]);
        var platformVersion = Py.Str(lib["execution_platform_version"]);
        if (doc.Get("executionPlatform") as string != platform || doc.Get("executionPlatformVersion") as string != platformVersion)
        {
            errors.Add($"executionPlatform / executionPlatformVersion: wymagane „{platform}” / „{platformVersion}”");
        }

        var ids = new HashSet<string?>();
        var components = new List<(PyDict Component, string Prefix)>();
        Walk(doc.Get("components"), string.Empty, components);
        foreach (var (c, prefix) in components)
        {
            var where = Label(c);
            var typeName = c.Get("type") as string;
            if (typeName == null || !types.TryGetValue(typeName, out var type))
            {
                errors.Add($"{where}: typ „{Py.ToStr(c.Get("type"))}” nie występuje w katalogu pól");
            }
            else
            {
                var status = Py.Str(type["status"]);
                if (status != "supported" && status != "restricted")
                {
                    errors.Add($"{where}: typ „{typeName}” ma status „{status}” — nie wolno go użyć");
                }
            }

            var id = c.Get("id") as string;
            if (ids.Contains(id))
            {
                errors.Add($"{where}: powtórzone id");
            }

            ids.Add(id);
            foreach (var bad in c.Keys.Where(k => StyleKeys.Contains(k)).OrderBy(k => k, StringComparer.Ordinal))
            {
                errors.Add($"{where}: własność wyglądu „{bad}” — schemat nie niesie stylów (ADR-019)");
            }

            if (c.Get("properties") is PyDict properties)
            {
                foreach (var prop in properties)
                {
                    if (!prop.Key.StartsWith("ph:", StringComparison.Ordinal))
                    {
                        errors.Add($"{where}: własność „{prop.Key}” spoza przestrzeni ph:");
                    }
                    else if (prop.Key == "ph:field" && profile != null && !Py.ToStr(prop.Value).StartsWith(Py.Str(profile["id"]) + ".", StringComparison.Ordinal))
                    {
                        errors.Add($"{where}: ph:field „{Py.ToStr(prop.Value)}” spoza przestrzeni nazw profilu {Py.Str(profile["id"])}. (R10)");
                    }
                    else if (prop.Key == "ph:field" && profile == null)
                    {
                        errors.Add($"{where}: ph:field wolno użyć tylko w formatkach procesów profilu (R9)");
                    }
                }
            }

            var columns = (c.Get("layout") as PyDict)?.Get("columns");
            if (columns != null && !(columns is long width && width >= 2 && width <= 16))
            {
                errors.Add($"{where}: layout.columns musi być puste albo z zakresu 2–16");
            }

            if (c.ContainsKey("key"))
            {
                var key = Py.ToStr(c["key"]);
                if (!KeyRe.IsMatch(key))
                {
                    errors.Add($"{where}: klucz „{key}” niezgodny ze wzorcem ^\\w+(\\.\\w+)*$");
                }

                var full = prefix + key;
                if (!keys.Add(full))
                {
                    errors.Add($"{where}: powtórzony klucz danych „{full}”");
                }

                if (!Py.Truthy(c.Get("label")))
                {
                    errors.Add($"{where}: pole danych bez etykiety (label)");
                }
            }
        }

        return (errors, keys);
    }

    /// <summary>bpmnProcessId → (klucz formatki albo „start” → zmienne z ph:outputs), w kolejności plików i elementów.</summary>
    private static List<(string Process, List<(string Key, List<string> Outputs)> Forms)> BpmnContracts(string profileDir)
    {
        var result = new List<(string Process, List<(string Key, List<string> Outputs)> Forms)>();
        var bpmnDir = Path.Combine(profileDir, "bpmn");
        if (!Directory.Exists(bpmnDir))
        {
            return result;
        }

        foreach (var file in Directory.EnumerateFiles(bpmnDir, "*.bpmn", SearchOption.AllDirectories).OrderBy(f => f, StringComparer.Ordinal))
        {
            XElement? root;
            try
            {
                root = XDocument.Load(file).Root;
            }
            catch (XmlException)
            {
                continue;
            }

            if (root == null)
            {
                continue;
            }

            foreach (var process in root.Elements(Bpmn + "process"))
            {
                var processId = process.Attribute("id")?.Value ?? string.Empty;
                var entry = result.FindIndex(r => r.Process == processId);
                if (entry < 0)
                {
                    result.Add((processId, new List<(string Key, List<string> Outputs)>()));
                    entry = result.Count - 1;
                }

                var forms = result[entry].Forms;
                var elements = process.Descendants(Bpmn + "userTask").Concat(process.Descendants(Bpmn + "startEvent")).ToList();
                foreach (var el in elements)
                {
                    var outputsProperty = el.Descendants(Zeebe + "property").FirstOrDefault(p => p.Attribute("name")?.Value == "ph:outputs");
                    var outputs = outputsProperty == null ? null : outputsProperty.Attribute("value")?.Value ?? string.Empty;
                    string? key = null;
                    if (el.Name.LocalName == "startEvent")
                    {
                        key = outputs != null ? StartForm : null;
                    }
                    else
                    {
                        var reference = el.Descendants(Zeebe + "formDefinition").FirstOrDefault()?.Attribute("externalReference")?.Value ?? string.Empty;
                        key = reference.StartsWith("ph:form/", StringComparison.Ordinal) ? reference.Substring("ph:form/".Length) : null;
                    }

                    if (string.IsNullOrEmpty(key))
                    {
                        continue;
                    }

                    var names = (outputs ?? string.Empty).Split(',').Where(o => o.Trim().Length > 0).Select(o => o.Split(':')[0].Trim()).ToList();
                    var existing = forms.FindIndex(f => f.Key == key);
                    if (existing >= 0)
                    {
                        forms[existing] = (key, names);
                    }
                    else
                    {
                        forms.Add((key, names));
                    }
                }
            }
        }

        return result;
    }

    private static List<string> DefaultFiles()
    {
        var files = new List<string>();
        var examples = Repo.P("design/forms/examples");
        if (Directory.Exists(examples))
        {
            files.AddRange(Directory.EnumerateFiles(examples, "*.form").OrderBy(f => f, StringComparer.Ordinal));
        }

        var profiles = Repo.P("profiles");
        if (Directory.Exists(profiles))
        {
            var found = new List<string>();
            foreach (var dir in Directory.GetDirectories(profiles).Where(d => !Path.GetFileName(d).StartsWith("_", StringComparison.Ordinal)))
            {
                var forms = Path.Combine(dir, "forms");
                if (Directory.Exists(forms))
                {
                    found.AddRange(Directory.EnumerateFiles(forms, "*.form", SearchOption.AllDirectories));
                }
            }

            files.AddRange(found.OrderBy(f => f, StringComparer.Ordinal));
        }

        return files;
    }

    public static int Validate(string[] args)
    {
        var cli = new Cli("użycie: ph forms validate [--check] [plik.form…]", args, new[] { "--check" }, Array.Empty<string>(), 0, 999);
        var catalog = Py.Dict(Repo.Yaml("design/forms/field-catalog.yaml"));
        var explicitFiles = cli.Positional.Select(f => Path.GetFullPath(f)).ToList();
        var files = explicitFiles.Count > 0 ? explicitFiles : DefaultFiles();
        var errors = 0;
        var warnings = 0;
        var seen = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);      // "<profil>|<proces>/<klucz>" → klucze pól
        var manifests = new Dictionary<string, PyDict>(StringComparer.Ordinal);
        foreach (var file in files)
        {
            var rel = Repo.Rel(file);
            var parts = rel.Split('/');
            PyDict? profile = null;
            var found = new List<string>();
            if (parts[0] == "profiles" && parts.Length > 1)
            {
                var pid = parts[1];
                if (!manifests.TryGetValue(pid, out profile))
                {
                    profile = Py.Dict(MiniYaml.LoadFile(Repo.P($"profiles/{pid}/profile.yaml")));
                    manifests[pid] = profile;
                }

                if (parts.Length != 5 || parts[2] != "forms")
                {
                    found.Add("formatka profilu musi leżeć w profiles/<id>/forms/<bpmnProcessId>/<klucz>.form");
                }
                else if (!Py.List(profile["processes"]).Select(p => Py.Str(Py.Dict(p)["bpmnProcessId"])).Contains(parts[3]))
                {
                    found.Add($"proces „{parts[3]}” nie należy do profilu {pid} (R9, R11)");
                }
            }

            var (formErrors, keys) = CheckForm(file, catalog, profile);
            found.AddRange(formErrors);
            if (profile != null && parts.Length == 5)
            {
                seen[$"{parts[1]}|{parts[3]}/{Path.GetFileNameWithoutExtension(file)}"] = keys;
            }

            foreach (var e in found)
            {
                Console.WriteLine($"BŁĄD        {rel}: {e}");
            }

            errors += found.Count;
        }

        if (explicitFiles.Count == 0 && Directory.Exists(Repo.P("profiles")))
        {
            var dirs = Directory.GetDirectories(Repo.P("profiles")).Where(d => !Path.GetFileName(d).StartsWith("_", StringComparison.Ordinal))
                .OrderBy(d => d, StringComparer.Ordinal);
            foreach (var dir in dirs)
            {
                var pid = Path.GetFileName(dir);
                foreach (var (process, forms) in BpmnContracts(dir))
                {
                    foreach (var (key, outputs) in forms)
                    {
                        var target = $"profiles/{pid}/forms/{process}/{key}.form";
                        if (!seen.TryGetValue($"{pid}|{process}/{key}", out var keys))
                        {
                            if (!cli.Flag("--check"))
                            {
                                Console.WriteLine($"OSTRZEŻENIE {target}: brak pliku dla referencji z BPMN (formatkę można też utworzyć w projektancie)");
                            }

                            warnings++;
                            continue;
                        }

                        foreach (var missing in outputs.Where(o => !keys.Contains(o)))
                        {
                            Console.WriteLine($"BŁĄD        {target}: brak pola „{missing}” wymaganego przez ph:outputs w BPMN");
                            errors++;
                        }
                    }
                }
            }
        }

        Console.WriteLine($"formatek: {files.Count} · błędów: {errors} · ostrzeżeń: {warnings}");
        return errors > 0 ? 1 : 0;
    }
}
