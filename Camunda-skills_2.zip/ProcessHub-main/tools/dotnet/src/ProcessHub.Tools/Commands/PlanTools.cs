using System.Globalization;
using System.Text.RegularExpressions;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>
/// Spójność planu z repozytorium i konfiguracją agentów (= tools/plan/validate_plan.py): graf zależności, bramki,
/// role, `reads`, scenariusze, bramka zakresu w `dod`, budżet kontekstu, konflikty zapisu kroków równoległych.
/// </summary>
public sealed class PlanCheck
{
    public const string ScopeGate = "enforce_write_scope.py --verify-diff";
    private const double BytesPerToken = 3.0;
    private const double ReadsWarn = 0.35;
    private static readonly HashSet<string> WriteTools = new() { "edit_file", "write_file" };
    private static readonly string[] Runners = { "dotnet ", "npx ", "npm ", "node ", "python3 ", "ph ", "test " };
    private static readonly Regex TagRe = new("@[\\w-]+", RegexOptions.Compiled);

    public static readonly Dictionary<long, string[]> PhaseGates = new()
    {
        [1] = new[] { "G0" },
        [2] = new[] { "G0", "G1" },
        [3] = new[] { "G0", "G1" },
        [4] = new[] { "G0", "G1" },
        [5] = new[] { "G0", "G1", "G2" },
        [6] = new[] { "G0", "G1", "G2", "G3" },
    };

    private readonly Dictionary<string, PyDict> _roles = new(StringComparer.Ordinal);
    private readonly long _context;

    public PlanCheck(string backlog, PyDict registry, PyDict models, PlanCheck? platform = null)
    {
        Rel = backlog;
        Data = Py.Dict(Repo.Yaml(backlog));
        Profile = Data.Get("profile") as string;
        foreach (var s in Py.List(Data["steps"]).Select(Py.Dict))
        {
            var id = Py.Str(s["id"]);
            Steps[id] = s;
            Order.Add(id);
        }

        Gates = Data.Get("gates") as PyDict ?? new PyDict();
        foreach (var r in Py.List(registry["roles"]).Select(Py.Dict))
        {
            _roles[Py.Str(r["name"])] = r;
        }

        Platform = platform;
        var envProfile = Environment.GetEnvironmentVariable("PH_MODEL_PROFILE");
        var prof = Py.Dict(Py.Dict(models["profiles"])[string.IsNullOrEmpty(envProfile) ? Py.Str(models["default_profile"]) : envProfile]);
        _context = prof.Get("context_limit_tokens") is long limit ? limit : 0;
    }

    public string Rel { get; }

    public PyDict Data { get; }

    public string? Profile { get; }

    public Dictionary<string, PyDict> Steps { get; } = new(StringComparer.Ordinal);

    /// <summary>Identyfikatory kroków w kolejności pliku (słownik nie gwarantuje kolejności).</summary>
    public List<string> Order { get; } = new();

    public PyDict Gates { get; }

    public PlanCheck? Platform { get; }

    public List<string> Errors { get; } = new();

    public List<string> Warnings { get; } = new();

    // --- globy --------------------------------------------------------------------------------------------------

    /// <summary>Czy istnieje nazwa pasująca do obu wzorców jednego segmentu ścieżki.</summary>
    public static bool SegOverlap(string a, string b)
    {
        if (a == b || a == "*" || b == "*")
        {
            return true;
        }

        var plainA = a.Replace("*", string.Empty);
        var plainB = b.Replace("*", string.Empty);
        var candidates = new[] { plainA, plainB, a.Replace("*", plainB), b.Replace("*", plainA) };
        return candidates.Any(c => Glob.FnMatch(c, a) && Glob.FnMatch(c, b));
    }

    private static (List<string> Head, List<string> Tail, bool Deep) Parts(string glob)
    {
        var segs = glob.Split('/').ToList();
        var cut = segs.IndexOf("**");
        if (cut < 0)
        {
            return (segs, new List<string>(), false);
        }

        return (segs.Take(cut).ToList(), segs.Skip(cut).Where(x => x != "**").ToList(), true);
    }

    /// <summary>Czy dwa globy zakresu zapisu mogą wskazać ten sam plik.</summary>
    public static bool GlobOverlap(string a, string b)
    {
        var (headA, tailA, deepA) = Parts(a);
        var (headB, tailB, deepB) = Parts(b);
        var common = Math.Min(headA.Count, headB.Count);
        for (var i = 0; i < common; i++)
        {
            if (!SegOverlap(headA[i], headB[i]))
            {
                return false;
            }
        }

        if (headA.Count != headB.Count && !(headA.Count < headB.Count ? deepA : deepB))
        {
            return false;
        }

        if (headA.Count == headB.Count && deepA != deepB)
        {
            return false;
        }

        return !(tailA.Count > 0 && tailB.Count > 0) || SegOverlap(tailA[0], tailB[0]);
    }

    /// <summary>Czy ścieżka (albo katalog) leży w zakresie globów.</summary>
    public static bool Covered(string path, IEnumerable<string> globs) =>
        globs.Any(g => Glob.FnMatch(path, g) || Glob.FnMatch(path + "/x", g));

    // --- graf ---------------------------------------------------------------------------------------------------

    public PyDict? Step(string id)
    {
        if (Steps.TryGetValue(id, out var own))
        {
            return own;
        }

        return Platform != null && Platform.Steps.TryGetValue(id, out var other) ? other : null;
    }

    public static long PhaseOf(PyDict step) => step.Get("phase") is long phase ? phase : 0;

    public HashSet<string> Ancestors(string id, HashSet<string>? seen = null)
    {
        seen ??= new HashSet<string>(StringComparer.Ordinal);
        var step = Step(id);
        if (step == null)
        {
            return seen;
        }

        foreach (var dep in Py.Strings(step.Get("depends_on")))
        {
            if (!seen.Contains(dep) && Step(dep) != null)
            {
                seen.Add(dep);
                Ancestors(dep, seen);
            }
        }

        return seen;
    }

    public bool BehindGate(string id, string gate)
    {
        var all = Ancestors(id);
        all.Add(id);
        return all.Any(x => Step(x)?.Get("gate_before") as string == gate);
    }

    /// <summary>Krok `a` na pewno kończy się przed startem `b`: `b` zależy od `a` albo dzieli je bramka.</summary>
    public bool Precedes(string a, string b)
    {
        if (Ancestors(b).Contains(a))
        {
            return true;
        }

        foreach (var gate in Gates)
        {
            var after = Py.Strings(Py.Dict(gate.Value).Get("after")).ToList();
            var before = new HashSet<string>(after, StringComparer.Ordinal);
            foreach (var g in after)
            {
                before.UnionWith(Ancestors(g));
            }

            if (before.Contains(a) && BehindGate(b, gate.Key))
            {
                return true;
            }
        }

        return false;
    }

    public bool Ordered(string a, string b) => Precedes(a, b) || Precedes(b, a);

    public List<(string A, string B, string X, string Y)> Conflicts(IReadOnlyList<string>? ids = null)
    {
        var list = ids ?? Order.Where(i => Py.Str(Steps[i]["agent"]) != "human").ToList();
        var found = new List<(string, string, string, string)>();
        for (var n = 0; n < list.Count; n++)
        {
            for (var m = n + 1; m < list.Count; m++)
            {
                var a = list[n];
                var b = list[m];
                if (Ordered(a, b))
                {
                    continue;
                }

                var hit = FirstOverlap(Py.Strings(Steps[a].Get("writes")), Py.Strings(Steps[b].Get("writes")).ToList());
                if (hit != null)
                {
                    found.Add((a, b, hit.Value.X, hit.Value.Y));
                }
            }
        }

        return found;
    }

    public static (string X, string Y)? FirstOverlap(IEnumerable<string> first, IReadOnlyList<string> second)
    {
        foreach (var x in first)
        {
            foreach (var y in second)
            {
                if (GlobOverlap(x, y))
                {
                    return (x, y);
                }
            }
        }

        return null;
    }

    // --- kontrole -----------------------------------------------------------------------------------------------

    public void Err(string id, string message) => Errors.Add($"{id}: {message}");

    public void Warn(string id, string message) => Warnings.Add($"{id}: {message}");

    public void Run(string handoffPattern, PyDict? estimates, List<string>? devAgents)
    {
        foreach (var gate in Gates)
        {
            foreach (var id in Py.Strings(Py.Dict(gate.Value).Get("after")))
            {
                if (!Steps.ContainsKey(id))
                {
                    Err(gate.Key, $"bramka wskazuje nieznany krok {id}");
                }
            }
        }

        foreach (var id in Order)
        {
            var s = Steps[id];
            if (!Regex.IsMatch(id, handoffPattern))
            {
                Err(id, $"identyfikator niezgodny ze schematem przekazania ({handoffPattern})");
            }

            foreach (var dep in Py.Strings(s.Get("depends_on")))
            {
                if (Step(dep) == null)
                {
                    Err(id, $"nieznana zależność {dep}");
                }
                else if (Steps.TryGetValue(dep, out var depStep) && PhaseOf(depStep) > PhaseOf(s))
                {
                    Warn(id, $"zależy od kroku {dep} z późniejszej fazy");
                }
            }

            if (Ancestors(id).Contains(id))
            {
                Err(id, "cykl zależności");
            }

            if (s.Get("gate_before") is string gateBefore && gateBefore.Length > 0 && !Gates.ContainsKey(gateBefore))
            {
                Err(id, $"nieznana bramka {gateBefore}");
            }

            if (Profile == null && PhaseGates.TryGetValue(PhaseOf(s), out var required))
            {
                foreach (var g in required)
                {
                    if (Gates.ContainsKey(g) && !BehindGate(id, g))
                    {
                        Warn(id, $"faza {PhaseOf(s)}, ale krok może ruszyć przed bramką {g}");
                    }
                }
            }

            CheckAgents(id, s, devAgents);
            CheckReads(id, s);
            CheckSpecs(id, s);
            CheckDod(id, s);
            if (Profile != null)
            {
                var own = $"profiles/{Profile}/";
                foreach (var w in Py.Strings(s.Get("writes")))
                {
                    if (!w.StartsWith(own, StringComparison.Ordinal))
                    {
                        Err(id, $"zapis poza profilem: {w}");
                    }
                }
            }
        }

        if (estimates != null)
        {
            var missing = Steps.Keys.Where(k => !estimates.ContainsKey(k)).Concat(estimates.Keys.Where(k => !Steps.ContainsKey(k)));
            foreach (var id in missing.OrderBy(x => x, StringComparer.Ordinal))
            {
                Err(id, "brak pary krok ↔ wycena (plan/estimates.yaml)");
            }
        }

        foreach (var (a, b, x, y) in Conflicts())
        {
            Warn(a, $"może być gotowy równocześnie z {b}, a zakresy zapisu się nakładają ({x} ↔ {y}) — prowadź po kolei albo zawęź `writes`");
        }
    }

    public void CheckAgents(string id, PyDict s, List<string>? devAgents)
    {
        var agent = Py.Str(s["agent"]);
        if (agent == "human")
        {
            return;
        }

        foreach (var field in new[] { "agent", "pair" })
        {
            if (s.Get(field) is not string name || name.Length == 0)
            {
                continue;
            }

            if (!_roles.ContainsKey(name))
            {
                Err(id, $"{field}: nieznana rola {name}");
            }
            else if (devAgents != null && !devAgents.Contains(name) && field == "agent")
            {
                Err(id, $"rola {name} nie jest na liście dev.agents profilu {Profile}");
            }
        }

        if (!_roles.TryGetValue(agent, out var role))
        {
            return;
        }

        var writes = Py.Strings(s.Get("writes")).ToList();
        if (writes.Count > 0 && !Py.Strings(role["tools"]).Any(t => WriteTools.Contains(t)))
        {
            Err(id, $"wykonawca {agent} nie ma narzędzi zapisu, a krok ma `writes`");
        }

        var roleTier = Py.Str(role["tier"]);
        if (s.Get("tier") is string tier && tier.Length > 0 && tier != roleTier)
        {
            Warn(id, $"poziom {tier} inny niż w rejestrze roli {agent} ({roleTier}) — obowiązuje rejestr");
        }

        var roleWrites = Py.Strings(role.Get("writes")).ToList();
        if (roleWrites.Count > 0 && Profile == null)
        {
            foreach (var w in writes)
            {
                if (!roleWrites.Any(allowed => GlobOverlap(w, allowed)))
                {
                    Err(id, $"rola {agent} nie może zapisywać w {w} (agents/registry.yaml: writes)");
                }
            }
        }
    }

    public void CheckReads(string id, PyDict s)
    {
        var produced = new List<string>();
        foreach (var dep in Ancestors(id))
        {
            var step = Step(dep);
            if (step != null)
            {
                produced.AddRange(Py.Strings(step.Get("writes")));
            }
        }

        long size = 0;
        foreach (var r in Py.Strings(s.Get("reads")))
        {
            var path = Repo.P(r);
            if (File.Exists(path))
            {
                size += new FileInfo(path).Length;
            }
            else if (Directory.Exists(path))
            {
                size += Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length);
            }
            else if (!Covered(r, produced))
            {
                Err(id, $"`reads`: {r} nie istnieje i nie tworzy go żaden poprzednik");
            }
        }

        var tokens = (long)(size / BytesPerToken);
        if (_context > 0 && tokens > ReadsWarn * _context)
        {
            var percent = PyFloat.RoundToInt(100.0 * tokens / _context);
            Warn(id, $"`reads` to ok. {tokens / 1000} tys. tokenów ({percent}% kontekstu) — przenieś duże pliki do `refs`");
        }
    }

    public void CheckSpecs(string id, PyDict s)
    {
        foreach (var spec in Py.Strings(s.Get("specs")))
        {
            var path = spec.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)[0];
            var file = Repo.P(path);
            if (!File.Exists(file))
            {
                Err(id, $"`specs`: brak pliku {path}");
                continue;
            }

            var text = Repo.Read(file);
            foreach (Match tag in TagRe.Matches(spec))
            {
                if (!text.Contains(tag.Value, StringComparison.Ordinal))
                {
                    Err(id, $"`specs`: {path} nie ma tagu {tag.Value}");
                }
            }
        }
    }

    public void CheckDod(string id, PyDict s)
    {
        var dod = Py.Truthy(s.Get("dod")) ? Py.Strings(s["dod"]).ToList() : Py.Strings(Data.Get("common_dod")).ToList();
        foreach (var cmd in dod)
        {
            if (!Runners.Any(r => cmd.StartsWith(r, StringComparison.Ordinal)))
            {
                Err(id, $"`dod`: „{cmd}” nie jest komendą — kryteria dla człowieka wpisz w `acceptance`");
            }
        }

        if (Py.Str(s["agent"]) != "human" && !dod.Any(c => c.Contains(ScopeGate, StringComparison.Ordinal)))
        {
            Err(id, "`dod` nie zawiera bramki zakresu (enforce_write_scope.py --verify-diff)");
        }
    }

    /// <summary>Lista dev.agents z manifestu profilu albo null, gdy plan nie jest planem profilu lub manifestu brak.</summary>
    public List<string>? DevAgents()
    {
        if (Profile == null)
        {
            return null;
        }

        var manifest = Path.Combine(Path.GetDirectoryName(Repo.P(Rel))!, "profile.yaml");
        if (!File.Exists(manifest))
        {
            return null;
        }

        var dev = Py.Dict(MiniYaml.LoadFile(manifest)).Get("dev") as PyDict;
        return dev?.Get("agents") is List<object?> agents ? agents.Select(Py.Str).ToList() : null;
    }
}

/// <summary>ph plan validate i ph plan place (= tools/plan/validate_plan.py, tools/plan/place_step.py).</summary>
public static class PlanTools
{
    private const string PlatformBacklog = "plan/backlog.yaml";

    private static (PyDict Registry, PyDict Models, PlanCheck Platform) LoadPlatform()
    {
        var registry = Py.Dict(Repo.Yaml("agents/registry.yaml"));
        var models = Py.Dict(Repo.Yaml("config/models.yaml"));
        return (registry, models, new PlanCheck(PlatformBacklog, registry, models));
    }

    private static List<string> ProfileBacklogs()
    {
        var root = Repo.P("profiles");
        if (!Directory.Exists(root))
        {
            return new List<string>();
        }

        return Directory.GetDirectories(root)
            .Where(d => !Path.GetFileName(d).StartsWith("_", StringComparison.Ordinal) && File.Exists(Path.Combine(d, "backlog.yaml")))
            .Select(d => Repo.Rel(Path.Combine(d, "backlog.yaml")))
            .OrderBy(x => x, StringComparer.Ordinal)
            .ToList();
    }

    public static int Validate(string[] args)
    {
        var cli = new Cli("użycie: ph plan validate [--backlog plik] [--check] [--conflicts KROK KROK…]", args,
            new[] { "--check", "--conflicts" }, new[] { "--backlog" }, 0, 99);
        var (registry, models, platform) = LoadPlatform();
        var handoff = Py.Str(Py.Dict(Py.Dict(Py.Dict(PyJson.Loads(Repo.ReadRel("agents/schemas/handoff.schema.json")))["properties"])["step"])["pattern"]);
        var backlog = cli.Opt("--backlog");

        if (cli.Flag("--conflicts"))
        {
            var plan = backlog != null && backlog != PlatformBacklog ? new PlanCheck(backlog, registry, models, platform) : platform;
            var ids = cli.Positional.ToList();
            if (ids.Count == 0)
            {
                throw new ToolException(cli.Usage + "\nbłąd: --conflicts wymaga identyfikatorów kroków", 2);
            }

            var unknown = ids.Where(i => !plan.Steps.ContainsKey(i)).ToList();
            if (unknown.Count > 0)
            {
                throw new ToolException($"Nie ma kroków: {string.Join(", ", unknown)}");
            }

            var found = plan.Conflicts(ids);
            foreach (var (a, b, x, y) in found)
            {
                Console.WriteLine($"KONFLIKT: {a} i {b} zapisują w tym samym miejscu ({x} ↔ {y}) — prowadź po kolei");
            }

            Console.WriteLine(found.Count == 0 ? "brak konfliktów zapisu" : $"konfliktów: {found.Count}");
            return found.Count > 0 ? 1 : 0;
        }

        var plans = new List<PlanCheck>();
        if (backlog == null || backlog == PlatformBacklog)
        {
            platform.Run(handoff, Py.Dict(Py.Dict(Repo.Yaml("plan/estimates.yaml"))["steps"]), null);
            plans.Add(platform);
        }

        var backlogs = backlog != null && backlog != PlatformBacklog
            ? new List<string> { backlog }
            : (backlog != null ? new List<string>() : ProfileBacklogs());
        foreach (var rel in backlogs)
        {
            var plan = new PlanCheck(rel, registry, models, platform);
            plan.Run(handoff, null, plan.DevAgents());
            plans.Add(plan);
        }

        var errors = 0;
        var warnings = 0;
        foreach (var plan in plans)
        {
            Console.WriteLine($"{plan.Rel}: kroków {plan.Steps.Count} · błędów {plan.Errors.Count} · ostrzeżeń {plan.Warnings.Count}");
            foreach (var e in plan.Errors)
            {
                Console.WriteLine($"  BŁĄD        {e}");
            }

            if (!cli.Flag("--check"))
            {
                foreach (var w in plan.Warnings)
                {
                    Console.WriteLine($"  OSTRZEŻENIE {w}");
                }
            }

            errors += plan.Errors.Count;
            warnings += plan.Warnings.Count;
        }

        if (cli.Flag("--check") && warnings > 0)
        {
            Console.WriteLine($"ostrzeżeń: {warnings} (szczegóły bez --check)");
        }

        return errors > 0 ? 1 : 0;
    }

    // --- ph plan place ------------------------------------------------------------------------------------------

    private static readonly Dictionary<string, string[]> ProfileNeeds = new(StringComparer.Ordinal)
    {
        ["backend"] = new[] { "S27" },
        ["db"] = new[] { "S27" },
        ["frontend"] = new[] { "S47" },
        ["bpmn"] = new[] { "S17" },
        ["forms"] = new[] { "S17" },
    };

    private const string ProfileHint = "krok implementuje operacje z manifestu (task-action, profile-action, query…)? dodaj do szkicu depends_on: [S38]";

    private static readonly string[] FieldOrder =
    {
        "id", "title", "phase", "gate_before", "agent", "pair", "pair_task", "tier", "size", "critical", "depends_on",
        "reads", "refs", "writes", "specs", "outcome", "notes", "dod", "acceptance",
    };

    private static readonly HashSet<string> FlowPlain = new() { "depends_on", "reads" };
    private static readonly HashSet<string> FlowQuoted = new() { "writes", "specs" };
    private static readonly HashSet<string> Block = new() { "refs", "outcome", "notes", "dod", "acceptance" };
    private static readonly HashSet<string> Quoted = new() { "title", "pair_task" };

    /// <summary>Krok w układzie pliku planu (element listy z wcięciem 2 spacji).</summary>
    public static List<string> EmitStep(PyDict step)
    {
        var lines = new List<string>();
        var keys = FieldOrder.Concat(step.Keys.Where(k => !FieldOrder.Contains(k)).OrderBy(k => k, StringComparer.Ordinal));
        foreach (var key in keys)
        {
            if (!step.ContainsKey(key))
            {
                continue;
            }

            var value = step[key];
            var prefix = lines.Count == 0 ? "  - " : "    ";
            if (FlowPlain.Contains(key))
            {
                lines.Add($"{prefix}{key}: [{string.Join(", ", Py.Strings(value))}]");
            }
            else if (FlowQuoted.Contains(key))
            {
                lines.Add($"{prefix}{key}: [{string.Join(", ", Py.Strings(value).Select(v => PyJson.Quote(v)))}]");
            }
            else if (Block.Contains(key))
            {
                lines.Add($"{prefix}{key}:");
                lines.AddRange(Py.Strings(value).Select(v => $"      - {PyJson.Quote(v)}"));
            }
            else if (Quoted.Contains(key))
            {
                lines.Add($"{prefix}{key}: {PyJson.Quote(Py.Str(value))}");
            }
            else if (value is bool flag)
            {
                lines.Add($"{prefix}{key}: {(flag ? "true" : "false")}");
            }
            else
            {
                lines.Add($"{prefix}{key}: {Py.ToStr(value)}");
            }
        }

        return lines;
    }

    private static string NextId(PlanCheck plan, PyDict draft)
    {
        if (plan.Profile != null)
        {
            var prefix = plan.Order.Count > 0 ? plan.Order[0].Split('-')[0] : plan.Profile.Substring(0, Math.Min(3, plan.Profile.Length)).ToUpperInvariant();
            var numbers = new List<int>();
            foreach (var id in plan.Order)
            {
                var parts = id.Split('-');
                if (parts.Length > 1 && int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out var number))
                {
                    numbers.Add(number);
                }
            }

            var next = numbers.Count > 0 ? numbers.Max() + 1 : 1;
            return $"{prefix}-{next.ToString("00", CultureInfo.InvariantCulture)}";
        }

        var used = new HashSet<int>();
        foreach (var id in plan.Order)
        {
            if (int.TryParse(id.Substring(1), NumberStyles.None, CultureInfo.InvariantCulture, out var number))
            {
                used.Add(number);
            }
        }

        if (draft.Get("phase") is long phase)
        {
            for (var n = (int)phase * 10; n < (int)phase * 10 + 10; n++)
            {
                if (!used.Contains(n))
                {
                    return $"S{n.ToString("00", CultureInfo.InvariantCulture)}";
                }
            }
        }

        return $"S{(used.Max() + 1).ToString("00", CultureInfo.InvariantCulture)}";
    }

    private static (PyDict Reasons, List<string> Remarks) SuggestDependencies(PlanCheck plan, PyDict draft)
    {
        var reasons = new PyDict();           // zależność → lista powodów, w kolejności dodania
        var remarks = new List<string>();

        void Add(string dep, string why)
        {
            if (reasons.Get(dep) is not List<object?> list)
            {
                list = new List<object?>();
                reasons[dep] = list;
            }

            if (!list.Contains(why))
            {
                list.Add(why);
            }
        }

        foreach (var dep in Py.Strings(draft.Get("depends_on")))
        {
            Add(dep, "podane w szkicu");
        }

        var known = new List<(string Id, PyDict Step)>();
        if (plan.Platform != null)
        {
            foreach (var platformId in plan.Platform.Order)
            {
                known.Add((platformId, plan.Platform.Steps[platformId]));
            }
        }

        foreach (var ownId in plan.Order)
        {
            known.Add((ownId, plan.Steps[ownId]));
        }

        var draftWrites = Py.Strings(draft.Get("writes")).ToList();
        foreach (var r in Py.Strings(draft.Get("reads")))
        {
            var path = Repo.P(r);
            if (File.Exists(path) || Directory.Exists(path))
            {
                continue;
            }

            // twórcą jest krok z najwęższym pasującym zakresem; przy remisie — wcześniejszy w planie
            string? best = null;
            var bestLength = -1;
            foreach (var (id, s) in known)
            {
                var matching = Py.Strings(s.Get("writes")).Where(w => PlanCheck.Covered(r, new[] { w })).ToList();
                if (matching.Count > 0 && matching.Max(w => w.Length) > bestLength)
                {
                    bestLength = matching.Max(w => w.Length);
                    best = id;
                }
            }

            if (best != null)
            {
                Add(best, $"tworzy {r}");
            }
        }

        var draftPhase = draft.Get("phase") as long?;
        foreach (var id in plan.Order)
        {
            var s = plan.Steps[id];
            if (draftPhase != null && PlanCheck.PhaseOf(s) > draftPhase.Value)
            {
                continue;
            }

            var hit = PlanCheck.FirstOverlap(draftWrites, Py.Strings(s.Get("writes")).ToList());
            if (hit != null)
            {
                Add(id, $"pisze w tym samym miejscu ({hit.Value.Y})");
            }
        }

        if (plan.Profile != null)
        {
            var own = $"profiles/{plan.Profile}/";
            var parts = draftWrites.Where(w => w.StartsWith(own, StringComparison.Ordinal)).Select(w => w.Substring(own.Length).Split('/')[0])
                .Distinct().OrderBy(x => x, StringComparer.Ordinal).ToList();
            foreach (var part in parts)
            {
                if (ProfileNeeds.TryGetValue(part, out var needs))
                {
                    foreach (var dep in needs)
                    {
                        Add(dep, $"zapis w {part}/ wymaga kroku platformy {dep}");
                    }
                }
            }

            if (parts.Contains("backend") && !reasons.ContainsKey("S38"))
            {
                remarks.Add(ProfileHint);
            }
        }

        foreach (var dep in reasons.Keys.Where(d => plan.Step(d) != null).ToList())
        {
            if (reasons.Keys.Any(other => other != dep && plan.Step(other) != null && plan.Precedes(dep, other)))
            {
                reasons.Remove(dep);          // wynika z innej zależności albo z bramki
            }
        }

        return (reasons, remarks);
    }

    private static int BlockEnd(List<string> lines, string id)
    {
        var pattern = new Regex("^  - (\\{ )?id: " + Regex.Escape(id) + "\\b");
        var start = lines.FindIndex(l => pattern.IsMatch(l));
        if (start < 0)
        {
            return -1;
        }

        var end = start + 1;
        while (end < lines.Count && !lines[end].StartsWith("  - ", StringComparison.Ordinal) && !lines[end].StartsWith("  # ", StringComparison.Ordinal))
        {
            end++;
        }

        while (end > start + 1 && lines[end - 1].Trim().Length == 0)
        {
            end--;
        }

        return end;
    }

    private static (int Position, string Where) InsertPosition(PlanCheck plan, List<string> lines, PyDict step)
    {
        var id = Py.Str(step["id"]);
        var own = Py.Strings(step.Get("depends_on")).Where(d => plan.Steps.ContainsKey(d) && d != id).ToList();
        var anchor = own.Count > 0 ? own.OrderBy(d => plan.Order.IndexOf(d)).Last() : null;
        var where = anchor != null ? $"po kroku {anchor}" : "na końcu planu";
        if (anchor == null && plan.Profile == null && step.Get("phase") is long phase)
        {
            var same = plan.Order.Where(i => i != id && plan.Steps[i].Get("phase") is long p && p == phase).ToList();
            if (same.Count > 0)
            {
                anchor = same[same.Count - 1];
                where = $"na końcu fazy {phase} (po kroku {anchor})";
            }
        }

        var end = anchor != null ? BlockEnd(lines, anchor) : -1;
        if (end < 0)
        {
            end = lines.Count;
            while (end > 0 && lines[end - 1].Trim().Length == 0)
            {
                end--;
            }
        }

        return (end, where);
    }

    public static int Place(string[] args)
    {
        var cli = new Cli("użycie: ph plan place <szkic.yaml> [--backlog plik] [--apply]", args, new[] { "--apply" }, new[] { "--backlog" }, 1, 1);
        var (registry, models, platform) = LoadPlatform();
        var backlog = cli.Opt("--backlog", PlatformBacklog)!;
        var plan = backlog == PlatformBacklog ? platform : new PlanCheck(backlog, registry, models, platform);
        var loaded = MiniYaml.LoadFile(Path.GetFullPath(cli.Pos(0)));
        if (loaded is PyDict wrapper && wrapper.Get("steps") is List<object?> wrapped && wrapped.Count == 1)
        {
            loaded = wrapped[0];
        }

        if (loaded is not PyDict draft || !draft.ContainsKey("title") || !draft.ContainsKey("agent"))
        {
            throw new ToolException("Szkic musi być jednym krokiem (mapowanie YAML) z polami co najmniej `title` i `agent`.");
        }

        if (plan.Profile == null && draft.Get("phase") is not long)
        {
            throw new ToolException("Szkic kroku platformy musi mieć pole `phase` (0–6) — od niego zależą bramki i miejsce w planie.");
        }

        var id = draft.Get("id") is string given && given.Length > 0 ? given : NextId(plan, draft);
        if (plan.Steps.ContainsKey(id))
        {
            throw new ToolException($"Krok {id} już istnieje w {plan.Rel}");
        }

        var (reasons, remarks) = SuggestDependencies(plan, draft);
        var step = Py.Dict(Py.Clone(draft));
        step["id"] = id;
        var ordered = new List<string>();
        if (plan.Platform != null)
        {
            ordered.AddRange(plan.Platform.Order.Where(reasons.ContainsKey));
        }

        ordered.AddRange(plan.Order.Where(reasons.ContainsKey));
        ordered.AddRange(reasons.Keys.Where(d => plan.Step(d) == null));
        step["depends_on"] = ordered.Select(d => (object?)d).ToList();
        plan.Steps[id] = step;
        plan.Order.Add(id);

        var gateNote = "bez zmian";
        var hasGate = step.Get("gate_before") is string existing && existing.Length > 0;
        if (plan.Profile == null && !hasGate && PlanCheck.PhaseGates.TryGetValue(PlanCheck.PhaseOf(step), out var required))
        {
            var missing = required.Where(g => plan.Gates.ContainsKey(g) && !plan.BehindGate(id, g)).ToList();
            if (missing.Count > 0)
            {
                var gate = missing[missing.Count - 1];
                step["gate_before"] = gate;
                gateNote = $"dodano {gate} — faza {PlanCheck.PhaseOf(step)} leży za tą bramką, a zależności jej nie wymuszają";
            }
        }

        foreach (var dep in ordered)
        {
            if (plan.Step(dep) == null)
            {
                plan.Err(id, $"nieznana zależność {dep}");
            }
        }

        if (plan.Ancestors(id).Contains(id))
        {
            plan.Err(id, "cykl zależności");
        }

        plan.CheckAgents(id, step, plan.DevAgents());
        plan.CheckReads(id, step);
        plan.CheckSpecs(id, step);
        plan.CheckDod(id, step);
        if (plan.Profile != null)
        {
            foreach (var w in Py.Strings(step.Get("writes")))
            {
                if (!w.StartsWith($"profiles/{plan.Profile}/", StringComparison.Ordinal))
                {
                    plan.Err(id, $"zapis poza profilem: {w}");
                }
            }
        }

        var conflicts = plan.Conflicts().Where(c => c.A == id || c.B == id).ToList();
        var lines = Repo.ReadRel(plan.Rel).Split('\n').ToList();
        var (position, where) = InsertPosition(plan, lines, step);
        var block = EmitStep(step);

        Console.WriteLine($"Krok:        {id} — {Py.Str(step["title"])}");
        Console.WriteLine($"Plan:        {plan.Rel}");
        Console.WriteLine($"Zależności:  {(ordered.Count > 0 ? string.Join(", ", ordered) : "brak")}");
        foreach (var dep in ordered)
        {
            Console.WriteLine($"  - {dep}: {string.Join("; ", Py.Strings(reasons[dep]))}");
        }

        Console.WriteLine($"Bramka:      {(step.Get("gate_before") is string shown && shown.Length > 0 ? shown : "brak")} ({gateNote})");
        Console.WriteLine($"Miejsce:     {where} — linia {position + 1} pliku");
        Console.WriteLine("Konflikty:   " + (conflicts.Count == 0 ? "brak — krok nie pójdzie równolegle z innym piszącym w tym samym miejscu" : string.Empty));
        foreach (var (a, b, x, y) in conflicts)
        {
            Console.WriteLine($"  - {(a == id ? b : a)}: {x} ↔ {y} — jeśli tamten krok ma objąć ten, dopisz {id} do jego depends_on");
        }

        foreach (var r in remarks)
        {
            Console.WriteLine($"Uwaga:       {r}");
        }

        foreach (var e in plan.Errors)
        {
            Console.WriteLine($"BŁĄD         {e}");
        }

        foreach (var w in plan.Warnings)
        {
            Console.WriteLine($"OSTRZEŻENIE  {w}");
        }

        if (plan.Profile == null)
        {
            Console.WriteLine($"Ręcznie:     wycena w plan/estimates.yaml (klucz {id}) i wiersz w tabeli plan/execution-plan.md");
        }

        Console.WriteLine("\n# --- wpis do planu ---");
        Console.WriteLine(string.Join("\n", block));

        if (plan.Errors.Count > 0)
        {
            Console.WriteLine("\nszkic ma błędy — popraw i uruchom ponownie" + (cli.Flag("--apply") ? " (nie zapisano)" : string.Empty));
            return 1;
        }

        if (cli.Flag("--apply"))
        {
            var separated = false;
            for (var n = 0; n < lines.Count - 1; n++)
            {
                if (lines[n].Length == 0 && lines[n + 1].StartsWith("  - ", StringComparison.Ordinal))
                {
                    separated = true;
                    break;
                }
            }

            var updated = lines.Take(position).ToList();
            if (separated)
            {
                updated.Add(string.Empty);
            }

            updated.AddRange(block);
            updated.AddRange(lines.Skip(position));
            Repo.Write(Repo.P(plan.Rel), string.Join("\n", updated));
            Console.WriteLine($"\nzapisano krok {id} w {plan.Rel} — uruchom: python3 tools/refresh.py");
        }

        return 0;
    }
}
