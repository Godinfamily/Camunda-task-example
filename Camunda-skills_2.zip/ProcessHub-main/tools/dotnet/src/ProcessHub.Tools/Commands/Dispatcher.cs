using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Mapowanie poleceń ph na implementacje i na skrypty Pythona, które zastępują.</summary>
public static class Dispatcher
{
    public sealed record Entry(string[] Words, string PythonScript, Func<string[], int> Run, string Summary);

    public static readonly List<Entry> Entries = new()
    {
        new(new[] { "guard" }, "tools/guard/enforce_write_scope.py", Guard.Run, "strażnik zakresu zapisu (stdin, --check, --verify-diff, --self-test)"),
        new(new[] { "profiles", "validate" }, "tools/profiles/validate_profiles.py", Profiles.Validate, "walidacja manifestów profili i CODEOWNERS"),
        new(new[] { "profiles", "new" }, "tools/profiles/new_profile.py", Profiles.New, "zakłada nowy profil projektu z szablonu"),
        new(new[] { "agents", "render" }, "tools/agents/render_agents.py", Agents.Render, "generuje agentów OpenCode, opencode.json i tabelę w AGENTS.md"),
        new(new[] { "agents", "validate-output" }, "tools/agents/validate_output.py", Agents.ValidateOutput, "sprawdza wynik agenta (JSON) schematem roli"),
        new(new[] { "step", "prepare" }, "tools/agents/prepare_step.py", Steps.Prepare, "przygotowuje krok: worktree, .agent-scope, pakiet roboczy"),
        new(new[] { "step", "dod" }, "tools/agents/run_dod.py", Steps.Dod, "uruchamia bramki Definition of Done kroku"),
        new(new[] { "step", "status" }, "tools/agents/plan_status.py", Steps.Status, "stan planu, scalenia, zatwierdzanie bramek"),
        new(new[] { "plan", "estimate" }, "tools/plan/estimate.py", Estimate.Run, "model wyceny → plan/estimation-report.md"),
        new(new[] { "plan", "export" }, "tools/plan/export_dashboard_data.py", ExportDashboard.Run, "dane dashboardu harmonogramu (plan/dashboard/data, data.js)"),
        new(new[] { "plan", "validate" }, "tools/plan/validate_plan.py", PlanTools.Validate, "spójność planów z repozytorium i rolami agentów (--check, --conflicts)"),
        new(new[] { "plan", "place" }, "tools/plan/place_step.py", PlanTools.Place, "miejsce nowego kroku w planie: zależności, bramka, konflikty (--apply)"),
        new(new[] { "forms", "validate" }, "tools/forms/validate_forms.py", Forms.Validate, "formatki .form względem katalogu pól i ph:outputs z BPMN"),
        new(new[] { "refresh" }, "tools/refresh.py", Refresh.Run, "odświeża pliki generowane i uruchamia wszystkie bramki (--check)"),
        new(new[] { "artifacts", "render" }, "tools/artifacts/render_artifacts.py", Artifacts.Run, "plan systemu, aktorzy, założenia (docs/artifacts)"),
        new(new[] { "notes", "build" }, "tools/handover/build_notebook_sources.py", Notes.Build, "źródła notesu LLM (docs/handover/notes/zrodla)"),
        new(new[] { "yaml" }, "", YamlDump.Run, "wypisuje plik YAML jako JSON (podgląd bez Pythona)"),
    };

    public static int Dispatch(List<string> args)
    {
        foreach (var e in Entries.OrderByDescending(e => e.Words.Length))
        {
            if (args.Count >= e.Words.Length && e.Words.Select((w, i) => args[i] == w).All(x => x))
            {
                return e.Run(args.Skip(e.Words.Length).ToArray());
            }
        }

        throw new ToolException($"nieznane polecenie: {string.Join(' ', args)} — zobacz: ph help", 2);
    }
}

public static class Help
{
    public static string Text =>
        "ph — narzędzia repozytorium Process Hub (.NET, bez Pythona)\n\nPolecenia:\n"
        + string.Join("\n", Dispatcher.Entries.Select(e => $"  ph {string.Join(' ', e.Words),-26} {e.Summary}"
            + (e.PythonScript.Length > 0 ? $"   [= python3 {e.PythonScript}]" : string.Empty)))
        + "\n\nOpcja globalna: --repo <ścieżka> (domyślnie katalog bieżący lub nadrzędny z AGENTS.md).";
}

public static class YamlDump
{
    public static int Run(string[] args)
    {
        if (args.Length != 1)
        {
            throw new ToolException("użycie: ph yaml <plik.yaml>", 2);
        }

        Console.Out.Write(PyJson.Dumps(MiniYaml.LoadFile(args[0]), indent: 1) + "\n");
        return 0;
    }
}
