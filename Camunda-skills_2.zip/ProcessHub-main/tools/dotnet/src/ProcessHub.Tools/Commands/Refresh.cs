using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>
/// ph refresh — odświeża wszystko, co generowane, i uruchamia wszystkie bramki repozytorium (= tools/refresh.py).
/// Każdy krok to istniejące polecenie ph wykonane w tym samym procesie.
/// </summary>
public static class Refresh
{
    private sealed record Step(string Title, string Command, Func<string[], int> Run, string[] Generate, string[] CheckArgs);

    private static readonly Step[] All =
    {
        new("manifesty profili i CODEOWNERS", "ph profiles validate", Profiles.Validate, new[] { "--write-codeowners" }, new[] { "--check" }),
        new("agenci OpenCode, opencode.json, tabela ról", "ph agents render", Agents.Render, Array.Empty<string>(), new[] { "--check" }),
        new("spójność planów", "ph plan validate", PlanTools.Validate, new[] { "--check" }, new[] { "--check" }),
        new("formatki a katalog pól i BPMN", "ph forms validate", Forms.Validate, new[] { "--check" }, new[] { "--check" }),
        new("wycena planu", "ph plan estimate", Estimate.Run, Array.Empty<string>(), new[] { "--check" }),
        new("dane dashboardu", "ph plan export", ExportDashboard.Run, Array.Empty<string>(), new[] { "--check" }),
        new("artefakty projektowe", "ph artifacts render", Artifacts.Run, Array.Empty<string>(), new[] { "--check" }),
        new("źródła notesu", "ph notes build", Notes.Build, Array.Empty<string>(), new[] { "--check" }),
        new("test strażnika zapisu", "ph guard", Guard.Run, new[] { "--self-test" }, new[] { "--self-test" }),
        new("test walidatora profili", "ph profiles validate", Profiles.Validate, new[] { "--self-test" }, new[] { "--self-test" }),
    };

    public static int Run(string[] args)
    {
        var cli = new Cli("użycie: ph refresh [--check]", args, new[] { "--check" }, Array.Empty<string>());
        var failed = new List<string>();
        foreach (var step in All)
        {
            var (code, output) = Capture(() => step.Run(cli.Flag("--check") ? step.CheckArgs : step.Generate));
            Console.WriteLine($"[{(code == 0 ? "OK " : "BŁĄD")}] {step.Title}  ({step.Command})");
            if (code != 0)
            {
                failed.Add(step.Title);
                foreach (var line in output.Trim().Split('\n').TakeLast(15))
                {
                    Console.WriteLine($"       {line}");
                }
            }
        }

        Console.WriteLine("wynik: " + (failed.Count == 0 ? "wszystko aktualne i spójne" : "do poprawy — " + string.Join(", ", failed)));
        return failed.Count > 0 ? 1 : 0;
    }

    /// <summary>Uruchamia polecenie z przechwyconym wyjściem; błąd narzędzia zamienia na kod wyjścia.</summary>
    private static (int Code, string Output) Capture(Func<int> action)
    {
        var originalOut = Console.Out;
        var originalError = Console.Error;
        var buffer = new StringWriter();
        Console.SetOut(buffer);
        Console.SetError(buffer);
        try
        {
            return (action(), buffer.ToString());
        }
        catch (ToolException e)
        {
            return (e.ExitCode == 0 ? 1 : e.ExitCode, buffer + e.Message);
        }
        catch (InvalidDataException e)
        {
            return (2, buffer + "BŁĄD DANYCH: " + e.Message);
        }
        finally
        {
            Console.SetOut(originalOut);
            Console.SetError(originalError);
        }
    }
}
