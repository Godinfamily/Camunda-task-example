using System.Text;
using System.Text.RegularExpressions;
using ProcessHub.Tools.Infrastructure;

namespace ProcessHub.Tools.Commands;

/// <summary>Generator agentów OpenCode (= tools/agents/render_agents.py) i walidator wyników agentów (= validate_output.py).</summary>
public static class Agents
{
    private const string Generated = "WYGENEROWANE przez tools/agents/render_agents.py — edytuj agents/registry.yaml, agents/prompts/ lub profiles/<id>/profile.yaml";
    private const string RoleBegin = "<!-- ROLE:BEGIN";
    private const string RoleEnd = "<!-- ROLE:END -->";
    private const string RfcGlob = "docs/rfc/RFC-*.md";
    private static readonly Dictionary<string, int> ClassRank = new() { ["internal"] = 0, ["confidential"] = 1, ["restricted"] = 2 };
    private static readonly HashSet<string> WriteTools = new() { "edit_file", "write_file" };

    private sealed class ConfigError : Exception
    {
        public ConfigError(string message) : base(message)
        {
        }
    }

    /// <summary>Wynik ustalenia modelu dla roli.</summary>
    private sealed record Resolved(string Profile, PyDict Cfg, string Tier, string Model, string? Variant, string Hosting, string DataClass);

    /// <summary>Uprawnienie edit: tekst („deny”) albo uporządkowane reguły wzorców.</summary>
    private sealed record Edit(string? Simple, List<(string Pattern, string Action)>? Rules)
    {
        public bool IsDeny => Simple == "deny";
    }

    private sealed record Agent(string Name, PyDict Role, Resolved Res, string Description, Edit Edit, string Body, bool Primary, string Scope);

    public static int Render(string[] args)
    {
        var cli = new Cli("użycie: ph agents render [--profile NAZWA] [--targets opencode,agents-md,json] [--check]", args, new[] { "--check" }, new[] { "--profile", "--targets" });
        try
        {
            return RenderCore(cli);
        }
        catch (ConfigError e)
        {
            Console.Error.WriteLine($"BŁĄD KONFIGURACJI: {e.Message}");
            return 2;
        }
    }

    private static int RenderCore(Cli cli)
    {
        var registry = Py.Dict(Repo.Yaml("agents/registry.yaml"));
        var models = Py.Dict(Repo.Yaml("config/models.yaml"));
        var tools = Py.List(Py.Dict(PyJson.Loads(Repo.ReadRel("agents/schemas/tools.json")))["tools"]);
        var agentsMd = Repo.ReadRel("AGENTS.md");
        var projectRules = agentsMd.Split(new[] { RoleBegin }, StringSplitOptions.None)[0].TrimEnd() + "\n";
        var profiles = new List<PyDict>();
        foreach (var d in Directory.GetDirectories(Repo.P("profiles")).OrderBy(x => x, StringComparer.Ordinal))
        {
            if (!Path.GetFileName(d).StartsWith("_", StringComparison.Ordinal) && File.Exists(Path.Combine(d, "profile.yaml")))
            {
                profiles.Add(Py.Dict(MiniYaml.LoadFile(Path.Combine(d, "profile.yaml"))));
            }
        }

        var envProfile = Environment.GetEnvironmentVariable("PH_MODEL_PROFILE");
        var modelProfile = cli.Opt("--profile") ?? (string.IsNullOrEmpty(envProfile) ? null : envProfile) ?? Py.Str(models["default_profile"]);
        var targets = cli.Opt("--targets") is string t
            ? t.Split(',').ToList()
            : (Py.Dict(Py.Dict(models["profiles"]).Get(modelProfile) ?? throw new ConfigError($"nieznany profil modeli: {modelProfile}")).Get("targets") is List<object?> tl
                ? tl.Select(Py.Str).ToList()
                : new List<string> { "opencode", "agents-md" });
        var roles = Py.List(registry["roles"]).Select(Py.Dict).ToList();
        var byName = roles.ToDictionary(r => Py.Str(r["name"]));
        var outputs = new List<(string Path, string Content)>();
        var warnings = new List<string>();
        var resolvedAll = new List<Resolved>();
        var rows = new List<(string Name, string Scope, string Tier, string Model, string? Variant, string Hosting, string DataClass)>();

        var agents = new List<Agent>();
        foreach (var r in roles)
        {
            var res = Resolve(r, modelProfile, models, null);
            var name = Py.Str(r["name"]);
            agents.Add(new Agent(name, r, res, Py.Str(r["description"]), PlatformEdit(r), PromptFor(r), name == "orchestrator", "platforma"));
        }

        foreach (var prof in profiles)
        {
            var pid = Py.Str(prof["id"]);
            var dev = prof.Get("dev") as PyDict ?? new PyDict();
            var profClass = dev.Get("dataClass") as string ?? Py.Str(Py.Dict(prof["data"])["classification"]);
            foreach (var roleName in Py.Strings(dev.Get("agents")))
            {
                var r = byName[roleName];
                var roleClass = Py.Str(r["data_class"]);
                var dc = ClassRank[profClass] > ClassRank[roleClass] ? profClass : roleClass;
                var res = Resolve(r, modelProfile, models, dc);
                var edit = WriteTools.Overlaps(Py.Strings(r["tools"]))
                    ? new Edit(null, new List<(string, string)> { ("*", "deny"), ($"profiles/{pid}/**", "allow"), (RfcGlob, "allow") })
                    : new Edit("deny", null);
                var desc = $"Profil „{pid}” ({Py.Str(Py.Dict(prof["owner"])["team"])}): {Py.Str(r["description"])} Zapis wyłącznie w profiles/{pid}/**.";
                agents.Add(new Agent($"{pid}-{roleName}", r, res, desc, edit, PromptFor(r) + ProfileAddendum(prof), false, $"`profiles/{pid}/**`"));
            }
        }

        foreach (var a in agents)
        {
            resolvedAll.Add(a.Res);
            var own = string.Join(", ", Py.Strings(a.Role.Get("writes")).Select(w => $"`{w}`"));
            rows.Add((a.Name, a.Scope != "platforma" ? a.Scope : (a.Edit.IsDeny ? "brak (tylko odczyt)" : (own.Length > 0 ? own : "platforma (bez `profiles/<id>/**`)")),
                a.Res.Tier, a.Res.Model, a.Res.Variant, a.Res.Hosting, a.Res.DataClass));
            if (OpencodeModel(a.Res) == null)
            {
                warnings.Add($"{a.Name}: model {a.Res.Model} nieustalony — ustaw zmienne profilu modeli {a.Res.Profile}");
            }

            var limit = a.Res.Cfg.Get("context_limit_tokens");
            var need = Py.Int(Py.Dict(a.Role["requires"])["min_context_tokens"]);
            if (limit is long l && l > 0 && l < need)
            {
                warnings.Add($"{a.Name}: kontekst {l} < wymagane {need} — orkiestrator dzieli pakiety rozmiaru L");
            }

            if (targets.Contains("opencode"))
            {
                outputs.Add((Repo.P($".opencode/agent/{a.Name}.md"), RenderOpencodeAgent(a)));
            }

            if (targets.Contains("json"))
            {
                outputs.Add((Repo.P($"agents/dist/{modelProfile}/{a.Name}.json"), RenderJson(a, tools, projectRules)));
            }
        }

        if (targets.Contains("opencode"))
        {
            var arch = agents.First(a => a.Name == "architect").Res;
            var small = agents.First(a => a.Name == "ci-triage").Res;
            outputs.Add((Repo.P("opencode.json"), RenderOpencodeConfig(models, resolvedAll, arch, small)));
            var agentDir = Repo.P(".opencode/agent");
            if (Directory.Exists(agentDir))
            {
                var expected = new HashSet<string>(agents.Select(a => a.Name + ".md"), StringComparer.Ordinal);
                foreach (var orphan in Directory.GetFiles(agentDir, "*.md").Select(Path.GetFileName).Where(n => !expected.Contains(n!)).OrderBy(n => n, StringComparer.Ordinal))
                {
                    warnings.Add($"plik .opencode/agent/{orphan} nie odpowiada żadnej roli — usuń go");
                }
            }
        }

        if (targets.Contains("agents-md"))
        {
            var block = RenderRoleBlock(rows);
            if (!agentsMd.Contains(RoleBegin, StringComparison.Ordinal) || !agentsMd.Contains(RoleEnd, StringComparison.Ordinal))
            {
                throw new ConfigError("AGENTS.md nie zawiera znaczników bloku ról");
            }

            var head = agentsMd.Substring(0, agentsMd.IndexOf(RoleBegin, StringComparison.Ordinal));
            var rest = agentsMd.Substring(head.Length + RoleBegin.Length);
            var tail = rest.Substring(rest.IndexOf(RoleEnd, StringComparison.Ordinal) + RoleEnd.Length);
            outputs.Add((Repo.P("AGENTS.md"), head + block + tail));
        }

        var stale = new List<string>();
        foreach (var (path, content) in outputs.OrderBy(o => o.Path.Replace('\\', '/').Split('/'), PartsComparer.Instance))
        {
            if (!Repo.SameContent(path, content))
            {
                stale.Add(Repo.Rel(path));
                if (!cli.Flag("--check"))
                {
                    Repo.Write(path, content);
                }
            }
        }

        foreach (var w in warnings.Distinct().OrderBy(w => w, StringComparer.Ordinal))
        {
            Console.Error.WriteLine($"OSTRZEŻENIE: {w}");
        }

        if (cli.Flag("--check"))
        {
            foreach (var s in stale)
            {
                Console.Error.WriteLine($"NIEAKTUALNE: {s}");
            }

            return stale.Count > 0 ? 1 : 0;
        }

        Console.WriteLine($"profil modeli: {modelProfile} · agentów: {agents.Count} · zapisano {stale.Count} plików, bez zmian {outputs.Count - stale.Count}");
        return 0;
    }

    private static bool Allowed(PyDict models, string dataClass, string hosting) =>
        Py.Dict(models["data_policy"]).Get(dataClass) is List<object?> l && l.OfType<string>().Contains(hosting);

    private static Resolved Resolve(PyDict role, string profileName, PyDict models, string? dataClass)
    {
        var profiles = Py.Dict(models["profiles"]);
        if (!profiles.ContainsKey(profileName))
        {
            throw new ConfigError($"nieznany profil modeli: {profileName}");
        }

        dataClass ??= Py.Str(role["data_class"]);
        var prof = Py.Dict(profiles[profileName]);
        var overrides = prof.Get("roles") as PyDict ?? new PyDict();
        var ov = overrides.Get(Py.Str(role["name"])) as PyDict ?? new PyDict();
        var effective = ov.Get("profile") as string ?? profileName;
        var tier = ov.Get("tier") as string ?? Py.Str(role["tier"]);
        if (!Allowed(models, dataClass, Py.Str(Py.Dict(profiles[effective])["hosting"])))
        {
            var onPrem = profiles.Where(kv => Allowed(models, dataClass, Py.Str(Py.Dict(kv.Value)["hosting"]))).Select(kv => kv.Key).ToList();
            if (onPrem.Count == 0)
            {
                throw new ConfigError($"rola {role["name"]} (dane: {dataClass}) nie ma dozwolonego profilu modeli");
            }

            effective = onPrem[0];
        }

        var cfg = Py.Dict(profiles[effective]);
        var tierCfg = Py.Dict(Py.Dict(cfg["tiers"])[tier]);
        return new Resolved(effective, cfg, tier, Py.Str(tierCfg["model"]), tierCfg.Get("variant") as string, Py.Str(cfg["hosting"]), dataClass);
    }

    private static readonly Regex EnvVar = new("\\$\\{(\\w+)\\}", RegexOptions.Compiled);

    private static string? EnvResolve(string? value)
    {
        if (value == null)
        {
            return null;
        }

        if (EnvVar.Matches(value).Any(m => string.IsNullOrEmpty(Environment.GetEnvironmentVariable(m.Groups[1].Value))))
        {
            return null;
        }

        return EnvVar.Replace(value, m => Environment.GetEnvironmentVariable(m.Groups[1].Value)!);
    }

    private static string? OpencodeModel(Resolved res)
    {
        var model = EnvResolve(res.Model);
        var provider = res.Cfg.Get("opencode_provider") as string;
        return !string.IsNullOrEmpty(provider) && !string.IsNullOrEmpty(model) ? $"{provider}/{model}" : null;
    }

    private static string PromptFor(PyDict role) => Repo.ReadRel(Py.Str(role["prompt"]));

    private static string ProfileAddendum(PyDict prof)
    {
        var pid = Py.Str(prof["id"]);
        var processes = string.Join(", ", Py.List(prof["processes"]).Select(p => $"`{Py.Str(Py.Dict(p)["bpmnProcessId"])}`"));
        var data = Py.Dict(prof["data"]);
        return $"\n\n## Profil projektu „{Py.Str(prof["name"])}” (`{pid}`)\n\n"
            + $"Pracujesz dla zespołu {Py.Str(Py.Dict(prof["owner"])["team"])}. Zanim zaczniesz, przeczytaj `profiles/{pid}/AGENTS.md` i `profiles/{pid}/profile.yaml`.\n"
            + $"- Zapisujesz wyłącznie w `profiles/{pid}/**`; platforma i inne profile są poza Twoim zakresem (blokuje to OpenCode i strażnik zapisu).\n"
            + "- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); skill `profile-extension`.\n"
            + $"- Działasz tylko na procesach profilu: {processes} (R9). Uprawnienia, operacje i typy zadań mają prefiks `{pid}.` (R10).\n"
            + $"- Dane: schemat `{Py.Str(data["schema"])}` (klasa: {Py.Str(data["classification"])}); dane platformy tylko przez widoki `platform_api`.\n"
            + "- Zmiana kontraktu profilu albo SDK platformy → RFC w `docs/rfc/` i status `needs-rfc`.\n";
    }

    private static Edit PlatformEdit(PyDict role)
    {
        if (!WriteTools.Overlaps(Py.Strings(role["tools"])))
        {
            return new Edit("deny", null);
        }

        var writes = Py.Strings(role.Get("writes")).ToList();
        if (writes.Count > 0)
        {
            var own = new List<(string, string)> { ("*", "deny") };
            own.AddRange(writes.Select(w => (w, "allow")));
            return new Edit(null, own);
        }

        return new Edit(null, new List<(string, string)> { ("*", "allow"), ("profiles/*/**", "deny"), ("profiles/_template/**", "allow") });
    }

    private static string RenderOpencodeAgent(Agent a)
    {
        var front = new List<string>
        {
            "---",
            $"# {Generated}",
            $"description: {PyJson.Quote(a.Description)}",
            $"mode: {(a.Primary ? "primary" : "subagent")}",
        };
        var model = OpencodeModel(a.Res);
        front.Add(model != null ? $"model: {model}" : $"# model nieustalony ({a.Res.Model}) — ustaw zmienne profilu {a.Res.Profile}");
        if (!string.IsNullOrEmpty(a.Res.Variant))
        {
            front.Add($"variant: {a.Res.Variant}");
        }

        front.Add("permission:");
        if (a.Edit.Simple != null)
        {
            front.Add($"  edit: {a.Edit.Simple}");
        }
        else
        {
            front.Add("  edit:");
            front.AddRange(a.Edit.Rules!.Select(r => $"    {PyJson.Quote(r.Pattern, ensureAscii: true)}: {r.Action}"));
        }

        if (!Py.Strings(a.Role["tools"]).Contains("run_command"))
        {
            front.Add("  bash: deny");
        }
        else if (a.Role.Get("commands") is string commandSet && commandSet.Length > 0)
        {
            front.Add("  bash:");
            front.AddRange(BashRules(commandSet).Select(kv => $"    {PyJson.Quote(kv.Key, ensureAscii: true)}: {Py.Str(kv.Value)}"));
        }

        front.Add($"  task: {(a.Primary ? "allow" : "deny")}");
        front.Add("  webfetch: deny");
        front.Add("  websearch: deny");
        front.Add("---");
        const string note = "\n\n> Narzędzia w OpenCode: read, grep, glob, edit, write, bash. Zapis poza `.agent-scope` i do cudzego profilu "
            + "blokuje plugin `.opencode/plugin/write-scope.js`; komendy ogranicza `permission.bash` (opencode.json albo zestaw roli "
            + "w tym pliku) — polityka: `agents/runtime-policy.yaml`.\n";
        return string.Join("\n", front) + "\n" + a.Body.TrimEnd() + note;
    }

    private static PyDict ReadRules()
    {
        var policy = Py.Dict(Repo.Yaml("agents/runtime-policy.yaml"));
        var rules = new PyDict { ["*"] = "allow" };
        foreach (var pattern in Py.Strings(Py.Dict(policy["read_guard"])["deny"]))
        {
            rules[pattern.StartsWith(".", StringComparison.Ordinal) ? "*" + pattern : pattern] = "deny";
        }

        return rules;
    }

    private static PyDict BashRules(string? setName = null)
    {
        var policy = Py.Dict(Repo.Yaml("agents/runtime-policy.yaml"));
        var run = Py.Dict(policy["run_command"]);
        var sets = run.Get("sets") as PyDict ?? new PyDict();
        var named = setName ?? string.Empty;
        if (named.Length > 0 && !sets.ContainsKey(named))
        {
            throw new ConfigError($"nieznany zestaw komend: {named} (agents/runtime-policy.yaml, run_command.sets)");
        }

        var cfg = named.Length > 0 ? Py.Dict(sets[named]) : run;
        var bash = new PyDict { ["*"] = cfg.Get("default") as string ?? "ask" };
        foreach (var prefix in Py.Strings(cfg["allow"]))
        {
            var p = prefix.TrimEnd();
            if (p.EndsWith("/", StringComparison.Ordinal) || p.EndsWith("-", StringComparison.Ordinal))
            {
                bash[p + "*"] = "allow";
                continue;
            }

            bash[p] = "allow";
            bash[p + " *"] = "allow";
        }

        foreach (var pattern in Py.Strings(run["deny_patterns"]))
        {
            var p = pattern.Trim();
            if (p is "env" or "printenv")
            {
                bash[p] = "deny";
                bash[p + " *"] = "deny";
            }
            else
            {
                bash["*" + p + "*"] = "deny";
            }
        }

        return bash;
    }

    private static string RenderOpencodeConfig(PyDict models, List<Resolved> resolved, Resolved defaultRes, Resolved smallRes)
    {
        var cfg = new PyDict
        {
            ["$schema"] = "https://opencode.ai/config.json",
            ["share"] = "disabled",
            ["autoupdate"] = "notify",
            ["permission"] = new PyDict
            {
                ["edit"] = "allow",
                ["bash"] = BashRules(),
                ["webfetch"] = "deny",
                ["websearch"] = "deny",
                ["read"] = ReadRules(),
            },
        };
        foreach (var (key, res) in new[] { ("model", defaultRes), ("small_model", smallRes) })
        {
            var m = OpencodeModel(res);
            if (m != null)
            {
                cfg[key] = m;
            }
        }

        foreach (var name in resolved.Select(r => r.Profile).Distinct().OrderBy(n => n, StringComparer.Ordinal))
        {
            var p = Py.Dict(Py.Dict(models["profiles"])[name]);
            if (p.Get("kind") as string != "openai-compatible")
            {
                continue;
            }

            var names = Py.Dict(p["tiers"]).Values.Select(t => EnvResolve(Py.Str(Py.Dict(t)["model"]))).Where(m => !string.IsNullOrEmpty(m))
                .Select(m => m!).Distinct().OrderBy(m => m, StringComparer.Ordinal).ToList();
            var mods = new PyDict();
            foreach (var m in names)
            {
                var entryModel = new PyDict { ["name"] = m, ["reasoning"] = true, ["tool_call"] = true };
                if (Py.Truthy(p.Get("context_limit_tokens")))
                {
                    entryModel["limit"] = new PyDict { ["context"] = p["context_limit_tokens"], ["output"] = p.Get("output_limit_tokens", 32768L) };
                }

                if (Py.Truthy(p.Get("variants")))
                {
                    entryModel["variants"] = Py.Clone(p["variants"]);
                }

                mods[m] = entryModel;
            }

            var provider = Py.Str(p["opencode_provider"]);
            var entry = new PyDict
            {
                ["npm"] = "@ai-sdk/openai-compatible",
                ["name"] = p.Get("display_name") as string ?? provider,
                ["options"] = new PyDict { ["baseURL"] = "{env:" + Py.Str(p["api_base_env"]) + "}", ["apiKey"] = "{env:" + Py.Str(p["api_key_env"]) + "}" },
            };
            if (mods.Count > 0)
            {
                entry["models"] = mods;
            }

            if (cfg.Get("provider") is not PyDict providers)
            {
                providers = new PyDict();
                cfg["provider"] = providers;
            }

            if (providers.Get(provider) is PyDict existing)
            {
                // kilka profili modeli na tej samej bramce (profil mieszany): łącz listy modeli
                if (existing.Get("models") is not PyDict merged)
                {
                    merged = new PyDict();
                    existing["models"] = merged;
                }

                foreach (var model in mods)
                {
                    merged[model.Key] = model.Value;
                }
            }
            else
            {
                providers[provider] = entry;
            }
        }

        return PyJson.Dumps(cfg, indent: 2) + "\n";
    }

    private static string RenderJson(Agent a, List<object?> tools, string projectRules)
    {
        var schemaPath = Py.Str(a.Role["output_schema"]);
        var schema = PyJson.Loads(Repo.ReadRel(schemaPath));
        var system = projectRules.Trim() + "\n\n---\n\n# Twoja rola\n\n" + a.Body.Trim()
            + "\n\n---\n\n# Kontrakt wyjścia\n\nOstatnia wiadomość to wyłącznie JSON zgodny ze schematem `" + schemaPath + "`.";
        var cfg = a.Res.Cfg;
        var roleTools = Py.Strings(a.Role["tools"]).ToHashSet();
        var doc = new PyDict
        {
            ["_generated"] = Generated,
            ["role"] = Py.Str(a.Role["name"]),
            ["model_profile"] = a.Res.Profile,
            ["hosting"] = a.Res.Hosting,
            ["provider"] = cfg.Get("opencode_provider"),
            ["api_base_env"] = cfg.Get("api_base_env"),
            ["api_key_env"] = cfg.Get("api_key_env"),
            ["model"] = a.Res.Model,
            ["variant"] = a.Res.Variant,
            ["tier"] = a.Res.Tier,
            ["reasoning"] = a.Role["reasoning"],
            ["tools"] = tools.Where(t => roleTools.Contains(Py.Str(Py.Dict(t)["name"]))).ToList(),
            ["runtime_policy"] = "agents/runtime-policy.yaml",
            ["system"] = system,
            ["response_schema"] = schema,
            ["escalation"] = cfg.Get("escalation") ?? new List<object?>(),
        };
        return PyJson.Dumps(doc, indent: 2) + "\n";
    }

    private static string RenderRoleBlock(List<(string Name, string Scope, string Tier, string Model, string? Variant, string Hosting, string DataClass)> rows)
    {
        var table = string.Join("\n", rows.Select(r =>
            $"| `{r.Name}` | {r.Scope} | {r.Tier} | `{r.Model}`{(string.IsNullOrEmpty(r.Variant) ? string.Empty : " · " + r.Variant)} | {r.Hosting} | {r.DataClass} |"));
        return $"{RoleBegin} — sekcję generuje tools/agents/render_agents.py; nie edytuj ręcznie -->\n"
            + "## Agenci (OpenCode)\n\n"
            + "| Agent | Zakres zapisu | Poziom | Model · wariant | Hosting | Klasa danych |\n| --- | --- | --- | --- | --- | --- |\n"
            + table + "\n\nModel i warianty pochodzą z profilu modeli w `config/models.yaml` (ADR-021); poziom wybiera model i wariant "
            + "rozumowania, eskalacja: wyższy wariant, potem człowiek. Wszystkie role używają modelu w infrastrukturze banku (ADR-016); "
            + "klasa danych decyduje o przeglądzie bezpieczeństwa.\n" + RoleEnd;
    }

    /// <summary>ph agents validate-output &lt;schemat&gt; &lt;plik.json|-&gt; (= tools/agents/validate_output.py).</summary>
    public static int ValidateOutput(string[] args)
    {
        if (args.Length != 2)
        {
            throw new ToolException("użycie: ph agents validate-output <schemat.json> <plik.json|->", 2);
        }

        var schema = Py.Dict(PyJson.Loads(Repo.Read(args[0])));
        var raw = args[1] == "-" ? Console.In.ReadToEnd() : Repo.Read(args[1]);
        object? doc;
        try
        {
            doc = PyJson.Loads(raw);
        }
        catch (System.Text.Json.JsonException e)
        {
            Console.Error.WriteLine($"NIEZGODNE: JSONDecodeError: {e.Message.Split('\n')[0]}");
            return 1;
        }

        var errors = JsonSchemaLite.Validate(schema, doc);
        if (errors.Count > 0)
        {
            Console.Error.WriteLine($"NIEZGODNE: ValidationError: {errors[0].Message}");
            return 1;
        }

        Console.WriteLine("ZGODNE");
        return 0;
    }

    /// <summary>Porządek ścieżek jak w pathlib (porównanie listy części).</summary>
    private sealed class PartsComparer : IComparer<string[]>
    {
        public static readonly PartsComparer Instance = new();

        public int Compare(string[]? x, string[]? y)
        {
            for (var i = 0; i < Math.Min(x!.Length, y!.Length); i++)
            {
                var c = string.CompareOrdinal(x[i], y[i]);
                if (c != 0)
                {
                    return c;
                }
            }

            return x.Length.CompareTo(y.Length);
        }
    }
}
