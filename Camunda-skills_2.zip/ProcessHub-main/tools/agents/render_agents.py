#!/usr/bin/env python3
"""Generator definicji agentów OpenCode z kanonicznego rejestru ról i profili projektów.

Wejście:  agents/registry.yaml, agents/prompts/*.md, config/models.yaml, agents/runtime-policy.yaml,
          profiles/*/profile.yaml (agenci zespołów profili), AGENTS.md (zasady projektu)
Wyjście:  .opencode/agent/*.md + opencode.json (OpenCode) · blok ról w AGENTS.md
          · opcjonalnie agents/dist/<profil-modeli>/<rola>.json (runtime'y wywołujące API bezpośrednio, cel `json`)

Agenci platformy nie zapisują w profiles/<id>/**; agenci profilu (np. `kredyty-module-implementer`) zapisują wyłącznie
w profiles/<id>/**. Klasa danych profilu może wymusić model w infrastrukturze banku (data_policy).

Użycie:
  python3 tools/agents/render_agents.py                         # profil modeli z config/models.yaml (default_profile)
  python3 tools/agents/render_agents.py --targets json          # dodatkowo pliki dla runtime'ów API
  python3 tools/agents/render_agents.py --check                 # bramka CI: pliki aktualne?
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
GENERATED = "WYGENEROWANE przez tools/agents/render_agents.py — edytuj agents/registry.yaml, agents/prompts/ lub profiles/<id>/profile.yaml"
CLASS_RANK = {"internal": 0, "confidential": 1, "restricted": 2}
WRITE_TOOLS = {"edit_file", "write_file"}
WEB_DENY = {"webfetch": "deny", "websearch": "deny"}
ROLE_BEGIN = "<!-- ROLE:BEGIN"
ROLE_END = "<!-- ROLE:END -->"
RFC_GLOB = "docs/rfc/RFC-*.md"          # wniosek o zmianę poza zakresem — wolno każdemu agentowi z prawem zapisu


class ConfigError(Exception):
    pass


def load():
    registry = yaml.safe_load((ROOT / "agents/registry.yaml").read_text(encoding="utf-8"))
    models = yaml.safe_load((ROOT / "config/models.yaml").read_text(encoding="utf-8"))
    tools = json.loads((ROOT / "agents/schemas/tools.json").read_text(encoding="utf-8"))["tools"]
    agents_md = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    project_rules = agents_md.split(ROLE_BEGIN)[0].rstrip() + "\n"
    profiles = []
    for d in sorted(p for p in (ROOT / "profiles").iterdir() if p.is_dir() and not p.name.startswith("_")):
        if (d / "profile.yaml").exists():
            profiles.append(yaml.safe_load((d / "profile.yaml").read_text(encoding="utf-8")))
    return registry, models, tools, agents_md, project_rules, profiles


def allowed(models: dict, data_class: str, hosting: str) -> bool:
    return hosting in models["data_policy"].get(data_class, [])


def resolve(role: dict, profile_name: str, models: dict, data_class: str | None = None) -> dict:
    """Ustala profil modeli, poziom, model i wariant rozumowania dla roli (z polityką danych)."""
    profiles = models["profiles"]
    if profile_name not in profiles:
        raise ConfigError(f"nieznany profil modeli: {profile_name}")
    data_class = data_class or role["data_class"]
    prof = profiles[profile_name]
    override = prof.get("roles", {}).get(role["name"], {})
    effective = override.get("profile", profile_name)
    tier = override.get("tier", role["tier"])
    if not allowed(models, data_class, profiles[effective]["hosting"]):
        on_prem = [n for n, p in profiles.items() if allowed(models, data_class, p["hosting"])]
        if not on_prem:
            raise ConfigError(f"rola {role['name']} (dane: {data_class}) nie ma dozwolonego profilu modeli")
        effective = on_prem[0]
    cfg = profiles[effective]
    tier_cfg = cfg["tiers"][tier]
    return {"profile": effective, "cfg": cfg, "tier": tier, "model": tier_cfg["model"],
            "variant": tier_cfg.get("variant"), "hosting": cfg["hosting"], "data_class": data_class}


def env_resolve(value: str | None) -> str | None:
    """Podstawia ${VAR} ze środowiska; None, gdy zmienna nie jest ustawiona."""
    if value is None:
        return None
    if any(not os.environ.get(v) for v in re.findall(r"\$\{(\w+)\}", value)):
        return None
    return re.sub(r"\$\{(\w+)\}", lambda m: os.environ[m.group(1)], value)


def opencode_model(res: dict) -> str | None:
    model = env_resolve(res["model"])
    provider = res["cfg"].get("opencode_provider")
    return f"{provider}/{model}" if provider and model else None


def prompt_for(role: dict) -> str:
    return (ROOT / role["prompt"]).read_text(encoding="utf-8")


def profile_addendum(prof: dict) -> str:
    pid = prof["id"]
    processes = ", ".join(f"`{p['bpmnProcessId']}`" for p in prof["processes"])
    return (
        f"\n\n## Profil projektu „{prof['name']}” (`{pid}`)\n\n"
        f"Pracujesz dla zespołu {prof['owner']['team']}. Zanim zaczniesz, przeczytaj `profiles/{pid}/AGENTS.md` i `profiles/{pid}/profile.yaml`.\n"
        f"- Zapisujesz wyłącznie w `profiles/{pid}/**`; platforma i inne profile są poza Twoim zakresem (blokuje to OpenCode i strażnik zapisu).\n"
        f"- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); skill `profile-extension`.\n"
        f"- Działasz tylko na procesach profilu: {processes} (R9). Uprawnienia, operacje i typy zadań mają prefiks `{pid}.` (R10).\n"
        f"- Dane: schemat `{prof['data']['schema']}` (klasa: {prof['data']['classification']}); dane platformy tylko przez widoki `platform_api`.\n"
        f"- Zmiana kontraktu profilu albo SDK platformy → RFC w `docs/rfc/` i status `needs-rfc`.\n"
    )


def permissions_block(edit) -> list[str]:
    lines = ["permission:"]
    if isinstance(edit, str):
        lines.append(f"  edit: {edit}")
    else:
        lines.append("  edit:")
        lines += [f"    {json.dumps(k)}: {v}" for k, v in edit.items()]
    return lines


def bash_block(role: dict) -> list[str]:
    """Uprawnienia komend agenta: brak narzędzia = zakaz; własny zestaw roli (pole `commands`) = reguły w pliku agenta."""
    if "run_command" not in role["tools"]:
        return ["  bash: deny"]
    if not role.get("commands"):
        return []                            # zestaw domyślny z opencode.json
    return ["  bash:"] + [f"    {json.dumps(k)}: {v}" for k, v in bash_rules(role["commands"]).items()]


def render_opencode_agent(name: str, role: dict, res: dict, description: str, edit, body: str, primary: bool) -> str:
    front = ["---", f"# {GENERATED}", f"description: {json.dumps(description, ensure_ascii=False)}",
             f"mode: {'primary' if primary else 'subagent'}"]
    model = opencode_model(res)
    front.append(f"model: {model}" if model else f"# model nieustalony ({res['model']}) — ustaw zmienne profilu {res['profile']}")
    if res.get("variant"):
        front.append(f"variant: {res['variant']}")
    front += permissions_block(edit)
    front += bash_block(role)
    front.append(f"  task: {'allow' if primary else 'deny'}")
    front += [f"  {k}: {v}" for k, v in WEB_DENY.items()]
    front.append("---")
    note = ("\n\n> Narzędzia w OpenCode: read, grep, glob, edit, write, bash. Zapis poza `.agent-scope` i do cudzego profilu "
            "blokuje plugin `.opencode/plugin/write-scope.js`; komendy ogranicza `permission.bash` (opencode.json albo zestaw roli "
            "w tym pliku) — polityka: `agents/runtime-policy.yaml`.\n")
    return "\n".join(front) + "\n" + body.rstrip() + note


def platform_edit(role: dict):
    if not WRITE_TOOLS & set(role["tools"]):
        return "deny"
    if role.get("writes"):                   # rola z własną listą ścieżek zapisu (np. orkiestrator: tylko postęp i pakiety)
        rules = {"*": "deny"}
        rules.update({w: "allow" for w in role["writes"]})
        return rules
    # Agenci platformy nie zmieniają kodu profili (z wyjątkiem szablonu utrzymywanego przez platformę).
    return {"*": "allow", "profiles/*/**": "deny", "profiles/_template/**": "allow"}


def runtime_policy() -> dict:
    return yaml.safe_load((ROOT / "agents/runtime-policy.yaml").read_text(encoding="utf-8"))


def bash_rules(set_name: str | None = None) -> dict:
    """Reguły komend: zestaw domyślny (None) albo nazwany zestaw roli; zakazy wspólne zawsze na końcu."""
    run = runtime_policy()["run_command"]
    if set_name and set_name not in run.get("sets", {}):
        raise ConfigError(f"nieznany zestaw komend: {set_name} (agents/runtime-policy.yaml, run_command.sets)")
    cfg = run["sets"][set_name] if set_name else run
    bash = {"*": cfg.get("default", "ask")}  # OpenCode stosuje OSTATNIĄ pasującą regułę: ogólne → szczegółowe → zakazy
    for prefix in cfg["allow"]:
        p = prefix.rstrip()
        if p.endswith("/") or p.endswith("-"):   # prefiks ścieżki lub nazwy (np. ../wt-) — bez spacji przed resztą
            bash[p + "*"] = "allow"
            continue
        bash[p] = "allow"
        bash[p + " *"] = "allow"
    for pattern in run["deny_patterns"]:
        p = pattern.strip()
        if p in ("env", "printenv"):
            bash[p] = "deny"
            bash[p + " *"] = "deny"
        else:
            bash["*" + p + "*"] = "deny"
    return bash


def read_rules() -> dict:
    """Zakazy odczytu z polityki (read_guard.deny): nazwy plików z kropką na początku dopasowane w każdym katalogu."""
    rules = {"*": "allow"}
    for pattern in runtime_policy()["read_guard"]["deny"]:
        rules[("*" + pattern) if pattern.startswith(".") else pattern] = "deny"
    return rules


def render_opencode_config(models: dict, resolved: list[dict], default_res: dict, small_res: dict) -> str:
    cfg = {"$schema": "https://opencode.ai/config.json",
           "share": "disabled",              # rozmowy z kodem banku nie trafiają do publicznych linków
           "autoupdate": "notify",           # aktualizacja narzędzia to decyzja zespołu
           "permission": {"edit": "allow", "bash": bash_rules(), "webfetch": "deny", "websearch": "deny",
                          "read": read_rules()}}
    for key, res in (("model", default_res), ("small_model", small_res)):
        m = opencode_model(res)
        if m:
            cfg[key] = m
    used = {r["profile"] for r in resolved}
    for name in sorted(used):
        p = models["profiles"][name]
        if p.get("kind") != "openai-compatible":
            continue
        names = sorted({m for m in (env_resolve(t["model"]) for t in p["tiers"].values()) if m})
        mods = {}
        for m in names:
            mods[m] = {"name": m, "reasoning": True, "tool_call": True}
            if p.get("context_limit_tokens"):
                mods[m]["limit"] = {"context": p["context_limit_tokens"], "output": p.get("output_limit_tokens", 32768)}
            if p.get("variants"):
                mods[m]["variants"] = p["variants"]      # warianty rozumowania przekazywane bramce w treści żądania
        entry = {"npm": "@ai-sdk/openai-compatible", "name": p.get("display_name", p["opencode_provider"]),
                 "options": {"baseURL": "{env:" + p["api_base_env"] + "}", "apiKey": "{env:" + p["api_key_env"] + "}"}}
        if mods:
            entry["models"] = mods
        existing = cfg.setdefault("provider", {}).get(p["opencode_provider"])
        if existing:                         # kilka profili modeli na tej samej bramce (profil mieszany): łącz listy modeli
            existing.setdefault("models", {}).update(mods)
        else:
            cfg["provider"][p["opencode_provider"]] = entry
    return json.dumps(cfg, ensure_ascii=False, indent=2) + "\n"


def render_json(role: dict, res: dict, tools: list, project_rules: str, body: str) -> str:
    schema = json.loads((ROOT / role["output_schema"]).read_text(encoding="utf-8"))
    system = (project_rules.strip() + "\n\n---\n\n# Twoja rola\n\n" + body.strip()
              + "\n\n---\n\n# Kontrakt wyjścia\n\nOstatnia wiadomość to wyłącznie JSON zgodny ze schematem `" + role["output_schema"] + "`.")
    cfg = res["cfg"]
    doc = {"_generated": GENERATED, "role": role["name"], "model_profile": res["profile"], "hosting": res["hosting"],
           "provider": cfg.get("opencode_provider"), "api_base_env": cfg.get("api_base_env"), "api_key_env": cfg.get("api_key_env"),
           "model": res["model"], "variant": res.get("variant"), "tier": res["tier"], "reasoning": role["reasoning"],
           "tools": [t for t in tools if t["name"] in role["tools"]], "runtime_policy": "agents/runtime-policy.yaml",
           "system": system, "response_schema": schema, "escalation": cfg.get("escalation", [])}
    return json.dumps(doc, ensure_ascii=False, indent=2) + "\n"


def render_role_block(rows: list[tuple]) -> str:
    table = "\n".join(f"| `{n}` | {scope} | {tier} | `{model}`{(' · ' + variant) if variant else ''} | {hosting} | {dc} |"
                      for n, scope, tier, model, variant, hosting, dc in rows)
    return (f"{ROLE_BEGIN} — sekcję generuje tools/agents/render_agents.py; nie edytuj ręcznie -->\n"
            "## Agenci (OpenCode)\n\n"
            "| Agent | Zakres zapisu | Poziom | Model · wariant | Hosting | Klasa danych |\n| --- | --- | --- | --- | --- | --- |\n"
            + table + "\n\nModel i warianty pochodzą z profilu modeli w `config/models.yaml` (ADR-021); poziom wybiera model i wariant "
            "rozumowania, eskalacja: wyższy wariant, potem człowiek. Wszystkie role używają modelu w infrastrukturze banku (ADR-016); "
            "klasa danych decyduje o przeglądzie bezpieczeństwa.\n" + ROLE_END)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=None, help="profil modeli z config/models.yaml")
    ap.add_argument("--targets", default=None, help="opencode,agents-md,json")
    ap.add_argument("--check", action="store_true", help="nie zapisuj; kod 1, jeśli pliki są nieaktualne")
    args = ap.parse_args()

    registry, models, tools, agents_md, project_rules, profiles = load()
    model_profile = args.profile or os.environ.get("PH_MODEL_PROFILE") or models["default_profile"]
    targets = args.targets.split(",") if args.targets else models["profiles"][model_profile].get("targets", ["opencode", "agents-md"])
    roles = {r["name"]: r for r in registry["roles"]}
    outputs: dict[Path, str] = {}
    warnings: list[str] = []
    resolved_all, rows = [], []

    agents = []  # (nazwa, rola, res, opis, edit, treść, primary, zakres)
    for r in registry["roles"]:
        res = resolve(r, model_profile, models)
        agents.append((r["name"], r, res, r["description"], platform_edit(r), prompt_for(r), r["name"] == "orchestrator", "platforma"))
    for prof in profiles:
        pid = prof["id"]
        prof_class = prof.get("dev", {}).get("dataClass", prof["data"]["classification"])
        for role_name in prof.get("dev", {}).get("agents", []):
            r = roles[role_name]
            dc = max(r["data_class"], prof_class, key=lambda c: CLASS_RANK[c])
            res = resolve(r, model_profile, models, dc)
            edit = {"*": "deny", f"profiles/{pid}/**": "allow", RFC_GLOB: "allow"} if WRITE_TOOLS & set(r["tools"]) else "deny"
            desc = f"Profil „{pid}” ({prof['owner']['team']}): {r['description']} Zapis wyłącznie w profiles/{pid}/**."
            agents.append((f"{pid}-{role_name}", r, res, desc, edit, prompt_for(r) + profile_addendum(prof), False, f"`profiles/{pid}/**`"))

    for name, r, res, desc, edit, body, primary, scope in agents:
        resolved_all.append(res)
        own = ", ".join(f"`{w}`" for w in r.get("writes", []))
        rows.append((name, scope if scope != "platforma" else ("brak (tylko odczyt)" if edit == "deny" else (own or "platforma (bez `profiles/<id>/**`)")),
                     res["tier"], res["model"], res.get("variant"), res["hosting"], res["data_class"]))
        if not opencode_model(res):
            warnings.append(f"{name}: model {res['model']} nieustalony — ustaw zmienne profilu modeli {res['profile']}")
        limit, need = res["cfg"].get("context_limit_tokens"), r["requires"]["min_context_tokens"]
        if limit and limit < need:
            warnings.append(f"{name}: kontekst {limit} < wymagane {need} — orkiestrator dzieli pakiety rozmiaru L")
        if "opencode" in targets:
            outputs[ROOT / f".opencode/agent/{name}.md"] = render_opencode_agent(name, r, res, desc, edit, body, primary)
        if "json" in targets:
            outputs[ROOT / f"agents/dist/{model_profile}/{name}.json"] = render_json(r, res, tools, project_rules, body)

    if "opencode" in targets:
        arch = next(a for a in agents if a[0] == "architect")[2]
        small = next(a for a in agents if a[0] == "ci-triage")[2]
        outputs[ROOT / "opencode.json"] = render_opencode_config(models, resolved_all, arch, small)
        stale_agents = {p.name for p in (ROOT / ".opencode/agent").glob("*.md")} - {f"{a[0]}.md" for a in agents} \
            if (ROOT / ".opencode/agent").exists() else set()
        for orphan in sorted(stale_agents):
            warnings.append(f"plik .opencode/agent/{orphan} nie odpowiada żadnej roli — usuń go")
    if "agents-md" in targets:
        block = render_role_block(rows)
        if ROLE_BEGIN not in agents_md or ROLE_END not in agents_md:
            raise ConfigError("AGENTS.md nie zawiera znaczników bloku ról")
        head, rest = agents_md.split(ROLE_BEGIN, 1)
        tail = rest.split(ROLE_END, 1)[1]
        outputs[ROOT / "AGENTS.md"] = head + block + tail

    stale = []
    for path, content in sorted(outputs.items()):
        current = path.read_text(encoding="utf-8") if path.exists() else None
        if current != content:
            stale.append(path.relative_to(ROOT))
            if not args.check:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
    for w in sorted(set(warnings)):
        print(f"OSTRZEŻENIE: {w}", file=sys.stderr)
    if args.check:
        for s in stale:
            print(f"NIEAKTUALNE: {s}", file=sys.stderr)
        return 1 if stale else 0
    print(f"profil modeli: {model_profile} · agentów: {len(agents)} · zapisano {len(stale)} plików, bez zmian {len(outputs) - len(stale)}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ConfigError as e:
        print(f"BŁĄD KONFIGURACJI: {e}", file=sys.stderr)
        sys.exit(2)
