#!/usr/bin/env python3
"""Jedna komenda po każdej zmianie źródeł: odświeża wszystko, co jest generowane, i uruchamia wszystkie bramki repozytorium.

  python3 tools/refresh.py            # wygeneruj i sprawdź
  python3 tools/refresh.py --check    # tylko sprawdź (bramka CI: kod 1, gdy coś jest nieaktualne albo niespójne)

Kolejność ma znaczenie: CODEOWNERS i agenci zależą od profili, dashboard od wyceny, artefakty od dashboardu,
źródła notesu od wszystkiego. Każdy krok to istniejące narzędzie — ten skrypt niczego nie generuje sam.
Odpowiednik .NET: `ph refresh` (tools/dotnet/README.md).
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# (opis, skrypt, argumenty przy generowaniu, argumenty przy --check); None = krok pomijany w danym trybie
STEPS = [
    ("manifesty profili i CODEOWNERS", "tools/profiles/validate_profiles.py", ["--write-codeowners"], ["--check"]),
    ("agenci OpenCode, opencode.json, tabela ról", "tools/agents/render_agents.py", [], ["--check"]),
    ("spójność planów", "tools/plan/validate_plan.py", ["--check"], ["--check"]),
    ("formatki a katalog pól i BPMN", "tools/forms/validate_forms.py", ["--check"], ["--check"]),
    ("wycena planu", "tools/plan/estimate.py", [], ["--check"]),
    ("dane dashboardu", "tools/plan/export_dashboard_data.py", [], ["--check"]),
    ("artefakty projektowe", "tools/artifacts/render_artifacts.py", [], ["--check"]),
    ("źródła notesu", "tools/handover/build_notebook_sources.py", [], ["--check"]),
    ("test strażnika zapisu", "tools/guard/enforce_write_scope.py", ["--self-test"], ["--self-test"]),
    ("test walidatora profili", "tools/profiles/validate_profiles.py", ["--self-test"], ["--self-test"]),
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    failed = []
    for title, script, generate, check in STEPS:
        res = subprocess.run([sys.executable, str(ROOT / script), *(check if args.check else generate)], cwd=ROOT, capture_output=True, text=True)
        print(f"[{'OK ' if res.returncode == 0 else 'BŁĄD'}] {title}  ({script})")
        if res.returncode != 0:
            failed.append(title)
            for line in ((res.stdout or "") + (res.stderr or "")).strip().splitlines()[-15:]:
                print(f"       {line}")
    print("wynik: " + ("wszystko aktualne i spójne" if not failed else "do poprawy — " + ", ".join(failed)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
