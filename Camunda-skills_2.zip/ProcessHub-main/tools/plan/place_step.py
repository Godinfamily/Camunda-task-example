#!/usr/bin/env python3
"""Wyznacza miejsce nowego kroku w planie: identyfikator, zależności, bramkę, pozycję w pliku i konflikty zapisu.

  python3 tools/plan/place_step.py szkic.yaml                                        # plan platformy
  python3 tools/plan/place_step.py szkic.yaml --backlog profiles/lizing/backlog.yaml # plan zespołu profilu
  python3 tools/plan/place_step.py szkic.yaml --backlog … --apply                    # wstaw krok do pliku planu (człowiek)

Szkic to jeden krok w YAML — te same pola co w planie (`title`, `agent`, `writes`, `reads`, `dod`…); `id`, `depends_on`
i `gate_before` są opcjonalne, narzędzie je proponuje. Skąd biorą się zależności:
  1. podane w szkicu,
  2. krok, który tworzy plik z `reads` (jeśli plik jeszcze nie istnieje),
  3. kroki, które piszą w tym samym miejscu co szkic (z tej samej lub wcześniejszej fazy) — nowy krok staje za nimi,
     żeby nie iść z nimi równolegle,
  4. kroki platformy wymagane przez część profilu, w której krok pisze (np. `frontend/` → S47).
Zależności wynikające z innych zależności albo z bramki są pomijane. Odpowiednik .NET: `ph plan place`. Kod wyjścia 1, gdy szkic ma błędy; --apply wtedy nie zapisuje.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import yaml

from validate_plan import PHASE_GATES, ROOT, PlanCheck, covered, glob_overlap, load_yaml

# Część profilu (pierwszy katalog w profiles/<id>/) → kroki platformy, które muszą być scalone wcześniej.
PROFILE_NEEDS = {
    "backend": ["S27"],       # SDK rozszerzeń, izolacja danych profilu
    "db": ["S27"],
    "frontend": ["S47"],      # sloty UI i trasy profili
    "bpmn": ["S17"],          # wtyczka bpmnlint ph
    "forms": ["S17"],         # kontrakt ph:outputs w modelach
}
PROFILE_HINT = "krok implementuje operacje z manifestu (task-action, profile-action, query…)? dodaj do szkicu depends_on: [S38]"
FIELD_ORDER = ["id", "title", "phase", "gate_before", "agent", "pair", "pair_task", "tier", "size", "critical", "depends_on",
               "reads", "refs", "writes", "specs", "outcome", "notes", "dod", "acceptance"]
FLOW_PLAIN = {"depends_on", "reads"}
FLOW_QUOTED = {"writes", "specs"}
BLOCK = {"refs", "outcome", "notes", "dod", "acceptance"}
QUOTED = {"title", "pair_task"}


def quote(text: str) -> str:
    return json.dumps(text, ensure_ascii=False)


def emit_step(step: dict) -> list[str]:
    """Krok w układzie pliku planu (lista elementów z wcięciem 2 spacji)."""
    lines = []
    for key in FIELD_ORDER + sorted(k for k in step if k not in FIELD_ORDER):
        if key not in step:
            continue
        value = step[key]
        prefix = "  - " if not lines else "    "
        if key in FLOW_PLAIN:
            lines.append(f"{prefix}{key}: [{', '.join(value)}]")
        elif key in FLOW_QUOTED:
            lines.append(f"{prefix}{key}: [{', '.join(quote(v) for v in value)}]")
        elif key in BLOCK:
            lines.append(f"{prefix}{key}:")
            lines += [f"      - {quote(v)}" for v in value]
        elif key in QUOTED:
            lines.append(f"{prefix}{key}: {quote(value)}")
        elif isinstance(value, bool):
            lines.append(f"{prefix}{key}: {'true' if value else 'false'}")
        else:
            lines.append(f"{prefix}{key}: {value}")
    return lines


def next_id(plan: PlanCheck, draft: dict) -> str:
    if plan.profile:
        prefix = next(iter(plan.steps)).split("-")[0] if plan.steps else plan.profile[:3].upper()
        numbers = [int(i.split("-")[1]) for i in plan.steps if "-" in i and i.split("-")[1].isdigit()]
        return f"{prefix}-{(max(numbers) + 1 if numbers else 1):02d}"
    used = {int(i[1:]) for i in plan.steps if i[1:].isdigit()}
    phase = draft.get("phase")
    if isinstance(phase, int):
        free = [n for n in range(phase * 10, phase * 10 + 10) if n not in used]
        if free:
            return f"S{free[0]:02d}"
    return f"S{max(used) + 1:02d}"


def suggest_dependencies(plan: PlanCheck, draft: dict) -> tuple[dict[str, list[str]], list[str]]:
    """Zwraca (zależność → powody, uwagi)."""
    reasons: dict[str, list[str]] = {}
    remarks: list[str] = []

    def add(dep: str, why: str) -> None:
        reasons.setdefault(dep, [])
        if why not in reasons[dep]:
            reasons[dep].append(why)

    for dep in draft.get("depends_on", []):
        add(dep, "podane w szkicu")
    known = list((plan.platform.steps if plan.platform else {}).items()) + list(plan.steps.items())
    for r in draft.get("reads", []):
        if not (ROOT / r).exists():
            # twórcą jest krok z najwęższym pasującym zakresem (np. `*/Contracts/**`, nie całe `src/Modules/*/**`)
            producers = [(max(len(w) for w in s.get("writes", []) if covered(r, [w])), -n, sid)
                         for n, (sid, s) in enumerate(known) if covered(r, s.get("writes", []))]
            if producers:
                add(max(producers)[2], f"tworzy {r}")
    phase = draft.get("phase")
    for sid, s in plan.steps.items():
        if isinstance(phase, int) and s.get("phase", 0) > phase:
            continue                    # krok z późniejszej fazy nie może być poprzednikiem
        hit = next(((x, y) for x in draft.get("writes", []) for y in s.get("writes", []) if glob_overlap(x, y)), None)
        if hit:
            add(sid, f"pisze w tym samym miejscu ({hit[1]})")
    if plan.profile:
        own = f"profiles/{plan.profile}/"
        parts = sorted({w[len(own):].split("/")[0] for w in draft.get("writes", []) if w.startswith(own)})
        for part in parts:
            for dep in PROFILE_NEEDS.get(part, []):
                add(dep, f"zapis w {part}/ wymaga kroku platformy {dep}")
        if "backend" in parts and "S38" not in reasons:
            remarks.append(PROFILE_HINT)
    for dep in [d for d in reasons if plan.step(d)]:
        if any(plan.precedes(dep, other) for other in reasons if other != dep and plan.step(other)):
            del reasons[dep]            # wynika z innej zależności
    return reasons, remarks


def insert_position(plan: PlanCheck, lines: list[str], step: dict) -> tuple[int, str]:
    """Indeks linii, przed którą wstawić krok, i opis miejsca."""
    def block_end(sid: str) -> int | None:
        start = next((n for n, line in enumerate(lines) if re.match(rf"^  - (\{{ )?id: {re.escape(sid)}\b", line)), None)
        if start is None:
            return None
        end = start + 1
        while end < len(lines) and not lines[end].startswith("  - ") and not lines[end].startswith("  # "):
            end += 1
        while end > start + 1 and not lines[end - 1].strip():
            end -= 1
        return end

    order = list(plan.steps)
    own = [d for d in step.get("depends_on", []) if d in plan.steps and d != step["id"]]
    anchor = max(own, key=order.index) if own else None
    where = f"po kroku {anchor}" if anchor else "na końcu planu"
    if not anchor and not plan.profile and isinstance(step.get("phase"), int):
        same = [i for i, s in plan.steps.items() if s.get("phase") == step["phase"] and i != step["id"]]
        if same:
            anchor, where = same[-1], f"na końcu fazy {step['phase']} (po kroku {same[-1]})"
    end = block_end(anchor) if anchor else None
    if end is None:
        end = len(lines)
        while end > 0 and not lines[end - 1].strip():
            end -= 1
    return end, where


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("draft", help="plik YAML z jednym krokiem")
    ap.add_argument("--backlog", default="plan/backlog.yaml")
    ap.add_argument("--apply", action="store_true", help="wstaw krok do pliku planu (tylko gdy szkic nie ma błędów)")
    args = ap.parse_args()

    registry = load_yaml("agents/registry.yaml")
    models = load_yaml("config/models.yaml")
    platform = PlanCheck("plan/backlog.yaml", registry, models)
    plan = platform if args.backlog == "plan/backlog.yaml" else PlanCheck(args.backlog, registry, models, platform)
    draft = yaml.safe_load(Path(args.draft).read_text(encoding="utf-8"))
    if isinstance(draft, dict) and isinstance(draft.get("steps"), list) and len(draft["steps"]) == 1:
        draft = draft["steps"][0]
    if not isinstance(draft, dict) or "title" not in draft or "agent" not in draft:
        sys.exit("Szkic musi być jednym krokiem (mapowanie YAML) z polami co najmniej `title` i `agent`.")

    if not plan.profile and not isinstance(draft.get("phase"), int):
        sys.exit("Szkic kroku platformy musi mieć pole `phase` (0–6) — od niego zależą bramki i miejsce w planie.")
    sid = draft.get("id") or next_id(plan, draft)
    if sid in plan.steps:
        sys.exit(f"Krok {sid} już istnieje w {plan.rel}")
    reasons, remarks = suggest_dependencies(plan, draft)
    step = dict(draft)
    step["id"] = sid
    step["depends_on"] = [d for d in list(plan.platform.steps if plan.platform else []) + list(plan.steps) if d in reasons] \
        + [d for d in reasons if not plan.step(d)]
    plan.steps[sid] = step

    gate_note = "bez zmian"
    if not plan.profile and not step.get("gate_before"):
        missing = [g for g in PHASE_GATES.get(step.get("phase", 0), []) if g in plan.gates and not plan.behind_gate(sid, g)]
        if missing:
            step["gate_before"] = missing[-1]
            gate_note = f"dodano {missing[-1]} — faza {step.get('phase')} leży za tą bramką, a zależności jej nie wymuszają"
    for dep in step["depends_on"]:
        if not plan.step(dep):
            plan.err(sid, f"nieznana zależność {dep}")
    if sid in plan.ancestors(sid):
        plan.err(sid, "cykl zależności")
    manifest = ROOT / Path(plan.rel).parent / "profile.yaml"
    dev = yaml.safe_load(manifest.read_text(encoding="utf-8")).get("dev", {}).get("agents") if plan.profile and manifest.exists() else None
    plan.check_agents(sid, step, dev)
    plan.check_reads(sid, step)
    plan.check_specs(sid, step)
    plan.check_dod(sid, step)
    if plan.profile:
        for w in step.get("writes", []):
            if not w.startswith(f"profiles/{plan.profile}/"):
                plan.err(sid, f"zapis poza profilem: {w}")
    conflicts = [c for c in plan.conflicts() if sid in (c[0], c[1])]

    lines = (ROOT / plan.rel).read_text(encoding="utf-8").split("\n")
    position, where = insert_position(plan, lines, step)
    block = emit_step(step)

    print(f"Krok:        {sid} — {step['title']}")
    print(f"Plan:        {plan.rel}")
    print(f"Zależności:  {', '.join(step['depends_on']) or 'brak'}")
    for dep in step["depends_on"]:
        print(f"  - {dep}: {'; '.join(reasons[dep])}")
    print(f"Bramka:      {step.get('gate_before', 'brak')} ({gate_note})")
    print(f"Miejsce:     {where} — linia {position + 1} pliku")
    print("Konflikty:   " + ("brak — krok nie pójdzie równolegle z innym piszącym w tym samym miejscu" if not conflicts else ""))
    for a, b, x, y in conflicts:
        print(f"  - {b if a == sid else a}: {x} ↔ {y} — jeśli tamten krok ma objąć ten, dopisz {sid} do jego depends_on")
    for r in remarks:
        print(f"Uwaga:       {r}")
    for e in plan.errors:
        print(f"BŁĄD         {e}")
    for w in plan.warnings:
        print(f"OSTRZEŻENIE  {w}")
    if not plan.profile:
        print(f"Ręcznie:     wycena w plan/estimates.yaml (klucz {sid}) i wiersz w tabeli plan/execution-plan.md")
    print("\n# --- wpis do planu ---")
    print("\n".join(block))

    if plan.errors:
        print("\nszkic ma błędy — popraw i uruchom ponownie" + (" (nie zapisano)" if args.apply else ""))
        return 1
    if args.apply:
        separated = any(lines[n] == "" and lines[n + 1].startswith("  - ") for n in range(len(lines) - 1))   # kroki oddzielone pustą linią
        new = lines[:position] + ([""] if separated else []) + block + lines[position:]
        (ROOT / plan.rel).write_text("\n".join(new), encoding="utf-8")
        print(f"\nzapisano krok {sid} w {plan.rel} — uruchom: python3 tools/refresh.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
