#!/usr/bin/env python3
"""Sprawdza pliki formatek (.form, Camunda Forms) względem katalogu pól i kontraktu danych z BPMN — bez modelu.

  python3 tools/forms/validate_forms.py                 # formatki wzorcowe i formatki profili
  python3 tools/forms/validate_forms.py --check         # bramka: kod 1, gdy są błędy
  python3 tools/forms/validate_forms.py profiles/flota/forms/rejestracja-samochodu/weryfikacja-wniosku.form

Gdzie leżą formatki w repozytorium:
  design/forms/examples/*.form                          formatki wzorcowe platformy
  profiles/<id>/forms/<bpmnProcessId>/<klucz>.form      formatki profilu przygotowane do importu (Form.Import);
                                                        `start.form` = formatka startowa procesu
Platforma nie wdraża tych plików automatycznie (ADR-018) — importuje je administrator procesu w projektancie formatek.

Błędy: niepoprawny JSON, pola najwyższego poziomu spoza formatu, typ pola spoza katalogu albo o statusie planowany/zablokowany,
klucz niezgodny ze wzorcem, powtórzony klucz lub id, własność stylu, własność spoza przestrzeni `ph:`, pole danych bez etykiety,
`ph:field` spoza przestrzeni nazw profilu, proces spoza profilu, brak pola wymaganego przez `ph:outputs` zadania w BPMN.
Ostrzeżenia: referencja `ph:form/<klucz>` w BPMN profilu bez pliku formatki (formatkę można też utworzyć w projektancie).

Odpowiednik .NET: `ph forms validate` (tools/dotnet/README.md).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
TOP_LEVEL = {"type", "id", "schemaVersion", "executionPlatform", "executionPlatformVersion", "exporter", "components", "versionTag"}
STYLE_KEYS = {"style", "styles", "class", "className", "css", "color", "background", "font", "fontSize", "margin", "padding", "border"}
KEY_RE = re.compile(r"^\w+(\.\w+)*$")
NS = {"bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL", "zeebe": "http://camunda.org/schema/zeebe/1.0"}
START_FORM = "start"


def catalog() -> dict:
    return yaml.safe_load((ROOT / "design/forms/field-catalog.yaml").read_text(encoding="utf-8"))


def walk(components: list, path: str = ""):
    """Wszystkie komponenty schematu z pełnym kluczem danych (kontenery `group` i `dynamiclist` dodają `path`)."""
    for c in components or []:
        yield c, path
        if isinstance(c.get("components"), list):
            prefix = f"{path}{c['path']}." if c.get("path") else path
            yield from walk(c["components"], prefix)


def check_form(file: Path, cat: dict, profile: dict | None) -> tuple[list[str], set[str]]:
    errors: list[str] = []
    try:
        doc = json.loads(file.read_text(encoding="utf-8"))
    except (ValueError, UnicodeDecodeError) as e:
        return [f"niepoprawny JSON: {e}"], set()
    lib = cat["library"]
    types = {t["type"]: t for t in cat["types"]}
    for extra in sorted(set(doc) - TOP_LEVEL):
        errors.append(f"pole najwyższego poziomu „{extra}” nie należy do formatu Camunda Forms")
    if doc.get("type") != "default":
        errors.append('type musi mieć wartość "default"')
    if doc.get("id") != file.stem and profile is not None and file.stem != START_FORM:
        errors.append(f"id „{doc.get('id')}” musi być równe nazwie pliku „{file.stem}” (klucz formatki)")
    if not isinstance(doc.get("schemaVersion"), int) or doc["schemaVersion"] > lib["schema_version_max"]:
        errors.append(f"schemaVersion musi być liczbą ≤ {lib['schema_version_max']}")
    if doc.get("executionPlatform") != lib["execution_platform"] or doc.get("executionPlatformVersion") != lib["execution_platform_version"]:
        errors.append(f"executionPlatform / executionPlatformVersion: wymagane „{lib['execution_platform']}” / „{lib['execution_platform_version']}”")
    keys: set[str] = set()
    ids: set[str] = set()
    for c, prefix in walk(doc.get("components", [])):
        where = c.get("id") or c.get("key") or c.get("type")
        t = types.get(c.get("type"))
        if t is None:
            errors.append(f"{where}: typ „{c.get('type')}” nie występuje w katalogu pól")
        elif t["status"] not in ("supported", "restricted"):
            errors.append(f"{where}: typ „{c['type']}” ma status „{t['status']}” — nie wolno go użyć")
        if c.get("id") in ids:
            errors.append(f"{where}: powtórzone id")
        ids.add(c.get("id"))
        for bad in sorted(STYLE_KEYS & set(c)):
            errors.append(f"{where}: własność wyglądu „{bad}” — schemat nie niesie stylów (ADR-019)")
        for prop, value in (c.get("properties") or {}).items():
            if not prop.startswith("ph:"):
                errors.append(f"{where}: własność „{prop}” spoza przestrzeni ph:")
            elif prop == "ph:field" and profile is not None and not str(value).startswith(profile["id"] + "."):
                errors.append(f"{where}: ph:field „{value}” spoza przestrzeni nazw profilu {profile['id']}. (R10)")
            elif prop == "ph:field" and profile is None:
                errors.append(f"{where}: ph:field wolno użyć tylko w formatkach procesów profilu (R9)")
        columns = (c.get("layout") or {}).get("columns")
        if columns is not None and not (isinstance(columns, int) and 2 <= columns <= 16):
            errors.append(f"{where}: layout.columns musi być puste albo z zakresu 2–16")
        if "key" in c:
            if not KEY_RE.match(str(c["key"])):
                errors.append(f"{where}: klucz „{c['key']}” niezgodny ze wzorcem {KEY_RE.pattern}")
            full = prefix + str(c["key"])
            if full in keys:
                errors.append(f"{where}: powtórzony klucz danych „{full}”")
            keys.add(full)
            if not c.get("label"):
                errors.append(f"{where}: pole danych bez etykiety (label)")
    return errors, keys


def bpmn_contracts(profile_dir: Path) -> dict[str, dict[str, list[str]]]:
    """bpmnProcessId → {klucz formatki albo `start` → lista zmiennych z ph:outputs}."""
    out: dict[str, dict[str, list[str]]] = {}
    for f in sorted(profile_dir.glob("bpmn/**/*.bpmn")):
        try:
            root = ET.parse(f).getroot()
        except ET.ParseError:
            continue
        for process in root.findall("bpmn:process", NS):
            forms = out.setdefault(process.get("id"), {})
            for el in list(process.iter(f"{{{NS['bpmn']}}}userTask")) + list(process.iter(f"{{{NS['bpmn']}}}startEvent")):
                ref = el.find(".//zeebe:formDefinition", NS)
                outputs = next((p.get("value", "") for p in el.findall(".//zeebe:property", NS) if p.get("name") == "ph:outputs"), None)
                if el.tag.endswith("startEvent"):
                    key = START_FORM if outputs is not None else None
                else:
                    reference = ref.get("externalReference", "") if ref is not None else ""
                    key = reference[len("ph:form/"):] if reference.startswith("ph:form/") else None
                if key:
                    forms[key] = [o.split(":")[0].strip() for o in (outputs or "").split(",") if o.strip()]
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*", help="pliki .form (domyślnie: wzorcowe i wszystkich profili)")
    ap.add_argument("--check", action="store_true", help="kod 1, gdy są błędy")
    args = ap.parse_args()
    cat = catalog()
    files = [Path(f).resolve() for f in args.files] or sorted(ROOT.glob("design/forms/examples/*.form")) + sorted(
        p for p in ROOT.glob("profiles/*/forms/**/*.form") if not p.relative_to(ROOT).parts[1].startswith("_"))
    errors = warnings = 0
    seen: dict[tuple[str, str], set[str]] = {}
    profiles: dict[str, dict] = {}
    for f in files:
        rel = f.relative_to(ROOT)
        profile = None
        found: list[str] = []
        if rel.parts[0] == "profiles":
            pid = rel.parts[1]
            profile = profiles.setdefault(pid, yaml.safe_load((ROOT / "profiles" / pid / "profile.yaml").read_text(encoding="utf-8")))
            if len(rel.parts) != 5 or rel.parts[2] != "forms":
                found.append("formatka profilu musi leżeć w profiles/<id>/forms/<bpmnProcessId>/<klucz>.form")
            elif rel.parts[3] not in [p["bpmnProcessId"] for p in profile["processes"]]:
                found.append(f"proces „{rel.parts[3]}” nie należy do profilu {pid} (R9, R11)")
        form_errors, keys = check_form(f, cat, profile)
        found += form_errors
        if profile is not None and len(rel.parts) == 5:
            seen[(rel.parts[1], rel.parts[3] + "/" + f.stem)] = keys
        for e in found:
            print(f"BŁĄD        {rel}: {e}")
        errors += len(found)
    if not args.files:
        for pdir in sorted(p for p in (ROOT / "profiles").iterdir() if p.is_dir() and not p.name.startswith("_")):
            for process, forms in bpmn_contracts(pdir).items():
                for key, outputs in forms.items():
                    keys = seen.get((pdir.name, f"{process}/{key}"))
                    target = f"profiles/{pdir.name}/forms/{process}/{key}.form"
                    if keys is None:
                        if not args.check:
                            print(f"OSTRZEŻENIE {target}: brak pliku dla referencji z BPMN (formatkę można też utworzyć w projektancie)")
                        warnings += 1
                        continue
                    for missing in [o for o in outputs if o not in keys]:
                        print(f"BŁĄD        {target}: brak pola „{missing}” wymaganego przez ph:outputs w BPMN")
                        errors += 1
    print(f"formatek: {len(files)} · błędów: {errors} · ostrzeżeń: {warnings}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
