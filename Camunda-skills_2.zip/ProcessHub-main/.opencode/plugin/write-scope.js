// Plugin OpenCode: blokuje zapis poza .agent-scope, edycję ścieżek chronionych (specyfikacje, kontrakty, ADR,
// uprawnienia, SDK rozszerzeń, kontrakty profili) oraz zapis do cudzego profilu projektu.
// Logika: tools/guard/enforce_write_scope.py albo narzędzie .NET `ph guard` (tools/dotnet) — ta sama w CI.
//
// Format eksportu — jeden obiekt domyślny, zgodny z oboma mechanizmami ładowania pluginów OpenCode:
//   - `id` + `server`  — moduł pluginu serwera (`PluginModule` z @opencode-ai/plugin): `server` zwraca haki,
//                        w tym `tool.execute.before`, który zatrzymuje zapis poza zakresem;
//   - `id` + `setup`   — definicja pluginu v2 (`define({ id, setup })` z @opencode-ai/plugin/v2), którą nowsze wersje
//                        OpenCode wymagają od plików w `.opencode/plugin/` („plugin must export a default definition
//                        with an id and an effect or setup function”). API v2 nie ma haka na wywołania narzędzi,
//                        więc `setup` niczego nie rejestruje — strażnika uruchamia `server`.
// Nie dodawaj innych eksportów: starsze ładowarki wywołują każdy eksport modułu jako plugin.
// Test: node .opencode/lib/write-scope.test.mjs
import { check, targetsOf } from "../lib/write-scope-core.js"

export const PLUGIN_ID = "process-hub-write-scope"

/** Haki pluginu serwera: przed każdym zapisem pyta strażnika repozytorium; odmowa przerywa wywołanie narzędzia. */
async function server({ directory, worktree } = {}) {
  const root = worktree || directory || process.cwd()
  return {
    "tool.execute.before": async (input, output) => {
      for (const file of targetsOf(input?.tool, output?.args)) {
        const result = check(root, file, input?.tool)
        if (!result.ok) throw new Error(result.reason)
      }
    },
  }
}

/** Definicja v2: wymagana przez nowszą ładowarkę; strażnik działa przez `server`. */
function setup() {}

export default { id: PLUGIN_ID, server, setup }
