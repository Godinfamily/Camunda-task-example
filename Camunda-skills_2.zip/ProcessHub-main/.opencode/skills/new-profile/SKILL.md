---
name: new-profile
description: Zakładanie nowego profilu projektu w Process Hub od zera — manifest (uprawnienia, role, operacje, trasy, sloty), przypisania grup AD, procesy BPMN, własne formatki do importu, dedykowane widoki, plan zespołu i agenci profilu. Używaj ZAWSZE, gdy powstaje nowy profil albo gdy do istniejącego profilu dochodzi nowy proces, rola, formatka lub widok.
---
# Nowy profil projektu — od zera do pierwszego kroku

Zasada: **najpierw deklaracja, potem kod**. Każdy element profilu istnieje najpierw w `profiles/<id>/profile.yaml`; kod bez wpisu w manifeście nie zostanie uruchomiony. Wszystko, co da się sprawdzić, sprawdza skrypt — uruchamiaj go po każdym etapie i poprawiaj do zielonego, zanim przejdziesz dalej.

Nie wymyślaj: kluczy manifestu (tylko `profiles/profile.schema.json`), nazw grup AD, nazw ról i procesów (podaje je zespół profilu), interfejsów SDK (sprawdź w `src/Platform/ProcessHub.Extensibility`), typów pól (tylko `design/forms/field-catalog.yaml`). Brak danych = pytanie w `open_questions` i status `blocked`.

## Dane wejściowe (bez nich nie zaczynaj)

| Potrzebne | Przykład | Kto podaje |
| --- | --- | --- |
| identyfikator profilu: małe litery i cyfry, 2–24 znaki | `lizing` | zespół profilu |
| nazwa, zespół (grupa w systemie kontroli wersji), właściciel produktu | „Lizing”, `@bank/zespol-lizing` | zespół profilu |
| procesy: `bpmnProcessId` i nazwa każdego | `umowa-lizingowa` | zespół profilu |
| role projektowe i grupy AD | „Analityk lizingu” ← `PH-LIZING-ANALITYCY` | zespół profilu + bezpieczeństwo |
| dedykowane widoki: strony, widżety, panele, pola formatek | strona „Rejestr umów” | zespół profilu |
| formatki: lista zadań użytkownika i pól każdej formatki | „Ocena wniosku”: kwota, decyzja, uzasadnienie | zespół profilu |
| klasa danych i retencja | `confidential`, 60 miesięcy | zespół profilu + bezpieczeństwo |

## Etap 0 — szkielet (człowiek, dwie komendy)

Agent nie zakłada profilu (zmienia się własność kodu). Człowiek uruchamia:

```bash
python3 tools/profiles/new_profile.py <id> --name "<Nazwa>" --team "<@grupa>" --process <bpmnProcessId>
python3 tools/refresh.py          # CODEOWNERS, agenci <id>-*, wszystkie bramki
```

Powstaje `profiles/<id>/` z manifestem, `authorization.yaml`, `AGENTS.md`, planem `backlog.yaml` (kroki `<PREFIKS>-01…05`) i katalogami `bpmn/`, `forms/`, `backend/`, `db/`, `frontend/`, `specs/`. Dalsze etapy to kroki tego planu: `/profil <id> <PREFIKS>-01`. Kroki spoza szablonu dopisujesz wg skilla `backlog-extension` (`python3 tools/plan/place_step.py <szkic.yaml> --backlog profiles/<id>/backlog.yaml`).

## Etap 1 — manifest `profile.yaml` (krok `-01`)

Kolejność wypełniania — każda sekcja korzysta z poprzedniej:

1. `processes` — wszystkie procesy profilu. Proces ma jednego właściciela.
2. `permissions` — tylko w przestrzeni nazw `<id>.`: `{ id: <id>.<Obszar>.<Akcja>, kind: read | write | sensitive-read, description }`. Zwykle para `View` (read) i `Manage` (write) na każdy dedykowany obszar.
3. `roles` — rola projektowa = role platformy + uprawnienia projektu. Role platformy: `process-starter`, `participant`, `process-manager`, `process-administrator` (pełna lista: `docs/architecture/02-roles-and-authorization.md`). Rola może mieć `platformRoles: []` — wtedy dostaje wyłącznie opcje dedykowane.
4. `data` — `schema: prj_<id>`, `classification`, `retentionMonths`.
5. `operations` — po jednej na każdą czynność. Wybór rodzaju:

   | Potrzeba | `kind` | Wymagane pola |
   | --- | --- | --- |
   | lista lub raport danych profilu | `query` | `permission` |
   | zmiana danych profilu bez zadania (katalog, słownik) | `profile-action` | uprawnienie `write` profilu, `requiresAssignee: false`, bez `appliesTo`, `sdk: "^1.1"` |
   | akcja na zadaniu | `task-action` | `appliesTo`, `requiresAssignee: true` |
   | akcja na sprawie | `case-action` | `appliesTo`, jawne `requiresAssignee` |
   | dodatkowe dane w widoku zadania | `task-enricher` | `appliesTo`; `sensitive: true` przy odczycie wrażliwym |
   | opcje pola formatki z danych profilu | `form-data-source` | `permission` |
   | dane profilu ze zdarzeń procesów | `event-handler` | `permission` |

6. `ui.routes` — każda strona: `{ path: /p/<id>/<nazwa>, title, permission }`.
7. `ui.slots` — każdy element w powłoce: `{ slot, component, title, permission, appliesTo? }`.

   | Dedykowany widok | `slot` |
   | --- | --- |
   | własna sekcja menu | `nav.section` (+ trasy w `ui.routes`) |
   | widżet na pulpicie | `dashboard.widget` |
   | panel w zadaniu | `task.panel` (+ operacja `task-enricher`) |
   | panel w sprawie | `case.panel` |
   | pole formatki z danymi profilu | `form.field` (+ operacja `form-data-source`) |

8. `integrations.jobTypes: ["<id>.*"]`, `dev.agents`, `dev.dataClass` (nie słabsza niż `data.classification`).

Wzorzec kompletnego manifestu: `profiles/flota/profile.yaml`. Sprawdzenie: `python3 tools/profiles/validate_profiles.py --check` — komunikaty i poprawki: `docs/guides/dedykowane-elementy-profilu.md`, sekcja 5.5.

## Etap 2 — `authorization.yaml` (krok `-01`)

```yaml
profile: <id>
assignments:
  - { group: PH-<ID>-<NAZWA>, roles: [<rola-projektowa>] }     # jedna grupa AD należy do jednego profilu
candidateGroups:
  <id>-<nazwa>: PH-<ID>-<NAZWA>                                # grupa kandydująca z BPMN → grupa AD
```

Nie nadajesz ról audytora ani administratora platformy (R7, R10). Plik przegląda bezpieczeństwo.

## Etap 3 — procesy BPMN (krok `-02`)

Plik `profiles/<id>/bpmn/<bpmnProcessId>.bpmn`, identyfikator procesu = wpis w manifeście. Skill `camunda-practices`; wzorzec: `profiles/flota/bpmn/`.

- Zadanie użytkownika: `<zeebe:userTask />`, `<zeebe:assignmentDefinition candidateGroups="…">` z grupą z `candidateGroups`, `<zeebe:formDefinition externalReference="ph:form/<klucz>" />`.
- Kontrakt danych zadania: `<zeebe:property name="ph:outputs" value="zmienna:typ,zmienna:typ" />` (typy: `string`, `number`, `boolean`, `date`).
- Zdarzenie startowe nie ma `externalReference` (Zeebe 8.9 go nie przyjmuje) — tylko `ph:outputs`; formatkę startową przypisuje Form Management.
- Krok systemowy: service task z typem `<id>.<obszar>.<czynność>` i worker w `profiles/<id>/workers/`.

Sprawdzenie: `npx bpmnlint "profiles/<id>/bpmn/**/*.bpmn"`.

## Etap 4 — formatki profilu (krok `-02`)

Formatki należą do aplikacji: wersje, akceptację i wycofanie prowadzi Form Management, a formatka należy do jednego procesu (R11). Repozytorium trzyma **pliki do importu**:

```
profiles/<id>/forms/<bpmnProcessId>/<klucz>.form     # <klucz> = to, co po ph:form/ w BPMN
profiles/<id>/forms/<bpmnProcessId>/start.form       # formatka startowa procesu
```

Szkielet pliku (skopiuj i zmień tylko `id` oraz `components`; wzorzec: `design/forms/examples/ocena-wniosku.form`):

```json
{
  "type": "default",
  "id": "<klucz>",
  "schemaVersion": 19,
  "executionPlatform": "Camunda Cloud",
  "executionPlatformVersion": "8.9.0",
  "exporter": { "name": "Process Hub", "version": "1.0.0" },
  "components": [
    { "type": "textfield", "id": "Field_<klucz>", "key": "<zmienna>", "label": "<Etykieta>",
      "validate": { "required": true }, "layout": { "row": "Row_1", "columns": null } }
  ]
}
```

Reguły (sprawdza je skrypt): typ pola ze statusem wspierany lub z ograniczeniami; każde pole danych ma `key` i `label`; każda zmienna z `ph:outputs` zadania ma pole o tym samym kluczu; żadnych własności wyglądu; własne własności tylko `properties: { "ph:…": … }`; pole profilu to typ bazowy (zwykle `select`) z `"ph:field": "<id>.<nazwa>"`. Skill `camunda-forms`.

Sprawdzenie: `python3 tools/forms/validate_forms.py --check`. Po wdrożeniu administrator procesu importuje pliki w projektancie formatek (`Form.Import`), druga osoba zatwierdza (R8).

## Etap 5 — moduł, dane, operacje (kroki `-03`, `-04`)

Skill `profile-extension`. Jeden wpis `operations[].id` = jedna klasa z atrybutem `[ProfileOperation("<id>.<Nazwa>")]` i rejestracja w `IProfileModule`. Kod nie sprawdza uprawnień, nie pisze audytu, nie obsługuje ponowień. Każda operacja zapisu ma scenariusz dostępu, odmowy i idempotencji w `profiles/<id>/specs/` (`# language: pl`, tagi `@<PREFIKS>-FR-xx`).

## Etap 6 — dedykowane widoki (krok `-05`)

Biblioteka Nx `profile-<id>-ui` z tagiem `scope:profile-<id>`, zależna tylko od `scope:extension-sdk`. Jeden wpis `ui.routes` = jedna strona; jeden wpis `ui.slots` = jeden komponent o nazwie z pola `component`. Przyciski akcji renderuje powłoka z `allowedActions`; komponent nie sprawdza ról. Wygląd tylko z `core/ui-kit` i tokenów; teksty w `profiles/<id>/frontend/i18n/pl.json`. Skill `design-system`.

## Lista kontrolna (wszystko musi być zielone)

```bash
python3 tools/profiles/validate_profiles.py --check     # manifest, przestrzenie nazw, R1, R9, R10, CODEOWNERS
npx bpmnlint "profiles/<id>/bpmn/**/*.bpmn"             # modele
python3 tools/forms/validate_forms.py --check           # formatki ↔ katalog pól ↔ ph:outputs
python3 tools/plan/validate_plan.py --backlog profiles/<id>/backlog.yaml   # plan zespołu
python3 tools/refresh.py --check                        # wszystko, co generowane, jest aktualne
```

## Czego nie robisz

- Nie dodajesz pozycji do menu platformy ani nie zmieniasz jej ekranów — tylko własna sekcja i sloty.
- Nie piszesz własnych kontrolerów ani endpointów — tylko operacje i zapytania z manifestu.
- Nie łączysz się z Camunda poza workerami typów `<id>.*`.
- Nie zmieniasz SDK, kontraktów platformy, `specs/**` ani cudzego profilu — brak punktu rozszerzenia to `docs/rfc/RFC-<krok>-<temat>.md` i status `needs-rfc`.
