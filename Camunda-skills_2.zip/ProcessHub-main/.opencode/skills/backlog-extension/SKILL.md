---
name: backlog-extension
description: Rozszerzanie planu Process Hub o nowe kroki — w planie platformy (plan/backlog.yaml) i w planie zespołu profilu (profiles/<id>/backlog.yaml): szkic kroku, wyznaczenie zależności, bramki, miejsca w pliku i konfliktów zapisu narzędziem place_step.py, wycena, walidacja. Używaj ZAWSZE, gdy do planu dochodzi krok, gdy nowy profil dostaje własny plan albo gdy trzeba ustalić, po czym nowy krok może ruszyć.
---
# Rozszerzanie backlogu — nowy krok we właściwym miejscu

Miejsca kroku nie ustalasz „na oko”. Piszesz szkic, a zależności, bramkę, pozycję w pliku i konflikty wylicza skrypt. Ty decydujesz o treści kroku (cel, wynik, zakres zapisu), skrypt — o kolejności.

## Który plan

| Praca dotyczy | Plan | Identyfikatory | Kto zatwierdza |
| --- | --- | --- | --- |
| platformy (moduły, kontrakty, powłoka, SDK, narzędzia) | `plan/backlog.yaml` | `S` + dwie cyfry | tech lead i architekt — plik chroniony, wstawia człowiek |
| jednego profilu (`profiles/<id>/**`) | `profiles/<id>/backlog.yaml` | `<PREFIKS>-<dwie cyfry>` (np. `KRE-05`) | zespół profilu (CODEOWNERS) |

Krok, który musiałby pisać i w platformie, i w profilu, rozdziel na dwa: krok platformy i zależny od niego krok profilu. Nowy profil dostaje plan z szablonu przy zakładaniu (`new_profile.py`, skill `new-profile`) — tutaj dopisujesz do niego kolejne kroki.

## Procedura

1. **Szkic.** Zapisz jeden krok jako plik YAML (propozycja: `plan/packets/drafts/<nazwa>.yaml` — katalog poza gitem). Pola jak w planie; `id`, `depends_on` i `gate_before` możesz pominąć.

```yaml
title: "Raport umów — zapytanie i strona /p/kredyty/umowy"
agent: frontend-developer            # rola z agents/registry.yaml (w profilu: z dev.agents manifestu)
pair: ui-reviewer                    # opcjonalnie
tier: T2
size: S                              # S | M | L
phase: 3                             # tylko plan platformy — obowiązkowe
reads: [profiles/kredyty/AGENTS.md, profiles/kredyty/profile.yaml, .opencode/skills/profile-extension/SKILL.md]
refs: ["design/mockups/index.html — wyszukaj `renderFleetCatalog`; nie wczytuj całości"]
writes: ["profiles/kredyty/frontend/**"]
specs: []
outcome:
  - "strona /p/kredyty/umowy z listą umów z zapytania kredyty.ContractsReport"
notes:
  - "przyciski akcji renderuje powłoka z allowedActions"
dod:
  - "python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile kredyty"     # platforma: --verify-diff main
  - "npx nx run-many -t lint test build --projects=tag:scope:profile-kredyty"
acceptance: []
```

2. **Miejsce.** Uruchom skrypt i przeczytaj raport:

```bash
python3 tools/plan/place_step.py <szkic.yaml>                                          # plan platformy
python3 tools/plan/place_step.py <szkic.yaml> --backlog profiles/<id>/backlog.yaml     # plan profilu
# bez Pythona: ph plan place <szkic.yaml> [--backlog …]
```

| Linia raportu | Co oznacza | Co robisz |
| --- | --- | --- |
| `Krok` | proponowany identyfikator | przyjmij; własny podaj w szkicu jako `id` |
| `Zależności` | lista `depends_on` z powodem każdej | sprawdź powody (niżej) |
| `Bramka` | `gate_before`, gdy faza leży za bramką, a zależności jej nie wymuszają | przyjmij |
| `Miejsce` | po którym kroku i w której linii pliku | tam wstaw wpis |
| `Konflikty` | kroki, które mogłyby iść równolegle i piszą w tym samym miejscu | zawęź `writes` albo dodaj zależność |
| `Uwaga` | podpowiedź, której skrypt nie rozstrzyga sam | odpowiedz i popraw szkic |
| `BŁĄD` | szkic nie przejdzie walidacji | popraw szkic i uruchom ponownie |

3. **Powody zależności** — skąd skrypt je bierze i kiedy je zmienić:

| Powód w raporcie | Znaczenie | Kiedy poprawić szkic |
| --- | --- | --- |
| `podane w szkicu` | Twoja decyzja | — |
| `tworzy <plik>` | plik z `reads` jeszcze nie istnieje; tworzy go ten krok | usuń plik z `reads`, jeśli nie jest potrzebny |
| `pisze w tym samym miejscu (<glob>)` | krok z tej samej lub wcześniejszej fazy ma nakładający się `writes`; nowy krok staje za nim | zawęź `writes`, jeśli kroki są naprawdę niezależne |
| `zapis w <część>/ wymaga kroku platformy` | reguła dla profili (tabela niżej) | — |

Zależność, która wynika z innej zależności albo z bramki, jest pomijana — krótka lista jest poprawna.

4. **Wstawienie.** Wpis z końca raportu (`# --- wpis do planu ---`) trafia do pliku planu w miejscu z linii `Miejsce`:
   - plan profilu — wklej wpis sam, jeśli `profiles/<id>/backlog.yaml` jest w zakresie zapisu Twojego kroku; inaczej przekaż raport zespołowi;
   - plan platformy — plik jest chroniony: wstawia człowiek komendą `python3 tools/plan/place_step.py <szkic.yaml> --apply` (agentom `--apply` jest zakazane).
5. **Wycena** (tylko plan platformy): wiersz w `plan/estimates.yaml` pod kluczem kroku — `{T, N, I, B, ai_share, review, trad_pd: [O, M, P], driver}`, skale i metoda w `plan/estimation.md` — oraz wiersz w tabeli fazy w `plan/execution-plan.md`.
6. **Sprawdzenie.** `python3 tools/refresh.py` — przelicza wycenę, dashboard i artefakty oraz uruchamia `validate_plan.py`. Ma być zielone.

## Zależności kroków profilu od platformy

Krok profilu nie wystartuje, dopóki krok platformy nie zostanie scalony. Skrypt dodaje je z `writes`:

| Krok profilu pisze w | Wymaga kroku platformy | Dlaczego |
| --- | --- | --- |
| `backend/`, `db/` | S27 | SDK rozszerzeń i izolacja danych profilu (schemat `prj_<id>`, widoki `platform_api`) |
| `backend/` z operacjami z manifestu | S38 — dopisz sam w `depends_on` | potok operacji profili; skrypt nie wie, czy krok implementuje operacje, więc pyta w linii `Uwaga` |
| `frontend/` | S47 | sloty UI i trasy profili w powłoce |
| `bpmn/`, `forms/` | S17 | wtyczka bpmnlint `ph`, kontrakt `ph:outputs` |
| `profile.yaml`, `authorization.yaml` | — | sam manifest; sprawdza `validate_profiles.py` |

Typowa kolejność w profilu (jak w szablonie): manifest → BPMN i formatki → moduł i dane → operacje → widoki. Nowy krok dopisujesz za ostatnim krokiem, który pisze w tej samej części profilu.

## Zasady dobrego kroku

- Jeden krok = jeden wynik, który da się sprawdzić komendą. Rozmiar `L` rozważ do podziału.
- `writes` jak najwęższe: katalog modułu albo części profilu, nie `**`. Ścieżkę chronioną (`specs/`, `Contracts`, `docs/adr`, `config/authorization`, SDK, `profile.yaml`) wymień wprost.
- `reads` to pliki czytane w całości — łącznie poniżej 35% kontekstu modelu; duże pliki do `refs` z nazwą szukanego fragmentu.
- `dod` to wyłącznie komendy; pierwsza jest bramką zakresu. Kryteria dla ludzi — `acceptance`.
- `outcome` nazywa pliki, moduły lub dowody; `notes` — granice z sąsiednimi krokami i decyzje.
- Nazw plików, ról, kroków i komend nie wymyślasz — bierzesz je z repozytorium. Czego nie wiesz, pytasz (`open_questions`).

## Zmiana istniejących kroków

Nowy krok często wymaga dopisania go do `depends_on` kroku późniejszego (np. krok integracyjny S50 ma objąć nowy moduł) — raport pokazuje takie kroki w linii `Konflikty`. Bramkę rozszerzasz, dopisując krok do jej pola `after`. Kroku już scalonego (`plan_status.py` pokazuje go jako scalony) nie zmieniasz — dopisujesz nowy.
