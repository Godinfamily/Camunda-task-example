---
name: project-artifacts
description: Jak powstają i jak odświeżać artefakty Process Hub — pliki generowane (agenci, CODEOWNERS, wycena, dashboard, artefakty projektowe, źródła notesu) oraz dokumenty pisane wg wzorca (RFC, ADR, raport PoC, AGENTS.md modułu, przekazanie, scenariusz Gherkin). Używaj ZAWSZE, gdy tworzysz któryś z tych dokumentów albo zmieniasz plik, z którego coś jest generowane.
---
# Artefakty projektu — generowane i pisane wg wzorca

Dwie zasady: pliku generowanego nie edytujesz (zmieniasz źródło i uruchamiasz generator); dokument pisany ręcznie ma stały układ sekcji — nie dodajesz własnych i nie pomijasz wymaganych.

## Jedna komenda

```bash
python3 tools/refresh.py            # po zmianie dowolnego źródła: generuje wszystko i uruchamia wszystkie bramki
python3 tools/refresh.py --check    # tylko sprawdza (bramka CI)
```

## Pliki generowane

| Zmieniasz (źródło) | Powstaje (nie edytuj) | Generator |
| --- | --- | --- |
| `agents/registry.yaml`, `agents/prompts/*.md`, `agents/runtime-policy.yaml`, `config/models.yaml`, `profiles/*/profile.yaml` (`dev`) | `.opencode/agent/*.md`, `opencode.json`, tabela ról w `AGENTS.md` | `tools/agents/render_agents.py` |
| `config/ownership.yaml`, `profiles/*/profile.yaml` (`owner`) | `CODEOWNERS` | `tools/profiles/validate_profiles.py --write-codeowners` |
| `plan/backlog.yaml`, `plan/estimates.yaml`, `plan/estimation-params.yaml`, `plan/progress/*.effort.json` | `plan/estimation-report.md` | `tools/plan/estimate.py` |
| to samo + `plan/dashboard/register.yaml` | `plan/dashboard/data/*.json`, `plan/dashboard/data.js` | `tools/plan/export_dashboard_data.py` |
| `docs/artifacts/actors.yaml`, `assumptions.yaml`, `templates/*`, dane dashboardu, profile | `docs/artifacts/01-plan-systemu.md`, `02-aktorzy.md`, `03-zalozenia.md`, `index.html` | `tools/artifacts/render_artifacts.py` |
| dowolny plik repozytorium | `docs/handover/notes/zrodla/*.md` | `tools/handover/build_notebook_sources.py` |
| krok w `plan/backlog.yaml` | `plan/packets/<krok>.md`, `.agent-scope` | `tools/agents/prepare_step.py` |

Każdy generator ma `--check` (kod 1 = plik nieaktualny). Bez Pythona: odpowiedniki `ph` (`tools/dotnet/README.md`).

## Walidatory (nie generują, tylko sprawdzają)

| Co | Komenda |
| --- | --- |
| plany: zależności, role, `reads`, scenariusze, zakresy zapisu | `python3 tools/plan/validate_plan.py --check` |
| manifesty profili, przestrzenie nazw, R1, R9, R10 | `python3 tools/profiles/validate_profiles.py --check` |
| formatki `.form` ↔ katalog pól ↔ `ph:outputs` | `python3 tools/forms/validate_forms.py --check` |
| modele BPMN | `npx bpmnlint "bpmn/**/*.bpmn" "profiles/*/bpmn/**/*.bpmn"` |
| miejsce nowego kroku w planie | `python3 tools/plan/place_step.py <szkic.yaml> [--backlog profiles/<id>/backlog.yaml]` |
| wynik agenta (JSON) | `python3 tools/agents/validate_output.py agents/schemas/<schemat>.json <plik>` |
| zakres zmian kroku | `python3 tools/guard/enforce_write_scope.py --verify-diff main` |

## Dokumenty pisane wg wzorca

### RFC — `docs/rfc/RFC-<krok>-<temat>.md`
Wolno utworzyć w każdym kroku. Wzór: `docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md`.
```markdown
# RFC-<krok>-<temat>: <jedno zdanie, czego dotyczy>

- Zgłaszający: <agent lub zespół> · krok: <ID> · data: <RRRR-MM-DD>
- Dotyczy: <plik lub kontrakt, którego nie wolno zmienić w kroku>

## Problem
<co blokuje krok; fakt z repozytorium ze ścieżką pliku>

## Propozycja
<najmniejsza zmiana, która odblokowuje krok>

## Rozważone alternatywy
<co najmniej jedna, z powodem odrzucenia>

## Wpływ
<kroki do ponownego uruchomienia, wersja kontraktu, zgodność wsteczna>

## Decyzja
<wypełnia architekt: przyjęte | odrzucone, uzasadnienie>
```

### ADR — `docs/adr/ADR-<NNN>-<temat>.md`
Pisze tylko architekt. Nowy plik z kolejnym numerem; przyjętej decyzji się nie edytuje. Sekcje i statusy jak w istniejących plikach `docs/adr/` — przed pisaniem przeczytaj ostatni ADR i `docs/adr/README.md`, dopisz wiersz do indeksu.

### Raport PoC — `poc/<temat>/REPORT.md`
```markdown
# PoC <temat> — raport

## Wniosek
<jedno zdanie + rekomendacja statusu ADR-<NNN>>

## Co sprawdzono
| Punkt listy kontrolnej | Wynik (działa / nie działa / częściowo) | Dowód (test albo log) |

## Braki i obejścia
## Ryzyka
## Dane do kolejnych kroków
<wersje paczek, nazwy klas i uprawnień, zmierzone czasy — dokładnie, bez zaokrągleń>
```
Każda teza ma dowód. Czego nie sprawdzono — napisz „nie sprawdzono”, nie zgaduj.

### `AGENTS.md` modułu lub profilu
Najwyżej jedna strona: cel, inwarianty, granice, struktura, komendy testów. Wzór modułu: skill `ddd-module`; wzór profilu: `profiles/_template/AGENTS.md`.

### Przekazanie (ostatnia wiadomość wykonawcy)
Wyłącznie JSON, bez tekstu przed ani po, zgodny z `agents/schemas/handoff.schema.json`:
```json
{"step": "S30", "status": "done", "changed": ["src/Modules/TaskWork/Domain/WorkItem.cs"], "gates": {"build": "pass", "unit": "pass"}, "specs_covered": ["specs/tasks/claim-and-complete.feature"], "open_questions": [], "rfc": null}
```
`status`: `done` | `blocked` | `needs-rfc`. `changed`: ścieżki, które naprawdę zmieniłeś (`git status`). `gates`: tylko bramki, które uruchomiłeś, z wynikiem `pass` | `fail` | `skipped`. `rfc`: ścieżka pliku RFC albo `null`. Najwyżej 10 pytań.

### Scenariusz Gherkin — `specs/**/*.feature`, `profiles/<id>/specs/*.feature`
`# language: pl` w pierwszej linii; tag FR na każdym scenariuszu; osoby, grupy i procesy tylko ze `specs/README.md`. Skill `reqnroll-bdd`.

### Postęp
| Plik | Kto zapisuje |
| --- | --- |
| `plan/progress/<krok>.json` | orkiestrator (przekazanie wykonawcy) |
| `plan/progress/<krok>.gates.json` | `run_dod.py` |
| `plan/progress/gates.json`, pole `merged` | człowiek przez `plan_status.py` |
| `plan/progress/STATUS.md` | orkiestrator |
