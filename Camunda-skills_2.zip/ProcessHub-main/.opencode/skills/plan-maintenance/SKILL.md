---
name: plan-maintenance
description: Jak rozwijać harness Process Hub — nowa bramka planu, nowa rola agenta, nowa komenda w polityce, nowy skill, nowa komenda OpenCode (nowy krok planu — skill backlog-extension). Używaj ZAWSZE przy zmianach w agents/registry.yaml, agents/prompts, agents/runtime-policy.yaml, .opencode/skills i .opencode/command oraz przy dodawaniu bramki.
---
# Rozwój planu i harnessu

Te pliki zmienia człowiek albo architekt na jego zlecenie; `plan/backlog.yaml`, `agents/registry.yaml` i `agents/runtime-policy.yaml` są chronione lub wrażliwe — zmiana idzie przez PR z przeglądem. Po każdej zmianie: `python3 tools/refresh.py`.

## Nowy krok planu

Osobny skill: `backlog-extension` — szkic kroku, `python3 tools/plan/place_step.py <szkic.yaml> [--backlog profiles/<id>/backlog.yaml]` (zależności, bramka, miejsce w pliku, konflikty), wycena, walidacja.

## Nowa bramka

`gates: { G4: { after: [S61], approver: [tech-lead] } }` + `gate_before: G4` w krokach za bramką + wiersz w tabeli bramek `plan/execution-plan.md` + `gate_wait_days` w `plan/estimation-params.yaml`.

## Nowa rola agenta

1. `agents/prompts/<rola>.md` — układ jak w istniejących promptach: Rola · Wejście · Procedura · Zasady · Zatrzymaj się, gdy · Wynik.
2. Wpis w `agents/registry.yaml`:

```yaml
- name: <rola>
  description: <kiedy używać — jedno, dwa zdania>
  tier: T2                               # T0–T2: wariant high; T3: low
  tools: [read_file, search_text, find_files, edit_file, write_file, run_command]   # najmniej, ile trzeba
  writes: [docs/guides/**, docs/rfc/RFC-*.md]    # opcjonalnie: tylko te ścieżki; bez pola — cała platforma poza profilami
  commands: read-only                    # opcjonalnie: zestaw z run_command.sets; bez pola — zestaw domyślny
  prompt: agents/prompts/<rola>.md
  reasoning: medium
  requires: { tool_calling: true, structured_output: true, min_context_tokens: 64000, languages: [pl] }
  output_schema: agents/schemas/handoff.schema.json
  data_class: internal                   # internal | confidential | restricted
```

3. Przypadek kwalifikacyjny w `evals/agents/cases/` i wiersz w `evals/agents/README.md`.
4. Rola dla zespołów profili: dopisz ją do `dev.agents` w `profiles/<id>/profile.yaml`.
5. Mapowanie roli na rolę zespołu w `tools/plan/estimate.py` (`ROLE_OF_AGENT`), jeśli rola prowadzi kroki planu.

## Nowa komenda dla agentów

`agents/runtime-policy.yaml`: prefiks w `run_command.allow` (zestaw domyślny) albo w `run_command.sets.<zestaw>.allow`. Zakaz: wzorzec w `deny_patterns` (obowiązuje wszystkich, wygrywa z listą dozwolonych). Zmiana wymaga przeglądu bezpieczeństwa (`security_sensitive`).

## Zmiana albo nowy model LLM

`config/models.yaml` ma profil modeli na każdego kandydata (GLM 5.3 Flash, Qwen 3.8 27B, Gemma 4 31B); obowiązuje `default_profile`. Zmiana: popraw w profilu pola [DO WERYFIKACJI] wg `opencode models llm-gateway --verbose`, ustaw `default_profile`, uruchom `python3 tools/refresh.py`, przejdź kwalifikację E01–E11. Nowy model: skopiuj profil, ustaw `model`, limity i `variants` (albo usuń `variants`), zostaw `hosting: on-prem`. Rola na innym modelu: `roles: { <rola>: { profile: <profil> } }`. Procedura: `docs/agents/multi-model-guide.md`, sekcja 7; decyzja: ADR-021. Promptów, planu i polityki komend nie zmieniasz.

## Nowy skill

`.opencode/skills/<nazwa>/SKILL.md` z nagłówkiem `name` i `description` („Używaj ZAWSZE, gdy…”). Najwyżej dwie strony; przykłady z repozytorium, nie wymyślone. Dopisz skill do: tabeli w `.opencode/README.md`, sekcji „Gdzie szukać” w `AGENTS.md`, `reads` kroków, które go potrzebują.

## Nowa komenda OpenCode

`.opencode/command/<nazwa>.md`: nagłówek `description` i `agent`, treść z `$1`, `$2`, `$ARGUMENTS`. Komenda tylko wywołuje skrypty i agentów — logika zostaje w skryptach.

## Po zmianie

```bash
python3 tools/refresh.py            # generuje i sprawdza wszystko
```
Zmiana promptu, wariantu albo modelu roli = ponowna kwalifikacja roli (`evals/agents/README.md`).
