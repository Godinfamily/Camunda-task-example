# .opencode — konfiguracja OpenCode dla Process Hub

| Katalog lub plik | Co zawiera | Źródło |
| --- | --- | --- |
| `agent/` | agenci platformy i zespołów profili | generowane: `tools/agents/render_agents.py` (z `agents/registry.yaml`, `agents/prompts/`, `config/models.yaml`, `profiles/*/profile.yaml`) |
| `skills/` | technologia: `camunda-forms`, `camunda-practices`, `ddd-module`, `design-system`, `profile-extension`, `reqnroll-bdd` · rozwój platformy: `new-profile` (profil od zera: role, procesy, formatki, widoki), `project-artifacts` (pliki generowane i wzorce dokumentów), `backlog-extension` (nowy krok w planie platformy lub profilu z wyznaczeniem zależności), `plan-maintenance` (bramka, rola, komenda, skill) | ręcznie |
| `command/` | `/status`, `/krok`, `/profil`, `/bramki`, `/artefakty`, `/nowy-profil`, `/nowy-krok` | ręcznie |
| `plugin/write-scope.js`, `lib/write-scope-core.js`, `lib/write-scope.test.mjs` | strażnik zapisu przed każdym `write`, `edit`, `apply_patch`; eksport `{ id, server, setup }` zgodny z obiema ładowarkami pluginów OpenCode; test: `node .opencode/lib/write-scope.test.mjs` | ręcznie; logika w `tools/guard/enforce_write_scope.py` |
| `../opencode.json` | model, uprawnienia komend i odczytu (z `agents/runtime-policy.yaml`), dostawca bramki banku | generowane |

Skąd oszczędność tokenów: pakiety robocze z listą plików do przeczytania, bramki deterministyczne przed recenzją modelu, streszczenia logów przez `ci-triage`, skrypty zamiast modelu do czynności mechanicznych (`prepare_step.py`, `run_dod.py`, `plan_status.py`), wariant rozumowania dobrany do roli. Instrukcja startu: `docs/opencode/start.md`; opis agentów i harnessu dla ludzi: `docs/artifacts/05-agenci.md`.
