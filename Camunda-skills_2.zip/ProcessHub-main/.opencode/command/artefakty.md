---
description: Odśwież wszystko, co generowane, i uruchom bramki repozytorium (np. /artefakty albo /artefakty --check)
agent: orchestrator
---
Uruchom `python3 tools/refresh.py $ARGUMENTS` (bez Pythona: odpowiedniki `ph` z `tools/dotnet/README.md` w tej samej kolejności). Przedstaw wynik: które kroki są zielone, które czerwone i pierwszy błąd każdego czerwonego. Niczego nie poprawiaj ręcznie w plikach generowanych — wskaż plik źródłowy do zmiany (tabela w skillu `project-artifacts`).
