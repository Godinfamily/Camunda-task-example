---
description: Poprowadź założenie nowego profilu projektu (np. /nowy-profil lizing)
agent: orchestrator
---
Poprowadź założenie profilu `$1` wg skilla `new-profile` (`.opencode/skills/new-profile/SKILL.md` — przeczytaj go najpierw).

1. Sprawdź, czy `profiles/$1/profile.yaml` istnieje.
   - Nie istnieje: zbierz od człowieka dane z tabeli „Dane wejściowe” skilla (nazwa, zespół, pierwszy proces) i podaj mu do uruchomienia dokładnie dwie komendy — profilu nie zakładasz sam:
     `python3 tools/profiles/new_profile.py $1 --name "<Nazwa>" --team "<@grupa>" --process <bpmnProcessId>`
     `python3 tools/refresh.py`
     Zatrzymaj się do czasu, aż człowiek potwierdzi wykonanie.
   - Istnieje: przejdź dalej.
2. Uruchom `python3 tools/profiles/validate_profiles.py --check` i `python3 tools/plan/validate_plan.py --backlog profiles/$1/backlog.yaml`; czerwone — podaj komunikaty i zatrzymaj się.
3. Uruchom `python3 tools/agents/plan_status.py --backlog profiles/$1/backlog.yaml` i przedstaw kroki gotowe do startu. Pierwszy to manifest profilu — zaproponuj `/profil $1 <krok>`.
4. Wypisz, czego brakuje z tabeli „Dane wejściowe” (role, grupy AD, widoki, formatki) — te dane musi podać zespół profilu, zanim ruszy krok manifestu. Nie wymyślaj ich.
