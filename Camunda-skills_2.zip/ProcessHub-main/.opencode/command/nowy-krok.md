---
description: Wyznacz miejsce nowego kroku w planie platformy albo profilu (np. /nowy-krok plan/packets/drafts/raport.yaml kredyty)
agent: orchestrator
---
Wyznacz miejsce kroku ze szkicu `$1` wg skilla `backlog-extension` (`.opencode/skills/backlog-extension/SKILL.md` — przeczytaj go najpierw).

1. Jeśli podano profil (`$2`), uruchom `python3 tools/plan/place_step.py $1 --backlog profiles/$2/backlog.yaml`, w przeciwnym razie `python3 tools/plan/place_step.py $1` (bez Pythona: `ph plan place …`). Nie dodawaj `--apply`.
2. Przedstaw raport: identyfikator, zależności z powodami, bramkę, miejsce w pliku, konflikty, uwagi i błędy. Błędy i uwagi opisz jako listę poprawek do szkicu — szkicu nie poprawiaj sam poza katalogiem `plan/packets/`.
3. Podaj człowiekowi dokładną komendę do wstawienia kroku (`… --apply`) i przypomnij: dla planu platformy wycena w `plan/estimates.yaml` i wiersz w `plan/execution-plan.md`, potem `python3 tools/refresh.py`.
