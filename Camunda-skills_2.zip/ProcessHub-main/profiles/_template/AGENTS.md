# AGENTS.md — profil „__ID__”

Pracujesz dla zespołu „__NAME__”. Część specyficzną profilu realizujesz wyłącznie w `profiles/__ID__/**`. Zasady platformy z głównego `AGENTS.md` obowiązują w całości. Jak powstaje profil krok po kroku: skill `new-profile`; kod na SDK: skill `profile-extension`.

## Granice

- Zależysz tylko od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`).
- Działasz tylko na procesach z `profile.yaml` (R9); uprawnienia, operacje i typy zadań mają prefiks `__ID__.` (R10).
- Każdy dedykowany element (operacja, trasa, slot) istnieje najpierw w `profile.yaml`; identyfikator w kodzie = identyfikator w manifeście.
- Dane: schemat `prj___ID__`; dane platformy tylko przez widoki `platform_api`.
- Formatki profilu to pliki `profiles/__ID__/forms/<bpmnProcessId>/<klucz>.form` przygotowane do importu; typy pól tylko z katalogu pól.
- Zmiana kontraktu (`profile.yaml`, `authorization.yaml`) — zatwierdza też architekt platformy. Brak punktu rozszerzenia → RFC w `docs/rfc/`.

## Struktura

```
profiles/__ID__/
  profile.yaml · authorization.yaml     kontrakt z platformą
  backlog.yaml                          plan zespołu (kroki __PREFIX__-xx)
  specs/                                scenariusze profilu (# language: pl)
  bpmn/                                 modele procesów profilu (typy zadań __ID__.*)
  forms/<bpmnProcessId>/<klucz>.form    formatki do importu; start.form = formatka startowa
  backend/ · db/ · frontend/            moduł na SDK, migracje prj___ID__, biblioteka profile-__ID__-ui
```

## Komendy

```bash
python3 tools/profiles/validate_profiles.py --check
python3 tools/forms/validate_forms.py --check
npx bpmnlint "profiles/__ID__/bpmn/**/*.bpmn"
dotnet test profiles/__ID__/backend --filter "Category!=integration"
npx nx run-many -t lint test build --projects=tag:scope:profile-__ID__
python3 tools/guard/enforce_write_scope.py --verify-diff origin/main --profile __ID__
```
