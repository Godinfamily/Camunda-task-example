# ADR-021: Model agentów wymienny w ramach modeli w infrastrukturze banku

**Status:** Proponowana — uzupełnia ADR-016 w części „jedyny profil modeli”; zasada „wyłącznie model w infrastrukturze banku” pozostaje bez zmian

**Kontekst.** ADR-016 ustalił jeden profil modeli (`glm-self-hosted`, GLM 5.3 Flash). Bank nie rozstrzygnął ostatecznie, który model będzie dostępny na bramce — rozważane są GLM 5.3 Flash, Qwen 3.8 27B i Gemma 4 31B, a lista może się zmienić. Konfiguracja, prompty i dokumenty nie mogą zakładać konkretnego modelu.

**Decyzja.**
1. `config/models.yaml` zawiera po jednym profilu modeli na kandydata: `glm-self-hosted`, `qwen-self-hosted`, `gemma-self-hosted`. Obowiązuje profil z pola `default_profile`; zmiana modelu to zmiana tego pola i ponowne wygenerowanie konfiguracji (`python3 tools/refresh.py`).
2. Wszystko, co zależy od modelu, jest w profilu: nazwa wystawiona na bramce, limity kontekstu i wyjścia, warianty rozumowania i ich parametry, przypisanie poziomów T0–T3. Profil może nie mieć wariantów (model bez przełącznika rozumowania) i może kierować wybrane role na inny profil (pole `roles`, np. recenzenci na innym modelu niż wykonawcy).
3. Nic poza profilem nie zależy od modelu: prompty ról, skille, pakiety robocze, strażnik zapisu, polityka komend i bramki są wspólne. Prompty są pisane jako procedury z jawnym formatem wyniku, żeby słabszy model dawał zbliżone rezultaty.
4. Polityka danych z ADR-016 obowiązuje każdy profil: hosting wyłącznie `on-prem`; generator odrzuca profil z hostingiem zewnętrznym.
5. Model dostaje role dopiero po kwalifikacji E01–E11 na bramce banku (`evals/agents/README.md`), osobno dla każdego profilu. Rola, której model nie przechodzi, zostaje na innym profilu albo u człowieka.

**Konsekwencje.**
- Zmiana modelu nie wymaga zmian w planie, promptach ani narzędziach — tylko `default_profile`, weryfikacji pól oznaczonych [DO WERYFIKACJI] i kwalifikacji.
- Limit kontekstu wpływa na plan: `validate_plan.py` liczy budżet `reads` względem limitu obowiązującego profilu; mniejszy kontekst może wymagać przeniesienia plików do `refs` albo podziału kroków `L`.
- Model bez wariantów rozumowania nie ma eskalacji wariantu: po dwóch próbach następuje sesja od zera z diagnozą recenzenta i człowiek.
- Wycena zakłada skuteczność agentów zmierzoną w kwalifikacji; słabszy model to scenariusz „agenci słabsi” z `plan/estimation.md` (ryzyko R08).
- Profil mieszany wymaga jednoczesnego wystawienia dwóch modeli na bramce (pamięć GPU).

**Weryfikacja.** Dla każdego profilu przed użyciem: `opencode models llm-gateway --verbose` (nazwa, limity, warianty), poprawienie pól [DO WERYFIKACJI] w `config/models.yaml`, `python3 tools/refresh.py`, kwalifikacja E01–E11. Parametry Qwen 3.8 27B i Gemma 4 31B w repozytorium są wartościami wyjściowymi, niepotwierdzonymi na bramce banku.
