# Agenci w OpenCode z modelem w infrastrukturze banku — przewodnik

Rój agentów działa w OpenCode z modelem uruchomionym zawsze w infrastrukturze banku (ADR-016). Model jest wymienny (ADR-021): `config/models.yaml` ma profil dla każdego kandydata — GLM 5.3 Flash (obowiązujący), Qwen 3.8 27B, Gemma 4 31B — a obowiązuje ten z pola `default_profile`. Role są zdefiniowane raz (`agents/registry.yaml`, `agents/prompts/`) i nie zależą od modelu; generator tworzy z nich agentów OpenCode — także agentów zespołów profili projektów, którzy mogą zapisywać tylko we własnym profilu. Ten przewodnik opisuje budowę harnessu, profile modeli, zmianę modelu, politykę danych i kwalifikację (ADR-015, ADR-016, ADR-021).

## 1. Jak to jest zbudowane

```mermaid
flowchart LR
  REG[agents/registry.yaml<br/>role, poziomy, klasy danych] --> GEN[tools/agents/render_agents.py]
  PR[agents/prompts/*.md] --> GEN
  MOD[config/models.yaml<br/>profile modeli, warianty, polityka] --> GEN
  PROF[profiles/*/profile.yaml<br/>agenci zespołów profili] --> GEN
  POL[agents/runtime-policy.yaml<br/>komendy, zakazy] --> GEN
  GEN --> AG[.opencode/agent/*.md<br/>agenci platformy i profili]
  GEN --> CFG[opencode.json<br/>model, uprawnienia, dostawca]
  GEN --> AMD[AGENTS.md<br/>tabela agentów]
  AG --> OC[OpenCode]
  CFG --> OC
  SK[.opencode/skills/] --> OC
  PL[.opencode/plugin/write-scope.js] --> GUARD[tools/guard/enforce_write_scope.py]
  OC --> PL
  CI[CI: --verify-diff, --check] --> GUARD
```

| Plik | Kto edytuje | Rola |
| --- | --- | --- |
| `agents/registry.yaml`, `agents/prompts/*.md` | zespół platformy AI | definicje ról niezależne od narzędzia |
| `config/models.yaml` | zespół platformy AI + bezpieczeństwo | profile modeli na bramce banku (jeden na kandydata), profil obowiązujący, warianty rozumowania, limity, polityka danych |
| `profiles/<id>/profile.yaml` (`dev`) | zespół profilu + architekt | którzy agenci pracują dla profilu i jaka klasa danych |
| `agents/runtime-policy.yaml` | zespół platformy AI + bezpieczeństwo | dozwolone komendy i zakazy (→ `permission.bash`) |
| `.opencode/agent/*.md`, `opencode.json`, blok ról w `AGENTS.md` | nikt — generowane | konfiguracja OpenCode |
| `.opencode/skills/`, `.opencode/command/`, `.opencode/plugin/` | zespół platformy AI | skille, komendy `/status` `/krok` `/profil` `/bramki`, strażnik zapisu |

## 2. Profile modeli i warianty rozumowania

Każdy model ma w `config/models.yaml` własny **profil modeli**. Wszystko, co zależy od modelu, jest w profilu; wszystko inne (prompty, skille, pakiety, strażnik, bramki) jest wspólne.

| Profil | Model (nazwa na bramce) | Status | Warianty rozumowania | Kontekst · wyjście |
| --- | --- | --- | --- | --- |
| `glm-self-hosted` | `glm-5.3-flash` | obowiązujący (`default_profile`) | `low`, `high` — `chat_template_kwargs.enable_thinking` | 262 144 (256k) · 32 768 |
| `qwen-self-hosted` | `qwen3.8:27b` | kandydat | `low`, `high` — ten sam parametr; na Ollama inny [DO WERYFIKACJI] | 262 144 (256k) · 32 768 [DO WERYFIKACJI] |
| `gemma-self-hosted` | `gemma4:31b` | kandydat | brak — profil zakłada model bez przełącznika rozumowania [DO WERYFIKACJI] | 262 144 (256k) · 8 192 [DO WERYFIKACJI] |

Wartości oznaczone [DO WERYFIKACJI] są wyjściowe: nazwę modelu, limity i parametry wariantów potwierdza się na bramce banku (`opencode models llm-gateway --verbose`) przed pierwszym użyciem profilu. Limit kontekstu to wartość ustawiona **na serwerze** (vLLM: `max_model_len`; Ollama: `num_ctx`), nie wartość z karty modelu. Maksymalny kontekst bramki banku to **256k tokenów (262 144)** — tyle mają wszystkie profile; serwer musi być skonfigurowany na tę wartość dla każdego wystawionego modelu (dla Ollamy `num_ctx` domyślnie jest dużo niższy). Mniejszy limit na serwerze = wpisz mniejszą wartość w profilu, nigdy większą.

Pola profilu:

| Pole | Znaczenie |
| --- | --- |
| `tiers.<poziom>.model` | nazwa, pod którą bramka wystawia model; różne poziomy mogą wskazywać różne modele |
| `tiers.<poziom>.variant` | wariant rozumowania poziomu; pominięty = brak wariantu |
| `variants` | co trafia do bramki dla wariantu (treść żądania); brak pola = model bez przełącznika |
| `context_limit_tokens`, `output_limit_tokens` | limity przekazywane do OpenCode; od limitu kontekstu zależy budżet `reads` w planie |
| `roles` | wyjątki: `rola: { profile: <inny profil>, tier: <inny poziom> }` — np. recenzenci na innym modelu niż wykonawcy |
| `hosting` | zawsze `on-prem`; inna wartość zostanie odrzucona przez politykę danych |

W `opencode.json` wszystkie profile używają dostawcy `llm-gateway` z adresem i kluczem ze zmiennych `LLM_GATEWAY_URL` i `LLM_GATEWAY_KEY`.

**Poziomy.** T0–T2 (recenzja bezpieczeństwa, architektura, recenzja, implementacja) dostają najwyższy wariant profilu, T3 (triage, dokumentacja) — najniższy. Eskalacja po dwóch nieudanych próbach ma sens tylko tam, gdzie poziom wyżej ma inny wariant albo inny model. Gdy nie ma — role T0–T2 w profilach GLM i Qwen, wszystkie role w profilu Gemma — „eskalacja” to jedna sesja od zera z diagnozą recenzenta zamiast historii nieudanych prób, a potem człowiek. Pole `reasoning` w rejestrze ról jest opisowe; o wariancie decyduje poziom.

**Na co uważać przy modelach z listy.**

| Cecha | Skutek dla roju | Gdzie to widać |
| --- | --- | --- |
| mniejszy efektywny kontekst | pakiety z dużym `reads` nie mieszczą się; generator ostrzega, gdy limit jest niższy niż `min_context_tokens` roli | `render_agents.py` (ostrzeżenia), `validate_plan.py` (budżet `reads`) |
| słabsze wywoływanie narzędzi | pętle, zapis poza zakresem, przekazanie niezgodne ze schematem | kwalifikacja: `scope_violations`, `schema_valid` |
| brak trybu myślenia | słabsze role T0–T1 (recenzja, architektura) | kwalifikacja E04, E05, E11; rozważ profil mieszany |
| słabszy polski | scenariusze i dokumenty niższej jakości | kwalifikacja; w razie potrzeby `agents/prompts/<rola>.en.md` |
| mały limit wyjścia | urwane pliki przy dużych zmianach | dziel kroki `L`; podnieś `output_limit_tokens` po potwierdzeniu na serwerze |

## 3. Polityka danych

Każda klasa danych (`internal`, `confidential`, `restricted`) trafia wyłącznie do modelu w infrastrukturze banku. Klasa nadal ma znaczenie: decyduje o przeglądzie bezpieczeństwa (np. profil `aml`, recenzja bezpieczeństwa), a generator odrzuci każdy profil modeli z hostingiem zewnętrznym. Do tego: `share: disabled` w `opencode.json`, brak `webfetch` i `websearch`, zakaz odczytu `.env` i `secrets/**`.

## 4. Separacja pracy agentów

| Agent | Może zapisywać | Komendy | Nie może |
| --- | --- | --- | --- |
| agenci wykonawczy platformy (np. `module-implementer`) | platforma i `profiles/_template/**`, w kroku: tylko `writes` | zestaw domyślny (build, testy, lint, `git add`/`commit`) | `profiles/<id>/**`, ścieżki chronione bez jawnego zakresu |
| role z własną listą ścieżek (`bdd-analyst`, `docs-writer`, `ux-designer`) | tylko ścieżki z pola `writes` roli | zestaw domyślny albo brak | reszta repozytorium |
| agenci profilu (np. `kredyty-module-implementer`) | `profiles/kredyty/**` i wniosek `docs/rfc/RFC-*.md` | zestaw domyślny | platforma, inne profile, kontrakt profilu bez zatwierdzenia |
| recenzenci (`reviewer`, `ui-reviewer`, `security-reviewer`) | nic | `git diff`, `git status`, `git log` | wszystko inne (zakaz, bez pytania) |
| `ci-triage` | nic | brak | — |
| orkiestrator | `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | skrypty kroków, `opencode run --dir ../wt-*`, odczyt git | kod, `backlog.yaml`, `--force`, `--merged`, `--approve-gate` |

Domyślnie wszyscy agenci korzystają z tego samego modelu w banku (profil mieszany może skierować wybrane role na inny); różni ich zakres zapisu i zestaw komend. Egzekwują to cztery warstwy: uprawnienia `edit` i `bash` w plikach agentów OpenCode, plugin strażnika (`.agent-scope` z dyrektywą `@profile <id>`) działający w sesji uruchomionej w worktree kroku, bramka zakresu w Definition of Done (`enforce_write_scope.py --verify-diff main` — obejmuje też zmiany zrobione komendą) oraz CI z przeglądem CODEOWNERS. Wniosek RFC (`docs/rfc/RFC-*.md`) może złożyć każdy agent z prawem zapisu. Przypadek kwalifikacyjny E08 sprawdza, że agent profilu zgłasza RFC zamiast zmieniać cudzy kod. Pełny opis dla ludzi: `docs/artifacts/05-agenci.md`.

## 5. Kwalifikacja

Każda rola przechodzi przypadki z `evals/agents/` (E01–E11) na bramce banku. Ponowna kwalifikacja po zmianie wersji modelu, wariantu, serwera bramki lub promptu roli. Progi: `evals/agents/README.md`.

## 6. Dopasowanie pracy do modelu

- **Kontekst.** Limit ustala serwer bramki (`context_limit_tokens`); pakiet roboczy nadal ogranicza się do plików z pola `reads` — mniej tokenów i mniej pomyłek.
- **Rozumowanie.** Wysoki wariant tam, gdzie liczy się poprawność (architektura, recenzja, bezpieczeństwo); niski do streszczeń i dokumentacji.
- **Ustrukturyzowane wyjście.** Ostatnia wiadomość agenta to JSON ze schematu roli; `tools/agents/validate_output.py` sprawdza go przed zapisaniem postępu.
- **Język.** Zasady i scenariusze są po polsku. Jeśli kwalifikacja wykaże problemy z językiem, można dodać `agents/prompts/<rola>.en.md`.

## 7. Zmiana modelu

**Przełączenie na inny profil z listy** (np. z GLM na Qwen):

1. Zespół infrastruktury wystawia model na bramce banku. Sprawdź: `opencode models llm-gateway --verbose` — nazwa, limity, warianty, wywoływanie narzędzi.
2. W `config/models.yaml` popraw w profilu pola oznaczone [DO WERYFIKACJI] (nazwa modelu, limity, `variants`), potem ustaw `default_profile` na ten profil.
3. `python3 tools/refresh.py` — generuje agentów, `opencode.json` i tabelę w `AGENTS.md`, uruchamia wszystkie bramki. Przeczytaj ostrzeżenia generatora (kontekst mniejszy niż wymaga rola) i `validate_plan.py` (budżet `reads`).
4. Kwalifikacja E01–E11 na nowym profilu (sekcja 5). Rola, która nie przechodzi, zostaje na poprzednim profilu przez pole `roles` — albo u człowieka.
5. Pilotaż na krokach o niskiej złożoności (S10, S41, S46), potem włączenie przez PR. Bramka CI `render_agents.py --check` pilnuje, żeby wygenerowane pliki zgadzały się z `default_profile`.

Próba bez zmiany pliku (np. pliki dla runnera kwalifikacji): `PH_MODEL_PROFILE=qwen-self-hosted python3 tools/agents/render_agents.py --targets json`.

**Nowy model spoza listy.** Skopiuj istniejący profil pod nową nazwą (`<rodzina>-self-hosted`), ustaw `model` w poziomach, limity i `variants` (albo usuń `variants`, jeśli model nie ma przełącznika rozumowania), zostaw `hosting: on-prem`. Dalej jak wyżej od kroku 3. Dopisz model do tabeli w sekcji 2.

**Profil mieszany.** Wykonawcy na jednym modelu, recenzenci na innym — różne modele popełniają różne błędy, więc recenzja wyłapuje więcej. W profilu obowiązującym dodaj `roles: { reviewer: { profile: <inny profil> }, … }`; oba modele muszą być wystawione na bramce jednocześnie. Przykład jest w komentarzu na końcu `config/models.yaml`.

**Nowa wersja tego samego modelu** pod tą samą nazwą nie zmienia konfiguracji, ale wymaga ponownej kwalifikacji.

Czego zmiana modelu **nie** wymaga: zmian w `plan/backlog.yaml`, promptach ról, skillach, strażniku zapisu ani polityce komend.

## 8. Komendy

```bash
python3 tools/agents/render_agents.py                    # agenci OpenCode, opencode.json, tabela w AGENTS.md
python3 tools/agents/render_agents.py --check             # bramka CI
python3 tools/agents/render_agents.py --targets json      # pliki dla runnera kwalifikacji (agents/dist/)
opencode models llm-gateway --verbose                      # modele na bramce: nazwy, warianty i limity
PH_MODEL_PROFILE=<profil> python3 tools/agents/render_agents.py --targets json   # próba innego profilu modeli bez zmiany default_profile
python3 tools/guard/enforce_write_scope.py --self-test    # strażnik zapisu
python3 tools/profiles/validate_profiles.py --check       # manifesty profili i CODEOWNERS
python3 tools/plan/validate_plan.py --check               # plany ↔ role, zakresy zapisu, reads, scenariusze
opencode agent list                                       # agenci widoczni dla OpenCode
opencode debug agent kredyty-module-implementer           # model, wariant i uprawnienia agenta
```

Bez Pythona te same polecenia wykonuje narzędzie .NET: `ph agents render [--check]`, `ph guard --self-test`, `ph profiles validate --check` (`tools/dotnet/README.md`).
