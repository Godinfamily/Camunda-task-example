# Agenci AI w Process Hub — konfiguracja, zależności i harness

Dokument dla ludzi: tech leada, architekta, zespołów profili i bezpieczeństwa. Wyjaśnia, kim są agenci, co każdy z nich może, jak przebiega krok planu i co pilnuje, żeby agent nie wyszedł poza swoje zadanie. Źródłem prawdy pozostają pliki konfiguracji — każda sekcja wskazuje, gdzie je znaleźć.

## 1. W skrócie

- Pracę wykonuje **27 agentów** w OpenCode: 15 ról platformy i 12 agentów zespołów profili (`kredyty-…`, `flota-…`, `aml-…`). Wszyscy używają modelu uruchomionego w infrastrukturze banku (ADR-016). Model jest wymienny (ADR-021): dziś `glm-5.3-flash`, przygotowane są profile Qwen 3.8 27B i Gemma 4 31B.
- Agent dostaje **jeden krok planu** w postaci pakietu roboczego: cel, oczekiwany wynik, pliki do przeczytania, zakres zapisu, bramki. Pracuje w osobnym katalogu (`git worktree`) na własnej gałęzi.
- **Harness** — czyli wszystko dookoła modelu — decyduje, co agentowi wolno: które pliki zmieni, jakie komendy uruchomi, czego nie przeczyta. Te ograniczenia egzekwuje kod, nie polecenie w prompcie.
- O jakości decydują **bramki deterministyczne** (build, testy, zakres zapisu), potem **recenzja** innego agenta, na końcu **człowiek**: tylko człowiek scala, wypycha, zatwierdza bramki G0–G3 i zmienia plan.

## 2. Z czego składa się konfiguracja

```mermaid
flowchart LR
  subgraph Źródła["Źródła — edytuje człowiek"]
    REG["agents/registry.yaml<br/>role, narzędzia, zapis, zestaw komend"]
    PR["agents/prompts/*.md<br/>instrukcje ról"]
    POL["agents/runtime-policy.yaml<br/>komendy, zakazy, odczyt"]
    MOD["config/models.yaml<br/>model, warianty, klasy danych"]
    PROF["profiles/*/profile.yaml<br/>agenci zespołu profilu"]
    SCH["agents/schemas/*.json<br/>format wyniku roli"]
  end
  GEN["tools/agents/render_agents.py<br/>(albo: ph agents render)"]
  subgraph Wynik["Wynik — generowany, nie edytuj"]
    AG[".opencode/agent/*.md"]
    CFG["opencode.json"]
    AMD["tabela ról w AGENTS.md"]
  end
  subgraph Ręczne["Pisane ręcznie"]
    PLG[".opencode/plugin/write-scope.js<br/>strażnik zapisu"]
    CMD[".opencode/command/<br/>/status /krok /profil /bramki<br/>/artefakty /nowy-profil /nowy-krok"]
    SK[".opencode/skills/<br/>10 skilli"]
  end
  REG --> GEN
  PR --> GEN
  POL --> GEN
  MOD --> GEN
  PROF --> GEN
  GEN --> AG
  GEN --> CFG
  GEN --> AMD
  AG --> OC["OpenCode"]
  CFG --> OC
  PLG --> OC
  CMD --> OC
  SK --> OC
  PLG --> GUARD["tools/guard/enforce_write_scope.py"]
```

| Chcę zmienić… | Edytuję | Potem |
| --- | --- | --- |
| co rola robi i jak pracuje | `agents/prompts/<rola>.md` | `render_agents.py`, ponowna kwalifikacja roli (`evals/agents/`) |
| narzędzia, ścieżki zapisu albo zestaw komend roli | `agents/registry.yaml` (`tools`, `writes`, `commands`) | `render_agents.py` |
| dozwolone i zakazane komendy, zakazy odczytu | `agents/runtime-policy.yaml` | `render_agents.py`; przegląd bezpieczeństwa |
| model (profil modeli), wariant rozumowania, limity kontekstu | `config/models.yaml` (`default_profile` albo pola profilu) | `tools/refresh.py`, kwalifikacja E01–E11 |
| agentów zespołu profilu | `profiles/<id>/profile.yaml` (`dev.agents`, `dev.dataClass`) | `render_agents.py`; przegląd architekta |
| co krok ma zrobić i gdzie może pisać | `plan/backlog.yaml` | `validate_plan.py --check` |

Bramka CI `render_agents.py --check` nie przepuści zmiany, po której pliki wygenerowane różnią się od źródeł.

## 3. Role

„Zapis” to granica roli; w konkretnym kroku agent dostaje jeszcze węższy zakres z pola `writes` kroku. „Wariant” to tryb rozumowania modelu: `high` — z trybem myślenia, `low` — bez.

| Rola | Do czego służy | Poziom · wariant | Zapis | Komendy | Wynik |
| --- | --- | --- | --- | --- | --- |
| `orchestrator` | prowadzi plan: wybiera kroki, przygotowuje pakiety, uruchamia wykonawców, bramki i recenzje | T1 · high | tylko `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | skrypty kroków, `opencode run --dir ../wt-*`, odczyt git | przekazanie |
| `architect` | kontrakty modułów, OpenAPI, ADR, rozstrzyganie RFC | T1 · high | platforma | domyślne | przekazanie |
| `module-implementer` | moduł backendu .NET (DDD, heksagonalnie) | T2 · high | platforma | domyślne | przekazanie |
| `camunda-integrator` | PoC, moduł `CamundaIntegration`, bpmnlint, modele BPMN | T2 · high | platforma | domyślne | przekazanie |
| `data-engineer` | schematy MSSQL, RLS, Ledger, wydajność | T2 · high | platforma | domyślne | przekazanie |
| `frontend-developer` | biblioteki Angular, renderer i projektant formatek | T2 · high | platforma | domyślne | przekazanie |
| `design-system-engineer` | `core/theming`, `core/ui-kit`, komponenty pól | T2 · high | platforma | domyślne | przekazanie |
| `bdd-tester` | kroki Reqnroll, drivery, testy integracyjne i E2E | T2 · high | platforma | domyślne | przekazanie |
| `bdd-analyst` | scenariusze Gherkin i pytania do biznesu | T2 · high | tylko `specs/**` i wnioski RFC | brak | przekazanie |
| `ux-designer` | przenosi eksporty z Figma do `design/**` | T1 · high | tylko `design/**`, `poc/forms-ui/**` i wnioski RFC | domyślne | przekazanie |
| `docs-writer` | przewodniki i changelog po scaleniu kroków | T3 · low | tylko `docs/guides/**`, `CHANGELOG.md` i wnioski RFC | brak | przekazanie |
| `reviewer` | recenzja diffu kroku | T1 · high | brak | tylko `git diff`, `git status`, `git log` | werdykt + ustalenia |
| `ui-reviewer` | recenzja warstwy wizualnej i dostępności | T1 · high | brak | tylko odczyt git | werdykt + ustalenia |
| `security-reviewer` | szuka obejść autoryzacji, izolacji i audytu | T0 · high | brak | tylko odczyt git | `approve` / `block` |
| `ci-triage` | streszcza czerwoną bramkę dla wykonawcy | T3 · low | brak | brak | raport triage |

**Agenci profili** (`<profil>-<rola>`, np. `kredyty-module-implementer`) to te same role z dopisanym kontekstem profilu i zapisem ograniczonym do `profiles/<id>/**` oraz wniosków `docs/rfc/RFC-*.md`. Klasa danych agenta profilu to wyższa z klas roli i profilu — profil `aml` ma `restricted`, więc jego kroki zawsze przechodzą recenzję bezpieczeństwa.

Formaty wyników (`agents/schemas/`): przekazanie kroku (`handoff`), recenzja (`review`), recenzja bezpieczeństwa (`security-review`), triage. Ostatnia wiadomość agenta to wyłącznie JSON w formacie swojej roli; sprawdza go `tools/agents/validate_output.py`.

## 4. Przebieg kroku

```mermaid
sequenceDiagram
  autonumber
  participant H as Człowiek
  participant O as Orkiestrator
  participant S as Skrypty (bez modelu)
  participant W as Wykonawca (sesja w worktree)
  participant R as Recenzenci
  H->>O: /krok S30
  O->>S: prepare_step.py S30
  S-->>O: worktree ../wt-S30, .agent-scope, pakiet
  O->>W: opencode run --dir ../wt-S30 --agent module-implementer
  W-->>O: commit na gałęzi step/S30 + przekazanie JSON
  O->>S: validate_output.py, run_dod.py S30
  alt bramka czerwona
    S-->>O: S30.gates.json
    O->>W: skrót od ci-triage, kolejna próba (maks. 2)
  else bramki zielone
    O->>R: reviewer (+ security-reviewer, ui-reviewer)
    R-->>O: werdykt
  end
  O-->>H: podsumowanie, plan/progress/S30.json
  H->>H: PR, CI, scalenie, plan_status.py --merged S30
```

1. **Gotowość.** Krok może ruszyć, gdy wszystkie kroki z `depends_on` są scalone, a bramka `gate_before` zatwierdzona. Sprawdza to `plan_status.py` i ponownie `prepare_step.py`.
2. **Przygotowanie** (`prepare_step.py`, bez modelu): osobny worktree `../wt-<krok>` na gałęzi `step/<krok>`, plik `.agent-scope` z zakresem zapisu, pakiet roboczy `plan/packets/<krok>.md`.
3. **Wykonanie.** Wykonawca działa jako osobna sesja OpenCode uruchomiona **w worktree kroku**. To ważne: strażnik zapisu czyta `.agent-scope` z katalogu sesji. Krok z parą `bdd-tester` zaczyna Tester (testy mają być czerwone), potem implementer.
4. **Bramki** (`run_dod.py`, bez modelu): komendy z pola `dod` po kolei; pierwsza zawsze sprawdza zakres zapisu. Wynik w `plan/progress/<krok>.gates.json`.
5. **Naprawa.** Czerwona bramka → `ci-triage` streszcza log → wykonawca poprawia. Dwie próby; potem jedna sesja od zera z diagnozą recenzenta; potem człowiek.
6. **Recenzja.** `reviewer` zawsze; `security-reviewer`, gdy diff dotyka ścieżek `security_sensitive`, krok ma taką parę albo profil ma dane `restricted`; `ui-reviewer` dla `frontend/**` i `design/**`.
7. **Człowiek.** PR, CI, przegląd właścicieli kodu (CODEOWNERS), scalenie, oznaczenie `--merged`, kryteria z pola `acceptance`.

Krok zespołu profilu przebiega tak samo (`/profil kredyty KRE-02`), na planie `profiles/<id>/backlog.yaml`, gałęzi `profile/<id>/<krok>` i z postępem w `profiles/<id>/progress/`.

## 5. Skąd agent wie, co robić — pakiet roboczy

Pakiet powstaje z jednego wpisu w `plan/backlog.yaml`. Agent czyta tylko pakiet i pliki w nim wskazane — mniej tokenów, mniej pomyłek.

| Sekcja pakietu | Pole w backlogu | Po co |
| --- | --- | --- |
| Cel | `title` | jedno zdanie, co robimy |
| Wynik | `outcome` | pliki, moduły i dowody, po których poznać, że krok jest zrobiony |
| Wskazówki startowe | `notes` | granice z sąsiednimi krokami, decyzje biznesowe, pułapki |
| Czytaj | `reads` | pliki do przeczytania w całości — pilnowany budżet kontekstu |
| Sięgaj punktowo | `refs` | duże pliki (np. makieta, 145 kB), w których szuka się fragmentu |
| Wejście od poprzedników | `depends_on` | przekazania kroków, od których zależymy (pytania otwarte, zmienione pliki) |
| Wolno zapisywać | `writes` | zakres zapisu → `.agent-scope`; wniosek RFC wolno złożyć zawsze |
| Para | `pair`, `pair_task` | kto współpracuje i co robi |
| Scenariusze | `specs` | pliki `.feature` i tagi do zaliczenia |
| Definition of Done | `dod` | komendy bramek |
| Kryteria akceptacji człowieka | `acceptance` | to, czego komenda nie sprawdzi (zatwierdzenie PO, projektanta UX, bezpieczeństwa) |

Spójność planu z repozytorium sprawdza `python3 tools/plan/validate_plan.py`: nieznane zależności i cykle, role bez prawa zapisu, pliki z `reads`, które nie istnieją i których nie tworzy żaden poprzednik, scenariusze i tagi, bramkę zakresu w `dod`, budżet kontekstu oraz kroki, które mogą być gotowe jednocześnie, a piszą w tym samym miejscu.

### Prompty, skille i automatyzacja

Modele tej klasy (GLM 5.3 Flash, Qwen 3.8 27B, Gemma 4 31B) dają powtarzalne wyniki, gdy dostają procedurę, a nie opis — a prompty mają działać tak samo po zmianie modelu. Dlatego:

- **Każdy prompt roli ma ten sam układ:** Rola · Wejście · Procedura (numerowana) · Zasady · Zatrzymaj się, gdy · Wynik (dokładny JSON). Źródło: `agents/prompts/`.
- **`AGENTS.md` zawiera sekcję „Fakty, nie domysły”:** nazwy używane tylko, jeśli agent widział je w repozytorium; brak informacji = pytanie i status `blocked`; wynik komendy tylko po jej uruchomieniu.
- **Skille** niosą wiedzę i wzorce do kopiowania, zamiast zostawiać je wyobraźni modelu:

| Skill | Do czego |
| --- | --- |
| `ddd-module`, `camunda-practices`, `camunda-forms`, `design-system`, `reqnroll-bdd`, `profile-extension` | konwencje technologii i wzorce kodu |
| `new-profile` | nowy profil od zera: manifest, role, grupy AD, procesy BPMN, formatki do importu, dedykowane widoki, plan zespołu |
| `project-artifacts` | co jest generowane z czego i jaką komendą; wzorce RFC, raportu PoC, przekazania |
| `backlog-extension` | nowy krok w planie platformy albo profilu: szkic, zależności, bramka, miejsce w pliku, konflikty — z `place_step.py` |
| `plan-maintenance` | nowa bramka, rola agenta, komenda, skill |

- **Skrypty sprawdzają to, co agent mógłby zmyślić:**

| Skrypt | Pilnuje |
| --- | --- |
| `tools/plan/validate_plan.py` | plan ↔ repozytorium ↔ role |
| `tools/profiles/validate_profiles.py` | manifest profilu, przestrzenie nazw, R1, R9, R10 |
| `tools/forms/validate_forms.py` | formatki `.form` ↔ katalog pól ↔ kontrakt `ph:outputs` z BPMN |
| `tools/plan/place_step.py` | miejsce nowego kroku: zależności, bramka, pozycja w pliku, konflikty (`/nowy-krok`) |
| `tools/refresh.py` | wszystkie generatory i bramki jedną komendą (`/artefakty`) |

Nowy profil: `/nowy-profil <id>`. Człowiek uruchamia dwie komendy (szkielet i odświeżenie), a dalej agenci profilu wykonują pięć kroków z szablonu planu — manifest, BPMN i formatki, moduł i dane, operacje, widoki — każdy z własną bramką.

## 6. Zabezpieczenia — warstwy i ich granice

Żadna warstwa nie jest szczelna sama. Razem działają tak, że błąd agenta kończy się najwyżej odrzuconą gałęzią.

| # | Warstwa | Co zatrzymuje | Gdzie skonfigurowana | Czego nie zatrzymuje |
| --- | --- | --- | --- | --- |
| 1 | Uprawnienia `edit` agenta | zapis poza granicą roli (profil, recenzent, orkiestrator) | `.opencode/agent/*.md` z `agents/registry.yaml` | zapisu wykonanego komendą powłoki |
| 2 | Strażnik zapisu (plugin) | każdy `write`/`edit`/`patch` poza `.agent-scope`; ścieżki chronione (specyfikacje, kontrakty, ADR, uprawnienia, SDK, manifesty profili, `backlog.yaml`, `AGENTS.md`); cudzy profil | `.opencode/plugin/write-scope.js` → `tools/guard/enforce_write_scope.py` | sesji bez `.agent-scope` (traktowana jak sesja człowieka); zapisu komendą |
| 3 | Uprawnienia komend | sieć (`curl`, `wget`, `ssh`), `git push`, `git merge`, `--force`, `--merged`, `--approve-gate`, `--amend`, przekierowanie poza worktree, odczyt zmiennych środowiska | `agents/runtime-policy.yaml` → `opencode.json` i pliki agentów | wszystkiego — to dopasowanie wzorców tekstu, a `dotnet test` z natury uruchamia kod napisany przez agenta |
| 4 | Zakazy odczytu | `.env`, `secrets/**`, klucze i certyfikaty | `agents/runtime-policy.yaml` (`read_guard`) | odczytu przez dozwoloną komendę |
| 5 | Bramka zakresu w DoD | wszystko, co zmieniło się w worktree poza `writes` — także zmiany niezatwierdzone i powstałe z komendy | pole `dod` kroku: `enforce_write_scope.py --verify-diff main` | zmian poza repozytorium |
| 6 | Recenzja agentów | błędy logiki, naruszenia zasad, obejścia bezpieczeństwa | prompty recenzentów, `security_sensitive` w backlogu | tego, czego recenzent nie zauważy |
| 7 | Człowiek i CI | scalenie bez przeglądu; zmiana chronionych ścieżek bez właściciela | ochrona `main`, `CODEOWNERS`, potok CI | — |

Stałe ustawienia: brak dostępu do internetu (`webfetch`, `websearch` wyłączone), `share: disabled` (rozmowy nie trafiają do publicznych linków), model wyłącznie w banku.

Gdy strażnik nie może się uruchomić (brak Pythona i narzędzia `ph`), zapis jest blokowany — zachowanie celowe.

Plugin eksportuje jeden obiekt `{ id, server, setup }`: `server` rejestruje hak `tool.execute.before` (starsza ładowarka OpenCode), `setup` spełnia wymóg nowszej ładowarki, która dla plików z `.opencode/plugin/` żąda definicji z `id` i `setup` — bez niego OpenCode zgłasza „plugin must export a default definition with an id and an effect or setup function”. Nowsza ładowarka nie ma haka na wywołania narzędzi, więc gdyby OpenCode przestał ładować `server`, warstwę 2 zastępują warstwy 5–7 (bramka zakresu w DoD, recenzja, CI). Test: `node .opencode/lib/write-scope.test.mjs`.

### Zestawy komend

| Zestaw | Kto | Dozwolone bez pytania | Reszta |
| --- | --- | --- | --- |
| domyślny | role wykonawcze | `dotnet build/test/format/new/sln`, `npx nx`, `npx bpmnlint`, `npx gherkin-lint`, `npx @redocly/cli lint`, `npm test`, `git diff/status/log/add/commit`, `python3 tools/…`, `ph …` | pytanie do człowieka |
| `read-only` | recenzenci | `git diff`, `git status`, `git log` | zakaz |
| `orchestrator` | orkiestrator | skrypty `tools/agents/`, `validate_plan.py`, `validate_profiles.py --check`, `validate_forms.py`, `refresh.py`, `ph step …`, odczyt git, `opencode run --dir ../wt-*` | pytanie do człowieka |
| brak | `ci-triage`, `bdd-analyst`, `docs-writer` | — | zakaz |

Zakazy wspólne obowiązują w każdym zestawie i wygrywają z listą dozwolonych.

## 7. Model, poziomy i eskalacja

Model nie jest wpisany w role ani w prompty. `config/models.yaml` ma **profil modeli** dla każdego kandydata, a obowiązuje ten z pola `default_profile`:

| Profil | Model | Status | Warianty rozumowania |
| --- | --- | --- | --- |
| `glm-self-hosted` | GLM 5.3 Flash (`glm-5.3-flash`) | obowiązujący | `low` (bez trybu myślenia), `high` (z trybem myślenia) |
| `qwen-self-hosted` | Qwen 3.8 27B (`qwen3.8:27b`) | kandydat — parametry do potwierdzenia na bramce | `low`, `high` |
| `gemma-self-hosted` | Gemma 4 31B (`gemma4:31b`) | kandydat — parametry do potwierdzenia na bramce | brak (profil zakłada model bez przełącznika) |

Zmiana modelu to trzy czynności: ustawić `default_profile`, uruchomić `python3 tools/refresh.py`, przejść kwalifikację ról (E01–E11). Plan, prompty, skille i zabezpieczenia zostają bez zmian. Procedura i profil mieszany (np. recenzenci na innym modelu): `docs/agents/multi-model-guide.md`, sekcje 2 i 7.

Poziom roli wybiera model i wariant z profilu:

| Poziom | Role | Wariant (profile GLM i Qwen) | Znaczenie |
| --- | --- | --- | --- |
| T0 | `security-reviewer` | high | recenzja bezpieczeństwa, dane `restricted` |
| T1 | orkiestrator, architekt, recenzenci, `ux-designer` | high | planowanie, decyzje, recenzja |
| T2 | role wykonawcze | high | implementacja |
| T3 | `ci-triage`, `docs-writer` | low | streszczenia, dokumentacja |

Ważna konsekwencja: **gdy wyższy poziom nie ma innego wariantu ani innego modelu, nie ma na co eskalować**. Dotyczy to ról T0–T2 w profilach GLM i Qwen oraz wszystkich ról w profilu Gemma. Po dwóch nieudanych próbach orkiestrator uruchamia jedną sesję od zera — z diagnozą recenzenta zamiast historii prób — a potem oddaje krok człowiekowi.

Limit kontekstu pochodzi z profilu: maksimum bramki banku to 256k tokenów (262 144), ustawione we wszystkich profilach. `validate_plan.py` ostrzega, gdy same pliki z `reads` zajęłyby ponad 35% (ok. 92 tys. tokenów) — reszta zostaje na rozmowę, wyniki narzędzi i odpowiedź. Makieta (ok. 45 tys. tokenów) jest w `refs`, nie w `reads`, bo czytanie jej w całości przy każdym kroku UI marnuje kontekst i czas; model z mniejszym limitem na serwerze może wymagać przeniesienia kolejnych plików do `refs`.

## 8. Zależności między agentami i ludźmi

```mermaid
flowchart TD
  PO["Product Owner"] -->|zatwierdza specs| BA["bdd-analyst"]
  BA -->|scenariusze .feature| BT["bdd-tester"]
  AR["architect"] -->|kontrakty, OpenAPI, decyzje RFC| IMPL["role wykonawcze"]
  BT -->|czerwone testy| IMPL
  UX["projektant UX (człowiek)"] -->|eksport z Figma| UXD["ux-designer"]
  UXD -->|tokeny, katalog pól| DSE["design-system-engineer"]
  DSE -->|ui-kit| FE["frontend-developer"]
  IMPL -->|commit + przekazanie| GATES["bramki DoD (skrypt)"]
  FE --> GATES
  GATES -->|czerwone| TRI["ci-triage"]
  TRI --> IMPL
  GATES -->|zielone| REV["reviewer / security-reviewer / ui-reviewer"]
  REV -->|approve| HUM["Człowiek: PR, scalenie, bramki G0–G3"]
  REV -->|changes| IMPL
  ORC["orchestrator"] -.prowadzi.-> IMPL
  ORC -.prowadzi.-> GATES
  ORC -.prowadzi.-> REV
```

- **Kontrakty przed implementacją.** Implementer nie zmienia `*/Contracts/**` ani `specs/**`; brak w kontrakcie zgłasza plikiem `docs/rfc/RFC-<krok>-<temat>.md` i statusem `needs-rfc`. RFC rozstrzyga architekt z człowiekiem.
- **Platforma i profile.** Agenci platformy nie piszą w `profiles/<id>/**`; agenci profilu — nigdzie poza swoim profilem. Kroki profili czekają na kroki platformy S27, S38 i S47.
- **Kolejność w czasie** wynika z `depends_on` i bramek w `plan/backlog.yaml`, nie z ról. Aktualny stan: `/status`.

## 9. Co robi wyłącznie człowiek

| Czynność | Jak | Dlaczego nie agent |
| --- | --- | --- |
| scalenie i wypchnięcie | PR w systemie kontroli wersji | `git push` i `git merge` są zakazane dla agentów |
| oznaczenie scalenia | `plan_status.py --merged <krok>` | odblokowuje kolejne kroki |
| zatwierdzenie bramki G0–G3 | `plan_status.py --approve-gate G1 --by "…" --evidence "…"` | decyzja biznesowa lub architektoniczna; narzędzie wymaga scalenia kroków z pola `after` |
| pominięcie kontroli | `--force` | świadome odstępstwo |
| zmiana planu, ról, polityki komend | edycja źródeł + PR | ścieżki chronione i `security_sensitive` |
| nowy profil projektu | `new_profile.py` | zmienia własność kodu (CODEOWNERS) |
| kryteria `acceptance` | podpis, przegląd, test z czytnikiem ekranu | nie da się ich sprawdzić komendą |

## 10. Co zmienił przegląd konfiguracji (listopad 2026)

| Obszar | Było | Jest |
| --- | --- | --- |
| Orkiestrator | mógł edytować całą platformę (zakaz tylko w prompcie); miał wszystkie komendy, w tym `--merged` i `--approve-gate` | zapis tylko w postępie i pakietach; własny zestaw komend; zakazy egzekwuje harness |
| Recenzenci i triage | pełny zestaw komend (w tym `dotnet format`, generatory) | recenzenci: tylko odczyt git; `ci-triage`: bez komend |
| Role wąskie | `bdd-analyst`, `docs-writer`, `ux-designer` mogli pisać w całej platformie | zapis tylko we własnych katalogach |
| Zapis komendą | `git diff --output`, przekierowania i `dotnet format` omijały strażnika bez śladu | zakazy wzorców + bramka zakresu w każdym DoD (obejmuje pliki niezatwierdzone i nieśledzone) |
| Wniosek RFC | zasada kazała złożyć RFC, a strażnik blokował zapis w `docs/rfc/` (dla agentów profili zawsze) | `docs/rfc/RFC-*.md` dozwolony w każdym kroku |
| Uruchamianie wykonawcy | `/krok` zlecał pracę podagentowi w głównym katalogu — bez `.agent-scope`, więc bez strażnika | wykonawca jako sesja w worktree (`opencode run --dir`) |
| Przekazanie do recenzji | recenzja `git diff main...HEAD`, ale nikt nie zatwierdzał zmian | agent zatwierdza na gałęzi kroku (`git add`, `git commit`) |
| Bramki G0–G3 | zatwierdzenie bez sprawdzenia kroków | wymaga scalenia kroków z pola `after` |
| Zakazy odczytu | `*.pfx` i `*.key` były w polityce, ale nie w `opencode.json` | generowane z polityki |
| Eskalacja | „wyższy poziom” przy tym samym wariancie nic nie zmieniał | jawna reguła: sesja od zera z diagnozą, potem człowiek |
| Schematy | identyfikator kroku profilu (`KRE-02`) nie przechodził walidacji przekazania; triage nie miał kategorii `scope`, `integration`, `e2e` | poprawione |
| Backlog | krok S51 prowadzony przez rolę bez prawa zapisu; opisowe „komendy” w DoD kroków S06, S09, S54, S60; S13 bez dostępu do testowanego projektu; makieta 145 kB w `reads` siedmiu kroków | poprawione; każdy krok ma `outcome` i `notes`, kryteria dla ludzi w `acceptance` |

## 11. Znane ograniczenia i rzeczy do sprawdzenia

- **Narzędzia .NET (`ph`).** Zmiany w `render_agents.py`, `prepare_step.py`, `plan_status.py` i strażniku oraz nowe polecenia `ph plan validate`, `ph plan place`, `ph forms validate` i `ph refresh` są w plikach C# (`tools/dotnet`), ale nie były kompilowane w środowisku, w którym powstały. Przed użyciem uruchom `dotnet build tools/dotnet/ProcessHub.Tools.sln -c Release` i `tools/dotnet/parity.sh`.
- **Formatki profilu w repozytorium** (`profiles/<id>/forms/<bpmnProcessId>/<klucz>.form`) to nowa konwencja plików do importu; istniejące profile jeszcze ich nie mają — walidator zgłasza to jako ostrzeżenie.
- **OpenCode.** Reguły `bash` w plikach agentów, uruchamianie `opencode run --dir` przez orkiestratora i zachowanie komend wymagających zgody w sesji bez interfejsu sprawdź na przypiętej wersji (instrukcja: `docs/opencode/start.md`, krok 4): `opencode debug agent orchestrator`, `opencode debug agent reviewer`.
- **Parametry modeli.** Pola oznaczone [DO WERYFIKACJI] w `config/models.yaml` — parametr wariantów GLM oraz nazwy, limity i warianty profili Qwen 3.8 27B i Gemma 4 31B — są wartościami wyjściowymi, niepotwierdzonymi na bramce banku (krok S06). Żaden z profili kandydatów nie przeszedł kwalifikacji.
- **Komendy to najsłabsza warstwa.** Wzorce tekstu da się obejść; realną ochroną są worktree, brak sieci, brak `push`, bramka zakresu i przegląd człowieka. Agent uruchamiający testy uruchamia kod, który sam napisał — środowisko agentów nie powinno mieć dostępu do sekretów ani systemów produkcyjnych.
- **Podział pracy w parze** (kto pisze testy, kto kod) wynika z promptów, nie z uprawnień: obie role dostają ten sam `.agent-scope`.
- **Sesja człowieka.** Bez `.agent-scope` strażnik niczego nie blokuje (z `PH_STRICT=1` — chroni ścieżki chronione). Wbudowany agent `build` w głównym katalogu ma więc pełny zapis; używaj go świadomie.
- **Kwalifikacja.** Prompty wszystkich 15 ról zostały napisane od nowa — zgodnie z `evals/agents/README.md` każda rola wymaga ponownej kwalifikacji (E01–E11) na bramce banku, zanim zacznie kroki planu.

## 12. Słowniczek

| Pojęcie | Znaczenie |
| --- | --- |
| harness | kod i konfiguracja wokół modelu: narzędzia, uprawnienia, strażnik, skrypty kroków |
| krok | jednostka planu (`S30`, `KRE-02`) z zależnościami, zakresem zapisu i bramkami |
| pakiet roboczy | instrukcja kroku dla agenta, generowana z backlogu |
| worktree | osobny katalog roboczy tej samej historii git, jeden na krok |
| `.agent-scope` | plik z zakresem zapisu kroku, czytany przez strażnika |
| bramka deterministyczna (DoD) | komenda, która musi zakończyć się kodem 0 |
| bramka G0–G3 | decyzja człowieka rozdzielająca fazy planu |
| przekazanie | końcowy JSON agenta: status, zmienione pliki, bramki, pytania |
| RFC | wniosek o zmianę poza zakresem kroku (`docs/rfc/`) |
| para | druga rola w kroku: tester, współwykonawca albo recenzent |
