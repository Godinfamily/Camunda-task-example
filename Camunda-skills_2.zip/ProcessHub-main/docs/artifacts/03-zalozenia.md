<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Założenia Process Hub

Rejestr 38 założeń: 19 przyjętych, 10 do weryfikacji w PoC lub w trakcie prac, 9 czekających na decyzję. Każde ma źródło, punkt sprawdzenia i skutek, jeśli okaże się nieprawdą. Źródło: `assumptions.yaml`.

## Biznes

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-01 | Process Hub zastępuje natywny Tasklist; użytkownicy końcowi nie mają dostępu do webapp Tasklist ani Operate. | W-01, C16 | przyjęte | S60 | Użytkownicy mogliby obejść reguły widoczności i audyt (R10 w rejestrze ryzyk). |
| Z-02 | „Ta sama grupa uprawnień” to grupy kandydujące zadania i grupy inicjatora sprawy. | W-03, D-01 | decyzja otwarta | S05 / G0 | Zmiana reguły widoczności R3 i scenariuszy access/visibility. |
| Z-03 | Edytuje i kończy zadanie tylko osoba, która je przejęła; menadżer przekazuje zadania, ale ich nie edytuje. | W-04, R1 | przyjęte | S30 | — |
| Z-04 | Jedna osoba może mieć wiele ról naraz; uprawnienia sumują się w zakresach, a audyt zapisuje rolę uzasadniającą. | W-19 | przyjęte | S24 | — |
| Z-05 | Menadżer widzi etapy biznesowe zamiast BPMN; elementy na etapy mapuje administrator procesu. | W-26, D-03, ADR-006 | decyzja otwarta | warsztat przed S34 | Zmiana uprawnień StageMap.* i ekranu edytora mapy etapów. |
| Z-06 | Wynik biznesowy (sukces, odmowa, błąd) jest oznaczany na zdarzeniach końcowych BPMN. | W-25, ADR-011 | przyjęte | S17, S36 | Dashboard nie odróżni odmowy od błędu. |
| Z-31 | Biznes decyduje o polach formatki i ich układzie; wygląd jest wspólny dla całego systemu i nie da się go zmienić w pojedynczej formatce. | W-45, ADR-019 | przyjęte | S45, testy z użytkownikami | Prośby o stylowanie formatek oznaczają rozszerzenie design systemu, nie schematu (ryzyko R19). |
| Z-32 | Każdy proces ma formatki wyłącznie dla siebie; treść przenosi się między procesami tylko przez jawny eksport i import pliku. | W-46, R11, ADR-018 | przyjęte | S26, specs/forms/form-isolation.feature | — |
| Z-33 | Wycofanie wersji formatki wykonuje jedna uprawniona osoba z powodem; zadania w toku domyślnie zostają na wycofanej wersji. | W-44, D-13, D-14 | decyzja otwarta | S05 / przed S26 | Dodatkowa akceptacja wycofania albo inny domyślny tryb przepięcia zadań. |

## Architektura

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-07 | Modularny monolit .NET 10 w czterech rolach jednego obrazu wystarczy na skalę banku. | ADR-001 | przyjęte | S52 | Wydzielenie modułów do usług — kontrakty to umożliwiają. |
| Z-08 | Jeden tenant <default>; architektura gotowa na wielu bez zmian w kodzie domeny. | W-14, ADR-002 | przyjęte | scenariusze @multi-tenant | — |
| Z-09 | Tokeny trzyma BFF; przeglądarka ma tylko ciasteczko sesji. | ADR-008 | przyjęte | S18 | — |
| Z-36 | Własny renderer w Angularze odwzoruje zachowanie biblioteki form-js dla typów z katalogu pól. | ADR-019 | do weryfikacji | S07, S55 | Wariant zapasowy dla typów złożonych albo węższy katalog pól (ryzyko R16). |
| Z-38 | Licencja biblioteki form-js (bpmn.io) pozwala osadzić edytor w aplikacji banku przy widocznym znaku bpmn.io. | ADR-019 | do weryfikacji | S07 (przegląd prawny) | Bez zgody projektant formatek wymaga innego edytora. |

## Camunda

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-10 | Oficjalne SDK Camunda pokrywa potrzebne operacje (braki uzupełnia klient z OpenAPI wewnątrz ACL). | W-16, ADR-003 | do weryfikacji | S01 | Więcej kodu w module integracyjnym (ryzyko R01). |
| Z-11 | Autoryzacje zasobów Camunda zawężają dostęp per bpmnProcessId; token delegowany jest możliwy. | W-15, ADR-004 | do weryfikacji | S02 | Większy ciężar reguł L2 w aplikacji (ryzyko R02). |
| Z-12 | Task listener nadaje się do zastępstw w trybie fail-open. | W-23, ADR-007 | do weryfikacji | S03 | Zastępstwa realizowane przez projektor z opóźnieniem. |
| Z-13 | Read model zasilany wyszukiwaniem przyrostowym przez SDK mieści się w celu opóźnienia (propozycja P95 ≤ 5 s). | ADR-010, NFR-04 | do weryfikacji | S04 | Eksporter do Kafka (ryzyko R05). |
| Z-34 | Formatki w formacie Camunda Forms prowadzi aplikacja; zadania wskazują je referencją zewnętrzną, bez wdrażania formularzy do silnika. | W-43, C6, C22, ADR-018 | przyjęte | S29 | Wdrażanie do silnika wymagałoby szerszych uprawnień klienta platformy i drugiego cyklu życia. |
| Z-35 | Camunda 8.9 udostępnia ewaluację wyrażeń FEEL przez API klastra, wystarczającą do walidacji formatek na serwerze. | ADR-020 | do weryfikacji | S08 | Wariant zapasowy z ADR-020; do tego czasu walidacja bez wyrażeń (ryzyko R17). |

## Dane i bezpieczeństwo

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-14 | MS SQL Server 2022+ z RLS, tabelami Ledger i partycjonowaniem jest dostępny w banku. | ADR-005 | przyjęte | S06, S13 | Inny mechanizm niezmienności audytu. |
| Z-15 | Każde żądanie trafia do śladu operacyjnego; komendy i odczyty wrażliwe — do dziennika bezpieczeństwa, bez wartości PII. | W-08, W-18, NFR-02, NFR-09 | przyjęte | S25, S51 | — |

## Profile projektów

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-16 | Każdy proces ma dokładnie jeden profil-właściciela. | ADR-012 | przyjęte | validate_profiles.py | Procesy wspólne wielu projektów wymagają decyzji o właścicielu. |
| Z-17 | Punkty rozszerzeń SDK (operacje, wzbogacenia, źródła danych, zapytania, zdarzenia, sloty UI) pokrywają potrzeby projektów. | ADR-012, ADR-017, R13 | do weryfikacji | warsztat z zespołami przed S19; S38 (profil flota ujawnił brak operacji na danych profilu → RFC-FLO-03, ADR-017) | Kolejne RFC i wersje SDK. |
| Z-18 | Izolację danych profilu zapewni schemat i użytkownik bazy per profil z przełączaniem kontekstu w transakcji. | ADR-014 | do weryfikacji | S27 | Wariant zapasowy: osobne połączenie i login per profil (ryzyko R14). |
| Z-19 | Profile działają domyślnie in-process w pociągu wydań; model remote na wniosek zespołu. | D-08, D-10 | decyzja otwarta | przed S19 | Inny model wydań i koszt utrzymania po stronie zespołów. |
| Z-20 | Na start jedno repozytorium z CODEOWNERS dla platformy i profili. | D-09, ADR-013 | decyzja otwarta | przed S19 | Osobne repozytoria wymagają publikacji SDK i manifestów jako paczek. |
| Z-21 | Zespoły profili planują i wyceniają swoją część same; plan platformy obejmuje SDK, izolację, sloty UI i onboarding. | W-38 | przyjęte | S48 | — |

## Organizacja

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-22 | Zespół referencyjny 6,2 etatu (w tym 0,5 etatu projektanta UX) przy wykorzystaniu 75%. | plan/estimation-params.yaml | decyzja otwarta | S-1 | Inny kalendarz — przeliczenie modelu. |
| Z-23 | Dostępy (AD, RHBK, Kubernetes, MSSQL) i licencja Kendo UI są dostępne w pierwszych tygodniach. | S-3, S-4 | decyzja otwarta | S06, S16 | Około +5 tygodni w scenariuszu wolnych procedur (ryzyko R03). |
| Z-24 | Termin zewnętrznego pentestu jest zarezerwowany z wyprzedzeniem. | S-5 | decyzja otwarta | do tygodnia 12 | Przesunięcie G3 i pilotażu (ryzyko R06). |
| Z-37 | Projektant UX (0,5 etatu) prowadzi bibliotekę w Figma; do repozytorium trafiają eksporty, a agenci nie mają dostępu do Figma. | W-45, D-16, S-6, ADR-016 | decyzja otwarta | S09 | Bez projektanta wygląd zostaje na tokenach makiety; opóźnienie S16 i S49 (ryzyko R18). |

## AI i narzędzia

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-25 | Agentów uruchamia OpenCode z modelem z profilu modeli w config/models.yaml (dziś glm-5.3-flash; kandydaci: Qwen 3.8 27B, Gemma 4 31B — ADR-021); poziomy ról wybierają model i wariant rozumowania. | ADR-015 | przyjęte | kwalifikacja E01–E08 | Zmiana modelu = ponowna kwalifikacja ról. |
| Z-26 | Wszystkie dane (kod, dokumentacja, dane testowe) przetwarza wyłącznie model w infrastrukturze banku; zewnętrzne API są wykluczone. | W-40, ADR-016 | przyjęte | S06 (bramka), kwalifikacja E01–E08 | Bez bramki rój nie pracuje — prace prowadzą ludzie (ryzyko R15). |
| Z-30 | Narzędzia repozytorium działają bez Pythona — w wersji .NET (ph) z kodem źródłowym i bez zewnętrznych paczek. | W-41 | przyjęte | S00 (zgodność wyników z wersją Python) | Przy zablokowanym Pythonie i bez .NET zostaje praca ręczna. |
| Z-27 | Człowiek scala każdą zmianę i zatwierdza bramki; agenci pracują w osobnych worktree z zakresem zapisu. | AGENTS.md | przyjęte | S00 | — |

## Wycena

| Id | Założenie | Źródło | Status | Sprawdzenie | Jeśli nieprawda |
| --- | --- | --- | --- | --- | --- |
| Z-28 | Udział AI i koszt przeglądu per krok jak w plan/estimates.yaml; kalibracja po S10–S12. | plan/estimation.md | do weryfikacji | S10–S12 | Inne tygodnie i osobodni — model przelicza się automatycznie. |
| Z-29 | Dodatkowi ludzie nie skracają projektu; skraca go podział kroków ścieżki krytycznej. | scenariusze D i E | przyjęte | kalibracja | — |
