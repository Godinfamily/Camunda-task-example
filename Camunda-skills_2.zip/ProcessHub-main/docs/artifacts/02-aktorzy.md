<!-- WYGENEROWANE przez tools/artifacts/render_artifacts.py — edytuj actors.yaml, assumptions.yaml lub templates/ -->
# Aktorzy Process Hub

Kto korzysta z systemu, kto go wytwarza i z jakimi systemami współpracuje. Osoby w kolumnie „Kto” to świat testowy ze scenariuszy BDD (`specs/README.md`). Źródło: `actors.yaml`.

```mermaid
flowchart LR
  subgraph B["Użytkownicy biznesowi"]
    UB["Uczestnik · Inicjator · Menadżer procesu<br/>Administrator procesu · Audytor · Administrator platformy"]
    UP["Role projektowe z profili<br/>np. Analityk kredytowy, Underwriter, Analityk AML"]
  end
  subgraph W["Wytwarzanie"]
    TP["Zespół platformy"]
    TPR["Zespoły profili projektów"]
    AI["Rój agentów AI<br/>OpenCode + model w banku"]
  end
  PH["Process Hub<br/>platforma + profile"]
  CAM[("Camunda 8.9")]
  IDP[("RHBK + AD")]
  DB[("MS SQL Server")]
  SYS["Systemy i usługi projektów"]
  UB --> PH
  UP --> PH
  TP -->|platforma, SDK| PH
  TPR -->|profiles/&lt;id&gt;| PH
  AI -.->|pakiety robocze, człowiek scala| PH
  PH --> CAM
  PH --> IDP
  PH --> DB
  PH --> SYS
```

## Użytkownicy biznesowi — role platformy

Role wspólne dla wszystkich projektów; jedna osoba może mieć wiele ról naraz, w zakresie wybranych procesów.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-01 | Uczestnik | anna, bartek, celina, ewa, darek | Realizuje zadania swoich grup | moje zadania, przejęcie z grupy, szkic, zakończenie, własne zastępstwa; widzi stan zadań grupy tylko do odczytu | R1, R2, R3 | FR-01…FR-06, FR-12 |
| AK-02 | Inicjator procesu | anna | Uruchamia sprawy i śledzi ich postęp | start procesu z formatką startową, moje procesy z bieżącym etapem | R3 | FR-07, FR-08 |
| AK-03 | Menadżer procesu | marta, piotr | Pilnuje przepływu pracy w swoich procesach | wszystkie zadania i sprawy w zakresie, dashboard, eskalacje, przekazywanie pojedyncze i masowe, zastępstwa zespołu, nazwy i SLA etapów; formatki swoich procesów: projektowanie, przegląd, publikacja, wycofanie | R1 (nie edytuje), R6, R8, R11 | FR-10, FR-11, FR-13…FR-17, FR-28…FR-31 |
| AK-04 | Administrator procesu | adam | Utrzymuje konfigurację procesu | mapowanie elementów BPMN na etapy, widok techniczny; formatki swoich procesów: projektowanie, zatwierdzanie, publikacja, wycofanie, import i eksport | R4, R8, R11 | FR-15, FR-17, FR-28…FR-31 |
| AK-05 | Audytor | olga | Kontroluje zgodność i rozliczalność | odczyt wszystkich procesów, zadań, formatek z ich historią i dziennika audytu; żadnych akcji zapisu | R5, R7 | FR-19, FR-20 |
| AK-06 | Administrator platformy | zenon | Utrzymuje uprawnienia i rejestr profili | autoryzacje jako kod, rejestr profili, ślad operacyjny do analizy problemów | R7, R10 | FR-21, FR-23 |

## Role projektowe — przykłady z profili

Każdy profil składa własne role z ról platformy i uprawnień projektu; działają tylko w procesach profilu.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-07 | Analityk kredytowy (kredyty) | anna, bartek | Ocenia wnioski kredytowe | rola Uczestnika i Inicjatora w procesie wniosek-kredytowy + przeliczenie scoringu, dane wnioskodawcy | R1, R9 | FR-24, FR-25, KRE-FR-01 |
| AK-08 | Underwriter (kredyty) | celina, ewa | Akceptuje wnioski i odstępstwa | rola Uczestnika + odstępstwo od limitu, dane wnioskodawcy | R1, R9 | FR-24, FR-25 |
| AK-09 | Kierownik zespołu kredytowego (kredyty) | marta | Zarządza portfelem wniosków | rola Menadżera procesu + raport portfela | R9 | FR-24, FR-27 |
| AK-10 | Analityk i kierownik AML (aml) | darek, piotr | Weryfikuje klientów i transakcje | ponowna weryfikacja sankcji, profil ryzyka, eksport sprawy dla nadzoru (usługa zespołu AML) | R1, R9 | FR-24, FR-25, AML-FR-01 |
| AK-17 | Wnioskodawca (flota) | tomasz | Dostaje samochód służbowy zgodny z polityką floty | rola Inicjatora w procesie rejestracja-samochodu; przegląda katalog samochodów w sekcji „Flota” i wybiera model w formatce wniosku | R3, R9 | FR-07, FR-27, FLO-FR-01, FLO-FR-03 |
| AK-18 | Opiniujący — komórki IT, HR, Prawny, Finanse, Ryzyko (flota) | igor, hanna, lena, filip, rafal | Wydaje opinię komórki o wniosku | rola Uczestnika w procesie opiniowanie-rejestracji; każda komórka widzi i przejmuje tylko swoje zadanie opinii | R1, R2, R3, R9 | FR-24, FLO-FR-04 |
| AK-19 | Administrator katalogu samochodów (flota) | karol | Prowadzi katalog samochodów dostępnych do zakupu | bez ról platformy; dodaje, zmienia, wycofuje i przywraca modele operacjami na danych profilu (profile-action); każda zmiana w dzienniku | R9, R10 | FR-25, FR-27, FLO-FR-02 |

## Zespoły i osoby wytwarzające oraz decydujące

Platformę i profile realizują różne zespoły; ludzie zatwierdzają bramki i scalają zmiany.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-11 | Zespół platformy | architekt, backend .NET, frontend Angular, QA | Buduje i utrzymuje część wspólną | moduły platformy, SDK rozszerzeń i jego zgodność, CI, integracja z Camunda | ADR-012, ADR-013 | plan/backlog.yaml |
| AK-12 | Zespół profilu projektu | PO projektu, programiści projektu | Realizuje część specyficzną projektu | manifest profilu, operacje, dane prj_<id>, sloty UI, workery i scenariusze profilu; własny plan i rytm wydań | R9, R10 | profiles/<id>/backlog.yaml |
| AK-13 | Product Owner platformy i analityk | — | Prowadzi wymagania i decyzje biznesowe | akceptacja scenariuszy, decyzje D-01…D-07, D-10, D-11, D-13, D-14, priorytety | — | G0 |
| AK-14 | Bezpieczeństwo i compliance | — | Chroni bank i klientów | zatwierdzenie bramki modelu w banku (S-2), przegląd danych restricted, pentest, retencja audytu | R7 | G3, S-2, S-5 |
| AK-15 | DevOps | — | Zapewnia środowiska i dostarczanie | Camunda 8.9 na Kubernetes, RHBK, MSSQL, bramka modelu LLM w banku, pipeline CI/CD | — | S06, S-3 |
| AK-16 | Sponsor projektu | — | Zatwierdza zakres, zespół i budżet | decyzje startowe S-1 i S-6, rytm wydań profili (D-10) | — | S-1, S-6 |
| AK-26 | Projektant UX | — | Zapewnia spójny wygląd i użyteczność całego systemu | biblioteka w Figma (tokeny, komponenty pól, wzorce), eksport do design/**, zatwierdzanie wzorców regresji wizualnej, testy z użytkownikami; nie decyduje o treści formatek | ADR-019 | S09, D-16, NFR-08, NFR-15 |

## Systemy i aktorzy techniczni

Systemy, z którymi Process Hub współpracuje w czasie działania i wytwarzania.

| Id | Aktor | Kto | Cel | Co robi | Reguły i decyzje | Wymagania |
| --- | --- | --- | --- | --- | --- | --- |
| AK-20 | Camunda 8.9 | Zeebe, Operate, Tasklist, Identity | Orkiestruje procesy | jedyne źródło prawdy o stanie procesu i zadań; autoryzacje zasobów (L1); dostęp wyłącznie przez platformę | C1–C23 | ADR-003, ADR-004, ADR-018 |
| AK-21 | RHBK i Active Directory | — | Tożsamość i grupy | SSO jednego realmu, grupy AD jako podstawa ról platformy i projektowych | — | ADR-008 |
| AK-22 | MS SQL Server 2022+ | — | Dane platformy i profili | read model, audyt (Ledger), schematy modułów i prj_<id> profili z izolacją | — | ADR-005, ADR-014 |
| AK-23 | Systemy projektów | np. system scoringowy, rejestr kredytowy, listy sankcyjne | Dane i usługi projektów | wywoływane z operacji profili i workerów typów zadań <id>.* | R9 | profile.yaml: integrations |
| AK-24 | Usługi profili remote | np. usługa AML | Część specyficzna w osobnej usłudze | kontrakt profile-operations v1, wywołania z podpisanym kontekstem; własne wydania zespołu | R9 | ADR-012 |
| AK-25 | Rój agentów AI | OpenCode + model LLM w infrastrukturze banku | Przyspiesza wytwarzanie pod nadzorem ludzi | kroki planu w pakietach roboczych; agenci platformy (w tym warstwy wizualnej: ux-designer, design-system-engineer, ui-reviewer) i agenci profili z rozdzielonym zakresem zapisu; człowiek scala | ADR-015 | AGENTS.md |
