# 00. Przegląd architektury (v4)

Process Hub to własny TaskList nad Camunda 8.9. Camunda orkiestruje i rozstrzyga o stanie zadań; platforma rozstrzyga, kto co widzi i co może zrobić, nakłada warstwę etapów biznesowych, daje menadżerowi procesu dashboard, eskalacje i przekazywanie zadań oraz audytuje każdą akcję. Projekty biznesowe korzystają z platformy przez **profile projektów**: część wspólna działa tak samo dla każdego profilu, a część specyficzna (role projektowe, dane, operacje, rozszerzenia UI) należy do zespołu projektu i jest od platformy oddzielona (`13-project-profiles.md`).

## Zakres

- **W zakresie:** skrzynka zadań (moje, grupy), start procesów z aplikacji, „moje procesy”, panel menadżera procesu (dashboard, eskalacje, instancje, przekazywanie, zastępstwa), mapa etapów, formatki w formacie Camunda Forms (projektowanie, wersje, akceptacja, wycofanie, renderowanie komponentami design systemu — `14-form-management.md`), rola audytora, administracja uprawnieniami jako kod, pełny audyt, profile projektów z SDK rozszerzeń (operacje dedykowane, dane projektu, sloty UI).
- **Poza zakresem:** modelowanie BPMN (zespół deweloperski, poza aplikacją), Operate/Tasklist/Optimize jako narzędzia użytkowników, aplikacja mobilna natywna.

## Stos

| Warstwa | Wybór |
| --- | --- |
| Backend | .NET 10 (LTS), modularny monolit, jeden obraz w rolach `api`, `projector`, `jobs`, `worker` |
| Integracja z Camunda | oficjalne SDK Camunda, wyłącznie w module `CamundaIntegration` (ADR-003) |
| Baza | MS SQL Server 2022+ (RLS, tabele Ledger, partycjonowanie) |
| Frontend | Angular + Kendo UI, Nx, Signals; bpmn-js (viewer) tylko w edytorze mapy etapów; edytor form-js tylko w projektancie formatek (ADR-019) |
| Warstwa wizualna | design system: tokeny z Figma w `design/tokens.json`, komponenty w `core/ui-kit`, katalog pól formatek w `design/forms/` |
| SSO | RHBK, realm `camunda-platform`, federacja AD, BFF z ciasteczkiem (ADR-008) |
| Testy | xUnit, Reqnroll (Gherkin PL), Testcontainers, ArchUnitNET/NetArchTest, Playwright, Stryker.NET |
| Rozszerzenia | SDK `ProcessHub.Extensibility` i `@process-hub/extension-sdk`; profile w `profiles/<id>/` (ADR-012…014) |
| Wytwarzanie z AI | OpenCode z modelem wyłącznie w infrastrukturze banku, wymiennym przez profil modeli — dziś GLM 5.3 Flash (ADR-015, ADR-016, ADR-021); narzędzia repozytorium w Pythonie albo w .NET (`tools/dotnet/`) |

## Zmiany v2 względem v1

| Obszar | v1 | v2 | Dlaczego |
| --- | --- | --- | --- |
| Tenancy | tenant = linia biznesowa | **jeden tenant `<default>`**, architektura gotowa na wielu (ADR-002) | Wymóg; separacja wewnątrz tenanta przez autoryzacje zasobów |
| Separacja danych | tenant + RLS | **resource authorizations Camunda (L1) + polityka aplikacji (L2)**, autoryzacje jako kod (ADR-004) | Wymóg; jeden model uprawnień dla silnika i aplikacji |
| Klient Camunda | REST własny | **oficjalne SDK** za ACL (ADR-003) | Wymóg; wsparcie producenta przy zmianach wersji |
| Role | role stałe | **wiele ról naraz**, role jako dane, zakresy per proces (`02-roles-and-authorization.md`) | Użytkownik bywa wykonawcą, menadżerem i administratorem jednocześnie |
| Menadżer | menadżer zespołu | **menadżer procesu** (zakres: definicje procesów) + opcjonalnie zakres zespołu | Wymóg: dashboard, przekazywanie, formatki |
| Etapy | `zeebe:properties` w BPMN | **mapa etapów w aplikacji**, BPMN tylko jako zasiew (ADR-006) | Menadżer/administrator sam definiuje etapy bez technikaliów |
| Przekazywanie | opcjonalne | **wymagane**: osoba lub grupa, pojedynczo i masowo, plus zastępstwa (ADR-007) | Urlopy, nieobecności |
| Eskalacje, dashboard | brak | **nowe** (`08-process-dashboard.md`) | Wymóg |
| Audyt | Ledger | **Ledger + ślad operacyjny każdego żądania** (ADR-005) | Bezpieczeństwo i analiza problemów |
| BDD | SpecFlow | Reqnroll (ADR-009) | SpecFlow wycofany; Gherkin bez zmian |

## Zmiany v3 względem v2

| Obszar | v2 | v3 | Dlaczego |
| --- | --- | --- | --- |
| Projekty biznesowe | procesy w jednym katalogu ról | **profile projektów**: manifest, role projektowe, uprawnienia w przestrzeni nazw projektu (ADR-012) | Każdy projekt ma własne potrzeby co do danych i operacji |
| Część specyficzna | brak miejsca na kod projektu | **SDK rozszerzeń i punkty rozszerzeń**: operacje (na zadaniu, sprawie i danych profilu), wzbogacenia, źródła danych formatek, zapytania, zdarzenia, sloty UI z sekcją nawigacji profilu | Autonomia zespołów bez zmian w platformie |
| Separacja kodu | moduły platformy | **profiles/<id>/** z `CODEOWNERS`, testami architektury, schematem i użytkownikiem bazy per profil (ADR-013, ADR-014) | Zespół jednego projektu nie realizuje części innego |
| Reguły dostępu | R1–R8 | **R9** (zasoby tylko procesów profilu), **R10** (przestrzeń nazw profilu) | Separacja w czasie wykonania |
| Agenci AI | wielu dostawców | **OpenCode + model w banku (wymienny)**, agenci per profil (ADR-015, ADR-016, ADR-021) | Decyzja o narzędziach; dane nie opuszczają banku; separacja także w pracy agentów |

## Zmiany v4 względem v3

| Obszar | v3 | v4 | Dlaczego |
| --- | --- | --- | --- |
| Format formatek | własny schemat (JSON Schema, JSON Logic) | **Camunda Forms** (schemat form-js, FEEL), import i eksport `.form` (ADR-018) | Formatki zgodne z biblioteką Camunda 8.9, tworzone jak w Modelerze |
| Cykl życia | szkic, przegląd, publikacja | **pełne wersje, akceptacja, wycofanie** z wersją zastępczą i przepięciem zadań (`Form.Withdraw`) | Wymóg zarządzania wersjami i wycofywania |
| Separacja formatek | zakres roli | **formatka należy do jednego procesu — reguła R11** | Każdy proces ma formatki wyłącznie dla siebie |
| Projektant | własna kanwa | **osadzony edytor form-js**, paleta ograniczona katalogiem pól (ADR-019) | Te same możliwości co w Modelerze, bez własnego edytora |
| Wygląd formatek | kontrolki Kendo dobierane w kodzie | **materializacja z katalogu pól**: typ → komponent design systemu, tokeny z Figma | Biznes decyduje o polach i układzie, wygląd jest wspólny dla systemu |
| Walidacja na serwerze | JSON Logic | **reguły schematu + FEEL przez silnik** (ADR-020) | Camunda nie waliduje danych zadania względem formularza |
| Agenci AI | 12 ról | **+ `ux-designer`, `design-system-engineer`, `ui-reviewer`** | Warstwa wizualna ma własnych wykonawców i recenzenta |

## Mapa dokumentów

| Plik | Treść |
| --- | --- |
| `01-requirements.md` | wymagania FR/NFR z odsyłaczami do `specs/` |
| `02-roles-and-authorization.md` | role, uprawnienia, zakresy, autoryzacje L1/L2, macierz |
| `03-context-map.md` | konteksty DDD i ich relacje |
| `04-domain-model.md` | archetypy, agregaty, inwarianty, stany zadania |
| `05-solution-architecture.md` | kontenery, moduły, potok, SOLID, układ rozwiązania |
| `06-camunda-integration.md` | praktyki Camunda z uzasadnieniem |
| `07-process-stage-overlay.md` | mapa etapów: model, edycja, wersjonowanie, widoczność |
| `08-process-dashboard.md` | metryki, progi zdrowia, eskalacje |
| `09-persistence-mssql.md` | schematy, RLS, Ledger, partycje |
| `10-audit-and-security.md` | audyt każdej akcji, kontrole bezpieczeństwa |
| `11-frontend.md` | moduły UI, widoki, afordancje |
| `12-testing-strategy.md` | poziomy testów, tagi, drivery |
| `13-project-profiles.md` | profile projektów: kontrakt, role projektowe, punkty rozszerzeń, dane, UI, separacja, autonomia zespołów |
| `14-form-management.md` | moduł zarządzania formatkami: Camunda Forms, wersje, akceptacja, wycofanie, separacja per proces, renderowanie, warstwa wizualna |

Plan systemu, aktorzy, założenia i wytyczne UI w formie artefaktów projektowych: `docs/artifacts/`.
