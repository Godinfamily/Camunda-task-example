# 01-wejscie-i-architektura — Wejście do repozytorium, zasady dla agentów i ludzi, słownik i architektura (docs/architecture 00–14)

Pakiet zawiera 18 plików repozytorium Process Hub. Nagłówek „## Plik:” podaje ścieżkę oryginału.

## Plik: README.md

# Process Hub — własny TaskList dla Camunda 8.9

Repozytorium dokumentacji wykonywalnej (docs-as-code). Wszystko, czego potrzebują ludzie i agenci AI, leży tutaj jako tekst: architektura, decyzje (ADR), profile projektów, scenariusze BDD, plan wykonywalny, wycena i konfiguracja roju agentów (OpenCode z modelem uruchomionym w infrastrukturze banku — wymiennym, dziś GLM 5.3 Flash). Narzędzia repozytorium działają w Pythonie albo — gdy Python jest zablokowany — w .NET (`tools/dotnet/`, polecenie `ph`).

Wersja: **v4**. Platforma jest wspólna dla wszystkich projektów; każdy projekt ma **profil** z własnymi rolami, danymi i operacjami (`profiles/`), realizowany niezależnie przez zespół projektu. Wersja 4 dodaje **moduł zarządzania formatkami** w formacie Camunda Forms (wersje, akceptacja, wycofanie, separacja per proces, renderowanie komponentami design systemu — `docs/architecture/14-form-management.md`) i agentów warstwy wizualnej. Plan systemu, aktorzy, przyjęte założenia i wytyczne UI: `docs/artifacts/` (także jako strony `docs/artifacts/index.html` i `docs/artifacts/wytyczne-ui.html`).

## Kolejność czytania

| Kto | Najpierw | Potem |
| --- | --- | --- |
| Decydent, sponsor | `docs/artifacts/index.html` | `plan/dashboard/index.html` |
| Agent AI | `AGENTS.md` | pakiet kroku (`plan/packets/<krok>.md`) → pliki z sekcji „Czytaj” |
| Architekt / tech lead | `docs/architecture/00-overview.md` | `02-roles-and-authorization.md`, `13-project-profiles.md`, `docs/adr/` |
| Zespół profilu projektu | `profiles/README.md`, `docs/guides/dedykowane-elementy-profilu.md` | `profiles/<id>/AGENTS.md`, `profiles/<id>/profile.yaml`, przykład `profiles/flota/`, skill `profile-extension` |
| Biznes / Product Owner | `docs/architecture/01-requirements.md` | `specs/**/*.feature`, `profiles/<id>/specs/` |
| DevOps | `docs/adr/ADR-003…ADR-005`, `ADR-010`, `ADR-014`, `ADR-016` | `docs/opencode/start.md`, `tools/dotnet/README.md` |
| Zespół platformy AI | `docs/agents/multi-model-guide.md` | `config/models.yaml`, `evals/agents/` |
| Projektant UX / frontend | `docs/artifacts/04-wytyczne-ui.md` (start dla nowej osoby) | `design/README.md`, `design/forms/README.md`, `design/mockups/index.html`, `design/tokens.json` |
| Autor formatek, zespół formatek | `docs/architecture/14-form-management.md` | `docs/adr/ADR-018…ADR-020`, `design/forms/field-catalog.yaml`, `specs/forms/` |

## Mapa repozytorium

```
AGENTS.md                     zasady dla agentów i ludzi (czytane automatycznie przez OpenCode) + tabela agentów
CODEOWNERS                    własność kodu: platforma i zespoły profili (generowany)
docs/glossary.md              język wszechobecny (PL ↔ kod)
docs/artifacts/               plan systemu, aktorzy, założenia, wytyczne UI (Markdown + strony HTML)
docs/architecture/00..14      architektura v4 (13 — profile projektów, 14 — moduł zarządzania formatkami)
docs/adr/                     decyzje architektoniczne ADR-001…020
docs/rfc/                     wnioski o zmianę kontraktów, specyfikacji i SDK (np. RFC-FLO-03 → ADR-017)
docs/guides/                  przewodniki dla zespołów: dedykowane elementy procesów w profilu projektu
docs/opencode/start.md        start projektu z OpenCode krok po kroku
docs/agents/multi-model-guide.md  agenci w OpenCode z modelem w banku: wybór i zmiana modelu, warianty, polityka danych, kwalifikacja
docs/handover/                podsumowanie; od-zera/ — prompty odtwarzające repozytorium; notes/ — prompt i źródła do notesu
specs/                        scenariusze Gherkin platformy (Reqnroll, # language: pl)
profiles/                     profile projektów: schemat manifestu, szablon, kredyty (in-process), aml (remote), flota (przykład dedykowanych elementów)
config/authorization/         role platformy i role globalne jako kod
config/models.yaml            profile modeli na bramce banku (GLM, Qwen, Gemma), warianty rozumowania, limity, polityka danych
config/ownership.yaml         właściciele kodu platformy (źródło CODEOWNERS)
plan/execution-plan.md        plan wykonywalny: kroki, fazy, bramki, ścieżka krytyczna
plan/backlog.yaml             ten sam plan w formie maszynowej (orkiestrator)
plan/estimation.md            złożoność, pracochłonność hybrydy AI + ludzie, wrażliwość (+ estimates.yaml, estimation-report.md)
plan/dashboard/               interaktywny dashboard harmonogramu i wyceny (index.html działa z dysku)
.opencode/                    agenci (generowani), skille, komendy, plugin strażnika zapisu
opencode.json                 konfiguracja OpenCode (generowana)
agents/                       kanoniczne role (registry.yaml, prompts/), schematy wyjścia, polityka wykonania
tools/agents/                 generator agentów, prowadzenie kroków (prepare_step, run_dod, plan_status), walidator wyników
tools/guard/                  strażnik zakresu zapisu (OpenCode i CI)
tools/profiles/               walidacja manifestów profili i CODEOWNERS, zakładanie nowego profilu
tools/plan/                   model wyceny i eksport danych dashboardu
tools/dotnet/                 te same narzędzia w C# (.NET 10, bez zewnętrznych paczek) — polecenie `ph`, kod źródłowy i testy
evals/agents/                 kwalifikacja modeli do ról (E01–E11)
design/                       propozycja UI: README, tokens.json, mockups/index.html (klikalna makieta), forms/ (założenia wizualne formatek, katalog pól, formatka wzorcowa)
```

## Status decyzji

Decyzje oznaczone **Proponowana** rozstrzyga faza PoC: kroki S01–S04 (bramka G0 — do tego czasu agenci implementujący nie startują), kroki S07–S09 dla formatek i warstwy wizualnej (bramka G1 — do tego czasu kontrakty modułu formatek nie są zamrażane) oraz krok S27 (izolacja danych profili).

## Plik: AGENTS.md

# AGENTS.md — zasady dla agentów i ludzi

Process Hub zastępuje natywny Tasklist Camunda 8.9: własne UI (Angular), BFF w .NET 10 (modularny monolit), MS SQL Server, SSO w RHBK. Camunda jest jedynym źródłem prawdy o stanie procesu; platforma decyduje, kto co widzi, dodaje warstwę etapów biznesowych, dashboard menadżera, formatki w formacie Camunda Forms (z wersjami, akceptacją i wycofaniem) i pełny audyt. Projekty biznesowe korzystają z platformy przez **profile projektów** (`profiles/<id>/`) — własne role, dane i operacje, realizowane niezależnie przez zespoły projektów.

Agenci działają w OpenCode z modelem uruchomionym wyłącznie w infrastrukturze banku (ADR-016). Model jest wymienny: obowiązuje profil z `config/models.yaml` (dziś GLM 5.3 Flash; kandydaci: Qwen 3.8 27B, Gemma 4 31B — ADR-021). Zasady i procedury w tym pliku nie zależą od modelu. Ten plik OpenCode wczytuje automatycznie.

## Jak pracujesz

1. Przeczytaj pakiet swojego kroku (`plan/packets/<krok>.md`): Cel, Wynik, Wskazówki startowe. Potem pliki z sekcji „Czytaj” — w podanej kolejności i nic poza nimi. Pliki z sekcji „Sięgaj punktowo” przeszukujesz, nie wczytujesz.
2. Pracuj tylko w ścieżkach z `.agent-scope`. Plugin `.opencode/plugin/write-scope.js` (logika: `tools/guard/enforce_write_scope.py`) zablokuje resztę.
3. Zrób dokładnie to, co w sekcji „Wynik” — bez dodatkowych funkcji, plików, zależności i refaktoryzacji „przy okazji”.
4. Zakończ dopiero, gdy przechodzą wszystkie komendy Definition of Done z pakietu; potem zatwierdź zmiany na gałęzi kroku (`git add`, `git commit` — nigdy `push` ani `merge`).
5. Oddaj wynik w formacie przekazania (niżej) — sam JSON. Nie wklejaj logów ani transkryptów.

## Fakty, nie domysły

- Nazwy pliku, klasy, interfejsu, uprawnienia, komendy albo klucza konfiguracji używasz tylko wtedy, gdy widziałeś ją w repozytorium w tej sesji (odczyt albo wyszukiwanie). Nie znalazłeś — nie istnieje; nie zakładaj jej z pamięci.
- Pojęcia tylko ze słownika `docs/glossary.md`; reguły R1–R11 i nazwy uprawnień dokładnie jak w `docs/architecture/02-roles-and-authorization.md`.
- Nowy plik wzorujesz na istniejącym pliku tego samego rodzaju albo na wzorcu ze skilla — nie tworzysz własnego układu.
- Brakuje informacji potrzebnej do wykonania (nazwy, decyzji, pliku) → pytanie w `open_questions` i status `blocked`. Luk nie wypełniasz założeniami.
- Wynik komendy podajesz tylko, jeśli ją uruchomiłeś i zobaczyłeś kod wyjścia; inaczej `skipped`.
- Wszystko, co da się sprawdzić skryptem, sprawdzasz skryptem (`validate_plan.py`, `validate_profiles.py`, `validate_forms.py`, `render_agents.py --check`) i poprawiasz do zielonego.

## Zasady nienaruszalne

1. **Camunda tylko przez moduł `CamundaIntegration`** i wyłącznie przez oficjalne SDK Camunda (ADR-003). Żaden inny moduł ani profil nie zna typów SDK ani adresów Camunda.
2. **Każda akcja jest audytowana** (ADR-005, `docs/architecture/10-audit-and-security.md`) — także operacje profili. Endpoint bez potoku komend/zapytań nie przejdzie testu architektury.
3. **Edycja i zakończenie zadania tylko przez assignee** (reguła R1). Menadżer procesu przekazuje zadania, ale nie edytuje ich treści.
4. **Uprawnienia, nie nazwy ról.** W kodzie sprawdzasz `Permission.TaskReassign` albo uprawnienie profilu (`kredyty.Scoring.Recalculate`), nigdy `role == "Manager"`. Role to dane w `config/authorization/` i `profiles/<id>/`.
5. **`TenantId` wszędzie**, choć dziś jest jeden tenant (`<default>`). Nigdy nie zakładaj jednego tenanta w zapytaniu.
6. **Deny by default.** Brak uprawnienia = odmowa + wpis audytu z wynikiem `Denied`.
7. **Platforma i profile są rozdzielone.** Kod profilu zależy wyłącznie od SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`); platforma nie zna kodu profili. Krok profilu zmienia tylko `profiles/<id>/**` (reguły R9, R10; ADR-012, ADR-013).
8. **Nie zmieniasz** `specs/**`, `**/Contracts/**`, `docs/adr/**`, `config/authorization/**`, SDK rozszerzeń ani `profiles/*/profile.yaml` i `profiles/*/authorization.yaml`, jeśli nie jesteś ich właścicielem. Potrzebujesz zmiany → plik `docs/rfc/RFC-<krok>-<temat>.md` (wolno go utworzyć w każdym kroku), status `needs-rfc` i stop.
9. **Zakazane zależności:** komercyjne wersje MediatR, AutoMapper, FluentAssertions; każda nowa paczka NuGet/npm wymaga ADR (platforma) albo zgody architekta platformy (profil).
10. **Język:** kod i identyfikatory po angielsku; dokumentacja, teksty UI i Gherkin po polsku (`# language: pl`).
11. **Formatka należy do jednego procesu** (reguła R11) i ma format Camunda Forms; typy pól wyłącznie z katalogu pól (`design/forms/field-catalog.yaml`). Formatek nie wdrażasz do silnika (ADR-018).
12. **Wygląd tylko z design systemu.** Wartości wizualne wyłącznie z `design/tokens.json`, widoki z komponentów `core/ui-kit`; schemat formatki ani renderer nie niosą stylów (ADR-019).

## Komendy

```bash
dotnet build ProcessHub.sln -warnaserror
dotnet test ProcessHub.sln --filter "Category!=integration"     # unit + BDD in-memory
dotnet test tests/ProcessHub.ArchitectureTests                   # granice modułów i profili
dotnet test ProcessHub.sln --filter "Category=integration"      # Testcontainers: MSSQL + Camunda
npx nx affected -t lint test build                               # frontend
npx bpmnlint "bpmn/**/*.bpmn" "profiles/*/bpmn/**/*.bpmn"        # modele procesów
python3 tools/profiles/validate_profiles.py --check              # manifesty profili, CODEOWNERS
python3 tools/plan/validate_plan.py --check                      # spójność planów z repozytorium i rolami agentów
python3 tools/forms/validate_forms.py --check                    # formatki .form ↔ katalog pól ↔ kontrakt ph:outputs
python3 tools/plan/place_step.py <szkic.yaml> [--backlog …]     # miejsce nowego kroku: zależności, bramka, konflikty
python3 tools/refresh.py                                         # wszystko, co generowane + wszystkie bramki repozytorium (--check: tylko sprawdź)
```

Gdy Python jest niedostępny, każde narzędzie z `tools/` ma odpowiednik .NET: `ph <polecenie>` (`tools/dotnet/README.md`), np. `ph profiles validate --check`, `ph guard --self-test`.

## Format przekazania (JSON, ostatnia wiadomość agenta)

```json
{
  "step": "S30",
  "status": "done | blocked | needs-rfc",
  "changed": ["src/Modules/TaskWork/..."],
  "gates": {"build": "pass", "unit": "pass", "bdd": "pass", "arch": "pass"},
  "specs_covered": ["specs/tasks/claim-and-complete.feature"],
  "open_questions": [],
  "rfc": null
}
```

## Gdzie szukać

- Słownik pojęć: `docs/glossary.md`; plan systemu, aktorzy i założenia: `docs/artifacts/`
- Role i uprawnienia: `docs/architecture/02-roles-and-authorization.md`; profile projektów: `docs/architecture/13-project-profiles.md`, `profiles/README.md`
- Dedykowane elementy procesów w profilu (własne menu, strony, dane, operacje): `docs/guides/dedykowane-elementy-profilu.md`; przykład kompletnego profilu: `profiles/flota/`
- Praktyki Camunda z uzasadnieniem: `docs/architecture/06-camunda-integration.md` i skill `camunda-practices`
- Szablon modułu DDD: skill `ddd-module`; rozszerzenie w profilu: skill `profile-extension`; konwencje BDD: skill `reqnroll-bdd`
- Formatki: `docs/architecture/14-form-management.md`, katalog pól `design/forms/field-catalog.yaml`, skill `camunda-forms`
- UI: wytyczne dla nowych osób `docs/artifacts/04-wytyczne-ui.md`, `design/README.md`, formatki `design/forms/README.md`, tokeny `design/tokens.json`, klikalna makieta `design/mockups/index.html`, skill `design-system`
- Nowy profil od zera (role, procesy, formatki, dedykowane widoki): skill `new-profile`; artefakty generowane i wzorce dokumentów (RFC, raport PoC, przekazanie): skill `project-artifacts`; nowy krok w planie platformy albo profilu (zależności, bramka, miejsce): skill `backlog-extension` i `tools/plan/place_step.py`; nowa rola agenta, komenda, skill: skill `plan-maintenance`
- Jak działają agenci, ich uprawnienia i harness (dla ludzi): `docs/artifacts/05-agenci.md`
- Agenci są generowani z `agents/registry.yaml` (`tools/agents/render_agents.py`) — nie edytuj `.opencode/agent/` ręcznie

<!-- ROLE:BEGIN — sekcję generuje tools/agents/render_agents.py; nie edytuj ręcznie -->
## Agenci (OpenCode)

| Agent | Zakres zapisu | Poziom | Model · wariant | Hosting | Klasa danych |
| --- | --- | --- | --- | --- | --- |
| `architect` | platforma (bez `profiles/<id>/**`) | T1 | `glm-5.3-flash` · high | on-prem | confidential |
| `bdd-analyst` | `specs/**`, `docs/rfc/RFC-*.md` | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `bdd-tester` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `camunda-integrator` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `ci-triage` | brak (tylko odczyt) | T3 | `glm-5.3-flash` · low | on-prem | internal |
| `data-engineer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `docs-writer` | `docs/guides/**`, `CHANGELOG.md`, `docs/rfc/RFC-*.md` | T3 | `glm-5.3-flash` · low | on-prem | internal |
| `frontend-developer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `module-implementer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `orchestrator` | `plan/progress/**`, `plan/packets/**`, `profiles/*/progress/**` | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `reviewer` | brak (tylko odczyt) | T1 | `glm-5.3-flash` · high | on-prem | confidential |
| `ux-designer` | `design/**`, `poc/forms-ui/**`, `docs/rfc/RFC-*.md` | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `design-system-engineer` | platforma (bez `profiles/<id>/**`) | T2 | `glm-5.3-flash` · high | on-prem | internal |
| `ui-reviewer` | brak (tylko odczyt) | T1 | `glm-5.3-flash` · high | on-prem | internal |
| `security-reviewer` | brak (tylko odczyt) | T0 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-module-implementer` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-bdd-tester` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `aml-frontend-developer` | `profiles/aml/**` | T2 | `glm-5.3-flash` · high | on-prem | restricted |
| `flota-module-implementer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-bdd-tester` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-frontend-developer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `flota-data-engineer` | `profiles/flota/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-module-implementer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-bdd-tester` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-bdd-analyst` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-frontend-developer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |
| `kredyty-data-engineer` | `profiles/kredyty/**` | T2 | `glm-5.3-flash` · high | on-prem | confidential |

Model i warianty pochodzą z profilu modeli w `config/models.yaml` (ADR-021); poziom wybiera model i wariant rozumowania, eskalacja: wyższy wariant, potem człowiek. Wszystkie role używają modelu w infrastrukturze banku (ADR-016); klasa danych decyduje o przeglądzie bezpieczeństwa.
<!-- ROLE:END -->

## Plik: docs/glossary.md

# Słownik pojęć (Ubiquitous Language)

| Pojęcie (PL) | Kod | Definicja | Odwzorowanie w Camunda 8.9 |
| --- | --- | --- | --- |
| Tenant | `TenantId` | Najwyższa granica separacji danych. Domyślnie jeden: `<default>` | Tenant (multi-tenancy wyłączone = `<default>`) |
| Definicja procesu | `ProcessDefinitionKey` / `BpmnProcessId` | Model BPMN w konkretnej wersji; `BpmnProcessId` to identyfikator niezależny od wersji | Process definition |
| Instancja procesu | `ProcessInstanceKey` | Pojedyncze wykonanie definicji | Process instance |
| Zadanie | `WorkItem` (`UserTaskKey`) | Krok wymagający człowieka | Camunda user task |
| Assignee | `Assignee` | Osoba, która przejęła zadanie; jedyna może je edytować i zakończyć | `assignee` |
| Grupa kandydująca | `CandidateGroups` | Grupy, których członkowie mogą przejąć zadanie | `candidateGroups` |
| Inicjator | `InitiatorPartyId` | Osoba, która wystartowała proces z aplikacji | zmienna `initiatorPartyId` |
| Uprawnienie | `Permission` | Atomowa zdolność, np. `Task.Reassign` | — |
| Rola | `Role` | Nazwany zbiór uprawnień, zdefiniowany jako dane | Role / Group + Authorizations |
| Zakres | `Scope` | Do czego rola się odnosi: tenant, definicje procesów, zespół | `resourceId` autoryzacji |
| Przypisanie roli | `RoleAssignment` | Grupa AD lub osoba → rola w zakresie | Mapping rule + authorization |
| Menadżer procesu | rola `ProcessManager` | Nadzoruje instancje swoich procesów, przekazuje zadania, prowadzi formatki swoich procesów (projekt, przegląd, publikacja, wycofanie) i mapę etapów | autoryzacje READ/UPDATE na definicjach w zakresie |
| Administrator procesu | rola `ProcessAdministrator` | Konfiguruje proces w aplikacji: formatki, mapowanie elementów BPMN na etapy, progi | jw. + odczyt definicji |
| Audytor | rola `Auditor` | Wgląd tylko do odczytu we wszystkie procesy i dziennik audytu | READ na `*` |
| Formatka | `FormDefinition` (`FormKey`) | Formularz zadania albo startu procesu w formacie Camunda Forms; należy do dokładnie jednego procesu (R11) | brak zasobu w silniku — user task wskazuje ją przez `zeebe:formDefinition externalReference="ph:form/<klucz>"` |
| Wersja formatki | `FormVersion` | Treść formatki w cyklu `Draft → InReview → Approved → Published → Superseded / Withdrawn`; numer nadaje publikacja | — |
| Wersja obowiązująca | `CurrentVersion` | Opublikowana wersja przypinana nowym zadaniom; najwyżej jedna na formatkę | — |
| Przypięcie | `WorkItem.FormVersion` | Wersja formatki zapisana przy zadaniu w chwili utworzenia; zmienia ją tylko przepięcie przy wycofaniu | — |
| Wycofanie | `FormWithdrawal` (`Form.Withdraw`) | Zdjęcie opublikowanej wersji albo całej formatki z użycia, z powodem, wersją zastępczą i trybem dla zadań w toku | — |
| Kontrakt danych zadania | `ph:inputs`, `ph:outputs` | Zmienne, które zadanie dostaje i musi oddać; sprawdzany przy publikacji formatki | `zeebe:properties` na user tasku lub zdarzeniu startowym |
| Katalog pól | `design/forms/field-catalog.yaml` | Typy komponentów Camunda Forms ze statusem wsparcia i komponentem design systemu | typy komponentów form-js |
| Materializacja | `form-runtime`, `core/ui-kit` | Zamiana schematu formatki na interfejs z komponentów design systemu; schemat nie niesie wyglądu | — |
| Token wizualny | `design/tokens.json` | Nazwana wartość wyglądu (kolor, odstęp, wymiar) eksportowana z Figma; jedyne źródło wyglądu dla kodu | — |
| Mapa etapów | `StageMap` | Warstwa biznesowa nad BPMN: etapy i przypisane do nich elementy | brak — własny model |
| Etap | `Stage` | Biznesowy krok procesu widoczny dla menadżera | grupa elementów BPMN |
| Eskalacja | `Escalation` | Zdarzenie podniesienia rangi sprawy zamodelowane w BPMN | escalation event / timer boundary oznaczony `ph:escalationLevel` |
| Naruszenie SLA | `SlaBreach` | Zadanie lub etap po terminie wg progów w aplikacji | `dueDate` |
| Wynik biznesowy | `Outcome` | `success`, `rejected`, `error` — nadawany na zdarzeniu końcowym | `zeebe:property ph:outcome` |
| Incydent | `Incident` | Błąd techniczny zatrzymujący instancję | Incident |
| Przekazanie | `Reassignment` | Zmiana assignee lub grupy przez menadżera w trakcie procesu | assignment / update user task |
| Zastępstwo | `Absence` | Nieobecność od–do z zastępcą (osoba lub grupa) | korekta w task listenerze |
| Dziennik bezpieczeństwa | `SecurityJournal` | Niezmienny rejestr akcji (Ledger) | — |
| Ślad operacyjny | `OperationTrace` | Rekord diagnostyczny każdego żądania | — |
| Pakiet roboczy | work packet | Jednostka pracy agenta: krok planu + kontekst | — |
| Bramka | gate (G0–G3) | Decyzja człowieka odblokowująca kolejny etap planu | — |
| Profil projektu | `ProjectProfile` (`ProfileId`) | Projekt biznesowy korzystający z platformy (np. `kredyty`, `aml`): właściciel procesów, ról projektowych, danych i operacji | procesy profilu = definicje procesów z typami zadań `<id>.*` |
| Manifest profilu | `profile.yaml`, `authorization.yaml` | Kontrakt profilu z platformą; schemat `profiles/profile.schema.json` | — |
| Rola projektowa | `ProjectRole` | Rola w projekcie: złożenie ról platformy i uprawnień projektu w procesach profilu (np. `kredyty/underwriter`) | autoryzacje ról platformy na procesach profilu |
| Uprawnienie projektu | `ProfilePermission` | Uprawnienie w przestrzeni nazw profilu, np. `kredyty.Scoring.Recalculate` | — (L2) |
| Operacja dedykowana | `ITaskOperation`, `ICaseOperation`, `IProfileAction` | Akcja projektu na zadaniu, sprawie albo danych profilu (np. katalog), wykonywana przez potok platformy | zmiany zmiennych tylko przez szkic lub zakończenie zadania; operacja na danych profilu nie zmienia procesów |
| Operacja na danych profilu | `profile-action` (`IProfileAction`) | Zapis danych referencyjnych profilu w `prj_<id>` bez zadania i sprawy, np. katalog samochodów floty (ADR-017) | — |
| Komórka opiniująca | grupa kandydująca `flota-opinia-<komórka>` | Komórka banku (IT, HR, Prawny, Finanse, Ryzyko), która wydaje opinię w procesie profilu `flota` | instancja wielokrotnego user taska z `candidateGroups` ze zmiennej |
| Punkt rozszerzenia | extension point | Miejsce, w którym platforma oddaje sterowanie profilowi (operacja, wzbogacenie, źródło danych, zapytanie, zdarzenie, slot UI) | — |
| SDK rozszerzeń | `ProcessHub.Extensibility`, `@process-hub/extension-sdk` | Jedyna zależność kodu profilu; wersjonowane semantycznie | — |
| Slot UI | `SlotRegistration` | Miejsce w interfejsie na komponent profilu: panel zadania lub sprawy, widżet, pole formatki, sekcja nawigacji | — |
| Model integracji | `in-process` / `remote` | Moduł profilu w hoście platformy albo usługa zespołu wywoływana przez platformę | — |
| Schemat profilu | `prj_<id>` | Schemat i użytkownik bazy profilu; dane platformy tylko przez widoki `platform_api` | — |

## Plik: docs/architecture/00-overview.md

# 00. Przegląd architektury (v4)

Process Hub to własny TaskList nad Camunda 8.9. Camunda orkiestruje i rozstrzyga o stanie zadań; platforma rozstrzyga, kto co widzi i co może zrobić, nakłada warstwę etapów biznesowych, daje menadżerowi procesu dashboard, eskalacje i przekazywanie zadań oraz audytuje każdą akcję. Projekty biznesowe korzystają z platformy przez **profile projektów**: część wspólna działa tak samo dla każdego profilu, a część specyficzna (role projektowe, dane, operacje, rozszerzenia UI) należy do zespołu projektu i jest od platformy oddzielona (`13-project-profiles.md`).

## Zakres

- **W zakresie:** skrzynka zadań (moje, grupy), start procesów z aplikacji, „moje procesy”, panel menadżera procesu (dashboard, eskalacje, instancje, przekazywanie, zastępstwa), mapa etapów, formatki w formacie Camunda Forms (projektowanie, wersje, akceptacja, wycofanie, renderowanie komponentami design systemu — `14-form-management.md`), rola audytora, administracja uprawnieniami jako kod, pełny audyt, profile projektów z SDK rozszerzeń (operacje dedykowane, dane projektu, sloty UI).
- **Poza zakresem:** modelowanie BPMN (zespół deweloperski, poza aplikacją), Operate/Tasklist/Optimize jako narzędzia użytkowników, aplikacja mobilna natywna.

## Stos

| Warstwa | Wybór |
| --- | --- |
| Backend | .NET 10 (LTS), modularny monolit, jeden obraz w rolach `api`, `projector`, `jobs`, `worker` |
| Integracja z Camunda | oficjalne SDK Camunda, wyłącznie w module `CamundaIntegration` (ADR-003) |
| Baza | MS SQL Server 2022+ (RLS, tabele Ledger, partycjonowanie) |
| Frontend | Angular + Kendo UI, Nx, Signals; bpmn-js (viewer) tylko w edytorze mapy etapów; edytor form-js tylko w projektancie formatek (ADR-019) |
| Warstwa wizualna | design system: tokeny z Figma w `design/tokens.json`, komponenty w `core/ui-kit`, katalog pól formatek w `design/forms/` |
| SSO | RHBK, realm `camunda-platform`, federacja AD, BFF z ciasteczkiem (ADR-008) |
| Testy | xUnit, Reqnroll (Gherkin PL), Testcontainers, ArchUnitNET/NetArchTest, Playwright, Stryker.NET |
| Rozszerzenia | SDK `ProcessHub.Extensibility` i `@process-hub/extension-sdk`; profile w `profiles/<id>/` (ADR-012…014) |
| Wytwarzanie z AI | OpenCode z modelem wyłącznie w infrastrukturze banku, wymiennym przez profil modeli — dziś GLM 5.3 Flash (ADR-015, ADR-016, ADR-021); narzędzia repozytorium w Pythonie albo w .NET (`tools/dotnet/`) |

## Zmiany v2 względem v1

| Obszar | v1 | v2 | Dlaczego |
| --- | --- | --- | --- |
| Tenancy | tenant = linia biznesowa | **jeden tenant `<default>`**, architektura gotowa na wielu (ADR-002) | Wymóg; separacja wewnątrz tenanta przez autoryzacje zasobów |
| Separacja danych | tenant + RLS | **resource authorizations Camunda (L1) + polityka aplikacji (L2)**, autoryzacje jako kod (ADR-004) | Wymóg; jeden model uprawnień dla silnika i aplikacji |
| Klient Camunda | REST własny | **oficjalne SDK** za ACL (ADR-003) | Wymóg; wsparcie producenta przy zmianach wersji |
| Role | role stałe | **wiele ról naraz**, role jako dane, zakresy per proces (`02-roles-and-authorization.md`) | Użytkownik bywa wykonawcą, menadżerem i administratorem jednocześnie |
| Menadżer | menadżer zespołu | **menadżer procesu** (zakres: definicje procesów) + opcjonalnie zakres zespołu | Wymóg: dashboard, przekazywanie, formatki |
| Etapy | `zeebe:properties` w BPMN | **mapa etapów w aplikacji**, BPMN tylko jako zasiew (ADR-006) | Menadżer/administrator sam definiuje etapy bez technikaliów |
| Przekazywanie | opcjonalne | **wymagane**: osoba lub grupa, pojedynczo i masowo, plus zastępstwa (ADR-007) | Urlopy, nieobecności |
| Eskalacje, dashboard | brak | **nowe** (`08-process-dashboard.md`) | Wymóg |
| Audyt | Ledger | **Ledger + ślad operacyjny każdego żądania** (ADR-005) | Bezpieczeństwo i analiza problemów |
| BDD | SpecFlow | Reqnroll (ADR-009) | SpecFlow wycofany; Gherkin bez zmian |

## Zmiany v3 względem v2

| Obszar | v2 | v3 | Dlaczego |
| --- | --- | --- | --- |
| Projekty biznesowe | procesy w jednym katalogu ról | **profile projektów**: manifest, role projektowe, uprawnienia w przestrzeni nazw projektu (ADR-012) | Każdy projekt ma własne potrzeby co do danych i operacji |
| Część specyficzna | brak miejsca na kod projektu | **SDK rozszerzeń i punkty rozszerzeń**: operacje (na zadaniu, sprawie i danych profilu), wzbogacenia, źródła danych formatek, zapytania, zdarzenia, sloty UI z sekcją nawigacji profilu | Autonomia zespołów bez zmian w platformie |
| Separacja kodu | moduły platformy | **profiles/<id>/** z `CODEOWNERS`, testami architektury, schematem i użytkownikiem bazy per profil (ADR-013, ADR-014) | Zespół jednego projektu nie realizuje części innego |
| Reguły dostępu | R1–R8 | **R9** (zasoby tylko procesów profilu), **R10** (przestrzeń nazw profilu) | Separacja w czasie wykonania |
| Agenci AI | wielu dostawców | **OpenCode + model w banku (wymienny)**, agenci per profil (ADR-015, ADR-016, ADR-021) | Decyzja o narzędziach; dane nie opuszczają banku; separacja także w pracy agentów |

## Zmiany v4 względem v3

| Obszar | v3 | v4 | Dlaczego |
| --- | --- | --- | --- |
| Format formatek | własny schemat (JSON Schema, JSON Logic) | **Camunda Forms** (schemat form-js, FEEL), import i eksport `.form` (ADR-018) | Formatki zgodne z biblioteką Camunda 8.9, tworzone jak w Modelerze |
| Cykl życia | szkic, przegląd, publikacja | **pełne wersje, akceptacja, wycofanie** z wersją zastępczą i przepięciem zadań (`Form.Withdraw`) | Wymóg zarządzania wersjami i wycofywania |
| Separacja formatek | zakres roli | **formatka należy do jednego procesu — reguła R11** | Każdy proces ma formatki wyłącznie dla siebie |
| Projektant | własna kanwa | **osadzony edytor form-js**, paleta ograniczona katalogiem pól (ADR-019) | Te same możliwości co w Modelerze, bez własnego edytora |
| Wygląd formatek | kontrolki Kendo dobierane w kodzie | **materializacja z katalogu pól**: typ → komponent design systemu, tokeny z Figma | Biznes decyduje o polach i układzie, wygląd jest wspólny dla systemu |
| Walidacja na serwerze | JSON Logic | **reguły schematu + FEEL przez silnik** (ADR-020) | Camunda nie waliduje danych zadania względem formularza |
| Agenci AI | 12 ról | **+ `ux-designer`, `design-system-engineer`, `ui-reviewer`** | Warstwa wizualna ma własnych wykonawców i recenzenta |

## Mapa dokumentów

| Plik | Treść |
| --- | --- |
| `01-requirements.md` | wymagania FR/NFR z odsyłaczami do `specs/` |
| `02-roles-and-authorization.md` | role, uprawnienia, zakresy, autoryzacje L1/L2, macierz |
| `03-context-map.md` | konteksty DDD i ich relacje |
| `04-domain-model.md` | archetypy, agregaty, inwarianty, stany zadania |
| `05-solution-architecture.md` | kontenery, moduły, potok, SOLID, układ rozwiązania |
| `06-camunda-integration.md` | praktyki Camunda z uzasadnieniem |
| `07-process-stage-overlay.md` | mapa etapów: model, edycja, wersjonowanie, widoczność |
| `08-process-dashboard.md` | metryki, progi zdrowia, eskalacje |
| `09-persistence-mssql.md` | schematy, RLS, Ledger, partycje |
| `10-audit-and-security.md` | audyt każdej akcji, kontrole bezpieczeństwa |
| `11-frontend.md` | moduły UI, widoki, afordancje |
| `12-testing-strategy.md` | poziomy testów, tagi, drivery |
| `13-project-profiles.md` | profile projektów: kontrakt, role projektowe, punkty rozszerzeń, dane, UI, separacja, autonomia zespołów |
| `14-form-management.md` | moduł zarządzania formatkami: Camunda Forms, wersje, akceptacja, wycofanie, separacja per proces, renderowanie, warstwa wizualna |

Plan systemu, aktorzy, założenia i wytyczne UI w formie artefaktów projektowych: `docs/artifacts/`.

## Plik: docs/architecture/01-requirements.md

# 01. Wymagania

Każde FR ma scenariusze w `specs/`; identyfikator FR pojawia się w tagu scenariusza (`@FR-11`), dzięki czemu raport Reqnroll jest macierzą śledzenia.

## Funkcjonalne

| ID | Wymaganie | Rola | Specyfikacja |
| --- | --- | --- | --- |
| FR-01 | „Moje zadania”: zadania, w których jestem assignee | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-02 | „Do przejęcia”: nieprzypisane zadania moich grup kandydujących | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-03 | Stan zadań moich grup (także przypisanych innym), tylko odczyt | Uczestnik | `access/visibility.feature` |
| FR-04 | Przejęcie tylko przez członka grupy kandydującej; wyścig rozstrzyga silnik | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-05 | Zwolnienie tylko przez assignee | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-06 | Edycja szkicu i zakończenie tylko przez assignee, walidacja wg przypiętej wersji formatki | Uczestnik | `tasks/claim-and-complete.feature` |
| FR-07 | Start procesu z aplikacji z formatką startową, gdy mam uprawnienie startu dla definicji | Uczestnik | `processes/start-process.feature` |
| FR-08 | „Moje procesy”: wystartowane przeze mnie, z bieżącym etapem | Inicjator | `processes/start-process.feature` |
| FR-09 | Wiele ról jednocześnie; uprawnienia sumują się w zakresach; audyt zapisuje rolę uzasadniającą akcję | każda | `access/visibility.feature` |
| FR-10 | Menadżer procesu widzi wszystkie instancje i zadania procesów ze swojego zakresu | Menadżer procesu | `access/visibility.feature` |
| FR-11 | Przekazanie zadania osobie lub grupie w trakcie procesu, z obowiązkowym uzasadnieniem; pojedynczo i masowo | Menadżer procesu | `tasks/reassignment.feature` |
| FR-12 | Zastępstwa: nieobecność od–do z zastępcą; nowe zadania trafiają do zastępcy | Menadżer procesu, Uczestnik | `tasks/substitution.feature` |
| FR-13 | Lista procesów eskalowanych: poziom, od kiedy, etap, osoba | Menadżer procesu | `insight/escalations.feature` |
| FR-14 | Dashboard: wystartowane, zakończone sukcesem, negatywnie, błędem, aktywne, z incydentem; metryki; progi zdrowia | Menadżer procesu | `insight/process-dashboard.feature` |
| FR-15 | Mapa etapów: definiowanie etapów i przypisanie elementów BPMN, wersjonowanie per wersja definicji | Administrator procesu, Menadżer procesu | `insight/stage-map.feature` |
| FR-16 | Przy formatce i przy instancji widać mapę etapów z zaznaczonym etapem i stanem, bez technikaliów BPMN | Menadżer procesu | `insight/stage-map.feature` |
| FR-17 | Formatki tworzy i edytuje menadżer lub administrator procesu; zatwierdza inna osoba (R8); publikacja nadaje numer wersji | Menadżer, Administrator procesu | `forms/form-lifecycle.feature` |
| FR-18 | Zadanie renderuje wersję formatki przypiętą przy jego utworzeniu; przypięcie zmienia wyłącznie wycofanie wersji z przepięciem (FR-30) | Uczestnik | `forms/form-lifecycle.feature` |
| FR-19 | Audytor: wgląd tylko do odczytu we wszystkie procesy, zadania, historię i dziennik | Audytor | `access/visibility.feature` |
| FR-20 | Każda akcja zapisana w bazie: dziennik bezpieczeństwa i ślad diagnostyczny | system | `audit/audit.feature` |
| FR-21 | Uprawnienia jako kod: role, uprawnienia, przypisania do grup AD, uzgadnianie z Camunda | Administrator platformy | `access/authorization-as-code.feature` |
| FR-22 | Zapisane widoki list i preferencje UI | każda | — (v1, bez zmian) |
| FR-23 | Profil projektu: rejestracja z manifestu, procesy z jednym właścicielem, walidacja kontraktu | Administrator platformy, zespół profilu | `profiles/project-profiles.feature` |
| FR-24 | Role projektowe: złożenie ról platformy i uprawnień projektu, tylko w procesach profilu, rola uzasadniająca w audycie | Uczestnik, Menadżer procesu | `profiles/project-profiles.feature` |
| FR-25 | Operacje dedykowane profilu (na zadaniu, sprawie i danych profilu) w `allowedActions`, wykonywane przez potok platformy (uprawnienie, R1 dla zadań, R9, audyt, idempotencja) | Uczestnik, rola projektowa | `profiles/project-profiles.feature`, `profiles/flota/specs/katalog-samochodow.feature` |
| FR-26 | Dane projektu we własnym schemacie; wzbogacenie widoku zadania tylko w procesach profilu | Uczestnik | `profiles/project-profiles.feature` |
| FR-27 | Rozszerzenia UI profilu w slotach (panel zadania i sprawy, widżet, pole formatki, sekcja nawigacji, trasy `/p/<id>/`), widoczne tylko dla ról profilu | każda | `profiles/project-profiles.feature`, `profiles/flota/specs/katalog-samochodow.feature` |
| FR-28 | Formatki w formacie Camunda Forms: projektant z edytorem biblioteki form-js (jak w Modelerze), tylko elementy z katalogu pól, import i eksport plików `.form` | Menadżer, Administrator procesu | `forms/form-designer.feature` |
| FR-29 | Wersje formatki: historia zmian szkicu, numerowane wersje opublikowane, porównanie wersji, nowa wersja z dowolnej wcześniejszej | Menadżer, Administrator procesu | `forms/form-versioning.feature` |
| FR-30 | Wycofanie wersji albo całej formatki z obowiązkowym powodem, wersją zastępczą i wyborem skutku dla zadań w toku (pozostają albo są przepinane) | Menadżer, Administrator procesu | `forms/form-withdrawal.feature` |
| FR-31 | Separacja formatek: formatka należy do jednego procesu, jest widoczna i zarządzana tylko w jego zakresie, a zadanie renderuje wyłącznie formatkę własnego procesu (R11) | Menadżer, Administrator procesu, Uczestnik | `forms/form-isolation.feature` |
| FR-32 | Materializacja: formatkę renderują komponenty design systemu według katalogu pól; schemat nie niesie wyglądu; dane zadania są walidowane na serwerze według przypiętej wersji | Uczestnik | `forms/form-rendering.feature` |

Opis działania modułu formatek (FR-06, FR-07, FR-16–FR-18, FR-28–FR-32): `14-form-management.md`.

## Niefunkcjonalne

| ID | Wymaganie |
| --- | --- |
| NFR-01 | Deny by default; dwa poziomy autoryzacji (L1 Camunda, L2 aplikacja); OWASP ASVS L2 |
| NFR-02 | 100% żądań w śladzie operacyjnym, 100% komend i odczytów wrażliwych w dzienniku bezpieczeństwa; test kompletności audytu w CI |
| NFR-03 | Gotowość multi-tenant: `TenantId` w każdym agregacie, zapytaniu i wpisie audytu; włączenie kolejnego tenanta bez zmian w kodzie domeny |
| NFR-04 | Opóźnienie read modelu — cel do ustalenia w S04 (propozycja: P95 ≤ 5 s); dashboard pokazuje aktualną świeżość danych |
| NFR-05 | Listy i dashboard — cel do ustalenia (propozycja: P95 ≤ 500 ms przy danych z pilotażu) |
| NFR-06 | Niedostępność Camunda → tryb tylko do odczytu z read modelu, czytelny komunikat |
| NFR-07 | Awaria platformy nie zatrzymuje silnika: task listener zastępstw działa w trybie fail-open (ADR-007) |
| NFR-08 | WCAG 2.2 AA minimum; cele AAA wg `design/README.md` (kontrast tekstu, cele dotykowe, fokus) |
| NFR-09 | RODO: w audycie skróty i listy pól zamiast wartości PII; retencja wg compliance |
| NFR-10 | OpenTelemetry; `traceId` w każdym wpisie audytu i logu |
| NFR-11 | Separacja profili: kod profilu zależy tylko od SDK rozszerzeń; testy architektury, granice Nx, `CODEOWNERS` i strażnik zapisu w CI; schemat i użytkownik bazy per profil |
| NFR-12 | Zgodność SDK rozszerzeń: wersjonowanie semantyczne, zmiana niezgodna tylko w wersji głównej z okresem przejściowym ≥ 2 wersji pomocniczych; testy zgodności dla każdego profilu |
| NFR-13 | Awaria lub przekroczenie czasu operacji profilu nie blokuje pracy na zadaniu (propozycja limitu: 5 s dla operacji, 1 s dla wzbogacenia) |
| NFR-14 | Zgodność z Camunda Forms: każda opublikowana formatka jest poprawnym plikiem `.form` (oficjalny schemat formatu); zestaw zgodności porównuje w CI zachowanie renderera platformy z biblioteką form-js |
| NFR-15 | Spójność wizualna: komponenty UI używają wyłącznie tokenów z `design/tokens.json`; każdy typ z katalogu pól ma jeden komponent; regresja wizualna i axe-core dla katalogu komponentów w CI |

## Plik: docs/architecture/02-roles-and-authorization.md

# 02. Role, uprawnienia i autoryzacja

Uprawnienia są danymi, a nie kodem: rola to nazwany zbiór uprawnień, przypisany grupie AD w zakresie (tenant + definicje procesów). Ten sam plik deklaracji zasila autoryzacje zasobów w Camunda (poziom L1) i politykę aplikacji (L2), więc oba poziomy nie mogą się rozjechać.

## Model (archetyp Party + Knowledge Level)

```mermaid
classDiagram
    class Party {
      PartyId
      AdObjectGuid
    }
    class Permission {
      <<enumeration>>
      TaskClaim
      TaskReassign
      ProcessStart
    }
    class Role {
      RoleId
      Name
      ReadOnly
    }
    class RoleAssignment {
      Subject
      ValidFrom
      ValidTo
    }
    class Scope {
      TenantId
      Processes
      TeamId
    }
    Role "1" o-- "*" Permission
    RoleAssignment "*" --> "1" Role
    RoleAssignment "1" *-- "1" Scope
    Party "1" --> "*" RoleAssignment : przez grupy AD
```

- **Permission** — enum w kodzie (jedyne miejsce, gdzie uprawnienie „istnieje”). Test sprawdza, że YAML nie używa nieistniejących uprawnień.
- **Role** — dane w `config/authorization/roles.yaml`. Flaga `readOnly: true` (audytor) jest inwariantem: rola tylko do odczytu nie może zawierać uprawnień zapisu.
- **RoleAssignment** — grupa AD (z claimu `groups`) lub osoba → rola w zakresie, opcjonalnie z okresem ważności.
- **Uprawnienia efektywne** = suma przypisań, których zakres obejmuje zasób. Jedna osoba może być jednocześnie uczestnikiem procesu A, menadżerem procesu B i administratorem procesu C.

## Katalog uprawnień aplikacji (L2)

| Uprawnienie | Znaczenie |
| --- | --- |
| `Task.ViewOwn`, `Task.ViewGroup` | moje zadania; zadania moich grup kandydujących |
| `Task.Claim`, `Task.Complete` | przejęcie; zakończenie i szkic (dodatkowo reguła R1) |
| `Task.ViewAllInScope` | wszystkie zadania procesów w zakresie |
| `Task.Reassign`, `Task.ReassignBulk` | przekazanie zadania osobie lub grupie; masowo |
| `Absence.ManageOwn`, `Absence.ManageInScope` | własne zastępstwa; zastępstwa innych w zakresie |
| `Process.Start`, `Process.ViewOwn`, `Process.ViewAllInScope` | start; moje procesy; wszystkie instancje w zakresie |
| `Insight.Dashboard`, `Insight.Escalations` | dashboard i lista eskalacji |
| `StageMap.Edit` | nazwy, kolejność, opisy, progi SLA etapów |
| `StageMap.MapElements`, `Bpmn.ViewTechnical` | przypisanie elementów BPMN do etapów; techniczny podgląd BPMN |
| `Form.View` | lista formatek procesu, wersje, historia, porównanie, eksport |
| `Form.Edit`, `Form.Approve`, `Form.Publish` | tworzenie i edycja szkicu, import; zatwierdzenie (inna osoba niż autor); publikacja |
| `Form.Withdraw` | wycofanie wersji albo całej formatki, z powodem i skutkiem dla zadań w toku |
| `Audit.ViewJournal`, `Audit.ViewTrace` | dziennik bezpieczeństwa; ślad diagnostyczny |
| `Platform.Configure` | konfiguracja platformy, bez danych biznesowych |

## Role i ich odwzorowanie w Camunda

Zasób Camunda: `PROCESS_DEFINITION`, `resourceId` = `bpmnProcessId` lub `*`. Nazwy uprawnień Camunda do potwierdzenia w kroku S02 względem wersji 8.9.

| Rola | Zakres typowy | Uprawnienia aplikacji (L2) | Autoryzacje Camunda (L1) |
| --- | --- | --- | --- |
| Uczestnik | procesy, w których grupa uczestniczy | ViewOwn, ViewGroup, Claim, Complete, Process.Start*, Process.ViewOwn, Absence.ManageOwn | READ_PROCESS_DEFINITION, READ_USER_TASK, UPDATE_USER_TASK, CREATE_PROCESS_INSTANCE* |
| Menadżer procesu | wybrane definicje | ViewAllInScope, Reassign, ReassignBulk, Absence.ManageInScope, Process.ViewAllInScope, Insight.*, StageMap.Edit, Form.* | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK, UPDATE_USER_TASK |
| Administrator procesu | wybrane definicje | Process.ViewAllInScope, Insight.Dashboard, StageMap.Edit, StageMap.MapElements, Bpmn.ViewTechnical, Form.* | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE |
| Audytor | `*` | ViewAllInScope (tylko odczyt), Process.ViewAllInScope, Insight.*, Form.View, Audit.ViewJournal | READ_PROCESS_DEFINITION, READ_PROCESS_INSTANCE, READ_USER_TASK na `*` |
| Administrator platformy | tenant | Platform.Configure, Audit.ViewTrace | zarządzanie autoryzacjami tylko przez klienta reconcilera |

`*` — tylko gdy proces dopuszcza start z aplikacji przez tę grupę. `Form.*` = `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw`; uczestnik nie ma żadnego z nich — formatkę widzi wyłącznie na zadaniu.

**Dlaczego dwa poziomy.** Autoryzacja zasobów w Camunda jest gruba: `READ_USER_TASK` na definicji daje wszystkie zadania tej definicji. Reguły „tylko assignee edytuje”, „uczestnik widzi swoje i grupowe”, „menadżer nie edytuje treści” musi wymusić aplikacja (L2). L1 jest siatką bezpieczeństwa: nawet błąd w L2 nie pozwoli wyjść poza definicje w zakresie.

## Reguły na poziomie wiersza (L2)

1. **R1 Zapis = assignee.** `SaveDraft`, `Complete`, `Unclaim` wymagają `actor == assignee`; uprawnienie roli nie wystarcza.
2. **R2 Przejęcie.** Aktor należy do `candidateGroups` (lub `candidateUsers`), zadanie jest nieprzypisane.
3. **R3 Widoczność** = assignee ∨ grupa kandydująca ∨ inicjator ∨ `Task.ViewAllInScope` w zakresie definicji.
4. **R4 Ograniczenie projekcji.** XML BPMN, identyfikatory elementów, nazwy elementów niezmapowanych i zmienne spoza formatek tylko z `Bpmn.ViewTechnical`; pozostali widzą mapę etapów.
5. **R5 Odmowa jest zdarzeniem** audytu z wynikiem `Denied` i kodem reguły.
6. **R6 Przekazanie** wymaga `Task.Reassign`, kodu powodu (urlop, choroba, obciążenie, inne + opis), a osoba docelowa musi mieć rolę Uczestnika w zakresie definicji (inaczej nie mogłaby działać na zadaniu).
7. **R7 Rozdział obowiązków.** Audytor nie może mieć ról operacyjnych w tym samym zakresie — reconciler odrzuca taką konfigurację.
8. **R8 Cztery oczy.** Zatwierdzający formatkę ≠ autor ostatniej zmiany; zatwierdzenie dotyczy konkretnej treści i każda późniejsza zmiana je unieważnia.
9. **R9 Zasoby profilu.** Operacje, wzbogacenia, sloty i dane profilu dotyczą wyłącznie zadań i instancji procesów należących do tego profilu; uprawnienie projektowe działa tylko w procesach profilu. Operacja na danych profilu (`profile-action`, ADR-017) nie dotyczy żadnego procesu — działa wyłącznie na danych własnego profilu (`prj_<id>`), a jej trasy i wyniki widzą tylko role tego profilu.
10. **R10 Przestrzeń nazw profilu.** Profil definiuje uprawnienia, role, operacje i typy zadań wyłącznie z własnym prefiksem (`<id>.`), nie nadaje roli audytora ani administratora platformy; walidator manifestów i reconciler odrzucają naruszenia.
11. **R11 Formatka należy do procesu.** Formatka, jej wersje i przypięcia należą do dokładnie jednego procesu (`BpmnProcessId`) w tenancie. Uprawnienia `Form.*` działają wyłącznie w zakresie tego procesu; zadanie i start procesu renderują tylko formatkę własnego procesu; operacja łącząca formatki dwóch procesów (szkic z cudzej wersji, przypięcie albo wersja zastępcza spoza procesu) jest odrzucana (`14-form-management.md`).

## Ścieżka decyzji

```mermaid
flowchart LR
    A[Żądanie + Actor z sesji] --> B{Uprawnienie w roli<br/>dla zakresu zasobu?}
    B -- nie --> D[Denied + audyt]
    B -- tak --> C{Reguły wiersza R1–R11}
    C -- nie --> D
    C -- tak --> E[Allowed, GrantedBy = RoleAssignment]
    E --> F[Wywołanie Camunda przez SDK<br/>L1 sprawdza ponownie]
    F --> G[Audyt: Intent / Outcome]
```

`AccessDecision` zwraca `GrantedBy` — przypisanie roli, które uzasadnia akcję. Trafia ono do audytu jako „rola, w której działano”, co odpowiada na pytanie „dlaczego Marta mogła to zrobić”.

## Autoryzacje jako kod

- Źródło prawdy: `config/authorization/roles.yaml` (role platformy) i `assignments.yaml` (role globalne: Audytor, Administrator platformy) oraz `profiles/<id>/profile.yaml` i `profiles/<id>/authorization.yaml` (role projektowe, uprawnienia projektu, grupy AD i grupy kandydujące profilu).
- **Reconciler** (moduł `PlatformAdministration`, adapter w `CamundaIntegration`) liczy stan docelowy grup, ról, reguł mapowania i autoryzacji w Camunda, porównuje ze stanem faktycznym (wyszukiwanie przez SDK) i stosuje różnicę. W PR działa jako dry-run (raport różnic w komentarzu), po scaleniu — apply. Nocą w roli `jobs` wykrywa dryf i raportuje go w audycie.
- Aplikacja ładuje te same pliki dla L2, więc nie ma drugiej, ręcznie utrzymywanej tabeli ról.
- Zmiana uprawnień = PR z przeglądem; historia w Git + wpis w dzienniku bezpieczeństwa przy apply.

## Role projektowe (profile)

Rola projektowa (np. „Underwriter” w profilu `kredyty`) składa się z ról platformy i uprawnień projektu, w zakresie procesów profilu — szczegóły i przykłady: `13-project-profiles.md`, sekcja 4.

```mermaid
flowchart LR
  G["Grupa AD<br/>PH-KREDYT-UNDERWRITING"] --> RP["Rola projektowa<br/>kredyty/underwriter"]
  RP --> RPL["Role platformy<br/>Uczestnik"]
  RP --> UP["Uprawnienia projektu<br/>kredyty.Applicant.View<br/>kredyty.Limit.Override"]
  RP --> Z["Zakres<br/>procesy profilu: wniosek-kredytowy"]
  RPL --> L1["Autoryzacje Camunda (L1)<br/>na PROCESS_DEFINITION"]
  RPL --> L2["Uprawnienia aplikacji (L2)"]
  UP --> L2
```

- `AccessDecision.GrantedBy` dla roli projektowej ma postać `<profil>/<rola>`; audyt zapisuje też identyfikator profilu.
- Uprawnienia projektu są w katalogu L2 obok uprawnień platformy, ale `IAccessPolicy` zwraca je tylko dla zasobów procesów profilu (R9).
- Reconciler łączy deklaracje platformy i profili; konfiguracja naruszająca R7 albo R10 nie zostanie zastosowana.

## Tożsamość wywołań do Camunda (ADR-004, rozstrzyga S02)

| Wariant | Opis | Za | Przeciw |
| --- | --- | --- | --- |
| A. Delegowana | komendy użytkownika idą z jego tokenem (token exchange w RHBK) | L1 egzekwowane per osoba | wymaga, by SDK przyjmowało poświadczenia per wywołanie |
| B. Techniczna | klient techniczny per rola hosta, L2 egzekwowane w aplikacji z tych samych deklaracji | prostsze; standardowy tryb SDK | L1 chroni per klient, nie per osoba |

Rekomendacja: A dla komend użytkownika, jeśli PoC potwierdzi wsparcie SDK; B zawsze dla `projector` (tylko odczyt), `worker` (task listenery) i reconcilera — każdy z osobnym, minimalnym zestawem autoryzacji.

## Gotowość na wielu tenantów

- `TenantId` jest value object w Shared Kernel, obecny w każdym agregacie, zapytaniu, zdarzeniu i wpisie audytu.
- Dziś `ITenantContext` zwraca `<default>` (identyfikator tenanta Camunda przy wyłączonym multi-tenancy).
- RLS w MSSQL filtruje po `TenantId` już teraz (jedna wartość) — włączenie drugiego tenanta nie zmienia zapytań.
- Zakres `RoleAssignment` zawiera tenant; deklaracje w `assignments.yaml` mają klucz `tenant`.
- Włączenie multi-tenancy w Camunda wymaga decyzji przed pierwszym uruchomieniem środowiska docelowego (dokument DevOps v1, sekcja 7) — dlatego ADR-002 zapisuje, kiedy i jak to zrobić.

## Plik: docs/architecture/03-context-map.md

# 03. Mapa kontekstów (DDD)

Cztery konteksty są rdzeniem — tam powstaje przewaga nad natywnym Tasklistem: praca na zadaniach, cykl życia procesów z perspektywy użytkownika, wgląd menadżera (etapy, eskalacje, metryki) i formatki. Pozostałe są cienkie i wymienialne. Profile projektów to osobne konteksty poza platformą — każdy należy do zespołu projektu i rozmawia z platformą wyłącznie przez SDK rozszerzeń (Extension Host).

| Kontekst | Typ | Odpowiedzialność | Agregaty / modele |
| --- | --- | --- | --- |
| Task Work | core | przejęcie, zwolnienie, szkic, zakończenie, przekazanie (pojedyncze i masowe) | `WorkItem`, `ReassignmentBatch` |
| Process Lifecycle | core | start procesu z formatką startową, „moje procesy” | `ProcessStartRequest`; odczyt `MyProcessView` |
| Process Insight | core | mapa etapów, stan etapów instancji, eskalacje, dashboard, progi zdrowia | `StageMap`, `ProcessHealthPolicy`; odczyt `ProcessInstanceView`, `EscalationRecord`, `ProcessStats` |
| Form Management | core | formatki w formacie Camunda Forms: cykl życia wersji, cztery oczy (R8), publikacja z kontraktem danych zadania, wycofanie, separacja per proces (R11), import i eksport | `FormDefinition` (`FormVersion`, `FormReview`, `FormWithdrawal`) |
| Form Runtime | wspierający | wydanie schematu wersji przypiętej, walidacja danych na serwerze (reguły schematu, FEEL przez port `IExpressionEvaluator`) | bezstanowy |
| Party & Accountability | wspierający | osoby, grupy, przypisania ról, zastępstwa | `Party`, `RoleAssignment`, `Absence` |
| Access Policy | wspierający | uprawnienia efektywne (platformy i projektowe), reguły R1–R11, materializacja widoczności | `AccessDecision`, `TaskAccess` (odczyt) |
| Audit | wspierający | dziennik bezpieczeństwa (Ledger) i ślad operacyjny | `JournalEntry`, `OperationTrace` |
| Camunda Integration | generyczny (ACL) | oficjalne SDK: komendy, wyszukiwanie, przyjmowanie zdarzeń, workery task listenerów, katalog elementów BPMN (w tym referencje formatek i kontrakt danych), ewaluacja wyrażeń FEEL | bramy (porty) + adaptery SDK |
| Platform Administration | generyczny | autoryzacje jako kod: reconciler, raport dryfu | `AuthorizationPlan` |
| User Preferences, Notification | generyczne | widoki list, motyw; powiadomienia o przekazaniach, eskalacjach oraz przeglądach i wycofaniach formatek | `SavedListView` |
| Extension Host | wspierający | rejestr profili z manifestów, potok operacji profili, wzbogacenia, sloty UI, dystrybucja zdarzeń do profili (R9) | `ProfileRegistration`, `OperationDescriptor` |
| Profil projektu (np. kredyty, aml) | kontekst zespołu projektu, poza platformą | dane i operacje specyficzne dla projektu | definiuje zespół profilu |

```mermaid
flowchart TB
    RHBK[[RHBK / AD]]:::ext
    CAM[[Camunda 8.9]]:::ext

    subgraph CORE[Rdzeń]
      TW[Task Work]
      PL[Process Lifecycle]
      PI[Process Insight]
      FM[Form Management]
    end

    PA[Party & Accountability]
    AP[Access Policy]
    FR[Form Runtime]
    CI[Camunda Integration<br/>ACL + oficjalne SDK]
    ADM[Platform Administration]
    AU[(Audit)]
    EH[Extension Host<br/>SDK rozszerzeń]

    subgraph PROF[Profile projektów — poza platformą]
      PK[Profil kredyty]
      PAML[Profil aml]
    end

    RHBK -- Conformist: OIDC, claim groups --> PA
    CAM -- ACL --> CI
    CI -- Published Language: zdarzenia integracyjne --> TW
    CI -- zdarzenia + katalog elementów --> PI
    PA -- Customer/Supplier --> AP
    ADM -- deklaracje ról --> AP
    ADM -- plan autoryzacji --> CI
    AP -- Open Host: IAccessPolicy --> CORE
    FM -- Published Language: schemat formatki --> FR
    TW --> FR
    PL --> FR
    PI -- mapa etapów --> FM
    CORE -. zdarzenia audytu przez outbox .-> AU
    AP -. odmowy .-> AU
    ADM -. zmiany uprawnień .-> AU
    CORE -- operacje i zdarzenia --> EH
    AP -- decyzje R9 --> EH
    EH -- Open Host + Published Language: SDK --> PROF
    EH -. audyt operacji profili .-> AU
    ADM -- manifesty i role projektowe --> AP
    classDef ext stroke-dasharray: 5 5
```

## Relacje i dlaczego takie

- **Camunda → Camunda Integration: Anti-Corruption Layer.** Typy SDK i pojęcia silnika (`userTaskKey`, `elementId`, typy zdarzeń) kończą się na granicy modułu. Aktualizacja SDK lub Camunda dotyka jednego modułu i jego testów kontraktowych.
- **RHBK → Party: Conformist.** OIDC to język opublikowany; nie negocjujemy go.
- **Party → Access Policy: Customer/Supplier.** Polityka czyta przypisania i zastępstwa, nigdy ich nie zmienia.
- **Access Policy → rdzeń: Open Host Service.** Jeden kontrakt `IAccessPolicy` w `AccessPolicy.Contracts`.
- **Form Management → Form Runtime: Published Language.** Schemat formatki w formacie Camunda Forms (form-js) z profilem zgodności `ph-forms-8.9`; ten sam dokument czyta renderer w przeglądarce i walidator na serwerze (ADR-018).
- **Camunda Integration → Form Management i Form Runtime.** Katalog elementów dostarcza referencje `ph:form/<klucz>` i kontrakt `ph:inputs`/`ph:outputs`; port `IExpressionEvaluator` wykonuje wyrażenia FEEL formatek silnikiem (ADR-020). Formatki nie są wdrażane do silnika.
- **Process Insight → Form Management.** Edytor formatki pokazuje mapę etapów z zaznaczonym etapem zadania (FR-16) — odczyt przez kontrakt `IStageMapQueries`.
- **Wszystko → Audit: Published Language zdarzeń audytu**, dostarczanych przez outbox; ślad operacyjny zapisuje middleware hosta.
- **Extension Host → profile: Open Host Service + Published Language.** SDK rozszerzeń (`ProcessHub.Extensibility`, `@process-hub/extension-sdk`, kontrakt `profile-operations v1` dla profili remote) to jedyna powierzchnia, jaką widzi profil. Wersjonowanie semantyczne chroni zespoły przed zmianami wewnątrz platformy, a platformę przed zależnością od kodu profili.
- **Profile → platforma: brak zależności w drugą stronę.** Platforma nie zna kodu profili; rejestruje je z manifestów przy starcie. Profile nie znają się nawzajem (R9, R10, testy architektury).
- **Shared Kernel** minimalny: `TenantId`, `PartyId`, `BpmnProcessId`, `CorrelationId`, `Result<T>`; SDK rozszerzeń udostępnia profilom ich odpowiedniki jako typy publiczne.

## Plik: docs/architecture/04-domain-model.md

# 04. Archetypy i model domeny

Model opiera się na archetypie Party (kto), Knowledge Level (co wolno i jak wygląda proces z perspektywy biznesu) i Journal (co się stało). Dzięki temu nowe role, etapy czy progi to dane, a nie zmiany w kodzie.

## Zastosowane archetypy i wzorce

| Archetyp / wzorzec | Gdzie | Co daje |
| --- | --- | --- |
| Party, PartyRole (Arlow, Neustadt) | Party & Accountability | Osoba z identyfikatorem AD; role grane w zakresie (`RoleAssignment`) |
| Accountability + Effectivity (Fowler) | Party | `Absence` (zastępstwo od–do), przypisania z okresem ważności, zapytania „na dzień” |
| Knowledge Level | Access, Insight, Forms | `Role → Permission`, `StageMap` (wiedza o definicji procesu), `FormDefinition` (typ) ↔ szkic w `WorkItem` (instancja) |
| Rule | Insight, Forms | Progi zdrowia; reguły walidacji i widoczności pól jako dane w schemacie Camunda Forms (wyrażenia FEEL) |
| Journal | Audit | Wpisy tylko dopisywane; korekta = wpis kompensujący |
| Specification | Access Policy | Reguły R1–R11 jako składane specyfikacje, testowalne bez bazy |
| Process Manager / Saga | Task Work | `ReassignmentBatch` — masowe przekazanie z trwałym stanem i wznowieniem |
| State | Forms, StageMap | Mapa etapów: `Draft → InReview → Published → Deprecated`; wersja formatki: `Draft → InReview → Approved → Published → Superseded / Withdrawn` |

## Agregaty i inwarianty

**`WorkItem`** (Task Work) — lokalny obraz zadania Camunda + szkic.
- `Claim(actor)`: R2; `Unclaim(actor)`, `SaveDraft`, `Complete`: R1.
- `Reassign(actor, target, reason)`: `Task.Reassign` w zakresie, kod powodu obowiązkowy, `target` uprawniony (R6), `target ≠ assignee`. Szkic przechodzi z zadaniem (decyzja D-05), zdarzenie zapisuje poprzedniego i nowego wykonawcę.
- `ChangeCandidateGroups(actor, groups, reason)`: zbiór niepusty, każda grupa uprawniona w zakresie; jeśli zadanie było przypisane — najpierw zwolnienie.
- `FormVersion` przypięta przy utworzeniu; zmienia ją wyłącznie przepięcie przy wycofaniu wersji (`Form.Repin`), zawsze w obrębie formatek tego samego procesu (R11).

**`ReassignmentBatch`** (Task Work) — `Start(actor, selection, target, reason)`, pozycje ze stanem `Pending/Done/Failed/Skipped`, idempotencja `batchId + taskKey`, wznawianie po awarii. Każda pozycja to osobna komenda `Reassign` (te same inwarianty i audyt).

**`Absence`** (Party) — `from < to`; zastępca ≠ nieobecny; brak nakładających się nieobecności tej samej osoby w tym samym zakresie; zastępca uprawniony w zakresie procesów.

**`StageMap`** (Process Insight) — dla `BpmnProcessId`, wersjonowana per wersja definicji.
- Element BPMN należy do co najwyżej jednego etapu; elementy spoza mapy są „techniczne” i niewidoczne dla menadżera.
- Kolejność etapów unikalna; nazwa etapu niepusta.
- Mapować można tylko elementy istniejące w danej wersji definicji (z katalogu elementów).
- Wersja `Published` jest niezmienna; każda zmiana tworzy nową wersję.

**`FormDefinition`** (Form Management) — formatka jednego procesu: tożsamość `(TenantId, BpmnProcessId, FormKey)`, zastosowanie (`Task` albo `ProcessStart`), wersje w formacie Camunda Forms. Pełny model, stany i komendy: `14-form-management.md`.
- Najwyżej jedna wersja robocza (`Draft`, `InReview`, `Approved`) i jedna obowiązująca (`Published`).
- `Approve` przez osobę ≠ autor ostatniej zmiany (R8); zatwierdzenie dotyczy skrótu treści.
- `Publish` wymaga zatwierdzenia, zgodności z katalogiem pól i z kontraktem danych zadania; nadaje kolejny numer; wersje opublikowane są niezmienne.
- `Withdraw` wymaga powodu; wersja zastępcza musi być wcześniej opublikowana i zgodna z kontraktem; zadania w toku pozostają albo są przepinane.
- Żadna operacja nie łączy formatek dwóch procesów (R11).

**`ProcessHealthPolicy`** (Process Insight) — progi `green/amber/red` per metryka; progi monotoniczne (np. `amber ≤ red` dla metryk „im mniej, tym lepiej”).

**`RoleAssignment`, `Role`** (Party/Access, ładowane z YAML) — rola `readOnly` bez uprawnień zapisu; konflikty rozdziału obowiązków odrzucane.

## Cykl życia zadania (lokalny obraz)

```mermaid
stateDiagram-v2
    [*] --> Open: utworzone w Camunda
    Open --> Assigned: Claim (R2) / Reassign / korekta zastępstwa
    Assigned --> Open: Unclaim (R1) / ChangeCandidateGroups
    Assigned --> Assigned: Reassign (menadżer, R6) / SaveDraft (R1)
    Assigned --> CompletionRequested: Complete (R1 + walidacja formatki)
    CompletionRequested --> Completed: potwierdzenie z silnika
    CompletionRequested --> Assigned: odrzucenie przez silnik
    Open --> Canceled: instancja anulowana / ścieżka zamknięta
    Assigned --> Canceled
    Completed --> [*]
    Canceled --> [*]
```

## Model mapy etapów

```mermaid
classDiagram
    class StageMap {
      BpmnProcessId
      TenantId
    }
    class StageMapVersion {
      Version
      ForDefinitionVersions
      Status
    }
    class Stage {
      StageId
      Order
      Name
      SlaTarget
    }
    class ElementMapping {
      ElementId
      StageId
    }
    class ElementCatalogEntry {
      ElementId
      Name
      Type
      Properties
    }
    StageMap "1" *-- "*" StageMapVersion
    StageMapVersion "1" *-- "*" Stage
    StageMapVersion "1" *-- "*" ElementMapping
    ElementMapping "*" --> "1" ElementCatalogEntry : tylko elementy z wersji
```

## Przykład kodu — przekazanie w agregacie

```csharp
public Result Reassign(Actor actor, PartyId target, ReassignReason reason, IReassignTargetPolicy targets)
{
    if (Status is not (WorkItemStatus.Open or WorkItemStatus.Assigned)) return Result.Fail(Rule.TaskNotActive);
    if (!actor.Has(Permission.TaskReassign, Scope)) return Result.Fail(Rule.R6NoPermission);
    if (reason.IsEmpty) return Result.Fail(Rule.R6ReasonRequired);
    if (Assignee == target) return Result.Fail(Rule.SameAssignee);
    if (!targets.CanWorkOn(target, Scope)) return Result.Fail(Rule.R6TargetNotEligible);

    var previous = Assignee;
    Assignee = target;
    Status = WorkItemStatus.Assigned;
    Raise(new WorkItemReassigned(Id, Tenant, previous, target, actor.PartyId, reason, DraftTransferred: Draft is not null));
    return Result.Ok();
}
```

Agregat nie woła Camunda. Handler najpierw zapisuje audyt `Intent`, potem woła bramę (`assignment` z `allowOverride: true`), a stan i `Outcome` zatwierdza dopiero po sukcesie silnika.

## Plik: docs/architecture/05-solution-architecture.md

# 05. Architektura rozwiązania

Jeden obraz kontenera .NET uruchamiany w czterech rolach; przeglądarka zna tylko Host, a Camunda — tylko moduł `CamundaIntegration` korzystający z oficjalnego SDK.

## Kontenery

```mermaid
flowchart LR
    U[Przeglądarka] -->|HTTPS + cookie __Host-| SPA[SPA Angular / nginx]
    SPA -->|/api| API
    subgraph HOST[Host .NET 10 — jeden obraz]
      API[rola api<br/>BFF, komendy, zapytania]
      PRJ[rola projector<br/>zdarzenia → read model]
      JOBS[rola jobs<br/>outbox, uzgadnianie, statystyki, reconciler]
      WRK[rola worker<br/>task listenery: zastępstwa]
    end
    API -->|OIDC| RHBK[(RHBK)]
    API -->|oficjalne SDK: komendy| CAM[(Camunda 8.9)]
    PRJ -->|oficjalne SDK: wyszukiwanie / strumień| CAM
    WRK -->|oficjalne SDK: job worker| CAM
    JOBS -->|oficjalne SDK: autoryzacje| CAM
    API --> DB[(MS SQL Server)]
    PRJ --> DB
    JOBS --> DB
    WRK --> DB
    API -->|operacje profili remote: mTLS + token platformy| PSV[Usługi profili remote<br/>np. AML]
    PWK[Workery profili<br/>typy zadań id.*] -->|job worker| CAM
```

Moduły profili `in-process` działają wewnątrz hosta (Extension Host ładuje je z rejestru manifestów przy starcie roli `api` i `jobs`). Usługi profili `remote` i workery profili wdraża zespół profilu; platforma nie zależy od nich przy starcie.

| Rola | Klient Camunda (minimalne uprawnienia) | Skalowanie |
| --- | --- | --- |
| `api` | delegowany token użytkownika lub `ph-api` (ADR-004); `ph-api` ma dodatkowo ewaluację wyrażeń (ADR-020) | HPA po żądaniach |
| `projector` | `ph-projector`: tylko odczyt na `*` | 1 aktywna instancja na partycję strumienia (lease w MSSQL) |
| `jobs` | `ph-reconciler`: zarządzanie autoryzacjami; reszta bez Camunda | 1 aktywna instancja na zadanie cykliczne (lease) |
| `worker` | `ph-worker`: aktywacja jobów typu `ph.substitution` | ≥ 2 repliki (task listener blokuje tworzenie zadania) |

**Dlaczego osobna rola `worker`.** Task listener wstrzymuje przejście stanu zadania w silniku do czasu obsługi joba. Worker musi być dostępny i szybki niezależnie od obciążenia API, więc ma własne repliki i własny klient o najmniejszych możliwych uprawnieniach.

## Układ rozwiązania

```
ProcessHub.sln
├── src/
│   ├── ProcessHub.Host/                        composition root, role (api|projector|jobs|worker), middleware śladu
│   ├── BuildingBlocks/
│   │   ├── ProcessHub.SharedKernel/            TenantId, PartyId, Result<T>, Permission (enum)
│   │   ├── ProcessHub.Application/             ICommand, IQuery, potok (behaviors), Actor, ITenantContext
│   │   └── ProcessHub.Infrastructure/          outbox, inbox, lease, interceptor RLS, EF Core bazowe
│   └── Modules/
│       ├── TaskWork/{Domain,Application,Infrastructure,Api,Contracts}
│       ├── ProcessLifecycle/…
│       ├── ProcessInsight/…
│       ├── FormManagement/…
│       ├── FormRuntime/…
│       ├── PartyAccountability/…
│       ├── AccessPolicy/…
│       ├── Audit/…
│       ├── PlatformAdministration/…
│       ├── UserPreferences/…
│       ├── ExtensionHost/…                     rejestr profili, potok operacji, wzbogacenia, sloty, zdarzenia (R9)
│       └── CamundaIntegration/{Application,Infrastructure.Sdk,Contracts}   jedyny moduł z referencją do SDK
│   └── Platform/
│       ├── ProcessHub.Extensibility/           SDK rozszerzeń (paczka NuGet, semver) — jedyna zależność profili
│       └── ProcessHub.Extensibility.Testing/   host testowy w pamięci i testy zgodności dla zespołów profili
├── tests/
│   ├── <Moduł>.UnitTests
│   ├── <Moduł>.Specs                          Reqnroll: kroki + drivery (in-memory i integracyjny)
│   ├── CamundaIntegration.ContractTests        ten sam zestaw na fake i na Camunda w Testcontainers
│   └── ProcessHub.ArchitectureTests
├── frontend/                                   Nx workspace (apps/process-hub, libs/platform/…, libs/platform/extension-sdk)
├── bpmn/                                       procesy przykładowe + reguły bpmnlint
├── config/authorization/                       autoryzacje jako kod (role platformy, role globalne)
└── profiles/<id>/                              profile projektów: manifest, backend, frontend, db, bpmn, workers, specs (własność zespołów)
```

## Potok komend i zapytań

Kolejność jest kontraktem testowanym w testach architektury:

1. **Ślad operacyjny** (middleware HTTP, każde żądanie, także odrzucone przed potokiem).
2. Walidacja wejścia.
3. Autoryzacja: `IAccessPolicy` → `AccessDecision` (z `GrantedBy`).
4. Audyt bezpieczeństwa: `Intent` przed wykonaniem, `Outcome` po nim.
5. Idempotencja po `requestId` (nagłówek `Idempotency-Key`).
6. Transakcja: Unit of Work + outbox w jednej transakcji.
7. Handler.

Zapytania: ślad → autoryzacja i specyfikacja widoczności → audyt odczytu (`[AuditedRead]`) → handler na read modelu.

Dispatcher: generowany źródłowo (np. biblioteka `Mediator`) lub własny — bez komercyjnych wersji MediatR.

## Porty modułu `CamundaIntegration` (ISP)

| Port | Operacje |
| --- | --- |
| `IUserTaskCommands` | `AssignAsync(key, user, allowOverride)`, `UnassignAsync`, `UpdateCandidatesAsync`, `CompleteAsync(key, variables)` |
| `IProcessStarter` | `StartAsync(bpmnProcessId, variables, tenantId)` |
| `IProcessQueries` | wyszukiwanie instancji, zadań, instancji elementów, incydentów (dla projektora i uzgadniania) |
| `IDefinitionCatalog` | pobranie XML wersji definicji i zbudowanie katalogu elementów (nazwa, typ, zdarzenie, `zeebe:properties`) |
| `IAuthorizationAdmin` | wyszukiwanie i zmiana grup, ról, reguł mapowania, autoryzacji (tylko reconciler) |
| `ITaskListenerHost` | rejestracja workera typu `ph.substitution` z korektami assignee/grup |
| `IExpressionEvaluator` | ewaluacja i sprawdzenie składni wyrażeń FEEL formatek silnikiem Camunda (ADR-020) **[PoC, S08]** |

Każdy port ma implementację na SDK i fake in-memory; testy kontraktowe uruchamiają ten sam zestaw na obu (dowód podstawialności — LSP).

## SOLID w praktyce

- **S** — jeden handler na komendę; inwarianty w agregatach; modele odczytu oddzielone od zapisu.
- **O** — nowe uprawnienie to wpis enuma i YAML; nowy typ pola formatki to wpis w katalogu pól i implementacja `IFieldType` (walidacja) oraz komponent w `core/ui-kit` (wygląd); nowa metryka dashboardu to implementacja `IProcessMetric`.
- **L** — fake i adapter SDK przechodzą te same testy kontraktowe.
- **I** — wąskie porty zamiast jednego „CamundaClient”.
- **D** — domena i aplikacja zależą od portów własnego modułu; adaptery wiąże tylko Host.

## Testy architektury (CI)

- Tylko `CamundaIntegration.Infrastructure.Sdk` referuje paczkę SDK Camunda.
- Moduł nie referuje wnętrza innego modułu (tylko `*.Contracts`).
- `Domain` nie zna EF Core, HTTP ani SDK.
- Każdy endpoint ma politykę autoryzacji i przechodzi przez potok; każda komenda ma deskryptor audytu.
- Kod nie porównuje nazw ról (`"Manager"`, `"Admin"`) — tylko `Permission`.
- Każda komenda i każde zapytanie modułu `FormManagement` przyjmuje zakres procesu (`TenantId`, `BpmnProcessId`); typy z katalogu pól mają po jednej implementacji `IFieldType` (parytet z `design/forms/field-catalog.yaml`).
- Zestawy profili (`profiles/*/backend/**`) referują tylko `ProcessHub.Extensibility` i paczki z listy dozwolonej; nie referują `ProcessHub.Modules.*`, `BuildingBlocks` ani innych profili.
- Platforma nie referuje żadnego zestawu z `profiles/` (kompozycja tylko przez rejestr manifestów).
- Każda klasa oznaczona `[ProfileOperation]` ma odpowiednik w `operations` manifestu; nazwa przestrzeni nazw .NET zawiera identyfikator profilu.

## Plik: docs/architecture/06-camunda-integration.md

# 06. Integracja z Camunda 8.9 — praktyki i ich uzasadnienie

Zasada przewodnia: silnik rozstrzyga o stanie (kto ma zadanie, czy jest zakończone, gdzie jest token), aplikacja rozstrzyga o widoczności i prezentacji. Każda praktyka poniżej z tego wynika; kolumna „Dlaczego” jest materiałem do nauki zespołu.

Elementy oznaczone **[PoC]** potwierdzamy w krokach S01–S04 na wersji 8.9 i wybranym wydaniu oficjalnego SDK.

## Oficjalne SDK

- SDK żyje wyłącznie w `CamundaIntegration.Infrastructure.Sdk`, za portami z `05-solution-architecture.md`.
- Jeden długożyjący klient na rolę hosta (bezpieczny wątkowo, z buforowaniem tokenu OAuth), wersja SDK przypięta w `Directory.Packages.props`, aktualizacja tylko z zielonymi testami kontraktowymi.
- Lista kontrolna pokrycia **[PoC, S01]**: start instancji z `tenantId`; wyszukiwanie instancji, zadań, instancji elementów, incydentów; `assignment` z `allowOverride`; zwolnienie; aktualizacja `candidateGroups`; `completion` ze zmiennymi; pobranie XML definicji; zarządzanie autoryzacjami; job worker (dla task listenerów) z korektami; ewaluacja wyrażenia FEEL (**[PoC, S08]**); anulowanie przez `CancellationToken`. Brakująca operacja → klient wygenerowany z OpenAPI Camunda, ale nadal wewnątrz ACL (ADR-003).
- Ponowienia: korzystamy z mechanizmu SDK; własny Polly tylko tam, gdzie SDK go nie ma — podwójne ponawianie mnoży obciążenie silnika przy awarii.

## Praktyki

| # | Praktyka | Dlaczego |
| --- | --- | --- |
| C1 | Kroki ludzkie jako Camunda user task (`<zeebe:userTask/>`) | Tylko ten typ obsługuje API v2, task listenery i aktualizację kandydatów; wariant oparty o job worker jest wycofywany |
| C2 | Przejęcie: `assignment` z `allowOverride: false`; przekazanie przez menadżera: `allowOverride: true` | Wyścig dwóch osób rozstrzyga silnik; świadome nadpisanie jest możliwe tylko w komendzie, która wymaga uprawnienia i powodu |
| C3 | Zmiana grupy: aktualizacja `candidateGroups` zadania (zwolnienie assignee, jeśli był) — nie anulowanie i ponowne utworzenie | Zadanie zachowuje klucz, historię i szkic; anulowanie zmieniłoby przebieg procesu i zgubiło ślad |
| C4 | `candidateGroups` jako FEEL ze zmiennej routingu, np. `=routing.ocenaGroups`, ze stabilnymi identyfikatorami grup | Reorganizacja zespołów nie wymaga wdrożenia BPMN; nazwy wyświetlane z AD nigdy nie trafiają do modelu |
| C5 | Start wyłącznie przez BFF: dopisuje `initiatorPartyId`, `initiatorGroupIds`, `caseId` i jawny `tenantId` | Camunda 8 nie ma klucza biznesowego ani pojęcia „inicjatora z grupy”; `caseId` służy też do korelacji komunikatów |
| C6 | Formatka przez referencję zewnętrzną (`zeebe:formDefinition externalReference="ph:form/<klucz>"`), klucz rozwiązywany w procesie zadania, wersja przypinana przy utworzeniu zadania | Silnik orkiestruje, a cykl życia formatki należy do aplikacji; instancja w toku nie zobaczy zmienionej formatki; referencja bez identyfikatora procesu nie pozwala wskazać formatki innego procesu (R11) |
| C7 | Kontrakt danych zadania jako `ph:inputs`/`ph:outputs` w `zeebe:properties` | Język opublikowany między zespołem BPMN a autorami formatek; publikacja formatki jest walidowana względem kontraktu: każde wyjście ma pole Camunda Forms o tym kluczu i zgodnym typie |
| C8 | Output mapping na user tasku, minimalny payload przy zakończeniu | Zmienne trafiają do magazynu wtórnego i eksportu: rozmiar, retencja, PII; proces dostaje tylko to, czego oczekuje |
| C9 | Załączniki jako referencje (obsługa dokumentów Camunda lub własny magazyn), nie zmienne | Limity rozmiaru zmiennych i retencja |
| C10 | Zastępstwa przez task listener (`creating`, `assigning`) zwracający korektę assignee/grup **[PoC, S03]** | Korekta dzieje się w silniku, zanim zadanie stanie się widoczne — bez wyścigu z projektorem i bez „mignięcia” zadania u nieobecnej osoby |
| C11 | Worker task listenera w trybie fail-open z limitem czasu: brak odpowiedzi platformy → zakończ job bez korekty + audyt `SubstitutionSkipped` | Listener blokuje przejście stanu; awaria platformy nie może zatrzymać produkcji bankowej. Pominięte korekty nadrabia job uzgadniający |
| C12 | Eskalacja: nieprzerywający timer boundary na user tasku + `ph:escalationLevel`, `ph:escalationReason`; propagacja do rodzica przez escalation event | Zadanie zostaje u wykonawcy, a eskalacja biegnie równolegle; oznaczenie w modelu czyni eskalację wykrywalną bez zgadywania po nazwach |
| C13 | Nie modeluj eskalacji ani odmowy jako błędu (`error event`) | Błąd BPMN zmienia przepływ i służy wyjątkom biznesowym; nadużycie miesza statystyki „błędów” z normalną ścieżką |
| C14 | Wynik biznesowy na każdym zdarzeniu końcowym: `ph:outcome` = `success` / `rejected` / `error` | Zakończenie techniczne ≠ sukces biznesowy; „wniosek odrzucony” to poprawne zakończenie, nie błąd. Incydent to osobna kategoria — błąd techniczny |
| C15 | Opcjonalny zasiew etapów: `ph:stage` na elementach | Zespół BPMN może podpowiedzieć etapy; ostateczną mapę ustala administrator procesu w aplikacji (ADR-006) |
| C16 | Autoryzacje jako kod, minimalne uprawnienia per klient techniczny; użytkownicy bez dostępu do webapp Tasklist/Operate | Platforma zastępuje Tasklist; bez odcięcia reguły R1 dałoby się obejść w natywnym UI |
| C17 | Read model ze zdarzeń / wyszukiwania przyrostowego, upsert po kluczach Camunda, znacznik czasu z zakładką | Kolejność i duplikaty są normalne; idempotentny upsert po kluczu daje „dokładnie raz” na read modelu |
| C18 | Katalog elementów budowany z XML raz na wersję definicji; XML nie trafia do UI bez `Bpmn.ViewTechnical` | Mapa etapów i wykrywanie eskalacji potrzebują typów i właściwości elementów; menadżer nie ma widzieć technikaliów |
| C19 | Instancje kończą się na swojej wersji definicji; migracja instancji tylko świadomie, z przemapowaniem etapów | Mapa etapów i formatki są per wersja; migracja bez przemapowania pokazałaby menadżerowi błędny etap |
| C20 | Idempotentne komendy (`requestId`); odpowiedź „zadanie już zakończone” przy tym samym `requestId` w dzienniku = sukces | Sieć może zerwać połączenie po przetworzeniu komendy; bez tego ponowienie dałoby błąd lub podwójny skutek |
| C21 | Reguły bpmnlint w CI (niżej) i wdrożenia tylko z pipeline'u, z jawnym tenantem | Braki w modelu (brak `ph:outcome`, brak nazwy zadania) psułyby dashboard i mapę etapów dopiero w produkcji |
| C22 | Formatki w formacie Camunda Forms prowadzi aplikacja; nie wdrażamy ich do silnika (`formId`) i nie używamy formularzy osadzonych | Prawo wdrażania zasobów obejmuje też BPMN — za szerokie dla klienta platformy; identyfikator formularza w silniku jest globalny w tenancie; wycofanie z przepięciem wymaga przypięć w aplikacji (ADR-018) |
| C23 | Wyrażenia FEEL formatek na serwerze wykonuje silnik (endpoint ewaluacji wyrażeń 8.9) za portem `IExpressionEvaluator` **[PoC, S08]** | Camunda nie waliduje danych zadania względem formularza; jeden silnik FEEL dla procesu i formatki zamiast własnej implementacji w .NET (ADR-020) |

## Przykładowy fragment BPMN

```xml
<bpmn:userTask id="OcenaWniosku" name="Ocena wniosku">
  <bpmn:extensionElements>
    <zeebe:userTask />
    <zeebe:assignmentDefinition candidateGroups="=routing.ocenaGroups" />
    <zeebe:formDefinition externalReference="ph:form/ocena-wniosku" />
    <zeebe:taskListeners>                                    <!-- [PoC, S03] typy zdarzeń dla 8.9 -->
      <zeebe:taskListener eventType="creating" type="ph.substitution" retries="3" />
      <zeebe:taskListener eventType="assigning" type="ph.substitution" retries="3" />
    </zeebe:taskListeners>
    <zeebe:properties>
      <zeebe:property name="ph:stage" value="ocena" />
      <zeebe:property name="ph:inputs" value="kwota:number,klientId:string" />
      <zeebe:property name="ph:outputs" value="decyzja:string,uzasadnienie:string" />
    </zeebe:properties>
    <zeebe:ioMapping>
      <zeebe:output source="=decyzja" target="decyzja" />
      <zeebe:output source="=uzasadnienie" target="uzasadnienie" />
    </zeebe:ioMapping>
  </bpmn:extensionElements>
</bpmn:userTask>

<bpmn:boundaryEvent id="SlaOcenyPrzekroczone" name="SLA oceny przekroczone"
                    attachedToRef="OcenaWniosku" cancelActivity="false">
  <bpmn:extensionElements>
    <zeebe:properties>
      <zeebe:property name="ph:escalationLevel" value="1" />
      <zeebe:property name="ph:escalationReason" value="Przekroczony czas oceny" />
    </zeebe:properties>
  </bpmn:extensionElements>
  <bpmn:timerEventDefinition><bpmn:timeDuration>=sla.ocena</bpmn:timeDuration></bpmn:timerEventDefinition>
</bpmn:boundaryEvent>

<bpmn:endEvent id="WniosekOdrzucony" name="Wniosek odrzucony">
  <bpmn:extensionElements>
    <zeebe:properties><zeebe:property name="ph:outcome" value="rejected" /></zeebe:properties>
  </bpmn:extensionElements>
</bpmn:endEvent>
```

## Reguły bpmnlint (własna wtyczka `bpmnlint-plugin-ph`)

| Reguła | Sprawdza |
| --- | --- |
| `ph/user-task-is-camunda` | każdy user task ma `zeebe:userTask` |
| `ph/user-task-named` | każdy user task ma nazwę (potrzebna w mapie etapów) |
| `ph/candidate-groups-expression` | `candidateGroups` to wyrażenie FEEL lub identyfikator z listy dozwolonych |
| `ph/end-event-outcome` | każde zdarzenie końcowe ma `ph:outcome` z dozwolonego zbioru |
| `ph/escalation-tagged` | nieprzerywające timery na user taskach i zdarzenia eskalacji mają `ph:escalationLevel` |
| `ph/task-contract` | user task z formatką ma `ph:outputs` |
| `ph/form-reference` | user task wskazuje formatkę wyłącznie przez `externalReference` w postaci `ph:form/<klucz>`; `formId`, `formKey` i formularze osadzone są zabronione |
| `ph/substitution-listener` | user task ma listenery `ph.substitution` (gdy proces objęty zastępstwami) |
| `ph/job-type-prefix` | typy zadań service tasków procesu profilu zaczynają się od identyfikatora profilu-właściciela (`kredyty.…`) |

## Zasilanie read modelu (ADR-010, rozstrzyga S04)

| Wariant | Opis | Kiedy |
| --- | --- | --- |
| Wyszukiwanie przyrostowe przez SDK | projektor co kilka sekund pobiera zmienione instancje, zadania, instancje elementów, incydenty (znacznik + zakładka czasowa) | start, jeden tenant, umiarkowany wolumen |
| Eksporter → Kafka → projektor | zdarzenia rekordów silnika w strumieniu | gdy opóźnienie lub obciążenie API wyszukiwania przekroczy cel NFR-04 |

Projektor jest napisany za portem `IProcessQueries`/`IEventFeed`, więc zmiana wariantu nie dotyka kontekstów rdzenia.

## Plik: docs/architecture/07-process-stage-overlay.md

# 07. Mapa etapów — warstwa biznesowa nad BPMN

Menadżer procesu widzi etapy, nie BPMN: administrator procesu przypisuje elementy modelu do nazwanych etapów, a aplikacja liczy z historii instancji, na którym etapie jest sprawa. To odpowiedź na pytanie „jak dużo menadżer widzi” — tyle, ile opisuje mapa etapów, i nic poza nią.

## Poziomy wglądu

| Poziom | Kto | Co widzi | Czego nie widzi |
| --- | --- | --- | --- |
| Mapa etapów | menadżer procesu, inicjator („moje procesy”), audytor | nazwane etapy, bieżący etap, czasy, eskalacje, incydent jako „wstrzymane — zgłoszono do wsparcia” | XML, identyfikatory i nazwy elementów niezmapowanych, zmienne spoza formatek |
| Techniczny | administrator procesu (`Bpmn.ViewTechnical`) | diagram BPMN tylko do odczytu, pozycje tokenów, nakładka mapowania | — |

Rekomendacja: menadżer nie dostaje diagramu BPMN. Jeśli w organizacji menadżer ma sam mapować elementy, nadajemy mu `StageMap.MapElements` w `roles.yaml` — to decyzja konfiguracyjna, nie zmiana kodu (D-03 w `plan/execution-plan.md`).

## Przykład: technika kontra etapy

```mermaid
flowchart LR
    subgraph BPMN[Model techniczny — widzi administrator procesu]
      S((start)) --> A[Weryfikuj dane<br/>service task] --> B[Ocena wniosku<br/>user task] --> G{decyzja}
      G --> C[Wylicz ofertę<br/>service task] --> D[Akceptacja klienta<br/>user task] --> E((sukces))
      G --> R((odrzucony))
    end
    subgraph MAP[Mapa etapów — widzi menadżer]
      E1[1. Rejestracja] --> E2[2. Ocena] --> E3[3. Oferta] --> E4[4. Zakończenie]
    end
    A -.-> E1
    B -.-> E2
    C -.-> E3
    D -.-> E3
    E -.-> E4
    R -.-> E4
```

## Cykl edycji

1. **Nowa wersja definicji** (wdrożenie z pipeline'u) → `CamundaIntegration` buduje katalog elementów z XML (C18).
2. **Szkic mapy** powstaje automatycznie: przeniesienie z poprzedniej wersji po `elementId` albo zasiew z `ph:stage`. Raport różnic: elementy nowe (niezmapowane), usunięte, zmienione typy.
3. **Administrator procesu** mapuje elementy w edytorze: lista elementów pogrupowana po typie (user taski na górze) + diagram bpmn-js tylko do odczytu z podświetleniem zaznaczenia.
4. **Menadżer procesu** nadaje nazwy, kolejność, opisy i cele SLA etapów (`StageMap.Edit`).
5. **Walidacja:** każdy user task zmapowany (błąd); każde zdarzenie końcowe zmapowane (ostrzeżenie); co najmniej jeden etap; brak elementu w dwóch etapach.
6. **Publikacja** wersji mapy (audyt, wersja niezmienna). Dotyczy instancji danej wersji definicji — także już trwających, bo mapa jest prezentacją, a stan liczony jest z historii.

## Stan etapu instancji (algorytm)

Wejście: historia instancji elementów (`ElementVisit`: elementId, start, koniec, incydent), aktywne eskalacje, opublikowana mapa dla wersji definicji instancji.

| Stan etapu | Warunek |
| --- | --- |
| `Active` | co najmniej jeden element etapu jest aktywny |
| `Completed` | elementy etapu były odwiedzone, żaden nie jest aktywny |
| `Pending` | żaden element etapu nie był odwiedzony, instancja trwa |
| `Skipped` | instancja zakończona lub minęła etap, a etap nie był odwiedzony |
| flaga `Escalated` | aktywna eskalacja na elemencie etapu |
| flaga `Blocked` | incydent na aktywnym elemencie etapu |

Przypadki brzegowe:
- **Równoległość** (bramka równoległa): kilka etapów może być `Active` naraz — UI pokazuje wszystkie.
- **Pętle**: ponowne wejście zmienia `Completed` → `Active`; historia pokazuje wszystkie wejścia.
- **Call activity**: domyślnie etap rodzica obejmuje całe wywołanie; opcjonalnie rozwinięcie do mapy procesu podrzędnego (ten sam mechanizm, osobna mapa).
- **Aktywny element niezmapowany**: instancja pokazuje ostatni znany etap z adnotacją „w toku”; nazwa elementu nie jest ujawniana.

## Gdzie mapa jest używana

- **Instancja**: pasek etapów (Kendo Stepper) z czasami wejścia/wyjścia, eskalacją, blokadą.
- **Dashboard**: liczba aktywnych instancji na etapie i czas na etapie (P50/P90) — wąskie gardła.
- **Formatka**: edytor i podgląd formatki pokazują mapę z zaznaczonym etapem, do którego należy zadanie tej formatki, oraz liczbę zadań aktualnie czekających na tym kroku (FR-16).

## Przykład zapisu wersji mapy

```json
{
  "bpmnProcessId": "wniosek-kredytowy",
  "tenantId": "<default>",
  "version": 3,
  "forDefinitionVersions": [7],
  "status": "Published",
  "stages": [
    { "id": "rejestracja", "order": 1, "name": "Rejestracja", "slaTarget": "PT4H" },
    { "id": "ocena", "order": 2, "name": "Ocena", "slaTarget": "P2D" },
    { "id": "oferta", "order": 3, "name": "Oferta", "slaTarget": "P3D" },
    { "id": "zakonczenie", "order": 4, "name": "Zakończenie" }
  ],
  "mappings": [
    { "elementId": "WeryfikujDane", "stageId": "rejestracja" },
    { "elementId": "OcenaWniosku", "stageId": "ocena" },
    { "elementId": "WyliczOferte", "stageId": "oferta" },
    { "elementId": "AkceptacjaKlienta", "stageId": "oferta" },
    { "elementId": "WniosekZaakceptowany", "stageId": "zakonczenie" },
    { "elementId": "WniosekOdrzucony", "stageId": "zakonczenie" }
  ]
}
```

## Plik: docs/architecture/08-process-dashboard.md

# 08. Dashboard menadżera procesu i eskalacje

Dashboard odpowiada na pytanie „czy z moim procesem wszystko w porządku” w jednym spojrzeniu: liczniki wyników, metryki przepływu i sygnalizacja zdrowia wg progów, które menadżer ustawia sam.

## Filtry

Proces (`bpmnProcessId`) z zakresu użytkownika · wersja definicji (domyślnie wszystkie) · okres (domyślnie 30 dni) · etap. Każdy widok pokazuje świeżość danych („dane sprzed N s”) z opóźnienia projektora.

## Liczniki wyników

| Licznik | Definicja |
| --- | --- |
| Wystartowane | instancje z datą startu w okresie |
| Zakończone sukcesem | zakończone w okresie na zdarzeniu `ph:outcome=success` |
| Zakończone negatywnie | `ph:outcome=rejected` — poprawne zakończenie, decyzja odmowna |
| Zakończone błędem | `ph:outcome=error` lub anulowane (D-06: czy anulowanie liczyć jako błąd) |
| Aktywne | trwające na koniec okresu |
| Z incydentem | aktywne z nierozwiązanym incydentem (błąd techniczny) |
| Eskalowane | aktywne z aktywną eskalacją |

## Metryki

| Metryka | Definicja | Uwagi |
| --- | --- | --- |
| Czas realizacji P50/P90 | koniec − start, instancje zakończone w okresie | `APPROX_PERCENTILE_CONT` w SQL Server 2022 dla dużych zbiorów |
| Czas na etapie P50/P90 | suma odwiedzin elementów etapu | wymaga opublikowanej mapy etapów |
| Przepustowość | zakończone / dzień | trend tygodniowy |
| Praca w toku i wiek | liczba aktywnych; najstarsza; rozkład wieku | |
| Naruszenia SLA | % zadań/etapów po celu SLA | cele z mapy etapów lub `dueDate` |
| Wskaźnik eskalacji | instancje eskalowane / wystartowane | |
| Wskaźnik incydentów | instancje z incydentem / wystartowane | |
| Oczekiwanie vs praca | utworzenie → przejęcie vs przejęcie → zakończenie | rozróżnia brak ludzi od trudności zadania |
| Przekazania | przekazania / zadanie | sygnał przeciążenia lub nieobecności |

Nowa metryka = implementacja `IProcessMetric` (definicja, zapytanie, kierunek „lepiej, gdy mniej/więcej”) — bez zmian w dashboardzie (OCP).

## Progi zdrowia

`ProcessHealthPolicy` per proces: dla każdej metryki progi `zielony / bursztynowy / czerwony` i kierunek. Status procesu = najgorszy status metryk oznaczonych jako kluczowe. Zmiana progów to komenda audytowana. Bez ustawionych progów metryka jest pokazywana bez koloru — nie zgadujemy norm za biznes.

## Eskalacje

- Wykrywanie: aktywacja elementu z `ph:escalationLevel` albo zdarzenia eskalacji (z katalogu elementów, C12) tworzy `EscalationRecord` (instancja, element, poziom, powód, od kiedy, zakres).
- Eskalacja jest aktywna, dopóki trwa jej zakres: dla timera na user tasku — dopóki zadanie nie zostanie zakończone lub anulowane; dla podprocesu zdarzeń — do jego zakończenia.
- Naruszenie SLA liczone przez aplikację (bez modelowania w BPMN) to osobna kategoria „po terminie”, pokazywana obok.
- Lista „Eskalowane”: proces, sprawa (`caseId`), etap, poziom, od kiedy, osoba lub grupa, akcja „Przekaż”.

## Źródło danych

- `insight.ProcessInstanceView`, `insight.ElementVisit`, `insight.EscalationRecord` z projektora.
- `insight.ProcessStatsDaily` — agregaty przyrostowe (rola `jobs`), z których dashboard czyta liczniki; percentyle liczone na żądanie dla okresu z indeksem kolumnowym na `ElementVisit`.
- Camunda Optimize mógłby dostarczyć analitykę, ale nie zna mapy etapów ani naszego modelu uprawnień — dlatego metryki liczymy sami; Optimize można rozważyć później dla analityków procesowych.

## Plik: docs/architecture/09-persistence-mssql.md

# 09. Persystencja — MS SQL Server 2022+

Jedna baza, schemat i `DbContext` per moduł. Izolację tenantów wymusza baza (RLS), niezmienność dziennika — tabela Ledger, a retencję śladu operacyjnego — partycje; żadna z tych gwarancji nie zależy od dyscypliny w kodzie.

| Schemat | Moduł | Tabele kluczowe |
| --- | --- | --- |
| `party` | Party & Accountability | `Party`, `GroupMembershipSnapshot`, `Absence` (temporal) |
| `access` | Access Policy | `TaskAccess` (materializacja widoczności), `EffectivePermissionCache` |
| `task` | Task Work | `WorkItem` (z przypięciem wersji formatki), `ReassignmentBatch`, `ReassignmentBatchItem`, `TaskView`, `FormPinHistory` |
| `process` | Process Lifecycle | `ProcessStartRequest`, `MyProcessView` |
| `insight` | Process Insight | `ElementCatalog`, `StageMap*` (temporal), `ProcessInstanceView`, `ElementVisit`, `EscalationRecord`, `ProcessStatsDaily`, `ProcessHealthPolicy` |
| `form` | Form Management | `FormDefinition`, `FormVersion` (temporal — rewizje szkicu; schemat Camunda Forms jako JSON), `FormReview`, `FormWithdrawal`, `FormRepinBatch`, `FormRepinItem` |
| `audit` | Audit | `SecurityJournal` (Ledger append-only), `OperationTrace` (partycjonowana) |
| `integration` | Camunda Integration | `Inbox`, `ProcessedRequest`, `FeedWatermark`, `Lease` |
| `admin` | Platform Administration | `AuthorizationApplyLog`, `DriftReport` |
| `prefs` | User Preferences | `SavedListView`, `UiSettings` |
| `ext` | Extension Host | `ProfileRegistration`, `ProfileProcess` (który proces należy do którego profilu), `OperationRequest` (idempotencja operacji profili) |
| `platform_api` | widoki dla profili | `Tasks`, `ProcessInstances`, `StageStates` — tylko odczyt, RLS do procesów profilu |
| `prj_<id>` | profil projektu | tabele zespołu profilu (np. `prj_kredyty.ScoringResult`); użytkownik bazy `prj_<id>` bez loginu |

## Rozwiązania i powody

- **RLS po tenancie.** Funkcja `security.fn_TenantPredicate(@TenantId)` porównuje wiersz z `SESSION_CONTEXT(N'TenantIds')`. Interceptor EF Core (`DbConnectionInterceptor`) ustawia wartość przy otwarciu połączenia przez `sp_set_session_context ... @read_only = 1`. Predykaty `FILTER` oraz `BLOCK AFTER INSERT/UPDATE`. Dziś jedna wartość `<default>` — dodanie tenanta nie zmienia zapytań (NFR-03).
- **Widoczność wewnątrz tenanta** nie jest robiona przez RLS, tylko przez `access.TaskAccess(TenantId, TaskKey, PrincipalKind, PrincipalId, AccessLevel)`: zapytanie łączy zadania z moimi principalami (osoba, grupy, zakresy ról). RLS pilnuje twardej granicy, `TaskAccess` — reguł biznesowych.
- **Dziennik bezpieczeństwa:** `audit.SecurityJournal` jako `LEDGER = ON (APPEND_ONLY = ON)`; cykliczny digest (`sys.sp_generate_database_ledger_digest`) do magazynu WORM; weryfikacja `sys.sp_verify_database_ledger`.
- **Ślad operacyjny:** `audit.OperationTrace` partycjonowana miesięcznie po `OccurredAt`, klastrowany indeks kolumnowy (analiza problemów, duże wolumeny). Retencja przez `TRUNCATE TABLE … WITH (PARTITIONS (…))` — bez kosztownego `DELETE`.
- **Tabele temporalne** (`SYSTEM_VERSIONING`) dla `Absence`, `StageMap*`, `FormVersion`: zapytania `FOR SYSTEM_TIME AS OF` („jaka mapa obowiązywała w chwili decyzji”).
- **Formatki per proces (R11).** Każda tabela schematu `form` ma `TenantId` i `BpmnProcessId`; unikalność `(TenantId, BpmnProcessId, FormKey)`; indeksy filtrowane pilnują jednej wersji roboczej i jednej obowiązującej na formatkę; klucz obcy przypięcia w `task.WorkItem` obejmuje `BpmnProcessId`, więc zadanie nie wskaże wersji formatki innego procesu — to świadomy wyjątek od zasady, że schematy modułów nie mają kluczy obcych między sobą: separację formatek ma gwarantować baza, a nie dyscyplina w kodzie. Kolumna schematu ma ograniczenie `ISJSON` i limit rozmiaru.
- **Współbieżność optymistyczna:** `rowversion` na agregatach.
- **Outbox per moduł** w transakcji zmiany stanu; dispatcher z `UPDLOCK, READPAST, ROWLOCK` (wiele instancji bez podwójnej wysyłki).
- **Inbox, `ProcessedRequest`, `FeedWatermark`:** deduplikacja zdarzeń, idempotencja komend, wznowienie projektora.
- **Lease:** tabela dzierżaw dla zadań singletonowych (`projector`, zadania `jobs`) — bez zewnętrznego koordynatora.
- **Uprawnienia bazy:** login aplikacji w `audit` ma tylko `INSERT`/`SELECT`; nie może zmieniać polityk bezpieczeństwa; migracje wykonuje osobna tożsamość pipeline'u.
- **Izolacja profili (ADR-014).** Każdy profil ma schemat `prj_<id>` i użytkownika bazy bez loginu z prawami tylko do tego schematu i `SELECT` na widokach `platform_api`. Extension Host wykonuje operację profilu w transakcji platformy pod `EXECUTE AS USER = 'prj_<id>'` i wraca `REVERT` przed zapisem audytu; widoki `platform_api` filtruje predykat RLS po `SESSION_CONTEXT(N'ProfileId')` i tabeli `ext.ProfileProcess`. Migracje profilu wykonuje osobna tożsamość z DDL tylko w `prj_<id>` [DO WERYFIKACJI w S27: zgodność z pulą połączeń EF Core].
- **Dostęp:** EF Core po stronie zapisu; listy i dashboard przez Dapper/SQL na widokach z indeksami pod `TaskAccess (PrincipalId, TenantId, Status)` i `ElementVisit (BpmnProcessId, StageId, StartedAt)`.

## Plik: docs/architecture/10-audit-and-security.md

# 10. Audyt każdej akcji i bezpieczeństwo

Każde żądanie zostawia dwa ślady w bazie: rekord diagnostyczny w `OperationTrace` (dla analizy problemów) i — dla akcji istotnych dla bezpieczeństwa — niezmienny wpis w `SecurityJournal`. Oba są wymuszone przez infrastrukturę hosta i sprawdzane testem kompletności w CI.

## Co jest audytowane

| Kategoria | `OperationTrace` | `SecurityJournal` |
| --- | --- | --- |
| Każde żądanie HTTP do BFF (także 401/403/4xx/5xx) | tak | — |
| Komendy (przejęcie, zakończenie, przekazanie, start, zastępstwa, formatki, mapa etapów, progi) | tak | tak: `Intent` + `Outcome` |
| Odczyty wrażliwe (szczegóły zadania, instancja, dashboard, eksport, dziennik audytu) | tak | tak |
| Odmowy autoryzacji | tak | tak, `Denied` + kod reguły |
| Logowanie, wylogowanie, odnowienie sesji | tak | tak |
| Zmiany uprawnień (apply reconcilera), wykryty dryf | tak | tak |
| Korekty zastępstw w task listenerze, pominięte korekty | tak | tak |
| Błędy frontendu (endpoint raportowania) | tak | — |

## Pola

| Pole | `OperationTrace` | `SecurityJournal` |
| --- | --- | --- |
| `OccurredAt` (UTC serwera), `TenantId`, `TraceId`, `CorrelationId` | ✓ | ✓ |
| `Actor` (PartyId + identyfikator AD), `OnBehalfOf` | ✓ | ✓ |
| `GrantedBy` (przypisanie roli uzasadniające akcję; dla roli projektowej `<profil>/<rola>`) | — | ✓ |
| `ProfileId` (profil projektu, gdy akcja to operacja, wzbogacenie lub zapytanie profilu) | ✓ | ✓ |
| `Action`, `Resource` (typ, id), `ProcessInstanceKey`, `UserTaskKey`, `BpmnProcessId` | ✓ | ✓ |
| `Outcome` (`Succeeded`/`Denied`/`Failed`/`Reconciled`), kod reguły | ✓ | ✓ |
| `Phase` (`Intent`/`Outcome`) | — | ✓ |
| `PayloadDigest` (SHA-256), lista zmienionych pól — bez wartości PII | — | ✓ |
| Endpoint, metoda, status HTTP, czas trwania, rozmiar odpowiedzi | ✓ | — |
| Błąd: typ wyjątku, komunikat po sanityzacji, kod problemu Camunda (problem detail), liczba ponowień | ✓ | — |
| Adres IP (skrócony wg polityki), User-Agent | ✓ | ✓ |

## Mechanika

- **Middleware śladu** w hoście opakowuje całe żądanie (także to odrzucone przed potokiem) i zapisuje rekord asynchronicznie przez kanał w pamięci z zapisem wsadowym; przy przepełnieniu zapis przechodzi w tryb synchroniczny, nie gubi rekordów.
- **Audyt dwufazowy** dla wywołań Camunda: `Intent` w osobnej, krótkiej transakcji przed wywołaniem SDK; po odpowiedzi stan + `Outcome` + outbox w jednej transakcji. Job uzgadniający rozstrzyga intencje bez wyniku na podstawie read modelu (`Reconciled`).
- **Test kompletności audytu** (CI): enumeruje wszystkie endpointy z `ApiExplorer`, wywołuje je w środowisku testowym jako użytkownik z uprawnieniem i bez, i sprawdza, że każdy zostawił `OperationTrace`, a komendy i odczyty wrażliwe — `SecurityJournal`.
- Dostęp: `Audit.ViewJournal` (audytor, bezpieczeństwo), `Audit.ViewTrace` (administrator platformy, wsparcie). Przeglądanie audytu jest audytowane.

## Kontrole bezpieczeństwa

- OWASP ASVS L2 jako baza wymagań; SAST/DAST i skan zależności w CI.
- BFF z ciasteczkiem `__Host-`, `HttpOnly`, `Secure`, `SameSite=Strict`, ochrona CSRF nagłówkiem; tokeny tylko po stronie serwera (ADR-008).
- CSP bez `unsafe-inline` dla skryptów; nagłówki HSTS, `X-Content-Type-Options`, `frame-ancestors 'none'`.
- Rate limiting per użytkownik i per endpoint w BFF; limity rozmiaru żądań (formatki).
- **Profile projektów.** Operacje profili przechodzą przez potok platformy (autoryzacja, R1, R9, audyt Intent/Outcome, idempotencja) — profil nie ma własnej ścieżki do zapisu zmiennych ani do Camunda. Limity czasu operacji i wzbogaceń (NFR-13); awaria profilu nie blokuje pracy na zadaniu. Profile `remote` wywoływane przez mTLS z krótkotrwałym tokenem platformy zawierającym aktora, zadanie, operację i `requestId`; odpowiedź walidowana schematem kontraktu `profile-operations v1`.
- Klienci techniczni Camunda z minimalnymi uprawnieniami per rola hosta; sekrety z magazynu sekretów (External Secrets), rotacja.
- Formatki: biała lista typów i własności z katalogu pól (`design/forms/field-catalog.yaml`) egzekwowana przy imporcie, zapisie i publikacji; typy `html`, `iframe` i `button` zablokowane; tekst Markdown po sanityzacji, bez surowego HTML i zasobów zewnętrznych; wyrażenia FEEL interpretowane, z limitem długości.
- Akcje formatek w dzienniku: `Form.Create`, `Form.Save`, `Form.Import`, `Form.Export`, `Form.SubmitForReview`, `Form.Recall`, `Form.Reject`, `Form.Approve`, `Form.Publish`, `Form.NewVersion`, `Form.Discard`, `Form.Withdraw`, `Form.Retire`, `Form.Repin` — każda z `BpmnProcessId`, kluczem formatki, numerem wersji i skrótem treści; odmowy z kodem R8 albo R11.
- Rozdział obowiązków (R7), cztery oczy przy formatkach (R8) i separacja formatek per proces (R11).
- Network Policy: tylko pody Host łączą się z Camunda; użytkownicy nie mają dostępu do webapp Tasklist/Operate.

## Plik: docs/architecture/11-frontend.md

# 11. Frontend (Angular)

UI nie liczy uprawnień: każdy zasób z API przychodzi z listą `allowedActions` (np. `["claim"]`, `["reassign","viewTechnical"]`), a akcje renderują się wyłącznie z niej. Reguły żyją w jednym miejscu — w backendzie. Motywy, WCAG, Signals i Kendo — jak w dokumencie wejściowym v1 o architekturze UI. Wzorzec wizualny i zachowania ekranów: `design/README.md` i klikalna makieta `design/mockups/index.html`; tokeny: `design/tokens.json`; formatki: `design/forms/README.md`. Wytyczne dla osób zaczynających pracę nad interfejsem: `docs/artifacts/04-wytyczne-ui.md`.

## Biblioteki (Nx)

| Biblioteka | Widoki |
| --- | --- |
| `task-workspace` | Moje zadania, Do przejęcia, Zadania grupy (odczyt), szczegóły zadania z formatką |
| `process-lifecycle` | Start procesu (katalog procesów, które mogę startować + formatka startowa), Moje procesy z paskiem etapów |
| `process-insight` | Dashboard, Eskalowane, Instancje procesu, szczegóły instancji (mapa etapów, historia, zadania) |
| `reassignment` | dialog przekazania (osoba/grupa, powód), przekazanie masowe z podglądem i raportem, zastępstwa |
| `stage-map-editor` | edytor mapy etapów: lista elementów + bpmn-js (viewer tylko do odczytu) dla `Bpmn.ViewTechnical`, edycja etapów |
| `form-designer` | lista formatek procesu, osadzony edytor form-js (paleta z katalogu pól), przegląd z porównaniem wersji, publikacja, wycofanie, import i eksport, podgląd jak u wykonawcy |
| `form-runtime` | renderer schematu Camunda Forms: interpretacja (dane, układ, FEEL, walidacja) i rejestr typ pola → komponent `core/ui-kit` |
| `audit-viewer` | dziennik bezpieczeństwa i ślad (wg uprawnień) |
| `core/*` | `ui-kit` (opakowania Kendo, w tym komponenty pól formatek), `auth`, `access` (sygnał `AccessContext`), `i18n`, `theming` (tokeny → zmienne CSS i motyw Kendo) |
| `apps/ui-catalog` | katalog komponentów `ui-kit` we wszystkich stanach — podstawa regresji wizualnej i przeglądu z projektantem UX |
| `platform/extension-sdk` | SDK rozszerzeń UI: typy `ProfileUiModule` i `SlotRegistration`, rejestr slotów, kontekst zadania i sprawy dla komponentów profili |
| `profiles/<id>/frontend` | biblioteka zespołu profilu (`profile-<id>-ui`): komponenty slotów i trasy `/p/<id>/` |

## Rozszerzenia profili (sloty)

- Powłoka renderuje sloty `task.panel`, `case.panel`, `dashboard.widget`, `form.field` i `nav.section`; komponent profilu pojawia się tylko, gdy proces należy do profilu i aktor ma uprawnienie slotu (decyzja przychodzi z API razem z `allowedActions`).
- Przyciski operacji dedykowanych renderuje powłoka z `allowedActions` (np. `kredyty.RecalculateScoring`) — profil dostarcza tylko etykietę i ewentualny formularz parametrów. Na stronach profilu (`/p/<id>/…`) `allowedActions` przychodzą z wynikiem zapytania profilu i obejmują operacje na danych profilu (`profile-action`, ADR-017), np. „Dodaj model” w katalogu floty.
- Sekcja nawigacji profilu (`nav.section`) to osobna grupa w szufladzie nawigacji, pod sekcjami platformy, z trasami `/p/<id>/`; widzą ją wyłącznie osoby z uprawnieniem trasy. Przykład: sekcja „Flota” → „Katalog samochodów” (`design/mockups/index.html`, persony Tomasz, Hanna, Karol).
- Granice Nx: biblioteki profili mają tag `scope:profile-<id>` i mogą zależeć wyłącznie od `scope:extension-sdk`; platforma nie importuje bibliotek profili (rejestracja przez manifest i `loadChildren`).
- Ładowanie domyślnie leniwe w obrazie aplikacji; Native Federation dla profilu z niezależnymi wydaniami frontendu [DO WERYFIKACJI w S47].
- Teksty profilu we własnych plikach i18n (`profiles/<id>/frontend/i18n/pl.json`); tokeny wizualne wyłącznie z `design/tokens.json`, żeby rozszerzenia wyglądały jak platforma.

## Formatki i design system

- **Podział ról.** Schemat formatki (Camunda Forms) niesie strukturę; `form-runtime` ją interpretuje; wygląd daje wyłącznie `core/ui-kit` na tokenach z `design/tokens.json`. Renderer nie zawiera kolorów, rozmiarów ani odstępów (ADR-019).
- **Rejestr materializacji.** Dla każdego typu z `design/forms/field-catalog.yaml` o statusie „wspierany” istnieje dokładnie jeden komponent pola; test parytetu porównuje katalog, rejestr frontendu i `IFieldType` w backendzie.
- **Edytor form-js** żyje wyłącznie w `form-designer` (granica Nx); renderuje w Preact wewnątrz komponentu-opakowania, bez wycieku stylów biblioteki do aplikacji. Znak bpmn.io pozostaje widoczny.
- **Wyrażenia.** FEEL i szablony wykonuje `form-runtime` bibliotekami `@bpmn-io/feelin` i `feelers`; o poprawności danych rozstrzyga serwer.
- **Układ.** Siatka 16 kolumn schematu jest odwzorowana w siatce CSS design systemu; poniżej progu szerokości pola układają się w jednej kolumnie.
- **Pola profili.** Slot `form.field` to wariant typu bazowego wskazany własnością `ph:field`; renderer podstawia komponent profilu tylko w formatkach procesów profilu.
- **Zestaw zgodności i regresja wizualna** są częścią `nx affected -t test` dla `form-runtime` i `ui-kit` (NFR-14, NFR-15).

## Ustalenia

- Wykresy dashboardu: Kendo Chart; liczniki i progi jako karty z kolorem statusu i etykietą tekstową (kolor nigdy nie jest jedynym nośnikiem informacji — WCAG 1.4.1).
- Mapa etapów: Kendo Stepper z czasami i flagami; w dashboardzie wykres słupkowy „aktywne na etapie”.
- bpmn-js wyłącznie w `stage-map-editor` i tylko dla uprawnienia `Bpmn.ViewTechnical`; edytor form-js wyłącznie w `form-designer`; licencja bpmn.io wymaga pozostawienia widocznego znaku wodnego w obu.
- Aktualizacje push przez SignalR (nowe zadanie, przekazanie, eskalacja); RxJS na brzegu, `toSignal` w komponentach.
- Konflikt przy przejęciu (`409` z silnika) → komunikat „zadanie przejął właśnie X” i odświeżenie listy.
- Formularze przekazania wymagają powodu z listy + opisu dla „inne”; przekazanie masowe pokazuje podgląd liczby zadań przed wykonaniem.

## Plik: docs/architecture/12-testing-strategy.md

# 12. Strategia testów

Te same scenariusze Gherkin działają na dwóch poziomach: szybko na adapterach in-memory (każdy commit) i na prawdziwym MSSQL + Camunda w Testcontainers (tag `@integration`). Kroki są cienkie; o poziomie decyduje wstrzyknięty driver.

| Poziom | Narzędzie | Co sprawdza | Kiedy |
| --- | --- | --- | --- |
| Domena | xUnit | inwarianty agregatów, specyfikacje R1–R11, algorytm stanu etapów | każdy commit |
| BDD aplikacyjne | Reqnroll + drivery in-memory | reguły z `specs/` | każdy commit |
| BDD integracyjne `@integration` | Reqnroll + Testcontainers (MSSQL, Camunda 8.9) | RLS, wyścig przejęcia, SDK, task listener, Ledger | PR do `main` |
| Kontraktowe | xUnit | porty `CamundaIntegration`: fake i SDK przechodzą ten sam zestaw | PR do `main` |
| Macierz autoryzacji | xUnit (generowane) | dla każdej pary rola × uprawnienie × zakres z YAML: oczekiwane Allowed/Denied | każdy commit |
| Kompletność audytu | xUnit + WebApplicationFactory | każdy endpoint zostawia ślad i (gdzie trzeba) wpis dziennika | każdy commit |
| Architektury | ArchUnitNET / NetArchTest | granice modułów, SDK tylko w ACL, potok, brak nazw ról w kodzie | każdy commit |
| bpmnlint | `bpmnlint-plugin-ph` | reguły z `06-camunda-integration.md` | każdy commit z BPMN |
| E2E | Playwright + axe-core | kluczowe ścieżki per rola, dostępność | nightly |
| Zgodność formatek | Jest + referencyjny form-js | formatki wzorcowe: te same widoczne pola, błędy walidacji i dane wyjściowe w rendererze platformy i w form-js; te same wyrażenia FEEL w przeglądarce i na serwerze | każdy commit `form-runtime`, każda zmiana wersji form-js |
| Schemat formatek | oficjalny schemat `@bpmn-io/form-json-schema` | każda formatka wzorcowa i każda wersja opublikowana w testach jest poprawnym plikiem `.form` | każdy commit |
| Regresja wizualna | Playwright (zrzuty katalogu komponentów) | komponenty `ui-kit` i pola formatek w obu motywach i trzech szerokościach; wzorce zatwierdza projektant UX | każdy commit `ui-kit`, `theming`, `design/tokens.json` |
| Parytet katalogu pól | xUnit + Jest | `design/forms/field-catalog.yaml` ↔ `IFieldType` ↔ rejestr `form-runtime` | każdy commit |
| Mutacyjne | Stryker.NET | siła testów domeny | nightly |
| Manifesty profili | `validate_profiles.py --check` + autotest | schemat, R9/R10, własność procesów i grup, `CODEOWNERS` | każdy commit |
| Zgodność SDK | `ProcessHub.Extensibility.Testing` | każdy profil przechodzi testy zgodności z bieżącą wersją SDK | każdy commit profilu i każda zmiana SDK |
| Scenariusze profili | Reqnroll na hoście testowym SDK | `profiles/<id>/specs/*.feature` (tagi `@<PROFIL>-FR-xx`) | każdy commit profilu |
| Granice zmian profilu | `enforce_write_scope.py --verify-diff --profile <id>` | PR zespołu zmienia wyłącznie `profiles/<id>/**` | każdy PR profilu |

## Konwencje BDD

- `# language: pl`; tag FR (`@FR-11`) na każdym scenariuszu; `@integration` dla scenariuszy wymagających infrastruktury.
- Świat testowy (osoby, grupy, procesy) opisany raz w `specs/README.md` — każdy plik korzysta z tych samych nazw.
- Kroki tylko delegują do driverów (`ITaskWorkDriver`, `IInsightDriver`, `IFormsDriver`…); żadnej logiki w bindingach.
- Asercje jako rozszerzenia domenowe (`ShouldBeDeniedBy("R6")`); bez komercyjnych bibliotek asercji.
- Pliki `.feature` zatwierdza człowiek (G0); implementer ma do nich dostęp tylko do odczytu.
- Scenariusze profilu leżą w `profiles/<id>/specs/` i należą do zespołu profilu (akceptuje właściciel produktu profilu); świat testowy pozostaje wspólny.

## Plik: docs/architecture/13-project-profiles.md

# 13. Profile projektów — część wspólna i część specyficzna

Każdy projekt biznesowy korzysta z tej samej platformy, ale ma własny profil: role projektowe, dane, operacje dedykowane, rozszerzenia UI i integracje. Profil deklaruje je w manifeście (`profiles/<id>/profile.yaml`) i implementuje wyłącznie przez SDK rozszerzeń. Separację wymuszają osobno: repozytorium, kompilacja, uprawnienia, wykonanie, baza danych, wdrożenie, CI i agenci AI — dzięki temu zespół projektu pracuje samodzielnie i nie może zrealizować części innego projektu (ADR-012, ADR-013, ADR-014).

## 1. Pojęcia

| Pojęcie | Znaczenie |
| --- | --- |
| Profil projektu | Projekt biznesowy korzystający z platformy (np. `kredyty`, `aml`); właściciel procesów, ról projektowych i danych projektu |
| Manifest profilu | `profile.yaml` — kontrakt z platformą (schemat `profiles/profile.schema.json`); `authorization.yaml` — grupy AD → role projektowe |
| Rola projektowa | Rola w ramach projektu: złożenie ról platformy (Uczestnik, Inicjator, Menadżer, Administrator procesu) i uprawnień projektu, ograniczone do procesów profilu |
| Uprawnienie projektu | Uprawnienie w przestrzeni nazw profilu, np. `kredyty.Scoring.Recalculate` |
| Operacja dedykowana | Akcja projektu na zadaniu, sprawie albo danych profilu (np. „Przelicz scoring”, „Zapisz model w katalogu”), wykonywana przez potok platformy |
| Punkt rozszerzenia | Miejsce, w którym platforma oddaje sterowanie profilowi: operacja, wzbogacenie zadania, źródło danych formatki, zapytanie, obsługa zdarzeń, slot UI |
| SDK rozszerzeń | Jedyna zależność profilu: `ProcessHub.Extensibility` (.NET) i `@process-hub/extension-sdk` (Angular); wersjonowane semantycznie |
| Model integracji | `in-process` — moduł profilu w hoście platformy; `remote` — usługa zespołu wywoływana przez platformę |

## 2. Platforma a profil

```mermaid
flowchart TB
  subgraph PL["Platforma — wspólna dla wszystkich profili"]
    CORE["Moduły platformy<br/>Task Work · Process Lifecycle · Process Insight<br/>Form Management · Access Policy · Audit · Camunda Integration"]
    EXT["Extension Host<br/>rejestr profili · potok operacji · sloty UI · zdarzenia"]
    SDK["SDK rozszerzeń<br/>ProcessHub.Extensibility · @process-hub/extension-sdk"]
    CORE --- EXT
    EXT --- SDK
  end
  subgraph KR["Profil kredyty — in-process"]
    KM["Kredyty.Extension<br/>operacje · wzbogacenia · zapytania"]
    KU["profile-kredyty-ui<br/>sloty · trasy /p/kredyty/"]
    KD[("schemat prj_kredyty")]
  end
  subgraph AM["Profil aml — remote"]
    AS["Usługa AML zespołu<br/>profile-operations v1"]
    AU["profile-aml-ui"]
    AD[("schemat prj_aml")]
  end
  subgraph FL["Profil flota — in-process (przykład)"]
    FM["Flota.Extension<br/>katalog samochodów · opinie komórek"]
    FU["profile-flota-ui<br/>sekcja „Flota” · /p/flota/katalog"]
    FD[("schemat prj_flota")]
  end
  KM -->|implementuje| SDK
  KU -->|implementuje| SDK
  AU -->|implementuje| SDK
  FM -->|implementuje| SDK
  FU -->|implementuje| SDK
  EXT -->|"żądanie z podpisanym kontekstem"| AS
  KM --> KD
  AS --> AD
  FM --> FD
```

Profil `flota` jest przykładem kompletu dedykowanych elementów jednego projektu: własna sekcja nawigacji i strona katalogu widoczne tylko dla ról profilu, operacje na danych profilu, pole formatki i panel zadania. Opis krok po kroku: `docs/guides/dedykowane-elementy-profilu.md`.

| Platforma — działa tak samo dla każdego profilu | Profil — decyduje zespół projektu |
| --- | --- |
| Skrzynka zadań, przejmowanie, szkic, zakończenie, reguły R1–R4 | Role projektowe i ich przypisanie do grup AD |
| Start procesu, moje procesy, przekazywanie, zastępstwa, eskalacje | Operacje dedykowane na zadaniach i sprawach |
| Dashboard, mapa etapów, formatki (projektowanie, wersje, runtime) | Dane projektu w schemacie `prj_<id>` i ich retencja |
| Audyt każdej akcji, autoryzacje jako kod, odmowy (R5) | Rozszerzenia UI w slotach i trasy `/p/<id>/` |
| Integracja z Camunda, projekcja read modelu | Workery typów zadań `<id>.*` i integracje z systemami projektu |
| SDK rozszerzeń, potok operacji, testy zgodności | Model integracji, rytm wydań, własny plan pracy |

## 3. Kontrakt profilu

Manifest (`profile.yaml`) deklaruje wszystko, co platforma ma zarejestrować: procesy, uprawnienia, role, dane, operacje, sloty UI, integracje i zakres pracy agentów. Platforma rejestruje tylko zadeklarowane elementy — kod profilu bez wpisu w manifeście nie zostanie uruchomiony.

`tools/profiles/validate_profiles.py` (bramka CI) sprawdza schemat i reguły międzyprofilowe:

| Reguła | Sprawdzenie |
| --- | --- |
| Własność procesu | proces należy do dokładnie jednego profilu |
| Przestrzeń nazw (R10) | uprawnienia, operacje i typy zadań mają prefiks `<id>.`; schemat danych `prj_<id>`; trasy `/p/<id>/` |
| Spójność ról | role używają tylko uprawnień profilu i procesów profilu; rola audytora nie występuje w profilach |
| Operacje | uprawnienie istnieje; proces należy do profilu (R9); operacja zapisu jawnie deklaruje `requiresAssignee`; `task-action` zawsze wymaga assignee (R1); `profile-action` ma uprawnienie projektu rodzaju `write`, `requiresAssignee: false` i nie ma `appliesTo` (ADR-017); odczyt wrażliwy ma `sensitive: true` |
| Grupy | grupa AD i grupa kandydująca należą do jednego profilu |
| Klasa danych | klasa danych dla agentów nie jest słabsza niż klasyfikacja danych profilu |
| Plan zespołu | kroki planu profilu zapisują wyłącznie w `profiles/<id>/` |
| Własność kodu | `CODEOWNERS` wygenerowany i aktualny |

Zmiany `profile.yaml` i `authorization.yaml` zatwierdza zespół profilu i architekt platformy; `authorization.yaml` także bezpieczeństwo.

## 4. Role projektowe

Rola projektowa składa się z ról platformy i uprawnień projektu, w zakresie procesów profilu:

| Profil | Rola projektowa | Role platformy | Uprawnienia projektu | Procesy |
| --- | --- | --- | --- | --- |
| kredyty | Analityk kredytowy | Uczestnik, Inicjator | `kredyty.Scoring.Recalculate`, `kredyty.Applicant.View` | wniosek-kredytowy |
| kredyty | Underwriter | Uczestnik | `kredyty.Applicant.View`, `kredyty.Limit.Override` | wniosek-kredytowy |
| kredyty | Kierownik zespołu kredytowego | Menadżer procesu | `kredyty.Applicant.View`, `kredyty.Portfolio.Report` | wszystkie procesy profilu |
| kredyty | Administrator procesów kredytowych | Administrator procesu | — | wszystkie procesy profilu |
| aml | Analityk AML | Uczestnik | `aml.Sanctions.Recheck`, `aml.Party.View` | weryfikacja-aml |
| aml | Kierownik zespołu AML | Menadżer procesu | `aml.Party.View`, `aml.Case.Export` | weryfikacja-aml |
| flota | Wnioskodawca | Inicjator | `flota.Catalog.View` | rejestracja-samochodu |
| flota | Opiniujący (komórka banku: IT, HR, Prawny, Finanse, Ryzyko) | Uczestnik | `flota.Catalog.View` | opiniowanie-rejestracji |
| flota | Administrator katalogu samochodów | — (tylko uprawnienia projektu) | `flota.Catalog.View`, `flota.Catalog.Manage` | dane profilu |

Uprawnienia efektywne to suma uprawnień ról (platformy i projektowych) w zakresach. Audyt zapisuje rolę uzasadniającą w postaci `<profil>/<rola projektowa>`, np. `kredyty/underwriter`. Role globalne — Audytor i Administrator platformy — pozostają w `config/authorization/` i nie są częścią profili (rozdział obowiązków R7).

Reconciler łączy `config/authorization/*.yaml` z `profiles/*/authorization.yaml`, odrzuca konfigurację naruszającą R10 i nadaje w Camunda autoryzacje zasobów dla procesów profilu.

## 5. Punkty rozszerzeń

| Punkt | Rodzaj w manifeście | Platforma zapewnia | Profil implementuje |
| --- | --- | --- | --- |
| Operacja na zadaniu | `task-action` | uprawnienie, R1 (assignee), R9, audyt Intent/Outcome, idempotencja, `allowedActions` | `ITaskOperation<TInput>` — logika i dane projektu |
| Operacja na sprawie | `case-action` | jak wyżej, kontekst instancji procesu | `ICaseOperation<TInput>` |
| Operacja na danych profilu | `profile-action` | uprawnienie projektu (`write`), audyt Intent/Outcome, idempotencja, kontekst bazy `prj_<id>`, `allowedActions` w wyniku zapytania; bez zadania, więc bez R1 (ADR-017, SDK 1.1) | `IProfileAction<TInput>` — np. katalog, słownik, progi |
| Wzbogacenie zadania | `task-enricher` | sekcja `extensions.<id>` w widoku zadania, limit czasu, audyt odczytu wrażliwego | `ITaskEnricher` |
| Źródło danych formatki | `form-data-source` | wywołanie z formatek procesów profilu, pamięć podręczna | `IFormDataSource` |
| Zapytanie | `query` | endpoint `/p/<id>/queries/...`, autoryzacja, ślad | `IProfileQuery<TResult>` |
| Obsługa zdarzeń | `event-handler` | zdarzenia platformy tylko dla procesów profilu (outbox, ponowienia) | `IPlatformEventHandler` — np. read model projektu |
| Slot UI | `ui.slots` | renderowanie w powłoce, widoczność wg procesu i uprawnienia | komponent Angular |

Potok operacji — ten sam dla każdego profilu:

```mermaid
sequenceDiagram
  participant UI as UI (allowedActions)
  participant API as Potok platformy
  participant AP as Access Policy
  participant AU as Audit
  participant EX as Extension Host
  participant OP as Operacja profilu
  UI->>API: POST /tasks/{key}/operations/kredyty.RecalculateScoring (requestId)
  API->>AP: uprawnienie, R1 assignee, R9 proces profilu
  AP-->>API: Allowed, GrantedBy kredyty/analityk-kredytowy
  API->>AU: Intent
  API->>EX: wykonaj w kontekście profilu (użytkownik bazy prj_kredyty)
  EX->>OP: ExecuteAsync(ctx, input)
  OP-->>EX: wynik i zmiany szkicu
  EX-->>API: wynik
  API->>AU: Outcome
  API-->>UI: wynik i nowe allowedActions
```

Szkic SDK (.NET):

```csharp
public interface IProfileModule
{
    ProfileId Id { get; }
    void Register(IProfileBuilder profile);
}

public interface ITaskOperation<TInput>
{
    ValueTask<OperationResult> ExecuteAsync(TaskOperationContext ctx, TInput input, CancellationToken ct);
}

public sealed record TaskOperationContext(
    TaskView Task,                   // zadanie procesu profilu, w granicach uprawnień aktora
    ActorContext Actor,              // kto i na podstawie jakiej roli
    IPlatformTaskCommands Tasks,     // szkic i zakończenie zadania przez platformę (R1)
    IClock Clock);

public interface IProfileAction<TInput>  // od SDK 1.1 (ADR-017)
{
    ValueTask<OperationResult> ExecuteAsync(ProfileActionContext ctx, TInput input, CancellationToken ct);
}

public sealed record ProfileActionContext(
    ActorContext Actor,              // kto i na podstawie jakiej roli projektowej
    IClock Clock);                   // bez zadania i bez komend procesu — wyłącznie dane profilu
```

Operacja nie sprawdza uprawnień i nie pisze audytu — robi to potok. Zmienne procesu zmienia tylko przez platformę (szkic lub zakończenie zadania), nigdy przez Camunda; `profile-action` w ogóle nie zmienia procesów.

## 6. Dane profilu

- **Schemat i tożsamość.** Każdy profil ma schemat `prj_<id>` i użytkownika bazy `prj_<id>` bez loginu, z uprawnieniami wyłącznie do własnego schematu i do widoków `platform_api`.
- **Wykonanie w kontekście profilu.** Platforma wykonuje operację profilu w tej samej transakcji, przełączając kontekst bezpieczeństwa bazy (`EXECUTE AS USER = 'prj_<id>'` … `REVERT`). Audyt platformy zapisuje się po powrocie do kontekstu aplikacji. Nawet błąd w kodzie profilu nie da dostępu do tabel platformy ani innych profili [DO WERYFIKACJI w S27: zgodność z pulą połączeń EF Core].
- **Dane platformy.** Profil czyta je wyłącznie przez widoki `platform_api` (zadania, instancje, etapy), filtrowane predykatem RLS do procesów profilu (`SESSION_CONTEXT('ProfileId')`).
- **Migracje.** Uruchamiane osobną tożsamością migracji profilu, z prawem DDL tylko w `prj_<id>`.
- **Retencja i klasyfikacja.** Z manifestu (`data.retentionMonths`, `data.classification`); klasa `restricted` wymaga przeglądu bezpieczeństwa i modelu AI w infrastrukturze banku.
- **Model remote.** Usługa zespołu może trzymać dane we własnej bazie — wtedy klasyfikacja i retencja z manifestu obowiązują tę bazę, a platforma nie ma do niej dostępu.

## 7. Rozszerzenia UI

| Slot | Gdzie | Warunek wyświetlenia |
| --- | --- | --- |
| `task.panel` | zakładka w szczegółach zadania | proces zadania należy do profilu i aktor ma uprawnienie slotu |
| `case.panel` | zakładka w szczegółach sprawy | jak wyżej, dla instancji procesu |
| `dashboard.widget` | pulpit i panel procesu | uprawnienie slotu |
| `form.field` | pole formatki w projektancie i runtime: wariant typu bazowego Camunda Forms z własnością `ph:field`, w palecie tylko dla formatek procesów profilu | formatka procesu profilu |
| `nav.section` | sekcja nawigacji z trasami `/p/<id>/` | uprawnienie trasy |

Przyciski operacji renderuje powłoka z `allowedActions` — komponent profilu nie decyduje o dostępności akcji. Na trasach `/p/<id>/` wynik zapytania profilu przychodzi z `allowedActions` operacji `profile-action` (np. „Dodaj model” w katalogu floty tylko dla administratora katalogu). Sekcja `nav.section` i trasy profilu nie pojawiają się u osób bez uprawnienia trasy; wejście z adresu kończy się odmową zapisaną w dzienniku (R5). Biblioteki profili mają tag Nx `scope:profile-<id>` i mogą zależeć tylko od `scope:extension-sdk`. Domyślnie ładowane leniwie w obrazie aplikacji; dla profilu, który potrzebuje niezależnych wydań frontendu, opcja Native Federation [DO WERYFIKACJI ze zgodnością Kendo UI].

## 8. Camunda i integracje

- Procesy profilu leżą w `profiles/<id>/bpmn/` i są wdrażane z pipeline'u z jawnym tenantem — jak procesy platformy (C21).
- Typy zadań service tasków mają prefiks profilu (`kredyty.rejestr.sprawdz`); reguła bpmnlint `job-type-prefix` porównuje prefiks z właścicielem procesu.
- Workery profilu łączą się z Camunda własnym klientem o minimalnych uprawnieniach [DO WERYFIKACJI w S02: ograniczanie aktywacji zadań do procesów profilu].
- Grupy kandydujące BPMN profilu mapuje `authorization.yaml` (`candidateGroups`).
- Mapa etapów, dashboard, eskalacje i formatki działają dla procesów profilu bez zmian — konfigurują je menadżer i administrator procesu z ról projektowych. Formatki należą do pojedynczego procesu, nie do profilu: menadżer jednego procesu profilu nie zarządza formatkami innego, jeśli nie ma go w zakresie (R11, `14-form-management.md`).

## 9. Separacja

| Warstwa | Mechanizm | Co zatrzymuje |
| --- | --- | --- |
| Repozytorium | `profiles/<id>/**` z `CODEOWNERS` (generowany); kontrakt profilu wymaga też architekta platformy | zmianę bez przeglądu właściciela |
| Kompilacja | profil zależy tylko od SDK; testy architektury (.NET) i granice modułów Nx | odwołanie do platformy lub innego profilu |
| Uprawnienia | przestrzeń nazw profilu, reconciler, walidator manifestów (R10) | uprawnienia i role poza profilem |
| Wykonanie | Extension Host wywołuje operację tylko dla procesów profilu (R9); osobny kontener zależności per profil | operację na zadaniu innego projektu |
| Dane | schemat i użytkownik bazy per profil, widoki `platform_api` z RLS | odczyt i zapis cudzych danych |
| Wdrożenie | in-process: wspólny obraz z pociągiem wydań; remote: osobna usługa i wydania zespołu | wzajemne blokowanie wydań (remote) |
| CI | filtry ścieżek per profil; `enforce_write_scope.py --verify-diff --profile <id>` | PR zespołu zmieniający kod spoza profilu |
| Agenci AI | agenci `<id>-<rola>` z zapisem tylko w `profiles/<id>/**`; plugin strażnika; klasa danych wybiera model | agenta jednego profilu realizującego część innego |

## 10. Autonomia zespołów

- **Plan i rytm.** Zespół prowadzi `profiles/<id>/backlog.yaml` tymi samymi narzędziami co platforma (`plan_status.py`, `prepare_step.py`, `run_dod.py` z `--backlog`). Kroki profilu mogą zależeć od kroków platformy (np. S38).
- **Kontrakt z platformą.** SDK wersjonowane semantycznie; zmiana niezgodna wstecz tylko w nowej wersji głównej, z okresem przejściowym co najmniej dwóch wersji pomocniczych. Platforma dostarcza testy zgodności i host testowy `ProcessHub.Extensibility.Testing`.
- **Nowe potrzeby.** Brak punktu rozszerzenia → RFC do zespołu platformy; profil nie obchodzi braku kodem platformy.
- **Wydania.** In-process: profil wchodzi do pociągu wydań platformy (propozycja: co dwa tygodnie). Remote: wydania zespołu w dowolnym rytmie, w granicach kontraktu `profile-operations`.
- **Cykl życia profilu.** Propozycja → PR z manifestem → walidacja i przegląd → reconciler nadaje autoryzacje → pierwsze wydanie → eksploatacja → wygaszenie (archiwizacja danych wg retencji, odebranie autoryzacji, usunięcie z rejestru).

## 11. In-process czy remote

| Kryterium | In-process (domyślnie) | Remote |
| --- | --- | --- |
| Technologia | .NET, SDK platformy | dowolna, kontrakt `profile-operations v1` |
| Wydania | pociąg wydań platformy | niezależne |
| Opóźnienie i spójność | jedna transakcja z platformą | wywołanie sieciowe, wynik w osobnej transakcji, limit czasu |
| Izolacja awarii | błąd profilu w procesie hosta (ograniczony limitami czasu i kontekstem bazy) | awaria usługi = operacja niedostępna, praca na zadaniu trwa dalej |
| Koszt utrzymania | niski | zespół utrzymuje własną usługę, mTLS, monitoring |
| Kiedy | większość projektów | inna technologia, osobny rytm wydań, ciężkie obliczenia, dane we własnej bazie |

## 12. Otwarte kwestie

- D-08: domyślny model integracji profili (rekomendacja: in-process; remote na wniosek zespołu).
- D-09: monorepo z `CODEOWNERS` czy osobne repozytoria profili publikujące paczki (rekomendacja: monorepo na start, bo walidacja międzyprofilowa i testy architektury działają w jednym miejscu).
- D-10: rytm pociągu wydań dla profili in-process.
- D-11: zakres danych platformy dostępnych w widokach `platform_api`.
- ADR-017 (operacje na danych profilu): zatwierdzenie przez architekta platformy, zasób audytu i limit czasu (`docs/rfc/RFC-FLO-03-operacja-na-danych-profilu.md`).
- Do weryfikacji w PoC: `EXECUTE AS USER` z pulą połączeń EF Core (S27), ograniczenie aktywacji zadań workerów do procesów profilu (S02), Native Federation z Kendo UI (S47).

## Plik: docs/architecture/14-form-management.md

# 14. Moduł zarządzania formatkami (Camunda Forms)

Formatka w Process Hub to formularz w formacie **Camunda Forms** — tym samym, który tworzy Camunda Modeler (biblioteka form-js). Biznes projektuje ją w aplikacji, w edytorze znanym z Modelera; aplikacja prowadzi jej wersje, akceptację i wycofanie; zadanie renderuje ją **komponentami design systemu**, a nie wyglądem biblioteki. Każda formatka należy do jednego procesu i poza nim nie istnieje. Decyzje: ADR-018 (format, cykl życia, separacja), ADR-019 (projektant i materializacja), ADR-020 (walidacja po stronie serwera). Warstwa wizualna: `design/forms/README.md`; wytyczne dla osób zaczynających pracę nad UI: `docs/artifacts/04-wytyczne-ui.md`.

## 1. Pięć zasad

1. **Schemat mówi „co”, design system mówi „jak”.** Schemat formatki zawiera pola, typy, etykiety, walidacje, warunki i układ w siatce. Nie zawiera kolorów, krojów ani stylów — i nie ma jak ich zawrzeć.
2. **Jedna formatka, jeden proces (R11).** Formatka, jej wersje i historia należą do dokładnie jednego `BpmnProcessId`. Nie ma biblioteki formatek wspólnych ani kopiowania między procesami w aplikacji.
3. **Każda zmiana przechodzi tę samą drogę:** szkic → przegląd → zatwierdzenie przez inną osobę (R8) → publikacja. Wersja opublikowana jest niezmienna.
4. **Zadanie renderuje wersję przypiętą przy jego utworzeniu** (FR-18). Publikacja nowej wersji nie zmienia zadań w toku; zmienia je wyłącznie świadome wycofanie wersji z przepięciem.
5. **Wycofać można zawsze, ale nigdy po cichu:** z powodem, ze wskazaniem skutku dla zadań w toku i z wpisem w dzienniku.

## 2. Pojęcia

| Pojęcie | Kod | Znaczenie |
| --- | --- | --- |
| Formatka | `FormDefinition` | Formularz jednego procesu: tożsamość `(TenantId, BpmnProcessId, FormKey)`, nazwa, zastosowanie, wersje |
| Klucz formatki | `FormKey` | Stały identyfikator w obrębie procesu, np. `ocena-wniosku`; model BPMN wskazuje go referencją `ph:form/ocena-wniosku` |
| Zastosowanie | `FormUsage` | `Task` — formatka zadań wskazujących klucz w BPMN; `ProcessStart` — formatka startowa procesu (najwyżej jedna obowiązująca na proces) |
| Wersja formatki | `FormVersion` | Stan treści w cyklu życia; numer nadawany przy publikacji (1, 2, 3…) |
| Wersja robocza | stany `Draft`, `InReview`, `Approved` | Jedyna edytowalna wersja formatki; najwyżej jedna naraz |
| Wersja obowiązująca | `CurrentVersion` | Opublikowana wersja przypinana nowym zadaniom; najwyżej jedna |
| Schemat | `Schema` | Dokument JSON w formacie Camunda Forms (`type: "default"`, `components`, `schemaVersion`…) |
| Katalog pól | `design/forms/field-catalog.yaml` | Lista typów komponentów Camunda Forms ze statusem wsparcia i komponentem design systemu, który je materializuje |
| Profil zgodności | `ph-forms-8.9` | Wersja katalogu pól + dopuszczalna `schemaVersion`; zapisywany przy każdej opublikowanej wersji |
| Kontrakt danych zadania | `ph:inputs`, `ph:outputs` | Zmienne, które zadanie dostaje i które musi oddać (praktyka C7) |
| Przypięcie | `WorkItem.FormVersion` | Wersja formatki zapisana przy zadaniu w chwili jego utworzenia |
| Wycofanie | `FormWithdrawal` | Zdjęcie opublikowanej wersji (albo całej formatki) z użycia, z powodem i trybem dla zadań w toku |
| Materializacja | `form-runtime` + `core/ui-kit` | Zamiana schematu na interfejs z komponentów design systemu |

## 3. Odpowiedzialności

| Kto | Decyduje o | Nie decyduje o |
| --- | --- | --- |
| Menadżer procesu, administrator procesu (biznes) | polach, typach, etykietach, podpowiedziach, walidacjach, warunkach widoczności, kolejności i układzie w wierszach; przeglądzie, publikacji i wycofaniu formatek swojego procesu | kolorach, krojach, rozmiarach, wyglądzie kontrolek i komunikatów; formatkach innych procesów |
| Zespół modelujący BPMN (zespół profilu) | referencji `ph:form/<klucz>` na zadaniu i kontrakcie danych `ph:inputs`/`ph:outputs` | treści formatki |
| Projektant UX (człowiek, Figma) | tokenach, wyglądzie i stanach komponentów pól, wzorcach formularza; akceptuje wzorce regresji wizualnej | strukturze konkretnych formatek |
| Agent `ux-designer` | przeniesieniu eksportów z Figma do `design/**` (tokeny, specyfikacje, katalog pól, makieta) | kodzie aplikacji |
| Agent `design-system-engineer` | `core/theming`, `core/ui-kit`, komponentach pól i ich testach wizualnych | logice interpretacji schematu |
| Agent `frontend-developer` | bibliotekach `form-designer` i `form-runtime` (interpretacja schematu, FEEL, układ) | wyglądzie — używa wyłącznie `core/ui-kit` |
| Agent `module-implementer` | modułach `FormManagement` i `FormRuntime` | kontraktach (architekt) |
| Agent `ui-reviewer` | zgodności zmian UI z tokenami, katalogiem pól i WCAG (tylko odczyt) | — |
| Architekt platformy | kontraktach modułu, statusach w katalogu pól, ADR | — |
| Zespół profilu | własnych polach formatek (`form.field` — warianty typów bazowych z katalogu pól) i źródłach danych — tylko dla procesów profilu (R9) | formatkach jako takich: prowadzą je menadżer i administrator procesu |
| Audytor | — (wgląd tylko do odczytu: `Form.View`, dziennik) | — |

## 4. Zgodność z Camunda Forms

**Format.** Wersja formatki przechowuje dokument dokładnie w formacie Camunda Forms: `type: "default"`, `id`, `schemaVersion`, `executionPlatform: "Camunda Cloud"`, `executionPlatformVersion: "8.9.0"`, `exporter` (`Process Hub` + wersja) i `components`. Metadane cyklu życia (stan, numer wersji, autorzy, przeglądy) żyją obok schematu, w kolumnach — do schematu nie dopisujemy własnych pól najwyższego poziomu. Każda opublikowana wersja jest poprawnym plikiem `.form`, który otworzy Camunda Modeler (NFR-14): serwer waliduje schemat katalogiem pól, który jest podzbiorem formatu, a zgodność z oficjalnym schematem formatu (`@bpmn-io/form-json-schema`) sprawdzają testy — na formatkach wzorcowych i na każdej wersji publikowanej w scenariuszach.

**Biblioteka.** Projektant osadza edytor `@bpmn-io/form-js-editor` — ten sam, którego używa Modeler. Wersja biblioteki jest przypięta; profil zgodności `ph-forms-8.9` dopuszcza `schemaVersion` ≤ 19 (form-js 2.x). Którą wersję form-js zawiera Modeler dla Camunda 8.9 — i czy lista typów jest ta sama — potwierdza **[PoC, S07]**.

**Katalog pól.** Camunda Forms ma 22 typy komponentów. Katalog pól przypisuje każdemu status i komponent design systemu; pełna specyfikacja: `design/forms/field-catalog.yaml`.

| Status | Typy | Skutek |
| --- | --- | --- |
| Wspierany | `textfield`, `textarea`, `number`, `datetime`, `checkbox`, `checklist`, `radio`, `select`, `taglist`, `group`, `dynamiclist`, `table`, `expression`, `separator` | dostępny w palecie projektanta, renderowany, walidowany |
| Wspierany z ograniczeniami | `text` (Markdown bez surowego HTML), `spacer` (wysokość ze skali odstępów), `image` (tylko zasób osadzony, z tekstem alternatywnym) | dostępny; publikacja sprawdza ograniczenie |
| Planowany | `filepicker`, `documentPreview` | poza paletą; publikacja odrzucona do decyzji D-15 o magazynie dokumentów (C9) |
| Zablokowany | `html`, `iframe`, `button` | poza paletą; import i publikacja odrzucone: brak dowolnego HTML i treści zewnętrznych (`10-audit-and-security.md`), a przyciski akcji renderuje powłoka z `allowedActions` |

**Wyrażenia.** Warunki widoczności (`conditional.hide`), dynamiczne `readonly`/`disabled`, opcje z wyrażenia (`valuesExpression`), pola wyliczane (`expression`) i szablony tekstu używają FEEL — tak jak w Camunda. W przeglądarce wykonuje je biblioteka `feelin` (ta sama co w form-js), po stronie serwera — silnik Camunda przez port `IExpressionEvaluator` (ADR-020).

**Import i eksport.** Formatkę można zaimportować z pliku `.form` (np. przygotowanego w Modelerze) i wyeksportować do pliku. Import tworzy wersję roboczą w bieżącym procesie albo zastępuje jej treść (jako kolejna rewizja szkicu) i przechodzi tę samą walidację katalogu co zapis; eksport wersji opublikowanej dopisuje `versionTag` z numerem wersji. Obie operacje są audytowane. To jedyna droga przeniesienia treści między procesami — świadoma, jawna i bez trwałego powiązania kopii z oryginałem.

**Czego nie robimy.** Formatki nie są wdrażane do silnika jako zasoby Camunda (`formId`). Zadanie wskazuje formatkę referencją zewnętrzną (C6), a cykl życia, wersje i przypięcia należą do aplikacji. Powody: prawo wdrażania zasobów w Camunda obejmuje także modele BPMN (za szerokie dla klienta technicznego platformy; nazwy uprawnień potwierdza S02), identyfikator formularza w silniku jest globalny dla tenanta (sprzeczne z R11), a wycofanie z przepięciem wymaga przypięć po stronie aplikacji (ADR-018).

**Pola profilu.** Pole dostarczane przez profil (slot `form.field`, np. „Model samochodu z katalogu”) to w schemacie zwykły komponent bazowy (zwykle `select`) z własnością `properties["ph:field"] = "<profil>.<nazwa>"`. Schemat pozostaje poprawnym Camunda Form; renderer podstawia komponent profilu tylko wtedy, gdy proces należy do tego profilu (R9), a paleta projektanta pokazuje pola profilu wyłącznie w formatkach jego procesów.

## 5. Model domenowy

```mermaid
classDiagram
    class FormDefinition {
      TenantId
      BpmnProcessId
      FormKey
      Name
      Usage
      Status
      CurrentVersion
    }
    class FormVersion {
      Number
      Status
      Schema
      Digest
      CatalogProfile
      LastChangedBy
      Contributors
    }
    class FormReview {
      Decision
      Reviewer
      Comment
      Digest
    }
    class FormWithdrawal {
      Reason
      Mode
      ReplacementVersion
      WithdrawnBy
    }
    class WorkItem {
      FormVersion
    }
    FormDefinition "1" *-- "1..*" FormVersion
    FormVersion "1" *-- "*" FormReview
    FormVersion "1" *-- "0..1" FormWithdrawal
    WorkItem "*" --> "0..1" FormVersion : przypięcie
```

**`FormDefinition`** (agregat, Form Management). Stan formatki: `Active` albo `Retired` (wycofana w całości).

**`FormVersion`** — stany i przejścia:

```mermaid
stateDiagram-v2
    [*] --> Draft: Create / NewVersion / Import
    Draft --> Draft: Save
    Draft --> InReview: SubmitForReview
    InReview --> Draft: Recall (autor) / Reject (z komentarzem)
    InReview --> Approved: Approve (R8)
    Approved --> Draft: Save (unieważnia zatwierdzenie)
    Approved --> Published: Publish (kontrakt danych, katalog pól)
    Published --> Superseded: publikacja nowszej wersji
    Published --> Withdrawn: Withdraw (powód)
    Superseded --> Withdrawn: Withdraw (powód)
    Superseded --> Published: przywrócenie jako zastępczej przy wycofaniu
    Draft --> [*]: Discard
```

Dawny cykl `Draft → InReview → Published → Deprecated` zostaje doprecyzowany: dochodzi `Approved` (już obecny w scenariuszach i makiecie), a `Deprecated` rozdziela się na `Superseded` (zastąpiona nowszą) i `Withdrawn` (wycofana decyzją człowieka).

**Inwarianty:**

1. Tożsamość `(TenantId, BpmnProcessId, FormKey)` jest unikalna i niezmienna; formatka nie zmienia procesu.
2. Formatka ma najwyżej jedną wersję roboczą (`Draft`, `InReview` lub `Approved`).
3. `Approve` wykonuje osoba inna niż autor ostatniej zmiany (R8); zatwierdzenie dotyczy konkretnej treści (skrót `Digest`) — każda późniejsza zmiana je unieważnia.
4. Treść wersji `Published`, `Superseded` i `Withdrawn` jest niezmienna; zmienia się tylko ich stan (zastąpienie, wycofanie, przywrócenie jako zastępczej).
5. `Publish` wymaga: stanu `Approved` z niezmienionym skrótem, zgodności z katalogiem pól, poprawnej składni wyrażeń FEEL i zgodności z kontraktem danych wszystkich zadań wskazujących formatkę (sekcja 9).
6. Numer wersji rośnie o jeden przy publikacji i nie jest używany ponownie; obowiązująca jest najwyżej jedna wersja.
7. `Withdraw` wymaga powodu; wersja zastępcza musi być wcześniej opublikowaną, niewycofaną wersją tej samej formatki, zgodną z bieżącym kontraktem danych.
8. Przypięcie może wskazywać wyłącznie wersję formatki tego samego procesu co zadanie (R11).
9. Formatki nie usuwa się fizycznie — wycofana (`Retired`) zachowuje historię, a jej klucz pozostaje zajęty; do stanu `Active` wraca wyłącznie przez publikację nowej wersji po pełnej akceptacji.

**Komendy:**

| Komenda | Uprawnienie | Reguły | Akcja w dzienniku |
| --- | --- | --- | --- |
| Utwórz formatkę | `Form.Edit` | R11; klucz wolny w procesie | `Form.Create` |
| Zapisz szkic | `Form.Edit` | wersja robocza; współbieżność optymistyczna | `Form.Save` |
| Importuj plik `.form` | `Form.Edit` | walidacja formatu i katalogu | `Form.Import` |
| Przekaż do przeglądu | `Form.Edit` | brak błędów walidacji katalogu i składni wyrażeń | `Form.SubmitForReview` |
| Cofnij z przeglądu | `Form.Edit` | tylko autor ostatniej zmiany | `Form.Recall` |
| Odrzuć do poprawy | `Form.Approve` | komentarz obowiązkowy | `Form.Reject` |
| Zatwierdź | `Form.Approve` | R8 | `Form.Approve` |
| Opublikuj | `Form.Publish` | inwariant 5 | `Form.Publish` |
| Utwórz nową wersję (szkic z wybranej wersji) | `Form.Edit` | inwariant 2 | `Form.NewVersion` |
| Porzuć szkic | `Form.Edit` | — | `Form.Discard` |
| Wycofaj wersję | `Form.Withdraw` | inwariant 7 | `Form.Withdraw` (+ `Form.Repin` dla przepiętych zadań) |
| Wycofaj formatkę | `Form.Withdraw` | powód obowiązkowy | `Form.Retire` |
| Eksportuj plik `.form` | `Form.View` | — | `Form.Export` |
| Przeglądaj formatki, wersje, historię | `Form.View` | R11 | odczyt w śladzie operacyjnym |

Uprawnienia `Form.View`, `Form.Edit`, `Form.Approve`, `Form.Publish`, `Form.Withdraw` mają menadżer i administrator procesu — każdy w zakresie swoich procesów; audytor ma `Form.View`. Uczestnik nie ma żadnego: formatkę widzi wyłącznie na zadaniu.

## 6. Wersjonowanie

- **Rewizje szkicu.** Każdy zapis wersji roboczej tworzy rewizję (tabela temporalna): kto, kiedy, co zmienił. Historia jest widoczna w projektancie; nie ma numerów — numer dostaje dopiero publikacja.
- **Wersje opublikowane.** Kolejne liczby całkowite w obrębie formatki. Każda ma skrót treści, profil zgodności, autora ostatniej zmiany, zatwierdzającego i publikującego.
- **Porównanie.** Dowolne dwie wersje (albo szkic z wersją obowiązującą) można porównać: pola dodane, usunięte i zmienione, z listą zmienionych właściwości. Zatwierdzający zawsze widzi różnicę względem wersji obowiązującej — bez tego cztery oczy byłyby formalnością.
- **Nowa wersja z dowolnej.** Szkic można utworzyć z każdej wcześniejszej wersji, także wycofanej; dalej idzie zwykłą drogą.
- **Wersje definicji procesu.** Formatka nie jest wersjonowana razem z BPMN. Zgodność z modelem zapewnia kontrakt danych sprawdzany przy publikacji dla każdej wersji definicji, która ma aktywne instancje i wskazuje formatkę (C19).

## 7. Akceptacja (cztery oczy)

```mermaid
sequenceDiagram
    actor M as Marta (menadżer)
    actor A as Adam (administrator)
    participant FM as Form Management
    participant N as Powiadomienia
    M->>FM: Zapisz szkic, Przekaż do przeglądu
    FM->>N: „Formatka czeka na przegląd” → osoby z Form.Approve w procesie
    A->>FM: Otwórz przegląd (różnica względem wersji obowiązującej)
    alt uwagi
        A->>FM: Odrzuć do poprawy (komentarz)
        FM->>N: powiadomienie autora
    else bez uwag
        A->>FM: Zatwierdź (R8: Adam ≠ autor ostatniej zmiany)
        M->>FM: Opublikuj (kontrakt danych, katalog pól)
        FM-->>M: wersja N opublikowana, poprzednia zastąpiona
    end
```

- R8 porównuje zatwierdzającego z autorem ostatniej zmiany. Lista wszystkich współautorów szkicu jest zapisywana i pokazywana zatwierdzającemu; zaostrzenie reguły do „żaden ze współautorów” to decyzja D-12.
- Publikować może każda osoba z `Form.Publish`, także autor — zatwierdzenie już się odbyło i dotyczy dokładnie tej treści.
- Zatwierdzenie nie wygasa z czasem; unieważnia je wyłącznie zmiana treści.

## 8. Wycofywanie

Wycofanie to osobna, audytowana operacja (`Form.Withdraw`) z obowiązkowym powodem: `Defect` (wada formatki), `Compliance` (wymóg zgodności), `ProcessChange` (zmiana procesu), `Other` (z opisem). Okno potwierdzenia pokazuje skutek: liczbę zadań w toku na tej wersji i zadania procesu wskazujące formatkę.

| Sytuacja | Nowe zadania | Zadania w toku na wycofanej wersji |
| --- | --- | --- |
| Wycofanie wersji obowiązującej **z wersją zastępczą** (wcześniej opublikowaną, zgodną z kontraktem) | dostają wersję zastępczą — wraca ona do stanu `Published` | do wyboru: **pozostają** na wycofanej wersji (domyślnie) albo są **przepinane** na zastępczą |
| Wycofanie wersji obowiązującej **bez zastępczej** | nie mają formatki do czasu kolejnej publikacji: zadanie pokazuje komunikat, zakończenie jest zablokowane, menadżer widzi alert | pozostają na wycofanej wersji; przepięcie niemożliwe |
| Wycofanie wersji zastąpionej (nieobowiązującej) | bez zmian | pozostają albo są przepinane na wersję obowiązującą |
| Wycofanie całej formatki (`Form.Retire`) | jak „bez zastępczej”; formatki nie da się opublikować ponownie bez nowego szkicu i pełnej akceptacji | pozostają na swoich wersjach |

- **Przepięcie** (`Repin`) jest jedynym wyjątkiem od niezmienności przypięcia. Wykonuje je zadanie w roli `jobs` z trwałym stanem i wznawianiem (wzorzec `ReassignmentBatch`). Szkic danych zadania przechodzi dla pól o tym samym kluczu i typie; pozostałe wartości są odrzucane, a wykonawca widzi na zadaniu informację o zmianie formatki. Każde przepięcie to wpis `Form.Repin`.
- **Przywrócenie** wycofanej wersji nie istnieje jako skrót: tworzy się z niej nowy szkic i przechodzi pełną akceptację.
- Wycofanie wykonuje jedna osoba — to operacja awaryjna; powiadomienie dostają wszyscy z `Form.Approve` w procesie. Wymóg drugiej osoby przy wycofaniu to decyzja D-13.
- Formatka startowa: wycofanie bez zastępczej wyłącza start procesu z aplikacji z czytelnym komunikatem w katalogu startowym.

## 9. Powiązanie z procesem i przypięcie

| Element | Jak wskazuje formatkę | Kontrakt danych |
| --- | --- | --- |
| User task | `zeebe:formDefinition externalReference="ph:form/<klucz>"` (C6) | `ph:inputs`, `ph:outputs` w `zeebe:properties` zadania (C7) |
| Start procesu | formatka z zastosowaniem `ProcessStart` przypisana do procesu w Form Management (zdarzenie startowe nie przyjmuje `externalReference`) | `ph:outputs` zdarzenia startowego |

Referencja nie zawiera identyfikatora procesu: klucz jest rozwiązywany zawsze w procesie zadania — `(TenantId, BpmnProcessId zadania, FormKey)`. Odwołanie do formatki innego procesu jest niewyrażalne.

```mermaid
sequenceDiagram
    participant CAM as Camunda
    participant CI as Camunda Integration (projektor)
    participant TW as Task Work
    participant FM as Form Management
    participant FR as Form Runtime
    actor U as Wykonawca
    CAM-->>CI: user task utworzony (elementId, bpmnProcessId)
    CI->>TW: zdarzenie integracyjne
    TW->>FM: wersja obowiązująca dla (tenant, proces, klucz z katalogu elementów)
    FM-->>TW: FormVersion N — przypięcie zapisane w WorkItem
    U->>FR: otwórz zadanie
    FR-->>U: schemat wersji N + dane wejściowe + tryb (edycja albo odczyt)
    U->>FR: Zakończ (wartości pól)
    FR->>FR: walidacja wg wersji N i kontraktu ph:outputs
    FR->>CAM: completion przez IUserTaskCommands (tylko zmienne z kontraktu)
```

- **Brak wersji obowiązującej** w chwili utworzenia zadania: zadanie powstaje bez przypięcia; przypięcie następuje przy pierwszym otwarciu po publikacji. Do tego czasu zadania nie da się zakończyć.
- **Kontrola spójności.** Katalog elementów (`IDefinitionCatalog`) daje listę referencji `ph:form/…` każdej wersji definicji. Projektant pokazuje „Powiązania”: które zadania (nazwa i etap; identyfikator elementu tylko z `Bpmn.ViewTechnical`) wskazują formatkę oraz referencje bez opublikowanej formatki („Brakujące formatki”). Po wdrożeniu nowej wersji definicji procesu kontrola sprawdza też, czy wersja obowiązująca spełnia jej kontrakt danych; niezgodność trafia jako ostrzeżenie do menadżera i administratora procesu. Naprawa: publikacja nowej wersji formatki, a dla zadań już przypiętych do starej — jej wycofanie z przepięciem.
- **Zgodność z kontraktem przy publikacji.** Każde wyjście z `ph:outputs` musi mieć pole o tym kluczu i zgodnym typie (`string` ↔ pola tekstowe, wyboru i dat; `number` ↔ `number`; `boolean` ↔ `checkbox`; `date` ↔ `datetime`). Pole czytające zmienną spoza `ph:inputs` daje ostrzeżenie. Sprawdzane są wszystkie wersje definicji z aktywnymi instancjami, które wskazują formatkę.
- **Formatka startowa nie ma przypięcia.** Start procesu waliduje dane względem wersji, którą wyświetlono (numer wersji jest w żądaniu); jeśli w międzyczasie zmieniła się wersja obowiązująca, żądanie jest odrzucane z prośbą o odświeżenie formatki — wpisane dane zostają w przeglądarce.
- **Reguły bpmnlint:** `ph/task-contract` (jest) oraz nowa `ph/form-reference` — user task wskazuje formatkę wyłącznie przez `externalReference` w postaci `ph:form/<klucz>`; `formId` i formularze osadzone są zabronione.

## 10. Separacja per proces (R11)

| Warstwa | Mechanizm |
| --- | --- |
| Model | tożsamość formatki zawiera `BpmnProcessId`; brak encji współdzielonych między procesami |
| Uprawnienia | `Form.*` sprawdzane w zakresie procesu formatki; menadżer procesu A nie ma ich w procesie B (odmowa `Denied` z nazwą uprawnienia) |
| Reguła wiersza | R11 odrzuca każdą operację łączącą dwa procesy: szkic z wersji formatki innego procesu, przypięcie spoza procesu zadania, wersję zastępczą z formatki innego procesu |
| API | wszystkie trasy pod `/api/processes/{bpmnProcessId}/forms/…`; lista zwraca wyłącznie procesy z `Form.View` |
| Baza | `TenantId` + `BpmnProcessId` w każdej tabeli schematu `form`; unikalność klucza w procesie; RLS po tenancie; test architektury: każde zapytanie modułu przyjmuje zakres procesu |
| Wykonanie | Form Runtime wydaje schemat tylko dla przypięcia zadania; brak trasy „pobierz formatkę po identyfikatorze” |
| Interfejs | ekran „Formatki” zawsze w kontekście jednego procesu; przełącznik procesu pokazuje tylko procesy w zakresie |
| Profile | pola profilu i źródła danych tylko w formatkach procesów profilu (R9) |
| Audyt | każdy wpis `Form.*` zawiera `BpmnProcessId`; odmowy R11 z kodem reguły |
| Testy | `specs/forms/form-isolation.feature`; macierz autoryzacji dla `Form.*` × proces |

## 11. Renderowanie na zadaniu

1. **Pobranie.** Widok zadania dostaje schemat przypiętej wersji, dane wejściowe (zmienne z `ph:inputs`), szkic danych i tryb: edycja (assignee) albo odczyt (pozostali — z jednym zdaniem wyjaśnienia, R1).
2. **Interpretacja** (`form-runtime`). Biblioteka czyta schemat Camunda Forms: drzewo komponentów, ścieżki danych (`key`, `path`), układ (`layout.row`, `layout.columns` w siatce 16 kolumn), warunki i wyrażenia FEEL, walidacje.
3. **Materializacja.** Każdy typ z katalogu pól ma dokładnie jeden komponent w `core/ui-kit` (opakowanie Kendo stylowane tokenami). Renderer nie zna kolorów ani rozmiarów — przekazuje komponentowi etykietę, podpowiedź, stan, błąd i wartość.
4. **Walidacja w przeglądarce** przy opuszczeniu pola i przy zakończeniu: wymagalność, długości, zakresy, wzorce, typy; podsumowanie błędów nad formatką z odnośnikami do pól.
5. **Walidacja na serwerze** (`FormRuntime`) przed wywołaniem silnika — zawsze, niezależnie od przeglądarki (FR-06):
   - poziom A (bezwarunkowy): tylko klucze znane schematowi, typy wartości, ograniczenia statyczne, przynależność do opcji statycznych, pole stale `readonly` nie może zmienić wartości wejściowej, a pole stale `disabled` nie jest przyjmowane, kontrakt `ph:outputs` (każde wyjście ma wartość zgodnego typu albo — gdy jego pole jest ukryte warunkiem — wartość pustą);
   - poziom B (wyrażenia): warunki ukrycia, dynamiczne `readonly`/`disabled`, opcje z wyrażeń — przez `IExpressionEvaluator` (ADR-020, PoC S08).
6. **Zakończenie.** Do silnika trafiają wyłącznie zmienne z kontraktu (C8).

Zestaw zgodności (NFR-14) uruchamia te same formatki wzorcowe w rendererze platformy i w referencyjnym form-js i porównuje zbiór widocznych pól, błędy walidacji i dane wyjściowe. Wygląd celowo się różni; zachowanie nie może.

## 12. Warstwa wizualna — założenia

Trzy warstwy, każda z jednym właścicielem:

| Warstwa | Zawartość | Właściciel | Gdzie |
| --- | --- | --- | --- |
| Struktura | pola, typy, teksty, walidacje, warunki, wiersze i szerokości | biznes (menadżer, administrator procesu) | schemat wersji formatki |
| Materializacja | typ pola → komponent, jego warianty i stany | zespół design systemu | `design/forms/field-catalog.yaml`, `core/ui-kit` |
| Wygląd | kolory, typografia, odstępy, promienie, wysokości kontrolek | projektant UX | Figma → `design/tokens.json` → `core/theming` |

- **Biznes układa, nie stylizuje.** W projektancie dostępne są wyłącznie własności katalogu. Układ to wiersze i szerokości w siatce; odstępy, wyrównania i typografię nadaje design system.
- **Jedna formatka, wszystkie motywy.** Ta sama wersja wygląda poprawnie w motywie jasnym i ciemnym, na telefonie (pola w jednej kolumnie poniżej progu szerokości) i przy powiększeniu 200%.
- **Spójność z resztą systemu.** Pole formatki to ten sam komponent, którego używają okna przekazania czy zastępstw; błędy, podpowiedzi i stan „tylko do odczytu” wyglądają wszędzie tak samo.
- **Zmiana wyglądu nie wymaga zmiany formatek.** Nowe tokeny albo poprawiony komponent działają dla wszystkich opublikowanych wersji; wersje formatek nie niosą wyglądu, więc pozostają niezmienne.
- **Figma jest źródłem wyglądu, repozytorium — źródłem prawdy dla kodu.** Projektant eksportuje zmienne i specyfikacje; do repozytorium trafiają jako pull request w `design/**`. Kod czyta wyłącznie `design/tokens.json` i katalog pól (ADR-019).

Szczegóły (siatka, stany pól, komunikaty, mapowanie każdego typu, proces Figma → kod): `design/forms/README.md`.

## 13. Projektant formatek

| Obszar ekranu | Zawartość |
| --- | --- |
| Nagłówek | proces, nazwa i klucz formatki, stan wersji roboczej, wersja obowiązująca, akcje cyklu życia z `allowedActions` |
| Miejsce w procesie | wstęga etapów z zaznaczonym etapem zadania i liczbą czekających spraw (FR-16); powiązania i kontrakt danych |
| Projekt | osadzony edytor form-js: paleta ograniczona do katalogu pól (plus pola profilu procesu), kanwa, panel właściwości bez własności zablokowanych |
| Podgląd jak u wykonawcy | ta sama formatka w rendererze platformy, z danymi przykładowymi, w obu motywach i szerokościach |
| Walidacja | błędy i ostrzeżenia katalogu oraz kontraktu, z odnośnikami do pól |
| Wersje | lista wersji ze stanami, autorami i datami; porównanie; „Utwórz nową wersję”, „Wycofaj”, eksport |
| Historia | rewizje szkicu, przeglądy z komentarzami, wycofania |

- Edytor pracuje na kanwie form-js (wygląd biblioteki, znak bpmn.io widoczny — wymóg licencji); o wyglądzie u wykonawcy rozstrzyga zakładka podglądu.
- Edycja możliwa tylko w stanie `Draft`; w pozostałych projektant jest tylko do odczytu, z jednym zdaniem „dlaczego”.
- Akcje nieodwracalne (publikacja, wycofanie) przechodzą przez okno potwierdzenia z podsumowaniem skutku.

## 14. API, dane, zdarzenia (szkic do kontraktów v1, krok S15)

| Trasa | Uprawnienie |
| --- | --- |
| `GET /api/processes/{p}/forms` · `GET …/forms/{key}` · `GET …/forms/{key}/versions/{n}` · `GET …/versions/{a}/diff/{b}` | `Form.View` |
| `POST /api/processes/{p}/forms` · `PUT …/forms/{key}/draft` · `POST …/draft/submit` · `POST …/draft/recall` · `DELETE …/draft` · `POST …/versions/{n}/new-version` · `POST …/import` | `Form.Edit` |
| `POST …/draft/approve` · `POST …/draft/reject` | `Form.Approve` |
| `POST …/draft/publish` | `Form.Publish` |
| `POST …/versions/{n}/withdraw` · `POST …/forms/{key}/retire` | `Form.Withdraw` |
| `GET …/versions/{n}/export` | `Form.View` |
| `GET /api/processes/{p}/forms/catalog` (katalog pól + pola profilu procesu) | `Form.View` |
| `GET /api/tasks/{taskKey}/form` · `GET /api/processes/{p}/start-form` | jak dla zadania i startu |

Schemat bazy `form`: `FormDefinition`, `FormVersion` (temporalna — rewizje szkicu), `FormReview`, `FormWithdrawal`, `FormRepinBatch`, `FormRepinItem`; przypięcie w `task.WorkItem` z historią przepięć. Zdarzenia przez outbox: `FormSubmittedForReview`, `FormApproved`, `FormRejected`, `FormVersionPublished`, `FormVersionWithdrawn`, `FormRetired` — odbiorcy: Task Work (przepięcia), Notification, Audit.

## 15. Bezpieczeństwo

- Biała lista typów i własności z katalogu pól, egzekwowana przy imporcie, zapisie, przekazaniu do przeglądu i publikacji — niezależnie od tego, co pozwolił edytor.
- Tekst formatek (`text`, etykiety, podpowiedzi) renderowany bez surowego HTML; Markdown po sanityzacji; brak zewnętrznych obrazów, ramek i skryptów (CSP bez zmian).
- FEEL jest interpretowany, nie kompilowany do kodu; limity długości wyrażeń i rozmiaru schematu; limit rozmiaru żądania zapisu.
- W dzienniku: skrót treści i lista zmienionych pól, bez wartości wpisanych przez wykonawców (NFR-09).
- Klient techniczny Camunda dostaje jedno nowe uprawnienie: ewaluację wyrażeń (`EXPRESSION: EVALUATE`, wariant B1 z ADR-020 — do potwierdzenia w S08) — bez prawa wdrażania zasobów.

## 16. Testy

| Zakres | Gdzie |
| --- | --- |
| Cykl życia, R8, kontrakt, przypięcie | `specs/forms/form-lifecycle.feature` (FR-17, FR-18) |
| Camunda Forms, katalog pól, import i eksport | `specs/forms/form-designer.feature` (FR-28) |
| Wersje, porównanie, nowa wersja | `specs/forms/form-versioning.feature` (FR-29) |
| Wycofanie i przepięcie | `specs/forms/form-withdrawal.feature` (FR-30) |
| Separacja per proces | `specs/forms/form-isolation.feature` (FR-31) |
| Materializacja i walidacja na zadaniu | `specs/forms/form-rendering.feature` (FR-32, FR-06) |
| Zgodność z form-js | zestaw zgodności w `form-runtime` (NFR-14) |
| Spójność wizualna i dostępność pól | regresja wizualna i axe na katalogu komponentów (NFR-15) |

## 17. Plan wykonania modułu

Kroki modułu są częścią planu platformy (`plan/backlog.yaml`, opis: `plan/execution-plan.md`); tu zebrane w kolejności wykonania.

| Krok | Faza | Cel | Wykonawca | Zależy od | Wynik |
| --- | --- | --- | --- | --- | --- |
| S07 | 0 | PoC: edytor form-js w Angularze, renderer na design systemie kontra viewer, zestaw zgodności na formatkach wzorcowych | `frontend-developer` + `ux-designer` | S00 | raport, decyzja ADR-019 |
| S08 | 0 | PoC: reguły schematu w .NET, ewaluacja FEEL przez API klastra, różnice względem przeglądarki | `camunda-integrator` + `module-implementer` | S01 | raport, decyzja ADR-020 |
| S09 | 0 | Warstwa wizualna: biblioteka w Figma, tokeny, katalog pól, specyfikacje komponentów | `ux-designer` + projektant UX | S00 | `design/**` zatwierdzone |
| S16 | 1 | Shell, motyw z tokenów, `ui-kit`, katalog komponentów | `frontend-developer` + `design-system-engineer` | S15, S09 | `frontend/**` |
| S26 | 2 | Form Management: wersje, R8, R11, publikacja z kontraktem i katalogiem, wycofanie, import i eksport | `module-implementer` + `bdd-tester` | S15 (G1) | moduł `FormManagement` |
| S28 | 2 | Schemat `form`, unikalność i klucze per proces, historia przypięć | `data-engineer` | S13, S15 (G1) | migracje |
| S29 | 2 | Referencje `ph:form` i kontrakt danych z katalogu elementów, kontrola spójności, reguła `ph/form-reference` | `camunda-integrator` + `module-implementer` | S17, S23, S26 | powiązania, reguła bpmnlint |
| S37 | 3 | Form Runtime: schemat przypiętej wersji, walidacja poziomu A i B, przypięcie | `module-implementer` + `bdd-tester` | S26, S29, S08 (G1) | moduł `FormRuntime` |
| S39 | 3 | Wycofanie w toku: przepięcie zadań, zadania bez formatki, powiadomienia | `module-implementer` + `bdd-tester` | S28, S30, S37 | saga przepięcia |
| S49 | 4 | Komponenty pól w `ui-kit` wg katalogu pól, regresja wizualna, axe | `design-system-engineer` + `ui-reviewer` | S16, S07, S09 | `ui-kit`, `ui-catalog` |
| S40 | 4 | Skrzynka zadań i renderer formatek (`form-runtime`) | `frontend-developer` + `ui-reviewer` | S16, S30, S37, S49 | formatka na zadaniu |
| S45 | 4 | Projektant formatek (`form-designer`) | `frontend-developer` + `ui-reviewer` | S16, S26, S40 | projektant |
| S55 | 5 | Zestaw zgodności, schemat `.form`, parytet katalogu i regresja wizualna w CI | `frontend-developer` + `ui-reviewer` | S50 | bramki CI |

- **Bramka G1** wymaga raportów S07 i S08 (ADR-019 i ADR-020 ze statusem „Przyjęta”) oraz zatwierdzonej warstwy wizualnej (S09) — kontrakty modułu są zamrażane dopiero po tych decyzjach.
- **Zapas.** Łańcuch S23 → S29 → S37 → S40 → S45 → S50 ma ok. 2,6 dnia zapasu; po ścieżce krytycznej to najciaśniejsza część planu.
- **Otwarte decyzje:** D-12 (zakres reguły czterech oczu), D-13 (druga osoba przy wycofaniu), D-14 (domyślny skutek wycofania), D-15 (załączniki), D-16 (właściciel biblioteki w Figma) — `plan/execution-plan.md`.

