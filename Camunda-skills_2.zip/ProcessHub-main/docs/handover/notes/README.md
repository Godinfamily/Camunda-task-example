# Notes w innym modelu — konfiguracja do pracy na plikach Process Hub

Notes dostaje dwie rzeczy: źródła (pakiety plików repozytorium) i prompt kontekstowy (instrukcje stałe). Pakiety są w Markdownie, bo notesy często nie przyjmują plików YAML, JSON, .feature czy .py i ograniczają liczbę źródeł.

## Konfiguracja

1. **Źródła** — wgraj z `zrodla/`:
   - obowiązkowo `00-indeks.md` … `08-artefakty-i-podsumowanie.md` (9 plików, ok. 400 KB);
   - opcjonalnie `09-narzedzia-kod.md`, jeśli chcesz pytać o działanie skryptów;
   - opcjonalnie cztery dokumenty v1 z projektu jako tło historyczne (prompt wie, że są częściowo nieaktualne).
2. **Prompt kontekstowy** — wklej `prompt-kontekstowy-pelny.txt` (ok. 8 tys. znaków). Jeśli pole ma niższy limit, użyj `prompt-kontekstowy-krotki.txt` (ok. 1,4 tys. znaków).
3. **Test** — zadaj pytania kontrolne z tabeli niżej i sprawdź, czy odpowiedzi mają odwołania do ścieżek plików.

## Pytania kontrolne

| Pytanie | Dobra odpowiedź zawiera |
| --- | --- |
| Kto może zakończyć zadanie i gdzie to jest zapisane? | regułę R1, odwołanie do docs/architecture/02 i specs/tasks/claim-and-complete.feature |
| Co zespół profilu kredyty może zrobić sam, a co wymaga zgody platformy? | operacje, dane prj_kredyty, sloty i plan zespołu sam; zmiana profile.yaml i authorization.yaml — z architektem platformy; nowe punkty rozszerzeń — RFC (docs/architecture/13, profiles/README.md) |
| Którzy agenci mogą zapisywać w profiles/aml i na jakim modelu działają? | agenci aml-* z zapisem tylko w profiles/aml/** (i wnioskami RFC); jak wszyscy — model z profilu modeli w infrastrukturze banku (dziś GLM 5.3 Flash, wymienny — ADR-021), a klasa restricted wymaga przeglądu bezpieczeństwa (AGENTS.md, config/models.yaml, ADR-016) |
| Jak odświeżyć wycenę, gdy Python jest zablokowany? | `ph plan estimate`, `ph plan export`, `ph artifacts render` — wyniki identyczne z wersją Python (tools/dotnet/README.md) |
| Które kroki są na ścieżce krytycznej i co ją realnie skraca? | ścieżkę z plan/estimation.md, podział kroków krytycznych, brak efektu większego zespołu, kroki profili poza ścieżką |
| Jakie decyzje muszą zapaść przed startem i przed S19? | S-1…S-6 (w tym S-2: bramka modelu LLM w banku i wybór modelu) oraz D-08 i D-09 z tygodniami z rejestru dashboardu |
| Które założenia są jeszcze do weryfikacji i gdzie zostaną sprawdzone? | Z-10…Z-13, Z-17, Z-18, Z-28 z krokami S01–S04, S19, S27, S38, S10–S12 (docs/artifacts/03-zalozenia.md) |
| Streszczenie dla zarządu na jedną stronę. | wniosek, 27,6 / 30,8 tyg. wobec 38,3, 459 wobec 597 osobodni, 3 ryzyka, decyzje startowe |
| Jak dodać krok do planu profilu kredyty i po czym może ruszyć? | szkic i place_step.py --backlog profiles/kredyty/backlog.yaml, zależności z powodami, S47 dla frontendu, S27 dla backendu (skill backlog-extension) |
| Co trzeba zrobić, żeby agenci pracowali na Qwen 3.8 27B? | default_profile: qwen-self-hosted po weryfikacji pól [DO WERYFIKACJI], refresh.py, kwalifikacja E01–E11 (config/models.yaml, ADR-021, docs/agents/multi-model-guide.md) |

## Odświeżanie

Po każdej zmianie w repozytorium:

```bash
python3 tools/plan/estimate.py
python3 tools/plan/export_dashboard_data.py
python3 tools/artifacts/render_artifacts.py
python3 tools/handover/build_notebook_sources.py
# bez Pythona: ph plan estimate && ph plan export && ph artifacts render && ph notes build
```

Potem podmień źródła w notesie. Jeśli zmieniła się wycena, zaktualizuj też „Kontekst w pigułce” na końcu pełnego promptu.
