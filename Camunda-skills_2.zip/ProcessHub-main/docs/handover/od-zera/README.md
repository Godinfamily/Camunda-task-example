# Prompty „od zera” — odtworzenie repozytorium Process Hub w innym modelu

Model nie dostaje żadnych plików. Wszystko, czego potrzebuje (kontekst, wymagania, decyzje, profile projektów, tabele kroków, wyceny, rejestr ryzyk i decyzji, paleta UI), jest w treści promptów. Prompty P00–P15 odtwarzają wersję v3.2; prompt P16 nakłada na nią zmiany v4 (moduł zarządzania formatkami i warstwa wizualna), a P17 — zmiany v5 (plan gotowy do startu agentów, zaostrzony harness, prompty ról od zera, skille rozwoju platformy, automatyzacja, wymienny model LLM). Wynik P00–P15 to repozytorium v3.2: architektura z profilami projektów (w tym przykładowy profil `flota` z dedykowanymi elementami i operacją na danych profilu — ADR-017), przygotowanie środowiska, ADR-y, scenariusze BDD, plan wykonawczy, rój agentów w OpenCode z modelem w infrastrukturze banku, narzędzia w Pythonie i w .NET, makieta UI, wycena, dashboard i artefakty projektowe.

## Kolejność

| Plik | Co powstaje |
| --- | --- |
| `P00-instrukcje-stale.txt` | instrukcje stałe — wklej jako instrukcje projektu / systemowe albo jako pierwszą wiadomość |
| `P01-repozytorium-i-wymagania.txt` | README, AGENTS.md, słownik, przegląd, wymagania |
| `P02-uprawnienia-konteksty-domena.txt` | role i uprawnienia (R1–R10), YAML ról globalnych, mapa kontekstów, model domeny |
| `P03-rozwiazanie-camunda-dane-audyt.txt` | architektura rozwiązania z Extension Host, praktyki Camunda C1–C21, MSSQL ze schematami profili, audyt |
| `P04-etapy-dashboard-frontend-testy.txt` | mapa etapów, dashboard menadżera, frontend ze slotami profili, testy |
| `P04b-profile-projektow.txt` | profile projektów: dokument architektury, schemat manifestu z operacją na danych profilu, profile kredyty i aml, szablon, walidator z autotestem, CODEOWNERS |
| `P04c-profil-flota.txt` | profil przykładowy flota: procesy BPMN opiniowania rejestracji samochodu przez komórki IT, HR, Prawny, Finanse, Ryzyko, katalog samochodów w sekcji „Flota”, rola administratora katalogu, scenariusze, plan, RFC-FLO-03, przewodnik `docs/guides/dedykowane-elementy-profilu.md` |
| `P05-srodowisko-devops.txt` | środowisko Camunda 8.9 na Kubernetes, RHBK, bramka modelu LLM w banku, bazy profili |
| `P06-adr.txt` | ADR-001…017 |
| `P07-specyfikacje-bdd.txt` | świat testowy i scenariusze, w tym profile projektów |
| `P08-plan-wykonawczy.txt` | plan 49 kroków, backlog.yaml, szablon pakietu, plany zespołów profili |
| `P09-roj-agentow-opencode.txt` | rejestr ról, generator agentów OpenCode (platforma i profile), plugin strażnika zapisu (eksport `{ id, server, setup }` zgodny z obiema ładowarkami OpenCode) i strażnik, skille, komendy, skrypty kroków |
| `P09b-narzedzia-dotnet.txt` | te same narzędzia w C# (`ph`, .NET 10, C# 10, bez paczek NuGet), testy, kontrola zgodności z Pythonem |
| `P10-modele-glm-i-kwalifikacja.txt` | profile modeli na bramce banku (GLM 5.3 Flash obowiązujący, Qwen 3.8 27B, Gemma 4 31B), warianty rozumowania, polityka danych, kwalifikacja E01–E08, przewodnik, instrukcja startu z OpenCode |
| `P11-projekt-ui.txt` | propozycja projektowa i tokeny |
| `P12-makieta-html.txt` | klikalna makieta (z profilem Flota: katalog samochodów, wniosek, opinie komórek) |
| `P13-wycena.txt` | model wyceny, raport, wnioski |
| `P14-dashboard-harmonogramu.txt` | eksport danych i interaktywny dashboard działający z dysku |
| `P14b-artefakty-projektowe.txt` | plan systemu, aktorzy, założenia (Markdown i strona HTML) |
| `P15-spojnosc-i-paczka.txt` | kontrola spójności, podsumowanie, paczka |
| `P16-modul-formatek.txt` | v4: moduł zarządzania formatkami Camunda Forms (opis, ADR-018…020, scenariusze, R11), warstwa wizualna (katalog pól, tokeny, wytyczne UI), agenci `ux-designer`, `design-system-engineer`, `ui-reviewer`, 8 nowych kroków planu i przeliczona wycena |
| `P17-harness-agentow-i-automatyzacja.txt` | v5: backlog z polami `outcome`, `notes`, `refs`, `acceptance` i poprawionymi krokami; strażnik z RFC i kontrolą zmian niezatwierdzonych; rejestr ról z `writes` i `commands`, zestawy komend i zakazy; 15 promptów ról od zera w jednym układzie i sekcja „Fakty, nie domysły”; skille `new-profile`, `backlog-extension`, `project-artifacts`, `plan-maintenance`; narzędzia `validate_plan`, `place_step`, `validate_forms`, `refresh` w Pythonie i .NET; szablon profilu z pięcioma krokami i formatkami; wymienny model (ADR-021); artefakt `docs/artifacts/05-agenci.md` |

## Wskazówki

- Każdy plik wklejaj jako osobną wiadomość, po zakończeniu poprzedniego etapu. Gdy odpowiedź urwie się, napisz: „kontynuuj od pliku <ścieżka>, bez powtarzania wcześniejszych”.
- Najlepiej uruchomić model z narzędziem do plików i kodu — wtedy sam wykona walidacje z każdego etapu (parsery YAML, Gherkin, Mermaid, generatory, przeglądarka bezgłowa). Bez niego dostaniesz pliki w blokach kodu do zapisania ręcznie.
- Etapy 9b (narzędzia .NET), 12 (makieta), 14 (dashboard) i 14b (strona artefaktów) dają najdłuższe pliki; jeśli model ma krótki limit odpowiedzi, poproś o nie w częściach (np. CSS i znaczniki, potem skrypt).
- Etap 17 zmienia wiele istniejących plików — model powinien pokazywać zmienione fragmenty z nagłówkiem ścieżki; jeśli ma narzędzie do plików, sam uruchomi kontrolę z końca etapu (`refresh.py --check`, test pluginu, próby `place_step.py` i profilu `lizing`).
- Etap 13 zawiera oczekiwane wyniki modelu — to test, czy wycena została zaimplementowana tak samo.
- Etap 4c daje modele BPMN: pełną walidację (Zeebe 8.9 przez `zeebe-bpmn-model`, wyrażenia FEEL, bpmnlint z regułami camunda-compat) model wykona, jeśli ma Javę z Mavenem albo Node; bez nich sprawdź przynajmniej, że XML parsuje się i każdy element ma kształt w DI.
- Numeracja wymagań W-xx w instrukcjach stałych jest wewnętrzna dla tego zestawu; rejestr wymagań repozytorium to `docs/handover/podsumowanie.md`.
- `prompty-od-zera.md` zawiera wszystkie prompty w jednym pliku, w tej samej kolejności.
